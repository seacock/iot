/*
 * ^Common.h
 *
 *  Created on: 31 ott 2018
 *      Author: andre
 */

#ifndef COMMON_H_
#define COMMON_H_

#include <ti/sysbios/knl/Task.h>
#include <ti/display/Display.h>
#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/BIOS.h>

#define BOARD_PIN_RED_LED CC1310_LAUNCHXL_PIN_RLED
#define STACKSIZE 1024

Display_Handle display;
Task_Struct stRxRadioTask;
Void RxRadioTf(UArg arg0, UArg arg1);
void StartRxRadioTf(void);  //+++ Set up and start RxRadioTf task.

Void RxRadioQTf(UArg arg0, UArg arg1);
void StartRxRadioQTf(void);  //+++ Set up and start RxRadioTf task.

#endif /* COMMON_H_ */
