/*
 *  ======== ^Primary.c ========
 */

/* Driver Header files */
// #include <ti/drivers/I2C.h>
// #include <ti/drivers/SDSPI.h>
// #include <ti/drivers/SPI.h>
// #include <ti/drivers/UART.h>
// #include <ti/drivers/Watchdog.h>

#include <^Common.h>

void StartDisplayTf(void);

//+++ Dynamic pin configuration. Application pin configuration tables. For input isn't possible for now to declare a single array...
PIN_Config LedPinCfg[] = {
    BOARD_PIN_RED_LED | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
    BOARD_PIN_GREEN_LED | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
    PIN_TERMINATE
};

PIN_Config DInPinCfg[] = {
    CC1310_LAUNCHXL_DIO1 | PIN_INPUT_EN | PIN_PULLUP | PIN_IRQ_DIS,
    CC1310_LAUNCHXL_DIO21 | PIN_INPUT_EN | PIN_PULLUP | PIN_IRQ_NEGEDGE,
    CC1310_LAUNCHXL_DIO22 | PIN_INPUT_EN | PIN_PULLUP | PIN_IRQ_NEGEDGE,
    PIN_TERMINATE
};

PIN_State LedPinState, DInPinState;
Clock_Struct WireClock, ContinTimeoutClock, ContinHaltedClock; //+++ 1) Clock used for debounce logic. 2) Clock for blinking.

void WireClockCb(UArg arg)
{
    Clock_stop(WireClockH); //+++ .

    /* Check that there is active button for debounce logic*/
    if (ActiveWirePinId != PIN_TERMINATE)
    {
        /* Debounce logic, only toggle if the button is still pushed (low) */
        if (!PIN_getInputValue(ActiveWirePinId))
        {
            /* Toggle LED based on the button pressed */
            switch (ActiveWirePinId)
            {
            case CC1310_LAUNCHXL_DIO1:
                Semaphore_post(DisplaySemH);   //+++ Post to semaphore.//---
                break;
            case CC1310_LAUNCHXL_DIO21:
                PIN_setInterrupt(DInPinH, CC1310_LAUNCHXL_DIO22 | PIN_IRQ_DIS);//---
                StartRxRfCoTf();
                break;
            case CC1310_LAUNCHXL_DIO22:
                PIN_setInterrupt(DInPinH, CC1310_LAUNCHXL_DIO21 | PIN_IRQ_DIS);//---
                StartRxRfSsTf();
                break;
            default:
                /* Do nothing */
                break;
            }
        }
    }

    ActiveWirePinId = PIN_TERMINATE;    //+++ Set ActiveWirePinId to none...
}

void ContinTimeoutClockCb(UArg arg)
{
    Clock_start(ContinHaltedClockH);
    RF_flushCmd(rfHandle, RF_CMDHANDLE_FLUSH_ALL, 1);
    PIN_setOutputValue(LedPinH, BOARD_PIN_RED_LED, 0);    //+++ .//---

    PIN_setInterrupt(DInPinH, CC1310_LAUNCHXL_DIO21 | PIN_IRQ_NEGEDGE);
    PIN_setInterrupt(DInPinH, CC1310_LAUNCHXL_DIO1 | PIN_IRQ_NEGEDGE);//---
}

void ContinHaltedClockCb(UArg arg)
{
    PIN_setOutputValue(LedPinH, BOARD_PIN_GREEN_LED, !PIN_getOutputValue(BOARD_PIN_GREEN_LED)); //+++ Toggle pin to indicate .
}

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    /* Call driver init functions */
    //GPIO_init();
    // I2C_init();
    // SDSPI_init();
    // SPI_init();
    // UART_init();
    // Watchdog_init();

    LedPinH = PIN_open(&LedPinState, LedPinCfg);    //+++ Open pin configuration table.
    if (LedPinH == NULL)
        while(1);

    DInPinH = PIN_open(&DInPinState, DInPinCfg);    //+++ Open pin configuration table.
    if (DInPinH == NULL)
        while(1);

    PIN_registerIntCb(DInPinH, CC1310_LAUNCHXL_DIOCb);//---

    //+++ Semaphore initialization.
    Semaphore_Params_init(&DisplaySemParams);
    Semaphore_construct(&DisplaySemStruct, 0, &DisplaySemParams);
    DisplaySemH = Semaphore_handle(&DisplaySemStruct);

    /* Open Display Driver */
    Display_init(); //+++ Not necessary.
    Display_Params displayParams;
    Display_Params_init(&displayParams);
    DisplayH = Display_open(Display_Type_UART, NULL);

    StartDisplayTf();//---

    Clock_Params clockParams;
    Clock_Params_init(&clockParams);

    /* Construct clock for debounce */
    Clock_construct(&WireClock, WireClockCb, 0, &clockParams);
    WireClockH = Clock_handle(&WireClock);

    /* Construct clock for continuous receiving */
    Clock_construct(&ContinTimeoutClock, ContinTimeoutClockCb, 1000000, &clockParams);
    ContinTimeoutClockH = Clock_handle(&ContinTimeoutClock);

    /* Construct clock for signalling the end of continuous receiving */
    clockParams.period = 10000;
    Clock_construct(&ContinHaltedClock, ContinHaltedClockCb, 0, &clockParams);
    ContinHaltedClockH = Clock_handle(&ContinHaltedClock);

    while (1) {
    }
}
