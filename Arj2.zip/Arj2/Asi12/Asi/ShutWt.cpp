#include "stdafx.h"
#include "Asi.h"

void CloseHandleNull(HANDLE hHan);

DWORD WINAPI CloseConnectTp(LPVOID lpParam)
{
	theApp.ThrAffinity(13);
	Hook *pstHook = (Hook*)lpParam;
	CTabFour *pTabFour = pstHook->pTabFour;

	HANDLE ahKernelObj[3] = { pstHook->hConnectTp, pstHook->hI2cMaTxTp, pstHook->hI2cMaRxTp };
	DWORD dwWaitResult = WaitForMultipleObjects(ARRAY_SIZE(ahKernelObj), ahKernelObj, TRUE, INFINITE);
	switch (dwWaitResult)
	{
	case WAIT_OBJECT_0:
		CloseHandleNull(pstHook->hConnectTp);
		CloseHandleNull(pstHook->hI2cMaTxTp);
		CloseHandleNull(pstHook->hI2cMaRxTp);
		CloseHandleNull(pTabFour->hRbAdcEv);
		CloseHandleNull(pTabFour->hRbPwmEv);
		CloseHandleNull(pTabFour->hSliEv);
		CloseHandleNull(pTabFour->hI2cTestEv);
		break;
	}

	CloseHandleNull(pstHook->hI2cAuTxTp);
	CloseHandleNull(pstHook->hI2cAuRxTp);

	pstHook->pAsiDlg->PostMessageW(RG_WM_COMM_ABATED);	//+++ SendMessageW wouldn't fit.

	return NO_ERROR;
}

//+++ Examine exit code of a thread.
DWORD WINAPI ThreadExCoTp(LPVOID lpParam)
{
	theApp.ThrAffinity(13);
	Hook::ThreadExCo *pstThExCo = (Hook::ThreadExCo*)lpParam;
	DWORD dwExitCodeThread;
	DWORD dwWaitResult = WaitForSingleObject(pstThExCo->hThreadExCo, INFINITE);
	switch (dwWaitResult)
	{
	case WAIT_OBJECT_0:
		GetExitCodeThread(pstThExCo->hThreadExCo, &dwExitCodeThread);
		if (dwExitCodeThread == ERROR_COMM)
			pstThExCo->pAsiDlg->SendMessageW(RG_WM_PIC_LIGHT, RED_LIGHT);
		break;
	}

	return NO_ERROR;
}

void CloseHandleNull(HANDLE hHan)
{
	if (hHan)
	{
		CloseHandle(hHan);
		hHan = NULL;
	}
}