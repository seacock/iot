/*
 * ^Common.h
 *
 *  Created on: 21 gen 2019
 *      Author: andre
 */

#ifndef COMMON_H_
#define COMMON_H_

/***** Includes *****/
/* Standard C Libraries */
#include <stdlib.h>

/* TI Drivers */
#include <ti/drivers/rf/RF.h>
#include <ti/drivers/PIN.h>

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Semaphore.h>

/* Driverlib Header files */
#include DeviceFamily_constructPath(driverlib/rf_prop_mailbox.h)

/* Board Header files */
#include "Board.h"

/* Application Header files */
#include "RFQueue.h"
#include "smartrf_settings/smartrf_settings.h"

/***** Defines *****/
/* Packet RX/TX Configuration */
/* Max length byte the radio will accept */
#define PAYLOAD_LENGTH         30
/* Set Transmit (echo) delay to 100ms */
#define TX_DELAY             (uint32_t)(4000000*0.1f)
/* NOTE: Only two data entries supported at the moment */
#define NUM_DATA_ENTRIES       2

#define TIMESTAMP 4 //+++ 4 bytes length

/* The Data Entries data field will contain:
 * 1 Header byte (RF_cmdPropRx.rxConf.bIncludeHdr = 0x1)
 * Max 30 payload bytes
 * 1 status byte (RF_cmdPropRx.rxConf.bAppendStatus = 0x1)
 * 4 timestamp bytes (TIMESTAMP preprocessor)*/
#define NUM_APPENDED_BYTES     6	//+++ 1 Header byte + 1 status byte + 4 timestamp bytes

#define STACKSIZE 1024
#define BYTELENGTH 8
#define TWO_WAY_TIMESTAMP1 251    //+++ Ad libitum same as Tx.
#define TWO_WAY_TIMESTAMP2 252    //+++ Ad libitum same as Tx.
#define TWO_WAY_TIMESTAMP3 253    //+++ Ad libitum same as Tx.

/* Log radio events in the callback */
//#define LOG_RADIO_EVENTS

/***** Prototypes *****/
void TermStat(RF_EventMask terminationReason, uint32_t cmdStatus);  //+++ RF events and status of commands.
void StartTimestampRxTf(void);
void StartAbsolCmuTf(void);

/***** Variable declarations *****/
Semaphore_Handle sem;

/* Pin driver handle */
PIN_Handle ledPinHandle;
PIN_State ledPinState;

#endif /* COMMON_H_ */
