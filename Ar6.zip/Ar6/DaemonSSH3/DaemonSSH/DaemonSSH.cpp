#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

static void daemonize(void)
{
	pid_t pid, sid;
	int fd; 
	
	if (getppid() == 1)	//+++ Already a daemon.
		return;
	
	pid = fork();	//+++ Fork off the parent process.
	if (pid < 0)
		exit(EXIT_FAILURE);

	if (pid > 0) 
		exit(EXIT_SUCCESS);	//+++ Killing the Parent Process.

	//+++ At this point we are executing as the child process.
	
	sid = setsid();	//+++ Create a new SID for the child process.
	if (sid < 0) 
		exit(EXIT_FAILURE);
	
	if ((chdir("/")) < 0)	//+++ Change the current working directory.
		exit(EXIT_FAILURE);

	fd = open("/dev/null", O_RDWR, 0);

	if (fd != -1)
	{
		dup2(fd, STDIN_FILENO);
		dup2(fd, STDOUT_FILENO);
		dup2(fd, STDERR_FILENO);

		if (fd > 2)
			close(fd);
	}
		
	umask(027);	//+++ Resetting File Creation Mask.
}

int main(int argc, char *argv[])
{
	daemonize();

	system("/tmp/VisualGDB/e/VisualStudio2017/Projects/RaspberryPi2/RyS10/RyS/Debug/RyS");

	return 0;
}