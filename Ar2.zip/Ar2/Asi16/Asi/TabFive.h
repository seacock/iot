#pragma once

#define MAX_READ 300	//+++ Initial size for dynamic C-style array vector.

// CTabFive dialog

class CTabFive : public CDlgExBase 
{
	DECLARE_DYNAMIC(CTabFive)
public:
	CButton jbnWeb;
	int iBatch;
	struct WebTie
	{		
		HANDLE hT_Tomcat;	//+++ Handle to T_Tomcat.
		int iThreadNum;
		const char* pcHostName;
		const char* pcPortNumber;
		string srIO;
		wstring wsrTotOut, wsrError;
	} *pstWebTie;	//???A
	CTabFive(CWnd* pParent = NULL);   // standard constructor
	virtual ~CTabFive();
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedBnWeb();
	afx_msg void OnEnUpdateEdTWHos();
	afx_msg void OnBnClickedRbRemot3();
	afx_msg void OnBnClickedRbNoip();
// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_TAB_FIVE };
#endif
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	DECLARE_MESSAGE_MAP()
private:
	CEdit jedThrWebMon;
	CEdit jedThreadWebHostName;
	CButton jrbRemot3;
	int jrbRemoteSvrPort;
	string srHostName, srPortNumber;
	wstring wsrThrWebMon;
	LRESULT OnInputWeb(WPARAM wParam, LPARAM lParam);	//+++ .
	LRESULT OnEdTWeM(WPARAM wParam, LPARAM lParam);	//+++ Web thread.	
};

static UINT RG_WM_INPUT_WEB = RegisterWindowMessage(_T("INPUT CTRLS WEB THREAD"));
static UINT RG_WM_ED_T_WEM = RegisterWindowMessage(_T("EDIT WEB THREAD"));