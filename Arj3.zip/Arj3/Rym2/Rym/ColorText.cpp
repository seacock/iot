#include "ColorText.h"

string CColorText::SasrColor[7] = { _RED_, _GREEN_, _YELLOW_, _BLUE_, _MAGENTA_, _CYAN_, _WHITE_ };

CColorText::~CColorText()
{
}

CColorText::CColorText(int iColor)
{
	iColorText = iColor;
}

ostream& operator <<(ostream &os, const CColorText &obj)
{
	// TODO: insert return statement here
	os << obj.SasrColor[obj.iColorText] << obj.ss.str() << "\x1B[0m";
	return os;
}