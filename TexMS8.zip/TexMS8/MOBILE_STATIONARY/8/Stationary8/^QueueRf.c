/*
 * ^QueueRf.c
 *
 *  Created on: 18 nov 2018
 *      Author: andre
 */

#include <^QueueRf.h>

void ArrangeQueueRf(uint8_t *aucRxBuffer, dataQueue_t *queue, rfc_dataEntryGeneral_t **rxEntry)
{
    uint8_t ucCount;
    rfc_dataEntryGeneral_t *item = (rfc_dataEntryGeneral_t*)&aucRxBuffer[0];
    for (ucCount = 0; ucCount < QUEUE_RX; ucCount++)
    {
       item->config.type = DATA_ENTRY_TYPE_GEN;    //+++ General Data Entry.
       item->config.lenSz  = 0;    //+++ No length indicator byte in data.
       item->length = DATA_SECTION_SIZE;   //+++ Total length of data field.
       item->status = DATA_ENTRY_PENDING;  //+++ Pending - starting state.

       uint8_t pad = 4 - ((DATA_SECTION_SIZE + ENTRY_HEADER_SIZE) % 4);    //+++ Padding needed for 4-byte alignment.
       item->pNextEntry = ((uint8_t*)item) + ENTRY_HEADER_SIZE + DATA_SECTION_SIZE + pad;

       // Make circular Last.Next -> First
       if (ucCount == (QUEUE_RX - 1))
           item->pNextEntry = aucRxBuffer;// Close the circle for the last item

       item = (rfc_dataEntryGeneral_t*)item->pNextEntry;
    }

    /* Create Data Entry Queue and configure for circular aucRxBuffer Data Entries */
    queue->pCurrEntry = &aucRxBuffer[0];
    queue->pLastEntry = NULL;

    *rxEntry = (rfc_dataEntryGeneral_t*)queue->pCurrEntry;    //+++ Initialize read pointer to the first entry.
}
