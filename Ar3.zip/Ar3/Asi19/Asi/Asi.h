
// Asi.h : main header file for the PROJECT_NAME application
//

#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"		// main symbols
#include "ShaWa.h"

// CAsiApp:
// See Asi.cpp for the implementation of this class
//

class CAsiApp : public CWinApp
{
public:
	CAsiApp();
	wstring wsrOut;	//+++ Get affinity info about processor and main thread.
	Hook stHook; //+++ The one and only Hook structure.
	wstring ThrAffinity(DWORD_PTR dwThreadAffinityMask); //+++ Sets a processor affinity mask for the specified thread. CPU #3 (dwThreadAffinityMask = 8) is reserved for another purpose.
	int ErrWsaSock(wstring wsrMsg, bool bCleanup, SOCKET Socket = INVALID_SOCKET);//+++ Error message, WSA cleanup and socket closure.

// Overrides
public:
	virtual BOOL InitInstance();

// Implementation

	DECLARE_MESSAGE_MAP()
};

extern CAsiApp theApp;
