/* 
 * File:   Adc.h
 * Author: Administrator
 *
 * Created on 19 April 2018, 17:10
 */

#ifndef ADC_H
#define	ADC_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "ShaDe.h"
#include <stdbool.h>

//+++ FOUR_STEPS are the 4 calls Raspberry makes to retrieve one 16 bit word 
//+++ from Pic24: 2 calls for higher byte and 2 calls for lower byte. That's 
//+++ for each sensor with SPI. So ADC is able to compute the average between 
//+++ each FOUR_STEPS task: from the end of one FOUR_STEPS task and the 
//+++ beginning of next FOUR_STEPS task. If AVERAGE leads to an interval 
//+++ smaller than the one spanning from the last step with changing value 4->0 
//+++ and the first step with changing value 0->1 needed for each sensor called 
//+++ by Raspberry, then the average can complete. Otherways the average will 
//+++ overlap over more FOUR_STEPS tasks.
#define AVERAGE 100

int mainADcX(void);
void Timer2TypeA(void); //+++ 16-Bit Timer Using System Clock (internal instruction cycle).
void SetupADConverter(void);    //+++ Set up Analog to Digital converter.
void ZeroAve(int iCount);   //+++ Zero all variables for average.
void ZeroVal(int iCount);   //+++ Zero variable for last value.

#ifdef	__cplusplus
}
#endif

#endif	/* ADC_H */