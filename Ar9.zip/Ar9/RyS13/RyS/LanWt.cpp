#include "SharA.h"

extern CRy gRy;
extern CAff gAff;
extern CSpi gSpi;
extern CUart gUart;
extern CI2c gI2c;

void BtnIncDec(int iFdLas);  	//+++ Manage 2 push buttons.
int SrNonblockFlag(int iDesc, int iValue);   	//+++ Set, reset the O_NONBLOCK flag of iDesc.
void CloseFdErr(int iFd, const char* pcErr);   	//???
void SendValue(int iFdLas, int iValue, string srWho);    	//+++ Send value to laptop ASUS.
void WriteToServer(int iFdLas, const char* buf);  	//+++ Send data to laptop ASUS.

void* LanTp(void *arg)
{
	CColorText coltGreen(CColorText::GREEN);
	CRy::ThreadInfo *pstThrInf = (CRy::ThreadInfo*)arg;

	int iRes;
	switch (pstThrInf->iThreadNum)
	{
	case ONE:
		iRes = sched_setaffinity(0, sizeof(CRy::ThreadInfo::stSet1), &CRy::ThreadInfo::stSet1);
		break;
	case TWO:
		iRes = sched_setaffinity(0, sizeof(CRy::ThreadInfo::stSet2), &CRy::ThreadInfo::stSet2);
		break;
	case THREE:
		iRes = sched_setaffinity(0, sizeof(CRy::ThreadInfo::stSet2), &CRy::ThreadInfo::stSet2);
		break;
	case TEMPORARY:
		iRes = sched_setaffinity(0, sizeof(CRy::ThreadInfo::stSet1), &CRy::ThreadInfo::stSet1);
		break;
	}

	if (iRes == -1)
		handle_error_en(iRes, "sched_setaffinity");

	pthread_barrier_wait(&gRy.stPortHost.barrier5);

#ifdef _BRIEF_
	gAff.DisplayThreadSchedAttr(pstThrInf->pcInfoArg);
	cpu_set_t stSet;
	sched_getaffinity(0, sizeof(stSet), &stSet);
	for (int iCount = 0; iCount < 4; iCount++)
		if (CPU_ISSET_S(iCount, sizeof(stSet), &stSet))
		{
			coltGreen.ss << "affinity: " << iCount << endl;
			cout << coltGreen;
		}

#endif // _BRIEF_

	int iSock = gRy.SockAddrConn(gRy.stPortHost.srLANServerHost.c_str(), atoi(gRy.stPortHost.srLANServerPort.c_str()));
	int iOn = 1;  	//+++ Selector for socket options.//???
	if(SrNonblockFlag(iSock, iOn) < 0)	//+++ Set socket to be non-blocking. In fact, when gRy.enStateDevice is set to I2C_RY_EXIT or to I2C_RY_SHUT_COMM, Asi has already closed its connection and this write would block. This can have two effects: 1)this app gets stuck; 2)Asi can block when trying to terminate because not all the threads it is waiting for from here are terminated.
		CloseFdErr(iSock, "fcntl()");  //???

	bool bOnlyOneTime = false;
	
	//+++ Send data to the server.
	if(pstThrInf->iThreadNum == ONE)
	{
		WriteToServer(iSock, pstThrInf->pcInfoArg);

		while (gRy.enStateDevice != CRy::RyExit)
		{
			if (gRy.enStateDevice == CRy::LaptopDismiss && bOnlyOneTime == false)
			{
				close(iSock);  	//+++ This gets out from its endless loop, recv on laptop side (ReceiveFromMcTp).
				bOnlyOneTime = true;
			}
			BtnIncDec(iSock);
		}
		
		gUart.UartClose(gUart.iUartHandle);

		//+++ shutdown(SocketFD, ...) wouldn't do from this thread to WebServUartTp. Instead pthread_kill does, even if it forces action.
		//+++ This situation arises when Asi terminates, but WebServUartTp is still performing recv(), without possibility to be notified
		//+++ of end of operations. WebServUartTp could be notified by remote client Hjc of exit, but this is not useful here. I don't plan to
		//+++ allow a kind of superuser with a password to stop WebServUartTp.
		if (pthread_kill(gRy.pstThrInf[SERV_MIX_JC - 1].ulThread_id, SIGTERM) != 0)	//??????
			handle_error1("pthread_kill()");
	}
	else if(pstThrInf->iThreadNum == TWO)
	{
		gSpi.stPoten.srIdMsg = pstThrInf->pcInfoArg;
		gSpi.stPoten.uiDelay = 100;
		gSpi.stPoten.ucUpper = CMD_UB_P;
		gSpi.stPoten.ucLower = CMD_LB_P;
		gSpi.stPoten.srName = "Potentiometer";
		gSpi.stPoten.uiNumOfSpiCalls = 0;
		gSpi.stPoten.ulTotNumOfSpiCalls = 0;
		gSpi.stPoten.uiTomcatCounter = 0;
		gSpi.stPoten.uiLaptopCounter = 0;

		WriteToServer(iSock, gSpi.stPoten.srIdMsg.c_str());

		while (gRy.enStateDevice != CRy::RyExit)
		{
			//+++ Wait for genStateSpi STATE_Potentiometer.
			pthread_mutex_lock(&gSpi.stSync.mutexSpi);
			while (gSpi.stSync.enStateSpi != CSpi::STATE_Potentiometer)
				pthread_cond_wait(&gSpi.stSync.condPotentiometer, &gSpi.stSync.mutexSpi);
			pthread_mutex_unlock(&gSpi.stSync.mutexSpi);

			if (gRy.enStateDevice == CRy::LaptopDismiss && bOnlyOneTime == false)
			{
				close(iSock);  	//+++ This gets out from its endless loop, recv on laptop side (ReceiveFromMcTp).
				bOnlyOneTime = true;
			}

			gSpi.SpiMaster(iSock, gSpi.stPoten);   	//+++ Execute shared routine while thread THREE is waiting.

			//+++ Set genStateSpi to STATE_Thermometer and wake up thread THREE.
			pthread_mutex_lock(&gSpi.stSync.mutexSpi);
			gSpi.stSync.enStateSpi = CSpi::STATE_Thermometer;
			pthread_cond_signal(&gSpi.stSync.condThermometer);
			pthread_mutex_unlock(&gSpi.stSync.mutexSpi);
		}
	}
	else if(pstThrInf->iThreadNum == THREE)
	{
		gSpi.stThermo.srIdMsg = pstThrInf->pcInfoArg;
		gSpi.stThermo.uiDelay = 100;
		gSpi.stThermo.ucUpper = CMD_UB_T;
		gSpi.stThermo.ucLower = CMD_LB_T;
		gSpi.stThermo.srName = "Thermometer";
		gSpi.stThermo.uiNumOfSpiCalls = 0;
		gSpi.stThermo.ulTotNumOfSpiCalls = 0;
		gSpi.stThermo.uiTomcatCounter = 0;
		gSpi.stThermo.uiLaptopCounter = 0;

		WriteToServer(iSock, gSpi.stThermo.srIdMsg.c_str());

		while (gRy.enStateDevice != CRy::RyExit)
		{
			//+++ Wait for genStateSpi STATE_Thermometer.
			pthread_mutex_lock(&gSpi.stSync.mutexSpi);
			while (gSpi.stSync.enStateSpi != CSpi::STATE_Thermometer)
				pthread_cond_wait(&gSpi.stSync.condThermometer, &gSpi.stSync.mutexSpi);
			pthread_mutex_unlock(&gSpi.stSync.mutexSpi);

			if (gRy.enStateDevice == CRy::LaptopDismiss && bOnlyOneTime == false)
			{
				close(iSock);  	//+++ This gets out from its endless loop, recv on laptop side (ReceiveFromMcTp).
				bOnlyOneTime = true;
			}

			gSpi.SpiMaster(iSock, gSpi.stThermo);   	//+++ Execute shared routine while thread TWO is waiting.	

			//+++ Set genStateSpi to STATE_Potentiometer and wake up thread TWO.
			pthread_mutex_lock(&gSpi.stSync.mutexSpi);
			gSpi.stSync.enStateSpi = CSpi::STATE_Potentiometer;
			pthread_cond_signal(&gSpi.stSync.condPotentiometer);
			pthread_mutex_unlock(&gSpi.stSync.mutexSpi);
		}
	}
	else if(pstThrInf->iThreadNum == TEMPORARY)
	{
		//+++ Wait for enStateI2c STATE_On.
		pthread_mutex_lock(&gI2c.stSync.mutexI2c);
		while (gI2c.stSync.enStateI2c != CI2c::STATE_On)
			pthread_cond_wait(&gI2c.stSync.condI2c, &gI2c.stSync.mutexI2c);
		pthread_mutex_unlock(&gI2c.stSync.mutexI2c);

		//+++ Here I'm sending data to a receiver without a back confirmation: (local write)->(remote receive), without control of the stream. There isn't the certainty that a sequence of local write will produce the same sequence of remote receive. Instead it's possible that many local write compose a single remote receive if the remote buffer is big enough: this creates problems at receiver. It's better to send a single composite string and the receiver will break it up following instructions.
		string srDelim = "-_-_";
		string srComp = pstThrInf->pcInfoArg + srDelim + 
								to_string(gI2c.I2cMaster(gI2c.stSync.SiFdI2c, ADC_AVERAGE, INVALID_FD)) + srDelim + 
								to_string(gI2c.I2cMaster(gI2c.stSync.SiFdI2c, PWM_FUNCTION, INVALID_FD)) + srDelim + 
								gRy.stPortHost.srI2cServerPort + srDelim + 
								gRy.stPortHost.srRemSvrPortR3 + srDelim + 
								gRy.stPortHost.srRemSvrPortNi + srDelim;
		WriteToServer(iSock, srComp.c_str());
	}

	close(iSock);  	//+++ This gets out from its endless loop, recv on laptop side (ReceiveFromMcTp).

	return 0;
}

int SrNonblockFlag(int iDesc, int iValue)
{
	int iOldflags = fcntl(iDesc, F_GETFL, 0);
	if (iOldflags == -1)	//+++ If reading the flags failed, return error indication now.
		return - 1;

	//+++ Set just the flag we want to set.
	if(iValue != 0)
		iOldflags |= O_NONBLOCK;  	//+++ Set the O_NONBLOCK flag of iDesc.
	else
		iOldflags &= ~O_NONBLOCK;  	//+++ Reset the O_NONBLOCK flag of iDesc.

	return fcntl(iDesc, F_SETFL, iOldflags);  	//+++ Store modified flag word in the descriptor.
}

void BtnIncDec(int iFdLas)
{
	static int siCount = 0;
	if (gRy.enStateDevice == CRy::RyNormal)
	{
		if (digitalRead(SWITCH_INC) == HIGH)
		{
			SendValue(iFdLas, ++siCount, "Pushbutton");
			pthread_mutex_lock(&gUart.stSync.mutexUart);
			while (gUart.stSync.enStateUart != CUart::STATE_NeutralUart)
				pthread_cond_wait(&gUart.stSync.condLan, &gUart.stSync.mutexUart);			
			gUart.stSync.enStateUart = CUart::STATE_Lan;
			gUart.UartPic(gUart.iUartHandle, gUart.asrLocal, ARRAY_SIZE(gUart.asrLocal), iFdLas);
			gUart.stSync.enStateUart = CUart::STATE_NeutralUart;
			pthread_cond_signal(&gUart.stSync.condWebServUart);
			pthread_mutex_unlock(&gUart.stSync.mutexUart);
		}			
		else if (digitalRead(SWITCH_DEC) == HIGH)
			SendValue(iFdLas, --siCount, "Pushbutton");
	}	

	delay(DELAY);
}

void SendValue(int iFdLas, int iValue, string srWho)
{
	string srValue = "something to initialize";
	sprintf((char*)srValue.c_str(), "%d", iValue);
	srWho += srValue;

	WriteToServer(iFdLas, srWho.c_str());
}

void WriteToServer(int iFdLas, const char* pcBuf)
{
	int iBytes = write(iFdLas, pcBuf, strlen(pcBuf) + 1); 	//+++ +1 important or buffer gets dirty.
	if(iBytes < 0)
		handle_error_en(iBytes, "write");
	else if(iBytes == 0)
		handle_error("write()");
}

void CloseFdErr(int iFd, const char* pcErr)
{
	close(iFd);
	handle_error(pcErr);
}