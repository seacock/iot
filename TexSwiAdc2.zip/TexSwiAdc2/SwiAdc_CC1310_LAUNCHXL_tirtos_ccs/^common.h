/*
 * Common.h
 *
 *  Created on: 21 ott 2018
 *      Author: andre
 */

#ifndef COMMON_H_
#define COMMON_H_

#include <stdio.h>

#include <xdc/runtime/Error.h>
#include <xdc/runtime/System.h>


/* Board Header file */
#include "Board.h"

#include <ti/sysbios/BIOS.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>

/* BIOS module Headers */
#include <ti/sysbios/knl/Swi.h>
#include <ti/display/Display.h>
#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/knl/Task.h>

Display_Handle  displayHandle;
PIN_Handle hDynPin;
Semaphore_Handle hSemADC;   // Semaphore
Swi_Handle swi0Handle;
Task_Struct stADCTask;
Swi_Struct swi0Struct;  //+++ It can't be local or becomes ineffective as soon goes out of scope.
bool bHigh1, bHigh2;

#endif /* COMMON_H_ */
