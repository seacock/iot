#include <iostream>
#include <wiringPi.h>
#include <wiringSerial.h>

using namespace std;

#define CTS 5	//+++ Clear to send input.	wiringPi 5. Phisical GPIO 18. 
#define RTS 6	//+++ Request to send output. wiringPi 6. Phisical GPIO 22.

int main(int argc, char *argv[])
{
	char sz[] = "Hello, World!";	//Hover mouse over "sz" while debugging to see its contents
	cout << sz << endl;	//<================= Put a breakpoint here
	if (wiringPiSetup() == -1)//???
	{
		cout << "Unable to start wiringPi\n";
		return 1 ;
	}
	pinMode(CTS, INPUT);
	pinMode(RTS, OUTPUT);
	digitalWrite(RTS, HIGH); delay(5);
	int handle = serialOpen("/dev/ttyAMA0", 9600);
	if (handle == -1)
		cout << "bad handle" << endl;
	int data, aaa = 0;
	digitalWrite(RTS, HIGH); 
//	delay(1);
	digitalWrite(RTS, LOW); 
	delay(30);
	digitalWrite(RTS, HIGH); 
//	delay(1);
	while (aaa < 21)
	{
		data = serialGetchar(handle);
		cout << (char)data << endl;
		aaa++;
	}
	while (digitalRead(CTS) == 1);
	serialPutchar(handle, 51);
	
	return 0;
}