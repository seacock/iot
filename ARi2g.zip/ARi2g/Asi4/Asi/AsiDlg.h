// AsiDlg.h : header file
//

#pragma once

#include "TabFrame.h"
#include "afxwin.h"
#include <iostream>	//+++ For wstring.
#include <string>	//+++ For to_wstring.
#include <sstream>	//+++ For ostringstream.

using namespace std;	//+++ For wstring.

// CAsiDlg dialog
class CAsiDlg : public CDialogEx
{
// Construction
public:
	HANDLE hShutI2cMaTxEv, hShutI2cAuTxEv;	//+++ Events: shut communication; shut I2C test. Each event must be waited for by a distinct thread. If 2 worker threads wait for the same event at the same time, race condition happens.
	CAsiDlg(CWnd* pParent = NULL);	// standard constructor
	void ShutComm(bool bDispatchMsg);	//+++ Shut communication with RaspberryPi2 and exit from worker threads.

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ASI_DIALOG };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
private:
	CTabFrame jtabFrame;	//+++ Container of tabbed dialogs.
	CStatic jpicLight;
	HBITMAP hBmpGreen, hBmpRed, hBmpIndigo;
	LRESULT OnPicLight(WPARAM wParam, LPARAM lParam);	//+++ Signalling light.	
};

static UINT RG_WM_COMM_ABATED = RegisterWindowMessage(_T("COMMUNICATION ABATED"));
static UINT RG_WM_PIC_LIGHT = RegisterWindowMessage(_T("PICTURE_CTRL LIGHT"));
static UINT GREEN_LIGHT = 6000;	//+++ At present not used.
static UINT RED_LIGHT = 6001;
static UINT INDIGO_LIGHT = 6002;