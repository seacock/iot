#include "Ry.h"
#include "SharA.h"
#include "Aff.h"
#include "ColorText.h"

cpu_set_t CRy::ThreadInfo::stSet1, CRy::ThreadInfo::stSet2, CRy::ThreadInfo::stSet3;

CRy::CRy()
{	
}

CRy::~CRy()
{
}

void CRy::PoolThread(int iNumThreads)
{
	CreateThread(iNumThreads, afp);

	for (int iNum = 0; iNum < iNumThreads; iNum++)	//+++ Now join with each thread.
	{
		void *res;
		int iRes = pthread_join(pstThrInf[iNum].ulThread_id, &res);
		if (iRes != 0)
			handle_error_en(iRes, "pthread_join");
#ifdef _BRIEF_
		CColorText coltGreen(CColorText::GREEN);
		coltGreen.ss << "Thread " << iNum << " exiting with status :" << res << endl;
		cout << coltGreen;
#endif // _BRIEF_
	}

	delete[] pstThrInf;

#ifdef _BRIEF_
	CColorText coltGreen(CColorText::GREEN);
	coltGreen.ss << "Application exits." << endl;
	cout << coltGreen;
#endif // _BRIEF_		
}

void CRy::CreateThread(int iNThreads, void *(**ppStartRoutine)(void*))
{
	int iRes;
	pthread_attr_t unAttr;
	stUtil.pAff->ThreadAttr(unAttr);

	pstThrInf = new ThreadInfo[iNThreads];   	//+++ Allocate memory for pthread_create arguments.
	if(pstThrInf == NULL)
		handle_error1("new");

	pstThrInf[0].iThreadNum = TL_One;
//	pstThrInf[1].iThreadNum = TL_Two;

	for (int iNum = 0; iNum < iNThreads; iNum++)	//+++ Create all threads.
	{
		pstThrInf[iNum].pstUtil = &stUtil;

		//+++ The pthread_create call stores the thread ID into corresponding element of pstThrInf[].
		if(pstThrInf[iNum].iThreadNum == TL_One)
			iRes = pthread_create(&pstThrInf[iNum].ulThread_id, &unAttr, ppStartRoutine[0], &pstThrInf[iNum]);
//		else if(pstThrInf[iNum].iThreadNum == TL_Two)
//			iRes = pthread_create(&pstThrInf[iNum].ulThread_id, &unAttr, ppStartRoutine[0], &pstThrInf[iNum]);
		if (iRes != 0)
			handle_error_en(iRes, "pthread_create");
	}

	//+++ Destroy the thread attributes object, since it is no longer needed.
	iRes = pthread_attr_destroy(&unAttr);
	if (iRes != 0)
		handle_error_en(iRes, "pthread_attr_destroy");
}