#include "RyS.h"
#include "Uart.h" //??????

extern CUart gUart; //??????

void BtnIncDec(int iFdLas)
{
	static int siCount = 0;

	if (ModeComm::SiMode == I2C_RY_NORMAL)
	{
		if (digitalRead(SWITCH_INC) == HIGH)
		{
			SendValue(iFdLas, ++siCount, "Pushbutton");
			pthread_mutex_lock(&Uart::SmutexUart);
			while (Uart::SenStateUart != STATE_NeutralUart)
				pthread_cond_wait(&Uart::ScondSocTxRxUart, &Uart::SmutexUart);			
			Uart::SenStateUart = STATE_SocTxRxUart;
			gUart.UartPic(gUart.iUartHandle, gUart.asrLocal, ARRAY_SIZE(gUart.asrLocal), iFdLas);
			Uart::SenStateUart = STATE_NeutralUart;
			pthread_cond_signal(&Uart::ScondWebServUart);
			pthread_mutex_unlock(&Uart::SmutexUart);
		}			
		else if (digitalRead(SWITCH_DEC) == HIGH)
			SendValue(iFdLas, --siCount, "Pushbutton");
	}	

	delay(DELAY);
}

void SendValue(int iFdLas, int iValue, string srWho)
{
	string srValue = "something to initialize";
	sprintf((char*)srValue.c_str(), "%d", iValue);
	srWho += srValue;

	WriteToServer(iFdLas, srWho.c_str());
}

void WriteToServer(int iFdLas, const char* pcBuf)
{
	int iBytes = write(iFdLas, pcBuf, strlen(pcBuf) + 1);	//+++ +1 important or buffer gets dirty.
	if (iBytes < 0)
		handle_error_en(iBytes, "write");
	else if (iBytes == 0)
		handle_error("write()");
}

int SrNonblockFlag(int iDesc, int iValue)
{
	int iOldflags = fcntl(iDesc, F_GETFL, 0);
	if (iOldflags == -1)	//+++ If reading the flags failed, return error indication now.
		return -1;

	//+++ Set just the flag we want to set.
	if (iValue != 0)
		iOldflags |= O_NONBLOCK;	//+++ Set the O_NONBLOCK flag of iDesc.
	else
		iOldflags &= ~O_NONBLOCK;	//+++ Reset the O_NONBLOCK flag of iDesc.

	return fcntl(iDesc, F_SETFL, iOldflags);	//+++ Store modified flag word in the descriptor.
}

void TomcatSetUp(bool bCmd)
{
	if (bCmd == true)
	{
		system("touch /mnt/Hjc/potentiometer.txt");
		system("chmod 7777 /mnt/Hjc/potentiometer.txt");
		system("truncate /mnt/Hjc/potentiometer.txt --size 0");
		system("touch /mnt/Hjc/thermometer.txt");
		system("chmod 7777 /mnt/Hjc/thermometer.txt"); 
		system("truncate /mnt/Hjc/thermometer.txt --size 0");
		system("/home/pi/apache-tomcat-8.5.23/bin/startup.sh");
	}
	else
	{
		system("/home/pi/apache-tomcat-8.5.23/bin/shutdown.sh");
		system("rm /mnt/Hjc/potentiometer.txt");
		system("rm /mnt/Hjc/thermometer.txt");
	}
}

void LocalIpFromGoogle()
{
	FILE* fp;
	char *pcRes = new char[BUFLEN];
	fp = popen("ip route get 8.8.8.8 | awk '{print $NF; exit}'", "r");
	fread(pcRes, 1, BUFLEN, fp);
	fclose(fp);	
	ThreadInfo::SsrRes += pcRes;
	delete[] pcRes;
	ThreadInfo::SsrRes += "  a GNU C++ server from RaspberryPi2, is answering back. To read a line the Java client reader needs only to find a new - line escape character or it gets stuck.\nThe last word End_Of_Transmission of this message is used by Java client to stop listening.\nThat allows the GNU C++ server to wait for a new message.This server adds to the received message a 0 escape sequence to avoid a dirty buffer in case of bad transmission (full capacity filled) from client Java: it's anyway not critical.An exceptional note over the internet: I'm no more sure about the causes of disaster in previous step. It goes against my little knowledge of C++. Even now that I'm using classes in Raspberry the same problem arises. So I've found the cause: bad routine in Uart.cpp . In other words: telecommunications are ideal till they work fine. One must allow for problems in some elements of the chain and recover from them: reset Microchip with little button on MicrostickII and improve routine in Uart.cpp .Good: I'm tidying code and I'll explain, not here.EndOfTransmission\n";
} 