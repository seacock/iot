/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * @author andre
 */
public class TimerS {
    int iSec = 0;
    boolean bOrientation = false;
    Timer timer = new Timer();
    TimerTask timerTask = new TimerTask(){
        @Override
        public void run()
        {
            iSec++;
            System.out.println("Seconds passed: " + iSec); 
            bOrientation = true;
        }
    };
    public void Start(){
        timer.scheduleAtFixedRate(timerTask, 1000, 300);
    }
    public void Stop(){
        if (timer != null)
        {
            timer.cancel();
            timer = null;
        }
    }
    public int GetTime(){
        return iSec;
    }
    public void ResetTime(){
        iSec = 0;
    }
}
