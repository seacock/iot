#include "RyS.h"

#define SOCK_RCVTIME_SEC 1	//+++ sec.
#define BROAD_ATTEMPTS 30

void* BroadTp(void *arg)
{
	ThreadInfo *pstThrInf = (ThreadInfo*)arg;
#ifdef _BRIEF_
	DisplayThreadSchedAttr(pstThrInf->pcInfoArg);
	cpu_set_t stSet;

	sched_getaffinity(0, sizeof(stSet), &stSet);
	for (int iCount = 0; iCount < 4; iCount++)
		if ( CPU_ISSET_S(iCount, sizeof(stSet), &stSet) )
			cout << "affinity: " << iCount << endl << endl;
#endif // _BRIEF_

	int iSocket;
	if ((iSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == INVALID_SOCKET)
		handle_error("socket()");

	int iBroadcastOpt;
	socklen_t optLen = sizeof(iBroadcastOpt);
#ifdef _TALKATIVE_
	if (getsockopt(iSocket, SOL_SOCKET, SO_BROADCAST, &iBroadcastOpt, &optLen) == -1)
		handle_error("getsockopt()");
	else
		cout << "SO_BROADCAST : " << iBroadcastOpt << endl;
#endif // _TALKATIVE_
	iBroadcastOpt = 1;
	if (setsockopt(iSocket, SOL_SOCKET, SO_BROADCAST, &iBroadcastOpt, optLen) == -1)
		handle_error("setsockopt()");
#ifdef _BRIEF_
	if (getsockopt(iSocket, SOL_SOCKET, SO_BROADCAST, &iBroadcastOpt, &optLen) == -1)
		handle_error("getsockopt()");
	else
		cout << "SO_BROADCAST : " << iBroadcastOpt << endl << endl;
#endif // _BRIEF_

	sockaddr_in stSaiOther;
	int iLenOther = sizeof(stSaiOther), iNumAtt;

	//+++ Zero struct and fill in its members.
	memset((char*)&stSaiOther, 0, sizeof(stSaiOther));
	stSaiOther.sin_family = AF_INET;
	stSaiOther.sin_port = htons(PORT);
	if (inet_aton(Wlan0Inet4::SacBroadcastAddr, &stSaiOther.sin_addr) == 0)
		handle_error1("inet_aton() failed\n");

	char acRecvFrom[BUFLEN], acSendTo[BUFLEN] = "RaspberryPi is broadcasting.\n";

	timeval tv;
	socklen_t lenTV = sizeof(tv);
	tv.tv_sec = SOCK_RCVTIME_SEC;
	tv.tv_usec = 0;
	if (setsockopt(iSocket, SOL_SOCKET, SO_RCVTIMEO, &tv, lenTV) == -1)	//+++ Blocking socket with timeout.
		handle_error("setsockopt()");
#ifdef _BRIEF_
	if (getsockopt(iSocket, SOL_SOCKET, SO_RCVTIMEO, &tv, &lenTV) == -1)
		handle_error("getsockopt()");
	else
		cout << "SO_RCVTIMEO : " << tv.tv_sec * 1000 * 1000 + tv.tv_usec << " micros" << endl << endl;
#endif // _BRIEF_

	memset(acRecvFrom, '\0', BUFLEN);	//+++ Important: clear the buffer by filling null, it might have previously received data.
	for (iNumAtt = 0; iNumAtt < BROAD_ATTEMPTS; iNumAtt++)
	{		
		if (sendto(iSocket, acSendTo, strlen(acSendTo), 0, (sockaddr*)&stSaiOther, iLenOther) == -1)
			handle_error("sendto()");

		if (recvfrom(iSocket, acRecvFrom, BUFLEN, 0, (sockaddr*)&stSaiOther, (socklen_t*)&iLenOther) <= 0)	//+++ It must use BUFLEN as buffer length is 0.
		{
			if (iNumAtt == BROAD_ATTEMPTS - 1)
				handle_error("recvfrom()");
			else
				continue;
		}			

		if (strstr(acRecvFrom, "Laptop ASUS answering to Raspberry's broadcast.") != NULL)	//+++ Greeting from Laptop ASUS to match.
			break;
		else
		{
			if (iNumAtt == BROAD_ATTEMPTS - 1)
				handle_error("recvfrom()");
		}
	}	

	//+++ Print details of the server/peer and the data received.
	string srRecvFrom(acRecvFrom);
	basic_string <char>::size_type indexStart, indexEnd;
	indexStart = srRecvFrom.find_first_of("*", 0);
	indexEnd = srRecvFrom.find_first_of("*", indexStart + 1);
	ThreadInfo::SsrLANServerPort = srRecvFrom.substr(indexStart + 1, indexEnd - indexStart - 1);
	char acHost[NI_MAXHOST], acService[NI_MAXSERV];	
	getnameinfo((struct sockaddr*)&stSaiOther, iLenOther, acHost, NI_MAXHOST, acService, NI_MAXSERV, NI_NUMERICSERV);
	ThreadInfo::SsrLANServerHost = acHost; 	//+++ See SockAddrConn declaration.
	cout << "Nr " << iNumAtt + 1 << " attempts.\tReceived packet from\t" << ThreadInfo::SsrLANServerHost.c_str() << ":" << acService << endl;
	puts(acRecvFrom);

	close(iSocket);

	pthread_barrier_wait(&ThreadInfo::Sbarrier5);
	pthread_barrier_destroy(&ThreadInfo::Sbarrier5);

	return SUCCESS;
}

void InterfacesIp()
{	
#define IFF_BROADCAST 0x2
	struct ifaddrs *pstIfAddr = NULL, *pstIfA = NULL;
	void *pTempor = NULL;
	
	//+++ Create a linked list of structures describing the network interfaces of this system.
	if (getifaddrs(&pstIfAddr) == -1)
		handle_error("getifaddrs()");
	    
	for (pstIfA = pstIfAddr; pstIfA != NULL; pstIfA = pstIfA->ifa_next)
	{
		if ((pstIfA->ifa_addr->sa_family == AF_INET) && (!strcmp(pstIfA->ifa_name, "wlan0")))
		{
			pTempor = &((struct sockaddr_in*)pstIfA->ifa_addr)->sin_addr;
			inet_ntop(pstIfA->ifa_addr->sa_family, pTempor, Wlan0Inet4::SacInternetAddress, INET_ADDRSTRLEN);     	//+++ Internet Address.

			strcpy(Wlan0Inet4::SacLineDescription, pstIfA->ifa_name);    	//+++ LineDescription.

			if ((pstIfA->ifa_netmask != NULL) && (pstIfA->ifa_netmask->sa_family == AF_INET))
			{
				pTempor = &((struct sockaddr_in*)pstIfA->ifa_netmask)->sin_addr;
				inet_ntop(pstIfA->ifa_netmask->sa_family, pTempor, Wlan0Inet4::SacNetmask, INET_ADDRSTRLEN);    	//+++ Netmask.
			}
			if ((pstIfA->ifa_flags & IFF_BROADCAST) && (pstIfA->ifa_ifu.ifu_broadaddr != NULL) && (pstIfA->ifa_ifu.ifu_broadaddr->sa_family == AF_INET))	
			{
				pTempor = &((struct sockaddr_in*)pstIfA->ifa_ifu.ifu_broadaddr)->sin_addr;
				inet_ntop(pstIfA->ifa_ifu.ifu_broadaddr->sa_family, pTempor, Wlan0Inet4::SacBroadcastAddr, INET_ADDRSTRLEN);    	//+++ Broadcast Addr.
			}
		}
	}

	freeifaddrs(pstIfAddr); /* free the dynamic memory */
	pstIfAddr = NULL; /* prevent use after free  */	
}