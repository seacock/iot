/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/* 
 * File:   
 * Author: MeMyselfAndI
 * Comments:
 * Revision history: 
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef XC_HEADER_TEMPLATE_H
#define	XC_HEADER_TEMPLATE_H

#include <xc.h> // include processor files - each processor file is guarded.  

// TODO Insert appropriate #include <>
#include "ShaDe.h"
#include <PPS.h>    //+++ For PPSUnLock and similar.

// TODO Insert C++ class definitions if appropriate

// TODO Insert declarations

// Comment a function and leverage automatic documentation with slash star star
/**
    <p><b>Function prototype:</b></p>
  
    <p><b>Summary:</b></p>

    <p><b>Description:</b></p>

    <p><b>Precondition:</b></p>

    <p><b>Parameters:</b></p>

    <p><b>Returns:</b></p>

    <p><b>Example:</b></p>
    <code>
 
    </code>

    <p><b>Remarks:</b></p>
 */
// TODO Insert declarations or function prototypes (right here) to leverage 
// live documentation
#if __XC16_VERSION__ >= 0x0401
#undef _ISR
#define _ISR __attribute__((interrupt, auto_psv))
#endif

#define INPUT_PIN 1

//+++ Conversion is so fast that, while Raspberry asks for upper byte of xxx 
//+++ couple, AD converter can perform many other conversions or present many
//+++ other couples. So, by the time Raspberry asks for lower byte of xxx 
//+++ couple, xxx couple has been replaced by another. This requires to freeze 
//+++ upper and lower bytes for 4 steps.
#define FOUR_STEPS 4
                        
//+++ Commands from Raspberry to retrieve AD converted physical quantities.
#define CMD_UB_P 0x01   //+++ Upper byte of potentiometer. Defined in Ry, Mip.
#define CMD_LB_P 0x02   //+++ Lower byte of potentiometer. Defined in Ry, Mip.
#define CMD_UB_T 0x04   //+++ Upper byte of thermometer. Defined in Ry, Mip.
#define CMD_LB_T 0x05   //+++ Lower byte of thermometer. Defined in Ry, Mip.
#define CMD_UB_RS 0x06   //+++ Upper byte of SPI resets. Defined in Ry, Mip.
#define CMD_LB_RS 0x07   //+++ Lower byte of SPI resets. Defined in Ry, Mip.

extern unsigned char guchUB[2], guchLB[2], guchUpdate[2], 
                            guchUBAveF[2], guchLBAveF[2], guchUpdateAve[2];
extern unsigned int guiSpiReset;
    
int mainSPIsX(void);
void ConfigSpiPortPins(void);   //+++ Configure port pins for SPI.
void ConfigSpiPPS(void);    //+++ Peripheral Pin Select for SPI.
void SetupSpi(void);    //+++ Set up Serial Peripheral Interface.
void ResetSpi(void);
void ZeroAve(int iCount);   //+++ Zero all variables for average.
void ZeroVal(int iCount);   //+++ Zero variable for last value.

#ifdef	__cplusplus
extern "C" {
#endif /* __cplusplus */

    // TODO If C++ is being used, regular C code needs function names to have C 
    // linkage so the functions can be used by the c code. 

#ifdef	__cplusplus
}
#endif /* __cplusplus */

#endif	/* XC_HEADER_TEMPLATE_H */