#pragma once

#include "AsiDlg.h"
#include "DlgExBase.h"
#include "TabOne.h"
#include "TabTwo.h"
#include "TabThree.h"
#include "TabFour.h"
#include "TabFive.h"

#define ERROR_COMM 5
#define ERROR_CLIENT_SIDE 4
#define NUM_WEB_THREADS 50
#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))
#define BUFLEN 512  //+++ Max length of buffer.
#define NUM_TEC 3
#define SERVER_SIDE 1000
#define CLIENT_SIDE 2000

//+++ It's elements are needed throughout application.
struct Hook
{
	CAsiDlg *pAsiDlg;	//+++ Pointer to parent dialog.

	//+++ Pointers to tabbed dialog pages.
	CTabOne *pTabOne;
	CTabTwo *pTabTwo;
	CTabThree *pTabThree;
	CTabFour *pTabFour;
	CTabFive *pTabFive;
	
	//+++ One structure for each socket. One socket for each remote thread. Each thread needs its own set of variables to communicate. Local copies or references expire when thread exits and Postmessage delays. Global strings, if any, need CRITICAL_SECTION.
	struct Channel
	{
		Hook *pHook;
		SOCKET AcceptSocket;	//+++ Socket of RaspberryPi2 client.
		wstring wsrRemoteThread, wsrMonitor;	//+++ Remote thread name; total/partial string received from RaspberryPi2 client.
		CDialogEx *pTabbDlg;	//+++ Pointer to dialog associated with this socket.
		UINT uiWmEdMonitor, uiWmEdValue, uiWmProgress;	//+++ WMsg for: Edit ctrl monitor; Edit ctrl value; Progress ctrl.
	} astChann[NUM_SOCKETS];	//+++ Array of structures for remote threads.	
	
	HANDLE ahT_Receive[NUM_SOCKETS];	//+++ Array of handles to T_Receive.
	HANDLE hT_Broad;	//+++ Handle to T_Broad.
	HANDLE hT_Connect;	//+++ Handle to T_Connect.
	HANDLE hT_Shell;	//+++ Handle to T_Shell.
	HANDLE hT_RyExit;	//+++ Handle to T_RyExit.	
	HANDLE hT_ShutComm;	//+++ Handle to T_ShutComm.	
	HANDLE hT_I2cMaTx;	//+++ Handle to T_I2cMaTx.	
	HANDLE hT_I2cMaRx;	//+++ Handle to T_I2cMaRx.
	HANDLE hT_I2cAuTx;	//+++ Handle to T_I2cAuTx.
	HANDLE hT_I2cAuRx;	//+++ Handle to T_I2cAuRx.

	int iShutAndWait;//???

	//+++ Argument for T_ThreadExCo.
	struct ThreadExCo
	{
		CAsiDlg *pAsiDlg;	//+++ Pointer to parent dialog.
		HANDLE hThreadExCo;	//+++ Handle to thread whose exit code needs to be examined.
	} astThreadExCo[NUM_TEC];	//+++ For threads: T_Connect, T_I2cMaRx, T_I2cAuRx.

	struct ServerI2C
	{
		char acIP[BUFLEN];
		char acPort[BUFLEN];
		char acWebPortR3[BUFLEN];
		char acWebPortNi[BUFLEN];
	} stServerI2c;
	SOCKET SockManual, SockAutom;
};

wstring StToWsUtf8(const string &str);
string WsToStUtf8(const wstring &wstr);