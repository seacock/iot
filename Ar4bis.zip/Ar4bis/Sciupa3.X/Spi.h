/* 
 * File:   Spi.h
 * Author: Administrator
 *
 * Created on 19 April 2018, 17:20
 */

#ifndef SPI_H
#define	SPI_H

#ifdef	__cplusplus
extern "C" {
#endif

//+++ Conversion is so fast that, while Raspberry asks for upper byte of xxx 
//+++ couple, AD converter can perform many other conversions or present many
//+++ other couples. So, by the time Raspberry asks for lower byte of xxx 
//+++ couple, xxx couple has been replaced by another. This requires to freeze 
//+++ upper and lower bytes for 4 steps.
#define FOUR_STEPS 4
                        
//+++ Commands from Raspberry to retrieve AD converted physical quantities.
#define CMD_UB_P 0x01   //+++ Upper byte of potentiometer. Defined in Ry, Mip.
#define CMD_LB_P 0x02   //+++ Lower byte of potentiometer. Defined in Ry, Mip.
#define CMD_UB_T 0x04   //+++ Upper byte of thermometer. Defined in Ry, Mip.
#define CMD_LB_T 0x05   //+++ Lower byte of thermometer. Defined in Ry, Mip.
#define CMD_UB_RS 0x06   //+++ Upper byte of SPI resets. Defined in Ry, Mip.
#define CMD_LB_RS 0x07   //+++ Lower byte of SPI resets. Defined in Ry, Mip.
    
int mainSPIsX(void);
void ConfigSpiPortPins(void);   //+++ Configure port pins for SPI.
void ConfigSpiPPS(void);    //+++ Peripheral Pin Select for SPI.
void Timer3TypeA(void); //+++ 16-Bit Timer Using System Clock (internal instruction cycle).
void SetupSpi(void);    //+++ Set up Serial Peripheral Interface.
void ResetSpi(void);
void ZeroAve(int iCount);   //+++ Zero all variables for average.
void ZeroVal(int iCount);   //+++ Zero variable for last value.

#ifdef	__cplusplus
}
#endif

#endif	/* SPI_H */