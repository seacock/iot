// CustEdit.cpp : implementation file
//

#include "stdafx.h"
#include "Asi.h"
#include "CustEdit.h"

// CCustEdit

IMPLEMENT_DYNAMIC(CCustEdit, CEdit)

CCustEdit::CCustEdit()
{
	bChangeBkgnd = false;
	clrText = RGB(0, 0, 100);
	clrBkgnd = RGB(255, 255, 180);
	brBkgnd.CreateSolidBrush(clrBkgnd);
}

CCustEdit::~CCustEdit()
{
}

BEGIN_MESSAGE_MAP(CCustEdit, CEdit)
	ON_WM_CTLCOLOR_REFLECT()
END_MESSAGE_MAP()

// CCustEdit message handlers

HBRUSH CCustEdit::CtlColor(CDC* pDC, UINT /*nCtlColor*/)
{
	// TODO:  Change any attributes of the DC here
	pDC->SetTextColor(clrText);
	if (bChangeBkgnd == true)
	{
		pDC->SetBkColor(clrBkgnd);
		return brBkgnd;            // ctl bkgnd  
	}

	// TODO:  Return a non-NULL brush if the parent's handler should not be called
	return NULL;
}
