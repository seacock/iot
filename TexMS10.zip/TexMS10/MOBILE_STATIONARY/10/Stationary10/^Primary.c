/*
 * Copyright (c) 2015-2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== ^Primary.c ========
 */

/* Driver Header files */
// #include <ti/drivers/I2C.h>
// #include <ti/drivers/SDSPI.h>
// #include <ti/drivers/SPI.h>
// #include <ti/drivers/UART.h>
// #include <ti/drivers/Watchdog.h>

#include <^Common.h>

//+++ Dynamic pin configuration. Application pin configuration tables.
PIN_Config LedPinCfg[] = {
    BOARD_PIN_RED_LED | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
    BOARD_PIN_GREEN_LED | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
    PIN_TERMINATE
};
PIN_Config InputPinCfg[] = {
    CC1310_LAUNCHXL_DIO12 | PIN_INPUT_EN | PIN_PULLUP | PIN_IRQ_DIS,
    PIN_TERMINATE
};
PIN_Config ButtonPinCfg[] = {
    Board_PIN_BUTTON0 | PIN_INPUT_EN | PIN_PULLUP | PIN_IRQ_NEGEDGE,
    PIN_TERMINATE
};

PIN_State LedPinState, InputPinState, ButtonPinState;

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    /* Call driver init functions */
    //GPIO_init();
    // I2C_init();
    // SDSPI_init();
    // SPI_init();
    // UART_init();
    // Watchdog_init();

    LedPinH = PIN_open(&LedPinState, LedPinCfg);    //+++ Open pin configuration table.
    if (LedPinH == NULL)
        while(1);

    PIN_setOutputValue(LedPinH, BOARD_PIN_GREEN_LED, !PIN_getOutputValue(BOARD_PIN_GREEN_LED)); //+++ Toggle pin to indicate TX.

    InputPinH = PIN_open(&InputPinState, InputPinCfg);    //+++ Open pin configuration table.
    if (InputPinH == NULL)
        while(1);

    PIN_registerIntCb(InputPinH, CC1310_LAUNCHXL_DIO12Cb);//---
    PIN_setInterrupt(InputPinH, CC1310_LAUNCHXL_DIO12 | PIN_IRQ_DIS);//---

    ButtonPinH = PIN_open(&ButtonPinState, ButtonPinCfg);    //+++ Open pin configuration table.
    if (ButtonPinH == NULL)
        while(1);

    PIN_registerIntCb(ButtonPinH, Board_PIN_BUTTON0Cb);//---
    PIN_setInterrupt(ButtonPinH, Board_PIN_BUTTON0 | PIN_IRQ_NEGEDGE);//---

    /* Open Display Driver */
    Display_init(); //+++ Not necessary.
    Display_Params displayParams;
    Display_Params_init(&displayParams);
    DisplayH = Display_open(Display_Type_UART, NULL);

    while (1) {
    }
}

void Board_PIN_BUTTON0Cb(PIN_Handle handle, PIN_Id pinId)
{
    //+++ Debounce logic.
    CPUdelay(1000);
    if (PIN_getInputValue(Board_PIN_BUTTON0) == 0)
        StartRxRadioTf();
}
