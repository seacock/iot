/*
 * ^clock.c
 *
 *  Created on: 25 ott 2018
 *      Author: andre
 */

#include <^common.h>
#include <ti/sysbios/knl/Clock.h>

Void ClockAdc(UArg arg0)
{
    Semaphore_post(hSemADC);   //+++ Post to semaphore.
    Event_post(hEvnGeneric, Event_Id_03);   //+++ Post to event.
    Hwi_post(5);
}

void StartClockAdc(void)
{
    Clock_Params clockParams;
    Error_Block eb;
    Error_init(&eb);
    Clock_Params_init(&clockParams);
    clockParams.period = 30;
    clockParams.startFlag = TRUE;
    clockParams.arg = (UArg)0x1111;
    Clock_Handle hClock = Clock_create(ClockAdc, 5, &clockParams, &eb);
    if (hClock == NULL)
        System_abort("Clock create failed");
}

Void ClockSwi(UArg arg0)
{
    Swi_post(hSwiOne);
    bDIO21 = !bDIO21;
    PIN_setOutputValue(hDynPin, CC1310_LAUNCHXL_DIO21, bDIO21);
}

void StartClockSwi(void)
{
    Clock_Params clockParams;
    Error_Block eb;
    Error_init(&eb);
    Clock_Params_init(&clockParams);
    clockParams.period = 1000;
    clockParams.startFlag = TRUE;
    clockParams.arg = (UArg)0x2222;
    Clock_Handle hClock = Clock_create(ClockSwi, 5, &clockParams, &eb);
    if (hClock == NULL)
        System_abort("Clock create failed");
}

Void ClockGeneric(UArg arg0)
{
    Event_post(hEvnGeneric, Event_Id_08);   //+++ Post to event.
}

void StartClockGeneric(void)
{
    Clock_Params clockParams;
    Error_Block eb;
    Error_init(&eb);
    Clock_Params_init(&clockParams);
    clockParams.period = 500;
    clockParams.startFlag = TRUE;
    clockParams.arg = (UArg)0x3333;
    Clock_Handle hClock = Clock_create(ClockGeneric, 5, &clockParams, &eb);
    if (hClock == NULL)
        System_abort("Clock create failed");
}
