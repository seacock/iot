/*
 * ^swi.c
 *
 *  Created on: 25 ott 2018
 *      Author: andre
 */

/*
 *  ======== ZeroSwf =======
 */

#include <^common.h>
#include <^swi.h>

Void ZeroSwf(UArg arg0, UArg arg1)
{
//    bDIO12 = !bDIO12;
//    PIN_setOutputValue(hDynPin, CC1310_LAUNCHXL_DIO12, bDIO12);
    static uint16_t uiCycle = 0;
    uiCycle++;
    if (uiCycle == 4000) {
        GPIO_toggle(Board_GPIO_LED1);
        sprintf(a2cSwiInfo[0], "\n%d cycles", uiCycle);
        sprintf(a2cSwiInfo[1], "Enter ZeroSwf, a0 = %d, a1 = %d", (Int)arg0, (Int)arg1);
        sprintf(a2cSwiInfo[2], "ZeroSwf trigger = %d", Swi_getTrigger());
        sprintf(a2cSwiInfo[3], "ZeroSwf pri = %d", Swi_getPri(hSwiZero));
        sprintf(a2cSwiInfo[4], "Exit ZeroSwf\n");
        uiCycle = 0;
    }
    int iBurst;
    for (iBurst = 0; iBurst < 50; iBurst++)
    {
        bDIO12 = !bDIO12;
        PIN_setOutputValue(hDynPin, CC1310_LAUNCHXL_DIO12, bDIO12);
    }
}

void StartZeroSwf(void)
{
    Swi_Params swiParams;
    Swi_Params_init(&swiParams);
    swiParams.arg0 = 1;
    swiParams.arg1 = 0;
    swiParams.priority = 2;
    swiParams.trigger = 3;

    Swi_construct(&stZeroSwi, (Swi_FuncPtr)ZeroSwf, &swiParams, NULL);
    hSwiZero = Swi_handle(&stZeroSwi);
}

Void OneSwf(UArg arg0, UArg arg1)
{
    static uint16_t uiCycle = 0;
    uiCycle++;
    if (uiCycle == 4000) {
        GPIO_toggle(Board_GPIO_LED1);
        sprintf(a2cSwiInfo[0], "\n%d cycles", uiCycle);
        sprintf(a2cSwiInfo[1], "Enter OneSwf, a0 = %d, a1 = %d", (Int)arg0, (Int)arg1);
        sprintf(a2cSwiInfo[2], "OneSwf trigger = %d", Swi_getTrigger());
        sprintf(a2cSwiInfo[3], "OneSwf pri = %d", Swi_getPri(hSwiOne));
        sprintf(a2cSwiInfo[4], "Exit OneSwf\n");
        uiCycle = 0;
    }
    int iBurst;
    for (iBurst = 0; iBurst < 50; iBurst++)
    {
        bDIO1 = !bDIO1;
        PIN_setOutputValue(hDynPin, CC1310_LAUNCHXL_DIO1, bDIO1);
    }
}

void StartOneSwf(void)
{
    Swi_Params swiParams;
    Swi_Params_init(&swiParams);
    swiParams.arg0 = 1;
    swiParams.arg1 = 0;
    swiParams.priority = 2;
    swiParams.trigger = 3;

    Swi_construct(&stOneSwi, (Swi_FuncPtr)OneSwf, &swiParams, NULL);
    hSwiOne = Swi_handle(&stOneSwi);
}
