/*
 * Common.h
 *
 *  Created on: 21 ott 2018
 *      Author: andre
 */

#ifndef COMMON_H_
#define COMMON_H_

#include <stdio.h>

#include <xdc/runtime/Error.h>
#include <xdc/runtime/System.h>


/* Board Header file */
#include "Board.h"

#include <ti/sysbios/BIOS.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>

/* BIOS module Headers */
#include <ti/sysbios/knl/Swi.h>
#include <ti/display/Display.h>
#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Event.h>

#define STACKSIZE 1024

Display_Handle  displayHandle;
PIN_Handle hDynPin;
Semaphore_Handle hSemADC;   // Semaphore
Event_Handle hEvnGeneric;   // Event
Swi_Handle hSwiZero, hSwiOne;
Task_Struct stADCTask, stGenericTask;
Swi_Struct stZeroSwi, stOneSwi;  //+++ It can't be local or becomes ineffective as soon as goes out of scope.

bool bDIO15, bDIO12, bDIO21, bDIO22, bDIO1;
Void GenericTf(UArg arg0, UArg arg1);
void StartGenericTf(void);

#endif /* COMMON_H_ */
