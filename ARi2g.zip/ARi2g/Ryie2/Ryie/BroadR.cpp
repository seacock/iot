#include "Ryie.h"

#define SOCK_RCVTIME_SEC 1	//+++ sec.
#define SOCK_RCVTIME_MICROSEC 500 * 1000	//+++ micros.
#define NUM_EWOULDBLOCK	15	//+++ Number of times error occurs.

void* BroadTp(void *arg)	
{
	ThreadInfo *pstThrInf = (ThreadInfo*)arg;
#ifdef _BRIEF_
	DisplayThreadSchedAttr(pstThrInf->pcInfoArg);
	cpu_set_t stSet;
	sched_getaffinity(0, sizeof(stSet), &stSet);
	for (int iCount = 0; iCount < 4; iCount++)
		if (CPU_ISSET_S(iCount, sizeof(stSet), &stSet))
			cout << "affinity: " << iCount << endl << endl;
#endif // _BRIEF_
	
	int iSocket;	 
	if ((iSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == INVALID_SOCKET)
		handle_error("socket");

	int iBroadcastOpt;
	socklen_t optLen = sizeof(iBroadcastOpt);
#ifdef _TALKATIVE_
	if (getsockopt(iSocket, SOL_SOCKET, SO_BROADCAST, &iBroadcastOpt, &optLen) == -1) 
		handle_error("getsockopt");
	else
		cout << "SO_BROADCAST : " << iBroadcastOpt << endl;
#endif // _TALKATIVE_
	iBroadcastOpt = 1;
	if (setsockopt(iSocket, SOL_SOCKET, SO_BROADCAST, &iBroadcastOpt, optLen) == -1)
		handle_error("setsockopt");
#ifdef _BRIEF_
	if (getsockopt(iSocket, SOL_SOCKET, SO_BROADCAST, &iBroadcastOpt, &optLen) == -1) 
		handle_error("getsockopt");
	else
		cout << "SO_BROADCAST : " << iBroadcastOpt << endl << endl;
#endif // _BRIEF_

	sockaddr_in stSaiOther;
	int iLenOther = sizeof(stSaiOther);	

	//+++ Zero struct and fill in its members.
	memset((char*)&stSaiOther, 0, sizeof(stSaiOther));
	stSaiOther.sin_family = AF_INET;
	stSaiOther.sin_port = htons(PORT);     
	if (inet_aton(ThreadInfo::SacBroadcast, &stSaiOther.sin_addr) == 0) 
		handle_error1("inet_aton() failed\n");
 
	char acRecvFrom[BUFLEN], acSendTo[BUFLEN] = "RaspberryPi is broadcasting.\n";
	
	timeval tv;
	socklen_t lenTV = sizeof(tv); 
	tv.tv_sec = SOCK_RCVTIME_SEC;
	tv.tv_usec = SOCK_RCVTIME_MICROSEC;
	if (setsockopt(iSocket, SOL_SOCKET, SO_RCVTIMEO, &tv, lenTV) == -1)	//+++ Blocking socket with timeout.
		handle_error("setsockopt");
#ifdef _BRIEF_
	if (getsockopt(iSocket, SOL_SOCKET, SO_RCVTIMEO, &tv, &lenTV) == -1) 
		handle_error("getsockopt");
	else
		cout << "SO_RCVTIMEO : " << tv.tv_sec * 1000 * 1000 + tv.tv_usec << " micros" << endl << endl;
#endif // _BRIEF_
				
	memset(acRecvFrom, '\0', BUFLEN);	//+++ Important: clear the buffer by filling null, it might have previously received data.
	int iLen = 0, iEWouldBlock = 0, iEIntr = 0;

//	do	//+++ Try NUM_EWOULDBLOCK times to send broadcast message to laptop and to receive some data.
//	{
	if (sendto(iSocket, acSendTo, strlen(acSendTo), 0, (sockaddr*)&stSaiOther, iLenOther) == -1)
		handle_error("sendto()");





	fd_set active_fd_set, read_fd_set;
	int i;
	struct sockaddr_in clientname;
	size_t size;


	  /* Initialize the set of active sockets. */
	FD_ZERO(&active_fd_set);
	FD_SET(iSocket, &active_fd_set);

	while (1)
	{
	  /* Block until input arrives on one or more active sockets. */
		read_fd_set = active_fd_set;
		if (select(FD_SETSIZE, &read_fd_set, NULL, NULL, NULL) < 0)
		{
			perror("select()");
			exit(EXIT_FAILURE);
		}

		      /* Service all the sockets with input pending. */
		for (i = 0; i < FD_SETSIZE; ++i)
			if (FD_ISSET(i, &read_fd_set))
			{
				iLen = recvfrom(iSocket, acRecvFrom, BUFLEN, 0, (sockaddr*)&stSaiOther, (socklen_t*)&iLenOther);	//+++ It must use BUFLEN as buffer length is 0.
				if (iLen <= 0)
				{
					if (errno == EINTR)	//+++ With broadcasting this error happens the first 4 times, then EWOULDBLOCK takes place. So iEIntr < 10 is a reasonable upper limit.
						iEIntr++;
					if (errno == EWOULDBLOCK)
						iEWouldBlock++;
					else
						handle_error("recvfrom()");
				} 
				else
					break;
			}
		if (iLen > 0)
			break;
	}








//	do	//+++ Try NUM_EWOULDBLOCK times to send broadcast message to laptop and to receive some data.
//	{
//		iLen = recvfrom(iSocket, acRecvFrom, BUFLEN, 0, (sockaddr*)&stSaiOther, (socklen_t*)&iLenOther);	//+++ It must use BUFLEN as buffer length is 0.
//		if (iLen <= 0)
//		{
//			if (errno == EINTR)	//+++ With broadcasting this error happens the first 4 times, then EWOULDBLOCK takes place. So iEIntr < 10 is a reasonable upper limit.
//				iEIntr++;
//			if (errno == EWOULDBLOCK)
//				iEWouldBlock++;
//			else
//				handle_error("recvfrom()");
//		} 
//		else
//			break;
//	} while (iEWouldBlock < NUM_EWOULDBLOCK && iEIntr < 10);

//	do	//+++ Try 5 times to send broadcast message to laptop and to receive some data.
//	{
//		if (sendto(iSocket, acSendTo, strlen(acSendTo), 0, (sockaddr*)&stSaiOther, iLenOther) == -1)
//			handle_error("sendto()");
//
//		iLen = recvfrom(iSocket, acRecvFrom, BUFLEN, 0, (sockaddr*)&stSaiOther, (socklen_t*)&iLenOther);
//		if (iLen < 0)
//		{
//			if (errno == EINTR)	//+++ With broadcasting this error happens the first 4 times, then EWOULDBLOCK takes place. So iEIntr < 10 is a reasonable upper limit.
//				iEIntr++;
//			else if (errno == EWOULDBLOCK)
//				iEWouldBlock++;
//			else
//				handle_error("recvfrom()");
//		} 
//		else
//			break;
//	} while (iEWouldBlock < 5 && iEIntr < 10);


	cout << endl << "iEWouldBlock " << iEWouldBlock << "		iEIntr " << iEIntr << endl;

	if (iLen <= 0)
		handle_error("recvfrom()");
         
	//+++ Print details of the server/peer and the data received.
	char acServerAddr[BUFLEN];
	inet_ntop(AF_INET, (sockaddr_in*)&stSaiOther.sin_addr, acServerAddr, sizeof(acServerAddr));		
	cout << "Received packet from " << acServerAddr << ":" << ntohs(stSaiOther.sin_port) << endl;
	puts(acRecvFrom);

	string srRecvFrom(acRecvFrom);
	basic_string <char>::size_type indexCh1a, indexCh1b; 
  
	indexCh1a = srRecvFrom.find_first_of("*", 0);  
	indexCh1b = srRecvFrom.find_first_of("*", indexCh1a + 1); 
	ThreadInfo::SsrLANServerHost = srRecvFrom.substr(indexCh1a + 1, indexCh1b - indexCh1a -  1);

	indexCh1a = srRecvFrom.find_first_of("*", indexCh1b + 1); 
	ThreadInfo::SsrLANServerPort = srRecvFrom.substr(indexCh1b + 1, indexCh1a - indexCh1b -  1);
 
	close(iSocket);

	pthread_barrier_wait(&ThreadInfo::Sbarrier5);

	return SUCCESS;
}

void InterfacesIp(char *pBroadcast)
{
	FILE *pstFile;
	char acLine[BUFLEN], *pcDefIf, *pcZeroes;	//+++ works also with less than 500, but...
     
	pstFile = fopen("/proc/net/route", "r");

	while (fgets(acLine, sizeof(acLine), pstFile))
	{
		pcDefIf = strtok(acLine, " \t");
		pcZeroes = strtok(NULL, " \t");
         
		if (pcDefIf != NULL && pcZeroes != NULL)
			if (strcmp(pcZeroes, "00000000") == 0)
			{
#ifdef _TALKATIVE_
				cout << "Default interface is : " << pcDefIf << endl;
#endif // _TALKATIVE_
				break;
			}
	}

	ifaddrs *pstIfaddr, *pstIfa;
	int iFamily, iRes;
	char acHostLocation[NI_MAXHOST];	

	if (getifaddrs(&pstIfaddr) == -1) 
		handle_error("getifaddrs");

	//+++ Walk through linked list, maintaining head pointer so we can free list later.
	for (pstIfa = pstIfaddr; pstIfa != NULL; pstIfa = pstIfa->ifa_next) 
	{
		if (pstIfa->ifa_addr == NULL || strcmp(pstIfa->ifa_name, pcDefIf) != 0)
			continue;

		iFamily = pstIfa->ifa_addr->sa_family;
#ifdef _TALKATIVE_
		//+++ Display interface name and family (including symbolic form of the latter for the common families).
		cout << pstIfa->ifa_name << " " << ((iFamily == AF_INET) ? "AF_INET " : "other family ") << iFamily << endl;
#endif // _TALKATIVE_
		//+++ For an AF_INET* interface address, display the address.
		if (iFamily == AF_INET) 
		{
			iRes = getnameinfo(pstIfa->ifa_addr, sizeof(sockaddr_in), acHostLocation, NI_MAXHOST, NULL, 0, 0);
			if (iRes != 0) 
				handle_error2("getnameinfo() failed: ", gai_strerror(iRes));

			char host[NI_MAXHOST];
			getnameinfo(pstIfa->ifa_addr, sizeof(sockaddr_in), host, NI_MAXHOST, NULL, 0, NI_NUMERICHOST);
			ThreadInfo::SteHost.push_back(host);
#ifdef _TALKATIVE_
			cout << "presentation form host address: " << host << endl;
			cout << "literal host location: " << acHostLocation << endl;
#endif // _TALKATIVE_
			char acHostName[BUFLEN];
			gethostname(acHostName, sizeof(acHostName));
			string srHostName(acHostName), srHost(acHostLocation);
			if (srHost.find(srHostName) == 0 && srHost.at(srHostName.length()) == '.')
				cout << "literal host location: " << acHostLocation << " contains literal host name: " << acHostName << endl;
			else
				continue;			
			
			if (inet_ntop(AF_INET, &((sockaddr_in*)pstIfa->ifa_ifu.ifu_broadaddr)->sin_addr, pBroadcast, INET_ADDRSTRLEN) == NULL) 
				handle_error("inet_ntop");

			cout << "presentation form broadcast address: " << pBroadcast << endl;
		}
	}

	freeifaddrs(pstIfaddr);
}