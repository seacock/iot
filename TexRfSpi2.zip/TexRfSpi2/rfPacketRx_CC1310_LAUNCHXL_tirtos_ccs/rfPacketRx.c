/*
 * Copyright (c) 2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/***** Includes *****/

/* TI Drivers */
#include <ti/drivers/rf/RF.h>
#include <ti/drivers/PIN.h>
#include <ti/drivers/GPIO.h>
#include <ti/drivers/SPI.h>

/* Driverlib Header files */
#include DeviceFamily_constructPath(driverlib/rf_prop_mailbox.h)

/* TI-RTOS Header files */
#include <xdc/std.h>
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Semaphore.h>

#include <ti/display/Display.h> ///###

/* Board Header files */
#include "Board.h"

/* Application Header files */
#include "RFQueue.h"
#include "smartrf_settings/smartrf_settings.h"

Display_Handle displayHandle;    //###
int iNumPacket = 0; //###

/***** Defines *****/

/* Packet RX Configuration */
#define DATA_ENTRY_HEADER_SIZE 8  /* Constant header size of a Generic Data Entry */
#define MAX_LENGTH             30 /* Max length byte the radio will accept */
#define NUM_DATA_ENTRIES       2  /* NOTE: Only two data entries supported at the moment */
#define NUM_APPENDED_BYTES     2  /* The Data Entries data field will contain:
                                   * 1 Header byte (RF_cmdPropRx.rxConf.bIncludeHdr = 0x1)
                                   * Max 30 payload bytes
                                   * 1 status byte (RF_cmdPropRx.rxConf.bAppendStatus = 0x1) */

#define PAYLOAD_LENGTH      30  //###

/***** Prototypes *****/
static void callback(RF_Handle h, RF_CmdHandle ch, RF_EventMask e);

/***** Variable declarations *****/
static RF_Object rfObject;
static RF_Handle rfHandle;

/* Pin driver handle */
static PIN_Handle ledPinHandle;
static PIN_State ledPinState;

/* Buffer which contains all Data Entries for receiving data.
 * Pragmas are needed to make sure this buffer is 4 byte aligned (requirement from the RF Core) */
#if defined(__TI_COMPILER_VERSION__)
#pragma DATA_ALIGN (rxDataEntryBuffer, 4);
static uint8_t 
rxDataEntryBuffer[RF_QUEUE_DATA_ENTRY_BUFFER_SIZE(NUM_DATA_ENTRIES,
                                                  MAX_LENGTH,
                                                  NUM_APPENDED_BYTES)];
#elif defined(__IAR_SYSTEMS_ICC__)
#pragma data_alignment = 4
static uint8_t 
rxDataEntryBuffer[RF_QUEUE_DATA_ENTRY_BUFFER_SIZE(NUM_DATA_ENTRIES,
                                                  MAX_LENGTH,
                                                  NUM_APPENDED_BYTES)];
#elif defined(__GNUC__)
static uint8_t 
rxDataEntryBuffer[RF_QUEUE_DATA_ENTRY_BUFFER_SIZE(NUM_DATA_ENTRIES,
                                                  MAX_LENGTH, 
                                                  NUM_APPENDED_BYTES)] 
                                                  __attribute__((aligned(4)));
#else
#error This compiler is not supported.
#endif

/* Receive dataQueue for RF Core to fill in data */
static dataQueue_t dataQueue;
static rfc_dataEntryGeneral_t* currentDataEntry;
static uint8_t packetLength;
static uint8_t* packetDataPointer;

static uint8_t packet[MAX_LENGTH + NUM_APPENDED_BYTES - 1]; /* The length byte is stored in a separate variable */

/*
 * Application LED pin configuration table:
 *   - All LEDs board LEDs are off.
 */
PIN_Config pinTable[] =
{
    Board_PIN_LED2 | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
#if defined Board_CC1352R1_LAUNCHXL
    Board_DIO30_RFSW | PIN_GPIO_OUTPUT_EN | PIN_GPIO_HIGH | PIN_PUSHPULL | PIN_DRVSTR_MAX,
#endif
	PIN_TERMINATE
};

#define THREADSTACKSIZE (1024)
#define SPI_MSG_LENGTH  (30)    //+++ 2 head spaces + 27 characters = SPI_MSG_LENGTH - 1
#define MAX_LOOP        (1000)
unsigned char slaveRxBuffer[SPI_MSG_LENGTH];
unsigned char slaveTxBuffer[SPI_MSG_LENGTH];

//+++ Semaphore to block slave until transfer is complete.
Semaphore_Struct semStructSpi;
Semaphore_Handle semHandleSpi;

unsigned char slaveRfBuffer[SPI_MSG_LENGTH]; //###

//+++ Semaphore to block slave until Rf transfer is complete.
Semaphore_Struct semStructRf;
Semaphore_Handle semHandleRf;

/***** Function definitions *****/

Task_Struct workTask;
/* Make sure we have nice 8-byte alignment on the stack to avoid wasting memory */
#pragma DATA_ALIGN(workTaskStack, 8)
#define STACKSIZE 1024
static uint8_t workTaskStack[STACKSIZE];
void transferCompleteFxn(SPI_Handle handle, SPI_Transaction *transaction);

/*
 * ======== Task ========
 *  slaveSpiT sends a message to master while simultaneously receiving a
 *  message from the master.
 */

Void slaveSpiT(UArg arg0, UArg arg1)
{
    /* Call driver init functions. */
    GPIO_init();
    SPI_init();

    /* Configure the LED pins */
    /*GPIO_setConfig(Board_GPIO_LED0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(Board_GPIO_LED1, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);*/ //###

    /* Turn on user LED */
    //GPIO_write(Board_GPIO_LED0, Board_GPIO_LED_ON);   //###

    Display_printf(displayHandle, 0, 0, "Starting the SPI slave example");
    Display_printf(displayHandle, 0, 0, "This example requires external wires to be "
               "connected to the header pins. Please see the Board.html for details.\n");

    SPI_Handle      slaveSpi;
    SPI_Params      spiParams;
    SPI_Transaction transaction;
    uint32_t        i;
    bool            transferOK;
    //int32_t         status;

    /*
     * Board_SPI_MASTER_READY & Board_SPI_SLAVE_READY are GPIO pins connected
     * between the master & slave.  These pins are used to synchronize
     * the master & slave applications via a small 'handshake'.  The pins
     * are later used to synchronize transfers & ensure the master will not
     * start a transfer until the slave is ready.  These pins behave
     * differently between spimaster & spislave examples:
     *
     * spislave example:
     *     * Board_SPI_MASTER_READY is configured as an input pin.  During the
     *       'handshake' this pin is read & a high value will indicate the
     *       master is ready to run the application.  Afterwards, the pin is
     *       read to determine if the master has already opened its SPI pins.
     *       The master will pull this pin low when it has opened its SPI.
     *
     *     * Board_SPI_SLAVE_READY is configured as an output pin.  During the
     *       'handshake' this pin is changed from low to high output.  This
     *       notifies the master the slave is ready to run the application.
     *       Afterwards, the pin is used by the slave to notify the master it
     *       is ready for a transfer.  When ready for a transfer, this pin will
     *       be pulled low.
     *
     * Below we set Board_SPI_MASTER_READY & Board_SPI_SLAVE_READY initial
     * conditions for the 'handshake'.
     */
    GPIO_setConfig(Board_SPI_SLAVE_READY, GPIO_CFG_OUTPUT | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(Board_SPI_MASTER_READY, GPIO_CFG_INPUT);
    Display_printf(displayHandle, 0, 0, "Board_SPI_SLAVE_READY = 0    Board_SPI_MASTER_READY = 0\n");  //###

    /*
     * Handshake - Set Board_SPI_SLAVE_READY high to indicate slave is ready
     * to run.  Wait for Board_SPI_MASTER_READY to be high.
     */
    GPIO_write(Board_SPI_SLAVE_READY, 1);
    while (GPIO_read(Board_SPI_MASTER_READY) == 0)
        Display_printf(displayHandle, 0, 0, "Board_SPI_SLAVE_READY = 1    Board_SPI_MASTER_READY = 0\n");  //###

    Display_printf(displayHandle, 0, 0, "Board_SPI_SLAVE_READY = 1    Board_SPI_MASTER_READY = 1\n");  //###

    /*
     * Create synchronization semaphore; this semaphore will block the slave
     * until a transfer is complete.  The slave is configured in callback mode
     * to allow us to configure the SPI transfer & then notify the master the
     * slave is ready.  However, we must still wait for the current transfer
     * to be complete before setting up the next.  Thus, we wait on semHandleSpi.
     * Once the transfer is complete the callback function will unblock the
     * slave.
     */
    /*status = sem_init(&slaveSem, 0, 0);
    if (status != 0)
    {
        Display_printf(displayHandle, 0, 0, "Error creating slaveSem\n");
        while(1);
    }
    Display_printf(displayHandle, 0, 0, "Created slaveSem\n");  //###*/

    Semaphore_Params semParams;
    /* Construct a Semaphore object to be used as a resource lock, inital count 0 */
    Semaphore_Params_init(&semParams);
    Semaphore_construct(&semStructSpi, 0, &semParams);

    /* Obtain instance handle */
    semHandleSpi = Semaphore_handle(&semStructSpi);

    /*
     * Wait until master SPI is open.  When the master is configuring SPI pins
     * the clock may toggle from low to high (or high to low depending on
     * polarity).  If using 3-pin SPI & the slave has been opened before the
     * master, clock transitions may cause the slave to shift bits out assuming
     * it is an actual transfer.  We can prevent this behavior by opening the
     * master first & then opening the slave.
     */
    while (GPIO_read(Board_SPI_MASTER_READY)) {}

    Display_printf(displayHandle, 0, 0, " Opening SPI as slave in callback mode\n");  //###

    /*
     * Open SPI as slave in callback mode; callback mode is used to allow us to
     * configure the transfer & then set Board_SPI_SLAVE_READY high.
     */
    SPI_Params_init(&spiParams);
    spiParams.bitRate = 500000 * 4; //###
    spiParams.frameFormat = SPI_POL1_PHA1;    //###
    spiParams.mode = SPI_SLAVE;
    spiParams.transferCallbackFxn = transferCompleteFxn;
    spiParams.transferMode = SPI_MODE_CALLBACK;
    slaveSpi = SPI_open(Board_SPI_SLAVE, &spiParams);
    if (slaveSpi == NULL) {
        Display_printf(displayHandle, 0, 0, "Error initializing slave SPI\n");
        while (1);
    }
    else
        Display_printf(displayHandle, 0, 0, "Slave SPI initialized\n");

    memcpy(slaveRfBuffer, "00000", 5);  //###

    for (i = 0; i < MAX_LOOP; i++)
    {
        /* Initialize slave SPI transaction structure */
        /* Copy message to transmit buffer */
        if (i == 0)
            strncpy((char*)slaveTxBuffer, (char*)"****************************", SPI_MSG_LENGTH);//###

        memset((void *) slaveRxBuffer, 0, SPI_MSG_LENGTH);
        transaction.count = SPI_MSG_LENGTH;
        transaction.txBuf = (void *) slaveTxBuffer;
        transaction.rxBuf = (void *) slaveRxBuffer;

        /* Toggle on user LED, indicating a SPI transfer is in progress */
        //GPIO_toggle(Board_GPIO_LED1); //###

        /*
         * Setup SPI transfer; Board_SPI_SLAVE_READY will be set to notify
         * master the slave is ready.
         */
        transferOK = SPI_transfer(slaveSpi, &transaction);
        if (transferOK)
        {
            GPIO_write(Board_SPI_SLAVE_READY, 0);//###
            Semaphore_pend(semHandleSpi, BIOS_WAIT_FOREVER);    //+++ Wait until transfer has completed.

            /*
             * Drive Board_SPI_SLAVE_READY high to indicate slave is not ready
             * for another transfer yet.
             */
            GPIO_write(Board_SPI_SLAVE_READY, 1);//###

            Display_printf(displayHandle, 0, 0, "Slave received: %s", slaveRxBuffer);

            //###
            //+++ Wait until rf has completed.
            Semaphore_pend(semHandleRf, BIOS_WAIT_FOREVER);
            strcpy((char*)slaveTxBuffer, (char*)"  ");//###
            strcat((char*)slaveTxBuffer, (char*)slaveRfBuffer);//###
        }
        else
            Display_printf(displayHandle, 0, 0, "Unsuccessful slave SPI transfer");
    }

    SPI_close(slaveSpi);

    /* Example complete - set pins to a known state */
    GPIO_setConfig(Board_SPI_MASTER_READY, GPIO_CFG_OUTPUT | GPIO_CFG_OUT_LOW);
    GPIO_write(Board_SPI_SLAVE_READY, 0);

    Display_printf(displayHandle, 0, 0, "\nDone");
}

/*
 *  ======== transferCompleteFxn ========
 *  Callback function for SPI_transfer().
 */
void transferCompleteFxn(SPI_Handle handle, SPI_Transaction *transaction)
{
    Semaphore_post(semHandleSpi);   //+++ Unlock resource.
}

void *mainThread(void *arg0)
{
    /* Open Display Driver */   //###
    Display_Params displayParams;
    Display_Params_init(&displayParams);
    displayHandle = Display_open(Display_Type_UART, NULL);
    if (displayHandle == NULL)
        while (1);  //+++ Failed to open display driver.

    //+++ Set up the task.
    Task_Params workTaskParams;
    Task_Params_init(&workTaskParams);
    workTaskParams.stackSize = STACKSIZE;
    workTaskParams.priority = 1;
    workTaskParams.stack = &workTaskStack;
    Task_construct(&workTask, slaveSpiT, &workTaskParams, NULL);

    //+++ Rf
    Display_printf(displayHandle, 1, 0, "Rf......................................................1");//###
    RF_Params rfParams;
    RF_Params_init(&rfParams);

    /* Open LED pins */
    ledPinHandle = PIN_open(&ledPinState, pinTable);
    if (ledPinHandle == NULL)
    {

        Display_printf(displayHandle, 1, 0, "Rf......................................................2");//###
        while(1);
    }

    /*int32_t         status = sem_init(&rfSem, 0, 0);
    if (status != 0)
    {
        Display_printf(displayHandle, 0, 0, "Error creating rfSem\n");
        while(1);
    }*/

    Semaphore_Params semParams1;
    /* Construct a Semaphore object to be use as a resource lock, inital count 1 */
    Semaphore_Params_init(&semParams1);
    Semaphore_construct(&semStructRf, 0, &semParams1);

    /* Obtain instance handle */
    semHandleRf = Semaphore_handle(&semStructRf);

    //Display_printf(displayHandle, 0, 0, "Created Sem\n");  //###

    if (RFQueue_defineQueue(&dataQueue, rxDataEntryBuffer, sizeof(rxDataEntryBuffer),
                                        NUM_DATA_ENTRIES, MAX_LENGTH + NUM_APPENDED_BYTES))
    {
        Display_printf(displayHandle, 1, 0, "Rf......................................................3");//###
        while(1);   //+++ Failed to allocate space for all data entries.
    }

    Display_printf(displayHandle, 1, 0, "Rf......................................................4");//###

    /* Modify CMD_PROP_RX command for application needs */
    /* Set the Data Entity queue for received data */
    RF_cmdPropRx.pQueue = &dataQueue;           
    /* Discard ignored packets from Rx queue */
    RF_cmdPropRx.rxConf.bAutoFlushIgnored = 1;  
    /* Discard packets with CRC error from Rx queue */
    RF_cmdPropRx.rxConf.bAutoFlushCrcErr = 1;   
    /* Implement packet length filtering to avoid PROP_ERROR_RXBUF */
    RF_cmdPropRx.maxPktLen = MAX_LENGTH;        
    RF_cmdPropRx.pktConf.bRepeatOk = 1;
    RF_cmdPropRx.pktConf.bRepeatNok = 1;

    //+++ Request access to the radio.
    rfHandle = RF_open(&rfObject, &RF_prop, (RF_RadioSetup*)&RF_cmdPropRadioDivSetup, &rfParams);

    //+++ Set the frequency.
    RF_postCmd(rfHandle, (RF_Op*)&RF_cmdFs, RF_PriorityNormal, NULL, 0);

    Display_printf(displayHandle, 1, 0, "Rf......................................................5");//###

    //+++ Enter RX mode and stay forever in RX.
    RF_EventMask terminationReason = RF_runCmd(rfHandle, (RF_Op*)&RF_cmdPropRx,
                                         RF_PriorityNormal, &callback, RF_EventRxEntryDone);

    switch(terminationReason)
    {
        case RF_EventLastCmdDone:
            //+++ A stand-alone radio operation command or the last radio operation command in a chain finished.
            break;
        case RF_EventCmdCancelled:
            //+++ Command cancelled before it was started; it can be caused by RF_cancelCmd() or RF_flushCmd().
            break;
        case RF_EventCmdAborted:
            //+++ Abrupt command termination caused by RF_cancelCmd() or RF_flushCmd().
            break;
        case RF_EventCmdStopped:
            //+++ Graceful command termination caused by RF_cancelCmd() or RF_flushCmd().
            break;
        default:
            //+++ Uncaught error event.
            while(1);
    }

    uint32_t cmdStatus = ((volatile RF_Op*)&RF_cmdPropRx)->status;
    switch(cmdStatus)
    {
        case PROP_DONE_OK:
            // Packet received with CRC OK
            break;
        case PROP_DONE_RXERR:
            // Packet received with CRC error
            break;
        case PROP_DONE_RXTIMEOUT:
            // Observed end trigger while in sync search
            break;
        case PROP_DONE_BREAK:
            // Observed end trigger while receiving packet when the command is
            // configured with endType set to 1
            break;
        case PROP_DONE_ENDED:
            // Received packet after having observed the end trigger; if the
            // command is configured with endType set to 0, the end trigger
            // will not terminate an ongoing reception
            break;
        case PROP_DONE_STOPPED:
            // received CMD_STOP after command started and, if sync found,
            // packet is received
            break;
        case PROP_DONE_ABORT:
            // Received CMD_ABORT after command started
            break;
        case PROP_ERROR_RXBUF:
            // No RX buffer large enough for the received data available at
            // the start of a packet
            break;
        case PROP_ERROR_RXFULL:
            // Out of RX buffer space during reception in a partial read
            break;
        case PROP_ERROR_PAR:
            // Observed illegal parameter
            break;
        case PROP_ERROR_NO_SETUP:
            // Command sent without setting up the radio in a supported
            // mode using CMD_PROP_RADIO_SETUP or CMD_RADIO_SETUP
            break;
        case PROP_ERROR_NO_FS:
            // Command sent without the synthesizer being programmed
            break;
        case PROP_ERROR_RXOVF:
            // RX overflow observed during operation
            break;
        default:
            // Uncaught error event - these could come from the
            // pool of states defined in rf_mailbox.h
            while(1);
    }

    while(1);
}

void callback(RF_Handle h, RF_CmdHandle ch, RF_EventMask e)
{
    if (e & RF_EventRxEntryDone)
    {
        //+++ Toggle pin to indicate RX.
        PIN_setOutputValue(ledPinHandle, Board_PIN_LED2, !PIN_getOutputValue(Board_PIN_LED2));

        currentDataEntry = RFQueue_getDataEntry();  //+++ Get current unhandled data entry.

        /* Handle the packet data, located at &currentDataEntry->data:
         * - Length is the first byte with the current configuration
         * - Data starts from the second byte */
        packetLength      = *(uint8_t*)(&currentDataEntry->data);
        packetDataPointer = (uint8_t*)(&currentDataEntry->data + 1);

        //+++ Copy the payload + the status byte to the packet variable.
        memcpy(packet, packetDataPointer, (packetLength + 1));

        //###
        uint8_t *pPacket = packet;
        pPacket += 2;
        memcpy(slaveRfBuffer, pPacket, packetLength);
        Semaphore_post(semHandleRf);

        RFQueue_nextEntry();
    }

}
