/*
 * ^Common.h
 *
 *  Created on: 21 gen 2019
 *      Author: andre
 */

#ifndef COMMON_H_
#define COMMON_H_

/***** Includes *****/
/* Standard C Libraries */
#include <stdlib.h>

/* TI Drivers */
#include <ti/drivers/rf/RF.h>
#include <ti/drivers/PIN.h>
#include <ti/drivers/pin/PINCC26XX.h>

#include <ti/sysbios/knl/Task.h>

/* Driverlib Header files */
#include DeviceFamily_constructPath(driverlib/rf_prop_mailbox.h)

/* Board Header files */
#include "Board.h"

/* Application Header files */
#include "RFQueue.h"
#include "smartrf_settings/smartrf_settings.h"

/***** Defines *****/
/* Packet TX/RX Configuration */
#define PAYLOAD_LENGTH      30
/* Set packet interval to 1000ms */
//#define PACKET_INTERVAL     (uint32_t)(4000000*1.0f)	//---DDD
#define PACKET_INTERVAL     (uint32_t)(4000000*0.2f)
/* Set Receive timeout to 500ms */
//#define RX_TIMEOUT          (uint32_t)(4000000*0.5f)	//---EEE
#define RX_TIMEOUT          (uint32_t)(4000000*0.1f)
/* NOTE: Only two data entries supported at the moment */
#define NUM_DATA_ENTRIES    2
/* The Data Entries data field will contain:
 * 1 Header byte (RF_cmdPropRx.rxConf.bIncludeHdr = 0x1)
 * Max 30 payload bytes
 * 1 status byte (RF_cmdPropRx.rxConf.bAppendStatus = 0x1) */
#define NUM_APPENDED_BYTES  2

/* Log radio events in the callback */
//#define LOG_RADIO_EVENTS

/***** Prototypes *****/
void StartTimestampTxTf(void);
void TermStat(RF_EventMask terminationReason, uint32_t cmdStatus);  //+++ RF events and status of commands.

/***** Variable declarations *****/
/* Pin driver handle */
PIN_Handle ledPinHandle;
PIN_State ledPinState;

#define STACKSIZE 1024
#define TS2_OFFSET 251    //+++ Slave asks offset. Master answers with offset.
#define TS2_SYNCHRO 252    //+++ Slave asks synchronization. Master answers with synchronization.
#define TS2_IDLE 253    //+++ Slave doesn't request anything. Master doesn't perform any request.
#define TS2_SLAVE 4    //+++ Byte where slave writes.
#define TS2_MASTER 5    //+++ Byte where master writes.
#define TS2_TS1 6    //+++ Byte where timestamp starts: 4 bytes long.
#define TS2_DP1 10    //+++ Byte where delta processing starts: 4 bytes long. 2 bytes would be enough.

#endif /* COMMON_H_ */
