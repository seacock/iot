/*
 * ^Common.h
 *
 *  Created on: 31 ott 2018
 *      Author: andre
 */

#ifndef COMMON_H_
#define COMMON_H_

#include <ti/sysbios/knl/Task.h>

#define BOARD_PIN_RED_LED CC1310_LAUNCHXL_PIN_RLED
#define STACKSIZE 1024

Task_Struct stRxRadioTask;
Void RxRadioTf(UArg arg0, UArg arg1);
void StartRxRadioTf(void);  //+++ Set up and start RxRadioTf task.

#endif /* COMMON_H_ */
