#include "SharA.h"
#include "ColorText.h"
#include "Aff.h"
#include "Ry.h"
#include "Spi.h"
#include "I2c.h"
#include "Uart.h"
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <wiringPi.h>

void BtnIncDec(int iFdLas, CRy *pRy);   	//+++ Manage 2 push buttons.
int SrNonblockFlag(int iDesc, int iValue);   	//+++ Set, reset the O_NONBLOCK flag of iDesc.
void SendValue(int iFdLas, int iValue, string srWho);    	//+++ Send value to laptop ASUS.
void WriteToServer(int iFdLas, const char* buf);  	//+++ Send data to laptop ASUS.

void* LanTp(void *arg)
{
	CColorText coltGreen(CColorText::GREEN);	
	CRy::ThreadInfo *pstThrInf = (CRy::ThreadInfo*)arg;
	CAff *pAff = pstThrInf->pstUtil->pAff;
	CRy *pRy = pstThrInf->pstUtil->pRy;
	CSpi *pSpi = pstThrInf->pstUtil->pSpi;
	CI2c *pI2c = pstThrInf->pstUtil->pI2c;
	CUart *pUart = pstThrInf->pstUtil->pUart;

	int iRes;
	switch (pstThrInf->iThreadNum)
	{
	case CRy::TL_One:
		iRes = sched_setaffinity(0, sizeof(CRy::ThreadInfo::stSet1), &CRy::ThreadInfo::stSet1);
		break;
	case CRy::TL_Two:
		iRes = sched_setaffinity(0, sizeof(CRy::ThreadInfo::stSet2), &CRy::ThreadInfo::stSet2);
		break;
	case CRy::TL_Three:
		iRes = sched_setaffinity(0, sizeof(CRy::ThreadInfo::stSet2), &CRy::ThreadInfo::stSet2);
		break;
	case CRy::TL_Temporary:
		iRes = sched_setaffinity(0, sizeof(CRy::ThreadInfo::stSet1), &CRy::ThreadInfo::stSet1);
		break;
	}

	if (iRes == -1)
		handle_error_en(iRes, "sched_setaffinity");

	pthread_barrier_wait(&pRy->stPortHost.barrier5);

#ifdef _BRIEF_
	pAff->DisplayThreadSchedAttr(pstThrInf->pcInfoArg);
	cpu_set_t stSet;
	sched_getaffinity(0, sizeof(stSet), &stSet);
	for (int iCount = 0; iCount < 4; iCount++)
		if (CPU_ISSET_S(iCount, sizeof(stSet), &stSet))
		{
			coltGreen.ss << "affinity: " << iCount << endl;
			cout << coltGreen;
		}

#endif // _BRIEF_

	int iSock = pRy->SockAddrConn(pRy->stPortHost.srLANServerHost.c_str(), atoi(pRy->stPortHost.srLANServerPort.c_str()));
	int iOn = 1;  	//+++ Selector for socket options.//???
	if(SrNonblockFlag(iSock, iOn) == -1)	//+++ Set socket to be non-blocking. In fact, when pRy->enStateDevice is set to I2C_RY_EXIT or to I2C_RY_SHUT_COMM, Asi has already closed its connection and this write would block. This can have two effects: 1)this app gets stuck; 2)Asi can block when trying to terminate because not all the threads it is waiting for from here are terminated.
		pRy->CloseFdErr(iSock, "fcntl()");   //???

	bool bOnlyOneTime = false;
	
	//+++ Send data to the server.
	if(pstThrInf->iThreadNum == CRy::TL_One)
	{
		WriteToServer(iSock, pstThrInf->pcInfoArg);

		while (pRy->enStateDevice != CRy::RyExit)
		{
			if (pRy->enStateDevice == CRy::LaptopDismiss && bOnlyOneTime == false)
			{
				pRy->CloseFdErr(iSock);    	//+++ This gets out from its endless loop, recv on laptop side (ReceiveFromMcTp).
				bOnlyOneTime = true;
			}
			BtnIncDec(iSock, pRy);
		}		
		
		pUart->UartClose(pUart->iUartHandle);

		//+++ shutdown(SocketFD, ...) wouldn't do from this thread to WebServUartTp. Instead pthread_kill does, even if it forces action.
		//+++ This situation arises when Asi terminates, but WebServUartTp is still performing recv(), without possibility to be notified
		//+++ of end of operations. WebServUartTp could be notified by remote client Hjc of exit, but this is not useful here. I don't plan to
		//+++ allow a kind of superuser with a password to stop WebServUartTp.
		if(pthread_kill(pRy->pstThrInf[CRy::TL_ServMixJC - 1].ulThread_id, SIGTERM) != 0)	//??????
			handle_error1("pthread_kill()");
	}
	else if(pstThrInf->iThreadNum == CRy::TL_Two)
	{
		pSpi->stPoten.srIdMsg = pstThrInf->pcInfoArg;
		pSpi->stPoten.uiDelay = 100;
		pSpi->stPoten.ucUpper = pSpi->kiCmdUbP;
		pSpi->stPoten.ucLower = pSpi->kiCmdLbP;
		pSpi->stPoten.srName = "Potentiometer";
		pSpi->stPoten.uiNumOfSpiCalls = 0;
		pSpi->stPoten.ulTotNumOfSpiCalls = 0;
		pSpi->stPoten.uiTomcatCounter = 0;
		pSpi->stPoten.uiLaptopCounter = 0;

		WriteToServer(iSock, pSpi->stPoten.srIdMsg.c_str());

		while (pRy->enStateDevice != CRy::RyExit)
		{
			//+++ Wait for genStateSpi STATE_Potentiometer.
			pthread_mutex_lock(&pSpi->stSync.mutexSpi);
			while (pSpi->stSync.enStateSpi != CSpi::STATE_Potentiometer)
				pthread_cond_wait(&pSpi->stSync.condPotentiometer, &pSpi->stSync.mutexSpi);
			pthread_mutex_unlock(&pSpi->stSync.mutexSpi);

			if (pRy->enStateDevice == CRy::LaptopDismiss && bOnlyOneTime == false)
			{
				pRy->CloseFdErr(iSock);    	//+++ This gets out from its endless loop, recv on laptop side (ReceiveFromMcTp).
				bOnlyOneTime = true;
			}

			pSpi->SpiMaster(iSock, pSpi->stPoten);   	//+++ Execute shared routine while thread THREE is waiting.

			//+++ Set genStateSpi to STATE_Thermometer and wake up thread THREE.
			pthread_mutex_lock(&pSpi->stSync.mutexSpi);
			pSpi->stSync.enStateSpi = CSpi::STATE_Thermometer;
			pthread_cond_signal(&pSpi->stSync.condThermometer);
			pthread_mutex_unlock(&pSpi->stSync.mutexSpi);
		}
	}
	else if(pstThrInf->iThreadNum == CRy::TL_Three)
	{
		pSpi->stThermo.srIdMsg = pstThrInf->pcInfoArg;
		pSpi->stThermo.uiDelay = 100;
		pSpi->stThermo.ucUpper = pSpi->kiCmdUbT;
		pSpi->stThermo.ucLower = pSpi->kiCmdLbT;
		pSpi->stThermo.srName = "Thermometer";
		pSpi->stThermo.uiNumOfSpiCalls = 0;
		pSpi->stThermo.ulTotNumOfSpiCalls = 0;
		pSpi->stThermo.uiTomcatCounter = 0;
		pSpi->stThermo.uiLaptopCounter = 0;

		WriteToServer(iSock, pSpi->stThermo.srIdMsg.c_str());

		while (pRy->enStateDevice != CRy::RyExit)
		{
			//+++ Wait for genStateSpi STATE_Thermometer.
			pthread_mutex_lock(&pSpi->stSync.mutexSpi);
			while (pSpi->stSync.enStateSpi != CSpi::STATE_Thermometer)
				pthread_cond_wait(&pSpi->stSync.condThermometer, &pSpi->stSync.mutexSpi);
			pthread_mutex_unlock(&pSpi->stSync.mutexSpi);

			if (pRy->enStateDevice == CRy::LaptopDismiss && bOnlyOneTime == false)
			{
				pRy->CloseFdErr(iSock);    	//+++ This gets out from its endless loop, recv on laptop side (ReceiveFromMcTp).
				bOnlyOneTime = true;
			}

			pSpi->SpiMaster(iSock, pSpi->stThermo);   	//+++ Execute shared routine while thread TWO is waiting.	

			//+++ Set genStateSpi to STATE_Potentiometer and wake up thread TWO.
			pthread_mutex_lock(&pSpi->stSync.mutexSpi);
			pSpi->stSync.enStateSpi = CSpi::STATE_Potentiometer;
			pthread_cond_signal(&pSpi->stSync.condPotentiometer);
			pthread_mutex_unlock(&pSpi->stSync.mutexSpi);
		}
	}
	else if(pstThrInf->iThreadNum == CRy::TL_Temporary)
	{
		//+++ Wait for enStateI2c STATE_On.
		pthread_mutex_lock(&pI2c->stSync.mutexI2c);
		while (pI2c->stSync.enStateI2c != CI2c::STATE_On)
			pthread_cond_wait(&pI2c->stSync.condI2c, &pI2c->stSync.mutexI2c);
		pthread_mutex_unlock(&pI2c->stSync.mutexI2c);

		//+++ Here I'm sending data to a receiver without a back confirmation: (local write)->(remote receive), without control of the stream. There isn't the certainty that a sequence of local write will produce the same sequence of remote receive. Instead it's possible that many local write compose a single remote receive if the remote buffer is big enough: this creates problems at receiver. It's better to send a single composite string and the receiver will break it up following instructions.
		string srDelim = "-_-_";
		string srComp = pstThrInf->pcInfoArg + srDelim + 
								to_string(pI2c->I2cMaster(pI2c->stSync.iFdI2c, pI2c->kiAdcAverage, INVALID_SD)) + srDelim + 
								to_string(pI2c->I2cMaster(pI2c->stSync.iFdI2c, pI2c->kiPwmFunction, INVALID_SD)) + srDelim + 
								pRy->stPortHost.srI2cServerPort + srDelim + 
								pRy->stPortHost.srRemSvrPortR3 + srDelim + 
								pRy->stPortHost.srRemSvrPortNi + srDelim;
		WriteToServer(iSock, srComp.c_str());
	}

	pRy->CloseFdErr(iSock);    	//+++ This gets out from its endless loop, recv on laptop side (ReceiveFromMcTp).

	return SUCCESS;
}

int SrNonblockFlag(int iDesc, int iValue)
{
	int iOldflags = fcntl(iDesc, F_GETFL, 0);
	if (iOldflags == -1)	//+++ If reading the flags failed, return error indication now.
		return -1;

	//+++ Set just the flag we want to set.
	if(iValue != 0)
		iOldflags |= O_NONBLOCK;  	//+++ Set the O_NONBLOCK flag of iDesc.
	else
		iOldflags &= ~O_NONBLOCK;  	//+++ Reset the O_NONBLOCK flag of iDesc.

	return fcntl(iDesc, F_SETFL, iOldflags);  	//+++ Store modified flag word in the descriptor.
}

void BtnIncDec(int iFdLas, CRy *pRy)
{
	CUart *pUart = pRy->stUtil.pUart;
	static int siCount = 0;
	if (pRy->enStateDevice == CRy::RyNormal)
	{
		if (digitalRead(pRy->kiButtonInc) == HIGH)
		{
			SendValue(iFdLas, ++siCount, "Pushbutton");
			pthread_mutex_lock(&pUart->stSync.mutexUart);
			while (pUart->stSync.enStateUart != CUart::STATE_NeutralUart)
				pthread_cond_wait(&pUart->stSync.condLan, &pUart->stSync.mutexUart);			
			pUart->stSync.enStateUart = CUart::STATE_Lan;
			pUart->UartPic(pUart->iUartHandle, pUart->asrLocal, ARRAY_SIZE(pUart->asrLocal), iFdLas);
			pUart->stSync.enStateUart = CUart::STATE_NeutralUart;
			pthread_cond_signal(&pUart->stSync.condWebServUart);
			pthread_mutex_unlock(&pUart->stSync.mutexUart);
		}			
		else if (digitalRead(pRy->kiButtonDec) == HIGH)
			SendValue(iFdLas, --siCount, "Pushbutton");
	}	

	delay(500);
}

void SendValue(int iFdLas, int iValue, string srWho)
{
	string srValue = "something to initialize";
	sprintf((char*)srValue.c_str(), "%d", iValue);
	srWho += srValue;

	WriteToServer(iFdLas, srWho.c_str());
}

void WriteToServer(int iFdLas, const char* pcBuf)
{
	int iBytes = write(iFdLas, pcBuf, strlen(pcBuf) + 1); 	//+++ +1 important or buffer gets dirty.
	if(iBytes < 0)
		handle_error_en(iBytes, "write");
	else if(iBytes == 0)
		handle_error("write()");
}