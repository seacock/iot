#include <iostream>
#include <wiringPi.h>
#include <wiringSerial.h>

using namespace std;

#define CTS 5	//+++ Clear to send input.	wiringPi 5. GPIO pin 18. 
#define RTS 6	//+++ Request to send output. wiringPi 6. GPIO pin 22.
char a2cSend[10][16] = { 
	"Monday*********", 
	"Tuesday********", 
	"Wednesday******", 
	"Thursday*******", 
	"Friday*********", 
	"Saturday*******", 
	"Sunday*********", 
	"January********", 
	"February*******", 
	"March**********"
 };

int main(int argc, char *argv[])
{
	if (sizeof(int) == 2)
	{
		printf("Storage size for int must be 4. Program terminates.\n");
		return 0;
	}

	if (wiringPiSetup() == -1)
	{
		cout << "Unable to start wiringPi\n";
		return 1 ;
	}

	pinMode(CTS, INPUT);
	pinMode(RTS, OUTPUT);
	digitalWrite(RTS, HIGH); 
	int handle = serialOpen("/dev/ttyAMA0", 9600);
	if (handle == -1)
		cout << "bad handle" << endl;

	int iData, iCharRx, iDataAvail, iNumCycle;

	cout << endl << endl;

	for (int iCount = 0; iCount < 10; iCount++)
	{
		iCharRx = 0;
		iNumCycle = 0;
		iDataAvail = 0;

		digitalWrite(RTS, LOW);
		
		while (iNumCycle < 300000)   
		{
			iDataAvail = serialDataAvail(handle);
			if (iDataAvail == 39)
				break;
			iNumCycle++;
		}

		cout << "Num of cycles " << iNumCycle << "\tData available " << iDataAvail << endl;

		while (iCharRx < iDataAvail)
		{
			iData = serialGetchar(handle);
			cout << (char)iData;
			iCharRx++;
		}

		digitalWrite(RTS, HIGH); 

		cout << endl << endl;

		while (digitalRead(CTS) == 1);
		serialPuts(handle, a2cSend[iCount]);
		while (digitalRead(CTS) == 0);
	}

	serialClose(handle);

	return 0;
}