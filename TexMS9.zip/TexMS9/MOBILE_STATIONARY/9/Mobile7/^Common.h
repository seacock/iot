/*
 * ^Common.h
 *
 *  Created on: 31 ott 2018
 *      Author: andre
 */

#ifndef COMMON_H_
#define COMMON_H_

#include <xdc/runtime/Error.h>
#include <xdc/runtime/System.h>

/* Board Header file */
#include "Board.h"

/* TI Drivers */
#include <ti/drivers/PIN.h>
#include <ti/drivers/pin/PINCC26XX.h>

#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/drivers/ADC.h>

#include <ti/sysbios/BIOS.h>

#define BOARD_PIN_GREEN_LED CC1310_LAUNCHXL_PIN_GLED
#define STACKSIZE 1024

/* Packet TX Configuration */
#define TX_PAYLOAD_LENGTH 41    //+++ Ad libitum.
#define TX_PAYLOAD_FORMAT 4    //+++ Ad libitum.
#define ADC_ROWS TX_PAYLOAD_FORMAT
#define ADC_COLUMNS TX_PAYLOAD_LENGTH

PIN_Handle DynPinH;  //+++ No static or green LED doesn't toggle.
Semaphore_Handle AdcSemH, TxSemH, SentPacketSemH;   //+++ 1) ClockAdc posts AdcSemH: AdcTf pends on AdcSemH after each conversion. 2) AdcTf posts TxSemH when it has filled AdcPacket, then TxRadioTf, pending on TxSemH, can transmit AdcPacket. 3) TxRadioTf posts SentPacketSemH, on which AdcTf pends: AdcPacket has been transmitted, Adc can fill another AdcPacket.
Task_Struct TxRadioTr, AdcTr;
uint8_t AdcPacket[ADC_ROWS][ADC_COLUMNS];

Void TxRadioTf(UArg arg0, UArg arg1);
void StartTxRadioTf(void);  //+++ Set up and start TxRadioTf task.

#endif /* COMMON_H_ */
