/*
 *  ======== ^Primary.c ========
 */

/* Driver Header files */
// #include <ti/drivers/I2C.h>
// #include <ti/drivers/SDSPI.h>
// #include <ti/drivers/SPI.h>
// #include <ti/drivers/UART.h>
// #include <ti/drivers/Watchdog.h>

#include <^Common.h>

void StartDisplayTf(void);

//+++ Dynamic pin configuration. Application pin configuration tables. For input isn't possible for now to declare a single array...
PIN_Config LedPinCfg[] = {
    BOARD_PIN_RED_LED | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
    BOARD_PIN_GREEN_LED | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
    PIN_TERMINATE
};

PIN_Config InputPinCfg[] = {
    CC1310_LAUNCHXL_DIO12 | PIN_INPUT_EN | PIN_PULLUP | PIN_IRQ_DIS,
    PIN_TERMINATE
};

PIN_Config Button0PinCfg[] = {
    Board_PIN_BUTTON0 | PIN_INPUT_EN | PIN_PULLUP | PIN_IRQ_NEGEDGE,
    PIN_TERMINATE
};

PIN_Config Button1PinCfg[] = {
    Board_PIN_BUTTON1 | PIN_INPUT_EN | PIN_PULLUP | PIN_IRQ_NEGEDGE,
    PIN_TERMINATE
};

PIN_State LedPinState, InputPinState, Button0PinState, Button1PinState;
Clock_Struct WireClock; //+++ Clock used for debounce logic.

void WireClockCb(UArg arg)
{
//    PIN_Handle buttonHandle = (PIN_State*)arg;//---
    Clock_stop(WireClockH); //+++ Stop the button clock.

    /* Check that there is active button for debounce logic*/
    if (ActiveWirePinId != PIN_TERMINATE)
    {
        /* Debounce logic, only toggle if the button is still pushed (low) */
        if (!PIN_getInputValue(ActiveWirePinId))
        {
            /* Toggle LED based on the button pressed */
            switch (ActiveWirePinId)
            {
            case CC1310_LAUNCHXL_DIO12:
                PIN_setOutputValue(LedPinH, BOARD_PIN_GREEN_LED, !PIN_getOutputValue(BOARD_PIN_GREEN_LED)); //+++
                Semaphore_post(DisplaySemH);   //+++ Post to semaphore.//---
                break;
            default:
                /* Do nothing */
                break;
            }
        }
    }

//    PIN_setConfig(buttonHandle, PIN_BM_IRQ, ActiveWirePinId | PIN_IRQ_NEGEDGE); //+++ Re-enable interrupts to detect button release.//---
    ActiveWirePinId = PIN_TERMINATE;    //+++ Set ActiveWirePinId to none...
}

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    /* Call driver init functions */
    //GPIO_init();
    // I2C_init();
    // SDSPI_init();
    // SPI_init();
    // UART_init();
    // Watchdog_init();

    LedPinH = PIN_open(&LedPinState, LedPinCfg);    //+++ Open pin configuration table.
    if (LedPinH == NULL)
        while(1);

    PIN_setOutputValue(LedPinH, BOARD_PIN_GREEN_LED, !PIN_getOutputValue(BOARD_PIN_GREEN_LED)); //+++ Toggle pin to indicate TX.

    InputPinH = PIN_open(&InputPinState, InputPinCfg);    //+++ Open pin configuration table.
    if (InputPinH == NULL)
        while(1);

    PIN_registerIntCb(InputPinH, CC1310_LAUNCHXL_DIO12Cb);//---
    PIN_setInterrupt(InputPinH, CC1310_LAUNCHXL_DIO12 | PIN_IRQ_DIS);//---

    Button0PinH = PIN_open(&Button0PinState, Button0PinCfg);    //+++ Open pin configuration table.
    if (Button0PinH == NULL)
        while(1);

    PIN_registerIntCb(Button0PinH, Board_PIN_BUTTON0Cb);//---
    PIN_setInterrupt(Button0PinH, Board_PIN_BUTTON0 | PIN_IRQ_NEGEDGE);//---

    Button1PinH = PIN_open(&Button1PinState, Button1PinCfg);    //+++ Open pin configuration table.
    if (Button1PinH == NULL)
        while(1);

    PIN_registerIntCb(Button1PinH, Board_PIN_BUTTON1Cb);//---
    PIN_setInterrupt(Button1PinH, Board_PIN_BUTTON1 | PIN_IRQ_NEGEDGE);//---

    //+++ Semaphore initialization.
    Semaphore_Params_init(&DisplaySemParams);
    Semaphore_construct(&DisplaySemStruct, 0, &DisplaySemParams);
    DisplaySemH = Semaphore_handle(&DisplaySemStruct);

    /* Open Display Driver */
    Display_init(); //+++ Not necessary.
    Display_Params displayParams;
    Display_Params_init(&displayParams);
    DisplayH = Display_open(Display_Type_UART, NULL);

    StartDisplayTf();//---

    /* Construct clock for debounce */
    Clock_Params clockParams;
    Clock_Params_init(&clockParams);
//    clockParams.arg = (UArg)InputPinH;//--- too long printing, it's better so
    Clock_construct(&WireClock, WireClockCb, 0, &clockParams);
    WireClockH = Clock_handle(&WireClock);

    while (1) {
    }
}
