#include "Spi.h"
#include "Ry.h"
#include "SharA.h"
#include <wiringPiSPI.h>
#include "ColorText.h"

#define SPI_MSG_LENGTH_TI 30
#define SPI_MSG_LENGTH_RY (SPI_MSG_LENGTH_TI - 1)
#define HEAD_SPACES 2

unsigned char aucMasterMsg[13][SPI_MSG_LENGTH_RY] = {	"Din don campanon", 
														"sete muneghe sul balcon:", 
														"una a stira,", 
														"una a lava,", 
														"una a fa capei de paja,", 
														"una a speta so mario,", 
														"una a fa el pan boio", 
														"sensa oio, sensa sal.", 
														"Sue rive del canal pasa do", 
														"fanti co do cavai bianchi.", 
														"Pasa a guera!", 
														"Tuti zo par tera!",
														"-------------------------"
													};
int iCount = 0;

CSpi::CSpi(CRy *pRaspberry)
{
	pRy = pRaspberry;
	uiNumOfSpiCalls = 0;
}

CSpi::~CSpi()
{
}

//+++ The delay between each of this calls must be shorter than TIMER3_PERIOD of Pic24 or the game doesn't work.
void CSpi::SpiMaster()
{
	unsigned char aucMasterBuf[SPI_MSG_LENGTH_RY], *pucMasterBuf;
	strcpy((char*)aucMasterBuf, (char*)aucMasterMsg[iCount++]);
	if (iCount == 13)
		iCount = 0;

	CColorText coltRed(CColorText::RED);
	wiringPiSPIDataRW(kiSpiChannel, aucMasterBuf, SPI_MSG_LENGTH_RY);
	pucMasterBuf = aucMasterBuf;
	pucMasterBuf += HEAD_SPACES;
	coltRed.ss << "----- " << pucMasterBuf << " received first--------" << endl;
	cout << coltRed;

	CColorText coltBlue(CColorText::BLUE);	
	unsigned char yyy = ' ';
	wiringPiSPIDataRW(kiSpiChannel, &yyy, 1);	//+++ That's it.
	coltBlue.ss << "----- " << yyy << " received second--------" << endl;
	cout << coltBlue;

#ifdef _TALKATIVE_
	cout << "----- " << uiNumOfSpiCalls << " number of SPI calls--------" << endl;
	uiNumOfSpiCalls++;
#endif // _TALKATIVE_
}