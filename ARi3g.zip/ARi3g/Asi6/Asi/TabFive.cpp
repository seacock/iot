// TabFive.cpp : implementation file
//

#include "stdafx.h"
#include "Asi.h"
#include "TabFive.h"
#include "afxdialogex.h"

DWORD WINAPI TomcatTp(LPVOID lpParam);
DWORD WINAPI TomcatFinishTp(LPVOID lpParam);

// CTabFive dialog

IMPLEMENT_DYNAMIC(CTabFive, CDlgExBase)

CTabFive::CTabFive(CWnd* pParent /*=NULL*/)
	: CDlgExBase(IDD_TAB_FIVE, pParent)
	, jrbRemoteSvrPort(0)
{
}

CTabFive::~CTabFive()
{
	delete[] pstWebTie;
}

void CTabFive::DoDataExchange(CDataExchange* pDX)
{
	CDlgExBase::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_ED_TWEM, jedThrWebMon);
	DDX_Control(pDX, IDC_ED_TWHOS, jedThreadWebHostName);
	DDX_Control(pDX, IDC_BN_WEB, jbnWeb);
	DDX_Radio(pDX, IDC_RB_REMOT3, jrbRemoteSvrPort);
	DDV_MinMaxInt(pDX, jrbRemoteSvrPort, 0, 1);
	DDX_Control(pDX, IDC_RB_REMOT3, jrbRemot3);
}

BEGIN_MESSAGE_MAP(CTabFive, CDlgExBase)
	ON_BN_CLICKED(IDC_BN_WEB, &CTabFive::OnBnClickedBnWeb)
	ON_EN_UPDATE(IDC_ED_TWHOS, &CTabFive::OnEnUpdateEdTWHos)	
	ON_BN_CLICKED(IDC_RB_REMOT3, &CTabFive::OnBnClickedRbRemot3)
	ON_BN_CLICKED(IDC_RB_NOIP, &CTabFive::OnBnClickedRbNoip)
	ON_REGISTERED_MESSAGE(RG_WM_INPUT_WEB, &CTabFive::OnInputWeb)
	ON_REGISTERED_MESSAGE(RG_WM_ED_T_WEM, &CTabFive::OnEdTWeM)	
END_MESSAGE_MAP()

// CTabFive message handlers

BOOL CTabFive::OnInitDialog()
{
	CDlgExBase::OnInitDialog();

	// TODO:  Add extra initialization here
	iBatch = 0;
	pstWebTie = new WebTie[NUM_WEB_THREADS];	
	jbnWeb.EnableWindow(false);
	jedThreadWebHostName.EnableWindow(false);
	jrbRemot3.EnableWindow(false);
	GetDlgItem(IDC_RB_NOIP)->EnableWindow(false);

	return TRUE;  // return TRUE unless you set the focus to a control
				  // EXCEPTION: OCX Property Pages should return FALSE
}

void CTabFive::OnBnClickedRbRemot3()
{
	// TODO: Add your control notification handler code here
	Hook &RstHook = theApp.stHook;
	srPortNumber = RstHook.stServerI2c.acWebPortR3;
}

void CTabFive::OnBnClickedRbNoip()
{
	// TODO: Add your control notification handler code here
	Hook &RstHook = theApp.stHook;
	srPortNumber = RstHook.stServerI2c.acWebPortNi;
}

void CTabFive::OnBnClickedBnWeb()
{
	// TODO: Add your control notification handler code here
	jbnWeb.EnableWindow(false);
	CString strHostName;
	jedThreadWebHostName.GetWindowTextW(strHostName);
	srHostName = WsToStUtf8(strHostName.GetBuffer());
	Hook &RstHook = theApp.stHook;
	
	sockaddr_in *sockaddr_ipv4 = NULL;
	if (SocketAddr(StToWsUtf8(GetRuntimeClass()->m_lpszClassName), (char*)srHostName.c_str(), (char*)srPortNumber.c_str(), &sockaddr_ipv4) == ERROR_COMM)
		return;

	ULONG ulIPv4Ta = sockaddr_ipv4->sin_addr.S_un.S_addr;

	for (int iCount = 0; iCount < NUM_WEB_THREADS; iCount++)
	{
		pstWebTie[iCount].iThreadNum = iCount;
		pstWebTie[iCount].pcHostName = srHostName.c_str();
		pstWebTie[iCount].pcPortNumber = srPortNumber.c_str();
		pstWebTie[iCount].ulIPv4Ta = ulIPv4Ta;
		pstWebTie[iCount].wsrError = L"";
		pstWebTie[iCount].wsrTotOut = L"";
		pstWebTie[iCount].hTomcatTp = CreateThread(NULL, 0, TomcatTp, &pstWebTie[iCount], 0, NULL);
	}
	CreateThread(NULL, 0, TomcatFinishTp, this, 0, NULL);
}

void CTabFive::OnEnUpdateEdTWHos()
{
	// TODO:  If this is a RICHEDIT control, the control will not send this notification unless you override the CDlgExBase::OnInitDialog() function to send the EM_SETEVENTMASK message to the control with the ENM_UPDATE flag ORed into the lParam mask.
	// TODO:  Add your control notification handler code here
	CString strHostName;
	jedThreadWebHostName.GetWindowTextW(strHostName);
	bool bEmptyHostName = strHostName.IsEmpty();
	jbnWeb.EnableWindow(!bEmptyHostName);
}

LRESULT CTabFive::OnInputWeb(WPARAM wParam, LPARAM lParam)
{
	Hook &RstHook = theApp.stHook;
	srPortNumber = RstHook.stServerI2c.acWebPortR3;
	jedThreadWebHostName.EnableWindow();
	jrbRemot3.EnableWindow();
	GetDlgItem(IDC_RB_NOIP)->EnableWindow();

	return NO_ERROR;
}

LRESULT CTabFive::OnEdTWeM(WPARAM wParam, LPARAM lParam)
{
	wsrThrWebMon += (const wchar_t*)wParam + (wstring)L"\r\n";
	jedThrWebMon.SetWindowTextW(wsrThrWebMon.c_str());
	return NO_ERROR;
}