#pragma once

#include "CustEdit.h"

#define NUM_SOCKETS 4

// CTabOne dialog

class CTabOne : public CDlgExBase
{
	DECLARE_DYNAMIC(CTabOne)
public:
	CButton jbnShut;
	CCustEdit jedCuSocTh;	//+++ Socket thread.
	string srPortNumber;	//+++ This server port: host byte order.
	u_short usPortTcpIp;	//+++ Laptop server port: TCP/IP network byte order.
	ULONG ulIPv4Addr;	//+++ Laptop IPv4 address.
	CTabOne(CWnd* pParent = NULL);   // standard constructor
	virtual ~CTabOne();
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedBnLan();
	afx_msg void OnBnClickedBnShut();
	afx_msg void OnEnUpdateEdPort();
	void ShutCloseSocket(SOCKET sock);	
// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_TAB_ONE };
#endif
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	DECLARE_MESSAGE_MAP()
private:
	CButton jbnLanServerStart;	
	CEdit jedSyPrMt;	//+++ Main thread system parameters.	
	CEdit jedLanServerPortNumber;
	wstring wsrMtrSocThr;
	wstring wsrMtrMain;
	string srHostName;	//+++ This server name: host byte order.	
	LRESULT OnEdSocT(WPARAM wParam, LPARAM lParam);	//+++ Socket thread.
};

static UINT RG_WM_ED_SOC_T = RegisterWindowMessage(_T("EDIT SOCKET THREAD"));