/*
 * ^Input.c
 *
 *  Created on: 04 dic 2018
 *      Author: andre
 */

#include <^Common.h>

void CC1310_LAUNCHXL_DIOCb(PIN_Handle handle, PIN_Id pinId)
{
    ActiveWirePinId = pinId;    //+++ Set current pinId to active.
    Clock_start(DInClockH);
}
