/* 
 * File:   Spi.h
 * Author: Administrator
 *
 * Created on 19 April 2018, 17:20
 */

#ifndef SPI_H
#define	SPI_H

#ifdef	__cplusplus
extern "C" {
#endif
    
#include <stdbool.h>    //+++ For bool. 
                        
//+++ Commands from Raspberry to retrieve AD converted physical quantities.
#define CMD_UB_P 0x01   //+++ Upper byte of potentiometer. Defined in RyS, Sciupa.
#define CMD_LB_P 0x02   //+++ Lower byte of potentiometer. Defined in RyS, Sciupa.
#define CMD_UB_T 0x04   //+++ Upper byte of thermometer. Defined in RyS, Sciupa.
#define CMD_LB_T 0x05   //+++ Lower byte of thermometer. Defined in RyS, Sciupa.
    
int mainSpi(void);
void ConfigSpiPortPins(void);   //+++ Configure port pins for SPI.
void ConfigSpiPPS(void);    //+++ Peripheral Pin Select for SPI.
void Timer3TypeA(void); //+++ 16-Bit Timer Using System Clock (internal instruction cycle).
void SetupSpi(void);    //+++ Set up Serial Peripheral Interface.
void ResetSpi(bool bTimeOut);
void ZeroAve(int iCount);   //+++ Zero all variables for average.
void SendValue(unsigned char uchVal); //+++

#ifdef	__cplusplus
}
#endif

#endif	/* SPI_H */