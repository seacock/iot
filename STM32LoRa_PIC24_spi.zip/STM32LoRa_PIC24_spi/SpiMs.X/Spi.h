/* 
 * File:   Spi.h
 * Author: Administrator
 *
 * Created on 19 April 2018, 17:20
 */

#ifndef SPI_H
#define	SPI_H

#ifdef	__cplusplus
extern "C" {
#endif
    
#include <stdbool.h>    //+++ For bool. 
    
int mainSpi(void);
void ConfigSpiPortPins(void);   //+++ Configure port pins for SPI.
void ConfigSpiPPS(void);    //+++ Peripheral Pin Select for SPI.
void SetupSpi(void);    //+++ Set up Serial Peripheral Interface.

#ifdef	__cplusplus
}
#endif

#endif	/* SPI_H */