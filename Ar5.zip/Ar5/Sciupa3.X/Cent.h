/* 
 * File:   Cent.h
 * Author: Administrator
 *
 * Created on 23 April 2018, 17:40
 */

#ifndef CENT_H
#define	CENT_H

#ifdef	__cplusplus
extern "C" {
#endif

#include <xc.h> // include processor files - each processor file is guarded.

#ifdef	__cplusplus
}
#endif

#endif	/* CENT_H */

