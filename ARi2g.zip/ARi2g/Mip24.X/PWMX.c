/*
 * File:   PWMX.c
 * Author: MeMyselfAndI
 *
 * Created on 7 agosto 2016, 19.26
 */

#include "PWMX.h"

int mainPWMX(void) 
{

    TRISBbits.TRISB11 = OUTPUT_PIN;  //+++ RP11-RB11: hwPin = 22. PWM output.
    PORTBbits.RB11 = 0;
    
    PPSUnLock;  //+++ Unlock the PPS functionality.
    iPPSOutput(OUT_PIN_PPS_RP11, OUT_FN_PPS_OC1);   //+++ Out Compare1: RP11.???
    PPSLock;    //+++ Lock the PPS functionality.

    OC1CON1 = 0;    //+++ Clear off the control bits initially.
    OC1CON2 = 0;    //+++ Clear off the control bits initially.
    OC1CON1bits.OCTSEL = 0x07;  //+++ Peripheral ck is ck input to OC module.
    OC1R = 0;   //+++ Based on the waveform requirements and the system clock.
    OC1RS = PWM_PERIOD;     //+++ Period of the waveform.
    OC1CON2bits.SYNCSEL = 0x1F;     //+++ Synchronization source as itself.
    OC1CON1bits.OCM = 6;    //+++ Select and start the Edge Aligned PWM mode.
    
    return 0;
}