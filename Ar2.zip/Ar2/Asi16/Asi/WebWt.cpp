#include "stdafx.h"
#include "Asi.h"
#include <vector>

int SocketConn(CTabFive::WebTie *pstWebTie);
void CommServerRead(int iSockfd, CTabFive::WebTie *pstWebTie);
int MsgWsaW(wstring wsrMsg, bool bCleanup, CTabFive::WebTie *pstWebTie);
DWORD WINAPI T_Tomcat(LPVOID lpParam);
DWORD WINAPI T_TomcatFinish(LPVOID lpParam);
extern CAsiApp theApp;

DWORD WINAPI T_Tomcat(LPVOID lpParam)
{
	wstring wsrMonSoc = L"T_Tomcat\r\n";
	wsrMonSoc += theApp.ThrAffinity(12);
	CTabFive::WebTie *pstWebTie = (CTabFive::WebTie*)lpParam;	

	//+++ Initialize Winsock
	WSADATA wsaData;
	int iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
	if (iResult != NO_ERROR)
	{
		wsrMonSoc += L"WSAStartup failed with error: " + to_wstring(iResult) + L"\r\n";
		return ERROR_COMM;
	}

	pstWebTie->srIO = "first_name=P";
	if (SocketConn(pstWebTie) == ERROR_COMM)	//+++ WSACleanup already called by SocketConn in case of error.
		return ERROR_COMM;
	Sleep(100);
	pstWebTie->srIO = "first_name=T";
	if (SocketConn(pstWebTie) == ERROR_COMM)	//+++ WSACleanup already called by SocketConn in case of error.
		return ERROR_COMM;
	Sleep(100);

	WSACleanup();

	return 0;
}

int SocketConn(CTabFive::WebTie *pstWebTie)
{
	//+++ Create a SOCKET for connecting to server.
	Hook &RstHook = theApp.stHook;
	SOCKET ConnectSocket = RstHook.pTabOne->TieSockAddr((char*)pstWebTie->pcHostName, (char*)pstWebTie->pcPortNumber, CLIENT_SIDE);
	CommServerRead((int)ConnectSocket, pstWebTie);

	if (closesocket(ConnectSocket) == SOCKET_ERROR)
		return MsgWsaW(L"closesocket failed with error: " + to_wstring(WSAGetLastError()) + L"\r\n", true, pstWebTie);

	return 0;
}

void CommServerRead(int iSockfd, CTabFive::WebTie *pstWebTie)
{
	vector<char> tchRecvLine(MAX_READ + 1);	//+++ Char array would do as well.
	string srPage = "/Gizmo/SensVa", srHost = pstWebTie->pcHostName + (string)":" + pstWebTie->pcPortNumber, srPostData = pstWebTie->srIO, srRecv = "";	//+++ Server's page to ask for; name of server; data to send to server; response from server.

																																						//+++ Form request.
	string srSendLine = "POST " + srPage + " HTTP/1.0\r\n" + "Host: " + srHost + "\r\n" +
		"Content-type: application/x-www-form-urlencoded\r\n" + "Content-length: " + to_string(srPostData.length()) + "\r\n\r\n" + srPostData + "\r\n";

	if (send(iSockfd, srSendLine.c_str(), (int)srSendLine.size(), 0) >= 0)	 //+++ Write the request.
		while (recv(iSockfd, &tchRecvLine[0], MAX_READ, 0) > 0)	 //+++ Read the response.
			srRecv += tchRecvLine.data();

	basic_string <char>::size_type kIndex;
	const char *pcStart = "\r\n\r\n";	//+++ Trailing chars to remove.
	kIndex = srRecv.find(pcStart);
	pstWebTie->srIO = "Something wrong...";
	if (kIndex != string::npos)
		pstWebTie->srIO = srRecv.substr(kIndex + strlen(pcStart)) + "\r\n";	//+++ Remove the trailing chars.

	pstWebTie->wsrTotOut += StToWsUtf8(pstWebTie->srIO);
}

DWORD WINAPI T_TomcatFinish(LPVOID lpParam)
{
	theApp.ThrAffinity(12);
	CTabFive *pTabFive = (CTabFive*)lpParam;
	wstring wsrBatch = L"		End batch-------------------------------------------------------------\r\n";

	HANDLE ahT_Tomcat[NUM_WEB_THREADS];	//+++ Handle to T_Tomcat.
	for (int iCount = 0; iCount < NUM_WEB_THREADS; iCount++)
		ahT_Tomcat[iCount] = pTabFive->pstWebTie[iCount].hT_Tomcat;

	//+++ Wait till all T_Tomcat instances exit.
	DWORD dwWaitResult = WaitForMultipleObjects(NUM_WEB_THREADS, ahT_Tomcat, TRUE, INFINITE);
	switch (dwWaitResult)
	{
	case WAIT_OBJECT_0:
		for (int iCount = 0; iCount < NUM_WEB_THREADS; iCount++)	//+++ Close thread procedure handles.			
		{
			CloseHandle(ahT_Tomcat[iCount]);
			pTabFive->SendMessageW(RG_WM_ED_T_WEM, (WPARAM)pTabFive->pstWebTie[iCount].wsrTotOut.c_str());
			pTabFive->SendMessageW(RG_WM_ED_T_WEM, (WPARAM)pTabFive->pstWebTie[iCount].wsrError.c_str());
		}
		pTabFive->iBatch++;
		wsrBatch = to_wstring(pTabFive->iBatch) + wsrBatch;
		pTabFive->SendMessageW(RG_WM_ED_T_WEM, (WPARAM)wsrBatch.c_str());
		break;
	}
	pTabFive->jbnWeb.EnableWindow();

	return 0;
}

int MsgWsaW(wstring wsrMsg, bool bCleanup, CTabFive::WebTie *pstWebTie)
{
	pstWebTie->wsrError += wsrMsg;

	if (bCleanup == true)
		WSACleanup();

	return ERROR_COMM;
}