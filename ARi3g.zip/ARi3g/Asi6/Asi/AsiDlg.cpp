// AsiDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Asi.h"
#include "AsiDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

DWORD WINAPI CloseConnectTp(LPVOID lpParam);	//+++ Worker thread: closes communication with RaspberryPi2.

// CAboutDlg dialog used for App About

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()

// CAsiDlg dialog

CAsiDlg::CAsiDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_ASI_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CAsiDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_TAB_FRAME, jtabFrame);	//+++ Added manually.
	DDX_Control(pDX, IDC_PIC_LIGHT, jpicLight);
}

BEGIN_MESSAGE_MAP(CAsiDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_REGISTERED_MESSAGE(RG_WM_PIC_LIGHT, &CAsiDlg::OnPicLight)
END_MESSAGE_MAP()

// CAsiDlg message handlers

BOOL CAsiDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	hShutI2cMaTxEv = CreateEvent(NULL, TRUE, FALSE, NULL);
	hShutI2cAuTxEv = CreateEvent(NULL, TRUE, FALSE, NULL);

	Hook &RstHook = theApp.stHook;
	RstHook.hCloseConnectTp = NULL;
	RstHook.hI2cMaTxTp = NULL;
	RstHook.hConnectTp = NULL;

	//+++ Insert 5 tabs and initialize the container of tabbed dialogs.
	jtabFrame.InsertItem(0, _T("Tab one"));
	jtabFrame.InsertItem(1, _T("Tab two"));
	jtabFrame.InsertItem(2, _T("Tab three"));
	jtabFrame.InsertItem(3, _T("Tab four"));
	jtabFrame.InsertItem(4, _T("Tab five"));

	jtabFrame.Init();

	hBmpGreen = LoadBitmap(GetModuleHandle(NULL), MAKEINTRESOURCE(IDB_GREEN));
	SendDlgItemMessage(IDC_PIC_LIGHT, STM_SETIMAGE, IMAGE_BITMAP, (LPARAM)hBmpGreen);
	hBmpRed = LoadBitmap(GetModuleHandle(NULL), MAKEINTRESOURCE(IDB_RED));
	hBmpIndigo = LoadBitmap(GetModuleHandle(NULL), MAKEINTRESOURCE(IDB_INDIGO));

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CAsiDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		if (nID == SC_CLOSE)
		{
			ShutComm(false);
			CloseHandle(hShutI2cMaTxEv);
			CloseHandle(hShutI2cAuTxEv);
		}

		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CAsiDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CAsiDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CAsiDlg::ShutComm(bool bDispatchMsg)
{
	SetEvent(hShutI2cMaTxEv);	//+++ Stop waiting for commands and exit worker thread I2cMaTxTp.
	SetEvent(hShutI2cAuTxEv);	//+++ Stop waiting for timer and exit worker thread I2cAuTxTp.

	Hook &RstHook = theApp.stHook;
	RstHook.hCloseConnectTp = CreateThread(NULL, 0, CloseConnectTp, &RstHook, 0, NULL);
	if (bDispatchMsg == true)
		RstHook.pTabOne->SendMessageW(RG_WM_ED_SOC_T, (WPARAM)L"CloseConnectTp\r\n");	//+++ SendMessageW must stay outside of worker thread if it is waited by WaitForSingleObject or WaitForMultipleObjects and dispatches to user interface.

																						//+++ Never use WaitForMultipleObjects or WaitForSingleObject in user interface thread, as that freezes the message queue and worker threads can't communicate: application stuck. Examine instead message queue with PeekMessage.
	BOOL boDone = FALSE;
	MSG msg;

	while (!boDone)
		while (PeekMessage(&msg, m_hWnd, RG_WM_COMM_ABATED, RG_WM_COMM_ABATED, PM_REMOVE))
			if (msg.message == RG_WM_COMM_ABATED)
				boDone = TRUE;

	if (bDispatchMsg == true)
		for (int iCount = 0; iCount < ARRAY_SIZE(RstHook.astChann); iCount++)
			if (RstHook.astChann[iCount].pCommon != NULL)
				RstHook.astChann[iCount].pCommon->
				SendMessageW(RstHook.astChann[iCount].uiWmEdMonitor, (WPARAM)RstHook.astChann[iCount].wsrMonitor.c_str());
}

LRESULT CAsiDlg::OnPicLight(WPARAM wParam, LPARAM lParam)
{
	if (wParam == GREEN_LIGHT)
		SendDlgItemMessage(IDC_PIC_LIGHT, STM_SETIMAGE, IMAGE_BITMAP, (LPARAM)hBmpGreen);
	else if (wParam == RED_LIGHT)
		SendDlgItemMessage(IDC_PIC_LIGHT, STM_SETIMAGE, IMAGE_BITMAP, (LPARAM)hBmpRed);
	else if (wParam == INDIGO_LIGHT)
		SendDlgItemMessage(IDC_PIC_LIGHT, STM_SETIMAGE, IMAGE_BITMAP, (LPARAM)hBmpIndigo);

	return NO_ERROR;
}