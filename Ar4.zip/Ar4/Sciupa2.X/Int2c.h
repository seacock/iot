/* 
 * File:   Int2c.h
 * Author: Administrator
 *
 * Created on 22 April 2018, 10:23
 */

#ifndef INT2C_H
#define	INT2C_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "ShaDe.h"
#include <i2c.h>
#include <stdlib.h>
    
#if __XC16_VERSION__ >= 0x0401
#undef _ISR
#define _ISR __attribute__((interrupt, auto_psv))
#endif

#define SLAVE_ADDRESS 0x07  //+++ Slave Address: Whatever between 0x00 and 0x77.
#define SLAVE_MODE 0    //+++
#define ADC_AVERAGE 110 //+++ Laptop ASUS sends it to Raspberry that sends here. Defined in LaT, Mip.
#define ADC_LASTVAL 120 //+++ Laptop ASUS sends it to Raspberry that sends here. Default at startup. Defined in LaT, Ry, Mip.

unsigned char guchInOut; //+++ Parameters Input Output Raspberry.

int mainI2CsX(void);
void InitI2C(void);
void ResetSpi(void);

#ifdef	__cplusplus
}
#endif

#endif	/* INT2C_H */

