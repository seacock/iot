/*
 * adc.c
 *
 *  Created on: 21 ott 2018
 *      Author: andre
 */

#include <^Adc.h>
#include <^Common.h>

#pragma DATA_ALIGN(AdcTaskStack, 8)  /* Make sure we have nice 8-byte alignment on the stack to avoid wasting memory */
static uint8_t AdcTaskStack[STACKSIZE];

Void AdcTf(UArg arg0, UArg arg1)
{
    ADC_Handle AdcH;
    ADC_Params AdcParams;
    uint16_t adcValue, uiCount = 0;
    int_fast16_t res;
    ADC_Params_init(&AdcParams);//---
    while (1) {
        /* Open ADC Driver */
//        ADC_Params_init(&AdcParams);
        AdcH = ADC_open(Board_ADC3, &AdcParams);
        if (AdcH == NULL)
            while (1);// Error initializing ADC channel Board_ADC3

        res = ADC_convert(AdcH, &adcValue);
        if (res == ADC_STATUS_SUCCESS) {
            PIN_setOutputValue(DynPinH, CC1310_LAUNCHXL_DIO21, !PIN_getOutputValue(CC1310_LAUNCHXL_DIO21));
            AdcPacket[0][uiCount] = adcValue >> 8;
            AdcPacket[1][uiCount] = adcValue;
        }
        ADC_close(AdcH);

        /* Open ADC Driver */
//        ADC_Params_init(&AdcParams);
        AdcH = ADC_open(Board_ADC4, &AdcParams);
        if (AdcH == NULL)
            while (1);// Error initializing ADC channel Board_ADC4

        res = ADC_convert(AdcH, &adcValue);
        if (res == ADC_STATUS_SUCCESS) {
            PIN_setOutputValue(DynPinH, CC1310_LAUNCHXL_DIO21, !PIN_getOutputValue(CC1310_LAUNCHXL_DIO21));
            AdcPacket[2][uiCount] = adcValue >> 8;
            AdcPacket[3][uiCount] = adcValue;
        }
        ADC_close(AdcH);

        uiCount++;
        if (uiCount == ADC_COLUMNS)
        {
            uiCount = 0;
            Semaphore_post(TxSemH);
            Semaphore_pend(SentPacketSemH, BIOS_WAIT_FOREVER);
            PIN_setOutputValue(DynPinH, CC1310_LAUNCHXL_DIO15, !PIN_getOutputValue(CC1310_LAUNCHXL_DIO15));
        }

        Semaphore_pend(AdcSemH, BIOS_WAIT_FOREVER);
    }
}

void StartAdcTf(void)
{
    /* Set up AdcTf task */
    Task_Params taskParams;
    Task_Params_init(&taskParams);
    taskParams.stackSize = STACKSIZE;
    taskParams.priority = 5;
    taskParams.stack = &AdcTaskStack;

    Task_construct(&AdcTr, AdcTf, &taskParams, NULL);
}
