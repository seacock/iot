/*
 * ^Common.h
 *
 *  Created on: 31 ott 2018
 *      Author: andre
 */

#ifndef COMMON_H_
#define COMMON_H_

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/knl/Clock.h>//---
#include <ti/display/Display.h>

/* TI Drivers */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/PIN.h>
#include <ti/drivers/pin/PINCC26XX.h>
#include <ti/drivers/rf/RF.h>

/* Board Header files */
#include "Board.h"

#define BOARD_PIN_GREEN_LED CC1310_LAUNCHXL_PIN_GLED
#define BOARD_PIN_RED_LED CC1310_LAUNCHXL_PIN_RLED
#define STACKSIZE 1024   //---

/* Packet RX Configuration */
#define RX_BUFFER_ENTRIES 5    //+++ Ad libitum.
#define TX_PAYLOAD_LENGTH 41    //+++ Starting point: Tx packet feature.
#define TX_PAYLOAD_FORMAT 4 //+++ Starting point: Tx packet feature.
#define QUEUE_RX RX_BUFFER_ENTRIES  //+++ For BUFFER_SIZE_BYTES, aucRxBuffer and QueueRx.
#define NUM_APPENDED_BYTES 2    //+++ The Data Entries data field will contain: 1 Header byte (RF_cmdPropRx.rxConf.bIncludeHdr = 0x1); Max 30 payload bytes; 1 status byte (RF_cmdPropRx.rxConf.bAppendStatus = 0x1) .
#define DATA_SECTION_SIZE (TX_PAYLOAD_LENGTH + NUM_APPENDED_BYTES) //+++ Must be word-aligned.
#define ENTRY_HEADER_SIZE 7 //+++ Ad libitum.
#define BUFFER_SIZE_BYTES (QUEUE_RX * (ENTRY_HEADER_SIZE + DATA_SECTION_SIZE))
#define COMPOSED_LENGTH (TX_PAYLOAD_LENGTH * TX_PAYLOAD_FORMAT * RX_BUFFER_ENTRIES / 2)
#define RAW_LENGTH (TX_PAYLOAD_LENGTH * TX_PAYLOAD_FORMAT * RX_BUFFER_ENTRIES * 2)  //+++ Oversized or isn't enough.
#define WIDE_SIZE 2

Display_Handle DisplayH;
PIN_Handle LedPinH, InputPinH, Button0PinH, Button1PinH; //+++ No static or green LED doesn't toggle.
Clock_Handle WireClockH;    //+++ Clock used for debounce logic.
PIN_Id ActiveWirePinId; //+++ PIN_Id for active button (in debounce period).
Semaphore_Handle DisplaySemH; //+++ Semaphore to block slow display, leaving scheduler to decide.//---
RF_Object rfObject;
RF_Handle rfHandle;//---
dataQueue_t queue;  //+++ Receive dataQueue for RF Core to fill in data.
#pragma DATA_ALIGN(aucRxBuffer, 4)   //+++ Buffer contains all Data Entries for receiving data. Pragmas needed to make sure aucRxBuffer is 4 byte aligned (requirement from the RF Core).
uint8_t aucRxBuffer[BUFFER_SIZE_BYTES * WIDE_SIZE];
bool bSynchro;
uint32_t auiComposedP[COMPOSED_LENGTH]; //+++ Each element is composed of a corresponding couple of elements of aucRawPackets.    //--- uint16_t App goes nuts.
uint8_t ucRxPacket[TX_PAYLOAD_LENGTH]; //---NO static
int iReceivedPacket, iComposed; //+++ Index of received single packet. 2) Index of composed packet.
Semaphore_Struct DisplaySemStruct;
Semaphore_Params DisplaySemParams;
uint8_t aucRawPackets[RAW_LENGTH]; //+++ 1) The sequence of RX_BUFFER_ENTRIES couples received. Apart the first sync couple, each remaining couple is upper and lower byte of Adc.
int iTwoSteps, iStartBound;  //+++ 1) Every 2 steps a couple is ready to compose a value for auiComposedP. 2) Position of first element of first packet of couple.

void CC1310_LAUNCHXL_DIO12Cb(PIN_Handle handle, PIN_Id pinId);
void Board_PIN_BUTTON0Cb(PIN_Handle handle, PIN_Id pinId);
void Board_PIN_BUTTON1Cb(PIN_Handle handle, PIN_Id pinId);
void StartRxRfCoTf(void);  //+++ Set up and start RxRfCoTf task.
void StartRxRfSsTf(void);  //+++ Set up and start RxRfSsTf task.

#endif /* COMMON_H_ */
