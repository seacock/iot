/*
 * ^AbsolRx.c
 *
 *  Created on: 24 gen 2019
 *      Author: andre
 */

#include "^Common.h"

/***** Variable declarations *****/
static RF_Object rfObject;
static RF_Handle rfHandle;
/* Buffer which contains all Data Entries for receiving data.
 * Pragmas are needed to make sure this buffer is aligned to a 4 byte boundary (requirement from the RF core).
 */
#pragma DATA_ALIGN(rxDataEntryBuffer, 4)
static uint8_t rxDataEntryBuffer[RF_QUEUE_DATA_ENTRY_BUFFER_SIZE(NUM_DATA_ENTRIES, PAYLOAD_LENGTH, NUM_APPENDED_BYTES)];

/* Receive dataQueue for RF Core to fill in data */
static dataQueue_t dataQueue;
static rfc_dataEntryGeneral_t* currentDataEntry;
static uint8_t packetLength;
static uint8_t* packetDataPointer;

static uint8_t txPacket[PAYLOAD_LENGTH];
static uint8_t rxPacket[PAYLOAD_LENGTH];
static bool bAdjust = false; //+++ Autoadjust.
const float CfPercentThreshold = 0.0001;

static uint32_t uiPacketInterval;
extern uint32_t uiMTimeStampCTB; //+++ Value obtained from TimestampRx, used only once to start communications.
extern int64_t llOffsetMs;	//+++ Value obtained from TimestampRx is used only to start communications. Then it is updated to allow for time drift.
static uint32_t uiTimestampNow, uiMirror; //+++ 1) Present timestamp sent by Tx and measured at intervals DeltaX, to align Tx and Rx RATs. 2) Present timestamp of Rx measured at the same intervals DeltaX of Tx, to align Tx and Rx RATs.
int64_t llDiffOff, llOffsetOld;	//+++ 1) Adjustment addendum for ratConfCmp.timeout . It accounts for frequency drift between Tx RAT and Rx RAT. 2) Hold previous offset to be compared with present offset.
float fAdjustmentFactor = 0.01;	//+++ The smaller the factor, the longer the time of adjustment. Not too small or adjustment never ends.

#pragma DATA_ALIGN(AbsolRxTaskStack, 8)  //+++ 1-byte alignment on the stack to avoid wasting memory.
static uint8_t AbsolRxTaskStack[STACKSIZE];
Task_Struct AbsolRxTr;

RF_RatConfigCompare ratConfCmp;
RF_RatHandle ratHandle;
static Semaphore_Handle hsemAbsolRx;
uint16_t cbRx = 0, cbTx = 0, cbRat = 0; //+++ To check that cbRat is about the same as cbRx and cbTx. If cbRat is much more it only ruins the flow.
#define SLOW 20	//+++ To slow down frequency of flickering of leds.
#define MAX32 4294967296	//+++ 2 pow 32
#define MAX_SPEED 7	//+++ It bears on ratConfCmp.timeout, i.e. frequency of callback. Not more than this or cbRat exceeds too much cbRx and cbTx.

Void AbsolRxTf(UArg arg0, UArg arg1);
static void AbsolRxCb(RF_Handle h, RF_CmdHandle ch, RF_EventMask e);
static void AbsolRxCb1(RF_Handle h, RF_CmdHandle ch, RF_EventMask e);

void onRatTriggered(RF_Handle h, RF_RatHandle rh, RF_EventMask e, uint32_t compareCaptureTime);

void StartAbsolRxTf(void)
{
	Semaphore_Params semParams;
	Semaphore_Params_init(&semParams);
	hsemAbsolRx = Semaphore_create(0, &semParams, NULL);
	if (hsemAbsolRx == NULL) //+++ Check if the handle is valid.
		while(1);

	uiPacketInterval = RF_convertMsToRatTicks(200);	//+++ Set packet interval in RAT ticks.

    Task_Params taskParams;
    Task_Params_init(&taskParams);
    taskParams.stackSize = STACKSIZE;
    taskParams.priority = 2;    //+++ More than 1 or is preempted by while (1) in mainThread.
    taskParams.stack = &AbsolRxTaskStack;
    taskParams.priority = 5;

    Task_construct(&AbsolRxTr, AbsolRxTf, &taskParams, NULL);
}

Void AbsolRxTf(UArg arg0, UArg arg1)
{
	RF_Params rfParams;
	RF_Params_init(&rfParams);
	rfParams.nInactivityTimeout = 50;	//---

	if( RFQueue_defineQueue(&dataQueue, rxDataEntryBuffer, sizeof(rxDataEntryBuffer),
										NUM_DATA_ENTRIES, PAYLOAD_LENGTH + NUM_APPENDED_BYTES))
	{
		/* Failed to allocate space for all data entries */
		PIN_setOutputValue(hDynPin, GREEN_LED, 1);
		PIN_setOutputValue(hDynPin, RED_LED, 1);
		while(1);
	}

	/* Modify CMD_PROP_TX and CMD_PROP_RX commands for application needs */

	//+++ No endTrigger-endTime: only delay and hamper operations.
	RF_cmdPropRx.pQueue = &dataQueue;	//+++ Set the Data Entity queue for received data.
	RF_cmdPropRx.rxConf.bAutoFlushIgnored = 1;	//+++ Discard ignored packets from Rx queue.
	RF_cmdPropRx.rxConf.bAutoFlushCrcErr = 1;	//+++ Discard packets with CRC error from Rx queue.
	RF_cmdPropRx.rxConf.bAppendTimestamp = 1;	//+++ Append RX timestamp to the payload. It can be disabled with adequate changes.//---
	RF_cmdPropRx.maxPktLen = PAYLOAD_LENGTH;	//+++ Implement packet length filtering to avoid PROP_ERROR_RXBUF.
	RF_cmdPropRx.pktConf.bRepeatOk = 0;	//+++ End RX operation when a packet is received correctly.
	RF_cmdPropRx.pktConf.bRepeatNok = 0;	//+++ End RX operation when a packet is received incorrectly.
	RF_cmdPropRx.startTrigger.triggerType = TRIG_NOW;

	//+++ No delay for startTrigger-startTime.
	RF_cmdPropTx.pktLen = PAYLOAD_LENGTH;
	RF_cmdPropTx.pPkt = txPacket;
	RF_cmdPropTx.startTrigger.triggerType = TRIG_NOW;

	rfHandle = RF_open(&rfObject, &RF_prop, (RF_RadioSetup*)&RF_cmdPropRadioDivSetup, &rfParams);	//+++ Request access to the radio.
	RF_postCmd(rfHandle, (RF_Op*)&RF_cmdFs, RF_PriorityNormal, NULL, 0);	//+++ Set the frequency.

	RF_RatConfigCompare_init(&ratConfCmp);
	ratConfCmp.callback = &onRatTriggered;
	ratConfCmp.channel = RF_RatChannelAny;
	/**
	 * Slave refers to common time base from master and no more to its own time.
	 */
	ratConfCmp.timeout = uiMTimeStampCTB + llOffsetMs + 4 * uiPacketInterval;
	ratHandle = RF_ratCompare(rfHandle, &ratConfCmp, NULL);
	if (ratHandle == RF_ALLOC_ERROR)
		while(1);

	llOffsetOld = -llOffsetMs;//---
	while(1)
	{
		Semaphore_pend(hsemAbsolRx, BIOS_WAIT_FOREVER);

		//+++ Wait for a packet.
		RF_EventMask terminationReasonA = RF_runCmd(rfHandle, (RF_Op*)&RF_cmdPropRx, RF_PriorityNormal, AbsolRxCb, RF_EventRxEntryDone);
//		uint32_t cmdStatusA = ((volatile RF_Op*)&RF_cmdPropRx)->status;
//		TermStatA(terminationReasonA, cmdStatusA);

		//+++ Send a packet.
		RF_EventMask terminationReasonB = RF_runCmd(rfHandle, (RF_Op*)&RF_cmdPropTx, RF_PriorityNormal, AbsolRxCb1, RF_EventLastCmdDone);
//		uint32_t cmdStatusB = ((volatile RF_Op*)&RF_cmdPropTx)->status;
//		TermStatB(terminationReasonB, cmdStatusB);

		RF_yield(rfHandle);
	}
//	Semaphore_delete(&hsemAbsolRx);//---
}

static void AbsolRxCb(RF_Handle h, RF_CmdHandle ch, RF_EventMask e)
{
    if (e & (RF_EventRxEntryDone))	//+++ No RF_EventLastCmdDone or works bad.
    {
    	cbRx++;
    	static uint8_t ucSlow = 0;
		ucSlow++;
		if (ucSlow == SLOW)
		{
			ucSlow = 0;
			PIN_setOutputValue(hDynPin, RED_LED, !PIN_getOutputValue(RED_LED));	//+++ Successful RX. Toggle LED.
		}

        currentDataEntry = RFQueue_getDataEntry();	//+++ Get current unhandled data entry.

        /* Handle the packet data, located at &currentDataEntry->data:
         * - Length is the first byte with the current configuration
         * - Data starts from the second byte */
        packetLength      = *(uint8_t *)(&(currentDataEntry->data));
        packetDataPointer = (uint8_t *)(&(currentDataEntry->data) + 1);

        memcpy(rxPacket, packetDataPointer, packetLength);	//+++ Copy the payload + status byte to the rxPacket variable.
		memcpy(txPacket, packetDataPointer, packetLength);	//+++ Copy the payload + status byte to the txPacket variable.

		uiTimestampNow = 0;
		uint8_t ucCount, ucShift;
		uint8_t *pucTxTimestamp = packetDataPointer + TS2_TS1;
		for (ucCount = 0, ucShift = SHIFT24; ucCount < sizeof(uint32_t); ucCount++, ucShift -= BYTELENGTH)
			uiTimestampNow += (*(pucTxTimestamp + ucCount)) << ucShift;

		int64_t llOffsetNow = (int64_t)uiTimestampNow - (int64_t)uiMirror;	//+++ Present offset to be compared with previous offset. Cast necessary for possible negative values.

		/**
		 * When RAT of Tx (uiTimestampNow) goes beyond MAX32, it starts anew from 0 and for a certain number of steps it is much
		 * smaller than RAT of Rx (uiMirror). These steps will end when RAT of Rx too goes beyond MAX32. This number of steps
		 * depends on: offset between Tx-Rx's RATs; duration of transmission i.e. uiPacketInterval. Here is not important to
		 * evaluate this number of steps, but within these steps uiTimestampNow is smaller than uiMirror and llOffsetNow must be
		 * corrected.
		 */
		if (llOffsetNow < 0)
			llOffsetNow += MAX32;

		llDiffOff =	(llOffsetNow - llOffsetOld) * fAdjustmentFactor;

		/**
		 * If offset is increasing, llDiffOff will be subtracted. If offset is decreasing, llDiffOff will be added.
		 */
		if (llOffsetNow < llOffsetOld)
			llDiffOff *= -1;

		float fDiffPercent = ((float)llabs(llOffsetNow - llOffsetOld)) / uiPacketInterval;

		if (fDiffPercent > CfPercentThreshold)
		{
			bAdjust = true;
			PIN_setOutputValue(hDynPin, CYAN_LED, 1);
		}

		llOffsetOld = llOffsetNow;

        RFQueue_nextEntry();
    }
}

static void AbsolRxCb1(RF_Handle h, RF_CmdHandle ch, RF_EventMask e)
{
    if (e & RF_EventLastCmdDone)
    {
    	cbTx++;
    	static uint8_t ucSlow = 0;
		ucSlow++;
		if (ucSlow == SLOW)
		{
			ucSlow = 0;
			PIN_setOutputValue(hDynPin, GREEN_LED, !PIN_getOutputValue(GREEN_LED));	//+++ Successful TX, toggle LED.
		}
    }
}

void onRatTriggered(RF_Handle h, RF_RatHandle rh, RF_EventMask e, uint32_t compareCaptureTime)
{
    if (e & RF_EventError)
    {
    	PIN_setOutputValue(hDynPin, YELLOW_LED, 0);
    	while(1);	// RF driver failed to trigger the callback on time.
    }

    uiMirror = RF_getCurrentTime();//---
    cbRat++;

    //+++ At the moment that happens after half an hour: too much strict condition. Communications go on well anyway. It will be eased.
    if (cbRat == 1000)
    {
    	cbRat = 0;
    	cbRx = 0;
    	cbTx = 0;
    	PIN_setOutputValue(hDynPin, ORANGE_LED, 0);
    }
	if ((cbRat > (uint16_t)(cbRx * 1.1) || cbRat > (uint16_t)(cbTx * 1.1)) && cbRat > 100)
		PIN_setOutputValue(hDynPin, ORANGE_LED, 1);

    //+++ RAT has triggered at compareCaptureTime. Trigger precisely with the same period again.
    if (bAdjust == true)
    {
    	PIN_setOutputValue(hDynPin, CYAN_LED, 0);	//+++ .
		ratConfCmp.timeout = (compareCaptureTime - llDiffOff + uiPacketInterval / MAX_SPEED);
		bAdjust = false;
    }
    else
    	ratConfCmp.timeout = (compareCaptureTime + uiPacketInterval / MAX_SPEED);

    rh = RF_ratCompare(h, &ratConfCmp, NULL);
    if (rh == RF_ALLOC_ERROR)
    	while(1);

    Semaphore_post(hsemAbsolRx);
    static uint8_t ucSlow = 0;
    ucSlow++;
    if (ucSlow == SLOW)
    {
    	ucSlow = 0;
    	PIN_setOutputValue(hDynPin, YELLOW_LED, !PIN_getOutputValue(YELLOW_LED));	//+++ Successful trigger, toggle LED.
    }
}
