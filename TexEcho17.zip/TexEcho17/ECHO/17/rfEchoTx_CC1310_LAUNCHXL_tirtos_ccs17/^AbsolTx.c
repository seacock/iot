/*
 * ^AbsolTx.c
 *
 *  Created on: 01 feb 2019
 *      Author: andre
 */

#include "^Common.h"
#include <string.h>

/***** Variable declarations *****/
static RF_Object rfObject;
static RF_Handle rfHandle;
/* Buffer which contains all Data Entries for receiving data.
 * Pragmas are needed to make sure this buffer is aligned to a 4 byte boundary (requirement from the RF core).
 */
#pragma DATA_ALIGN(rxDataEntryBuffer, 4)
static uint8_t rxDataEntryBuffer[RF_QUEUE_DATA_ENTRY_BUFFER_SIZE(NUM_DATA_ENTRIES, PAYLOAD_LENGTH, NUM_APPENDED_BYTES)];

#pragma DATA_ALIGN(AbsolTxTaskStack, 8)  //+++ 1-byte alignment on the stack to avoid wasting memory.
static uint8_t AbsolTxTaskStack[STACKSIZE];
Task_Struct AbsolTxTr;
///////////////////////////////////////////////////////////////////////////////
/* Receive dataQueue for RF Core to fill in data */
static dataQueue_t dataQueue;
static rfc_dataEntryGeneral_t* currentDataEntry;
static uint8_t packetLength;
static uint8_t* packetDataPointer;

static uint8_t txPacket[PAYLOAD_LENGTH];
static uint8_t rxPacket[PAYLOAD_LENGTH + NUM_APPENDED_BYTES - 1];	//---
RF_RatConfigCompare ratConfCmp;
RF_RatHandle ratHandle;
static Semaphore_Handle hsemAbsolTx;
extern uint32_t uiTimestamp2;
static uint16_t seqNumber = 0;
static uint32_t uiTimestampNow;
struct Match
{
	uint32_t uiZero, uiOne, uiRoundAbout, uiOther;
} stMatch;

Void AbsolTxTf(UArg arg0, UArg arg1);
static void AbsolTxCb(RF_Handle h, RF_CmdHandle ch, RF_EventMask e);
static void AbsolTxCb1(RF_Handle h, RF_CmdHandle ch, RF_EventMask e);

void onRatTriggered(RF_Handle h, RF_RatHandle rh, RF_EventMask e, uint32_t compareCaptureTime);

void StartAbsolTxTf(void)
{
	Semaphore_Params semParams;
	Semaphore_Params_init(&semParams);
	hsemAbsolTx = Semaphore_create(0, &semParams, NULL);
	if (hsemAbsolTx == NULL) //+++ Check if the handle is valid.
		while(1);

    Task_Params taskParams;
    Task_Params_init(&taskParams);
    taskParams.stackSize = STACKSIZE;
    taskParams.priority = 2;    //+++ More than 1 or is preempted by while (1) in mainThread.
    taskParams.stack = &AbsolTxTaskStack;

    Task_construct(&AbsolTxTr, AbsolTxTf, &taskParams, NULL);
}

Void AbsolTxTf(UArg arg0, UArg arg1)
{
    RF_Params rfParams;
    RF_Params_init(&rfParams);
    rfParams.nInactivityTimeout = 100;	//---
    memset(&stMatch, 0, sizeof(stMatch));

    if(RFQueue_defineQueue(&dataQueue, rxDataEntryBuffer, sizeof(rxDataEntryBuffer),
										   NUM_DATA_ENTRIES, PAYLOAD_LENGTH + NUM_APPENDED_BYTES))
	{
		/* Failed to allocate space for all data entries */
		PIN_setOutputValue(hDynPin, GREEN_LED, 1);
		PIN_setOutputValue(hDynPin, RED_LED, 1);
		while(1);
	}

    /* Modify CMD_PROP_TX and CMD_PROP_RX commands for application needs */
    RF_cmdPropTx.pktLen = PAYLOAD_LENGTH;
    RF_cmdPropTx.pPkt = txPacket;
    RF_cmdPropTx.startTrigger.triggerType = TRIG_NOW;

    RF_cmdPropRx.pQueue = &dataQueue;	//+++ Set the Data Entity queue for received data.
	RF_cmdPropRx.rxConf.bAutoFlushIgnored = 1;	//+++ Discard ignored packets from Rx queue.
	RF_cmdPropRx.rxConf.bAutoFlushCrcErr = 1;	//+++ Discard packets with CRC error from Rx queue.
	RF_cmdPropRx.maxPktLen = PAYLOAD_LENGTH;	//+++ Implement packet length filtering to avoid PROP_ERROR_RXBUF.
	RF_cmdPropRx.pktConf.bRepeatOk = 0;
	RF_cmdPropRx.pktConf.bRepeatNok = 0;
	RF_cmdPropRx.startTrigger.triggerType = TRIG_NOW;
	RF_cmdPropRx.endTrigger.triggerType = TRIG_REL_START;	//+++ Receive operation will end RX_TIMEOUT after command starts.
	RF_cmdPropRx.endTime = RX_TIMEOUT/10;	//--- Not less...

    rfHandle = RF_open(&rfObject, &RF_prop, (RF_RadioSetup*)&RF_cmdPropRadioDivSetup, &rfParams);	//+++ Request access to the radio.
    RF_postCmd(rfHandle, (RF_Op*)&RF_cmdFs, RF_PriorityNormal, NULL, 0);	//+++ Set the frequency.
    RF_RatConfigCompare_init(&ratConfCmp);
	ratConfCmp.callback = &onRatTriggered;
	ratConfCmp.channel = RF_RatChannelAny;
	ratConfCmp.timeout = uiTimestamp2 + 4 * PACKET_INTERVAL;	//+++ Common time base for slave.
	ratHandle = RF_ratCompare(rfHandle, &ratConfCmp, NULL);
	if (ratHandle == RF_ALLOC_ERROR)
		while(1);

    while(1)
    {
    	memset(txPacket, '0', PAYLOAD_LENGTH);	//---

    	/* Create packet with incrementing sequence number and payload */
		txPacket[0] = (uint8_t)(seqNumber >> 8);
		txPacket[1] = (uint8_t)(seqNumber++);

		uiTimestampNow = RF_getCurrentTime();
		uint8_t ucCount, ucShift;
		for (ucCount = TS2_TS1, ucShift = SHIFT24; ucCount < TS2_TS1 + sizeof(uint32_t); ucCount++, ucShift -= BYTELENGTH)
			txPacket[ucCount] = (uint8_t)(uiTimestampNow >> ucShift);

		static uint8_t ucData = 32;
		for (ucCount = START_DATA; ucCount < PAYLOAD_LENGTH; ucCount++)
			txPacket[ucCount] = ucData;

		ucData++;
		if (ucData == 128)
			ucData = 32;

		Semaphore_pend(hsemAbsolTx, BIOS_WAIT_FOREVER);

        RF_EventMask terminationReasonA = RF_runCmd(rfHandle, (RF_Op*)&RF_cmdPropTx, RF_PriorityNormal, AbsolTxCb, RF_EventLastCmdDone);//---
        uint32_t cmdStatusA = ((volatile RF_Op*)&RF_cmdPropTx)->status;
		TermStatA(terminationReasonA, cmdStatusA);

		RF_EventMask terminationReasonB = RF_runCmd(rfHandle, (RF_Op*)&RF_cmdPropRx, RF_PriorityNormal, AbsolTxCb1, /*RF_EventRxEntryDone*/RF_EventLastCmdDone);//---
		uint32_t cmdStatusB = ((volatile RF_Op*)&RF_cmdPropRx)->status;
		TermStatB(terminationReasonB, cmdStatusB);
    }
    //	Semaphore_delete(&hsemAbsolTx);//---
}

static void AbsolTxCb(RF_Handle h, RF_CmdHandle ch, RF_EventMask e)
{
    if(e & RF_EventLastCmdDone)	//--- No RF_EventTxDone .
        PIN_setOutputValue(hDynPin, GREEN_LED, !PIN_getOutputValue(GREEN_LED));	//+++ Successful TX. Toggle LED.
}

static void AbsolTxCb1(RF_Handle h, RF_CmdHandle ch, RF_EventMask e)
{
    if(e & RF_EventLastCmdDone/*RF_EventRxEntryDone*/)	//--- No RF_EventRxEntryDone .
    {
    	PIN_setOutputValue(hDynPin, RED_LED, !PIN_getOutputValue(RED_LED));	//+++ Successful RX. Toggle LED.
    	currentDataEntry = RFQueue_getDataEntry();	//+++ Get current unhandled data entry.

		/* Handle the packet data, located at &(currentDataEntry->data):
		 * - Length is the first byte with the current configuration
		 * - Data starts from the second byte
		 */
		packetLength      = *(uint8_t *)(&(currentDataEntry->data));
		packetDataPointer = (uint8_t *)(&(currentDataEntry->data) + 1);

		memcpy(rxPacket, packetDataPointer, (packetLength + 1));	//+++ Copy the payload + status byte to the rxPacket variable.

		if (rxPacket[25] == txPacket[25])
		{
			stMatch.uiZero++;
			PIN_setOutputValue(hDynPin, ORANGE_LED, true);
		}
		else if (rxPacket[25] + 1 == txPacket[25])
		{
			stMatch.uiOne++;
			PIN_setOutputValue(hDynPin, ORANGE_LED, true);
		}
		else if (rxPacket[25] == 127 && txPacket[25] == 32)
		{
			stMatch.uiRoundAbout++;
			PIN_setOutputValue(hDynPin, ORANGE_LED, true);
		}
		else
		{
			stMatch.uiOther++;
			PIN_setOutputValue(hDynPin, ORANGE_LED, false);
		}

		RFQueue_nextEntry();
    }
}

void onRatTriggered(RF_Handle h, RF_RatHandle rh, RF_EventMask e, uint32_t compareCaptureTime)
{
    if (e & RF_EventError)
    	while(1);	// RF driver failed to trigger the callback on time.

    //+++ RAT has triggered at compareCaptureTime. Trigger precisely with the same period again.
	ratConfCmp.timeout = compareCaptureTime + PACKET_INTERVAL / 40;	//---
    rh = RF_ratCompare(h, &ratConfCmp, NULL);
    if (rh == RF_ALLOC_ERROR)
    	while(1);

    Semaphore_post(hsemAbsolTx);
    PIN_setOutputValue(hDynPin, YELLOW_LED, !PIN_getOutputValue(YELLOW_LED));	//+++ Successful trigger. Toggle LED.
}
