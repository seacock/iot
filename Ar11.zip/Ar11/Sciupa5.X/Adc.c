#include "Cent.h"
#include "Adc.h"
#include "ShaDe.h"

#if __XC16_VERSION__ >= 0x0401
#undef _ISR
#define _ISR __attribute__((interrupt, auto_psv))
#endif

//+++ Upper and lower bytes from AD for 2 sensors.
unsigned char guchUB[N_SENS], guchLB[N_SENS];
unsigned int guiAverage[N_SENS]; //+++ Number of values to average.

//+++ Sum of upper and lower bytes to average.
//+++ If gulUB_Sum and gulLB_Sum are declared as unsigned int, AVERAGE can be any
//+++ value between 2 and 255, for example 13, or 158. Instead here AVERAGE can 
//+++ only be a power of 2, less than 65536, for example 4 or 1024. Otherways 
//+++ division goes wrong.
unsigned long gulUB_Sum[N_SENS], gulLB_Sum[N_SENS]; 
                               
//+++ Average of upper and lower bytes to pass to SPI1BUF.
unsigned char guchUB_Ave[N_SENS], guchLB_Ave[N_SENS];

int mainAdc(void) 
{   
    ZeroAve(POTENT);
    ZeroAve(THERMO);   
    SetupADConverter();   
    Timer2TypeA();
    
    return 0;
}

void Timer2TypeA(void)
{
    T2CON = 0x00;   //+++ Reset Timer2 control register and stop Timer2.
    TMR2 = 0x00;    //+++ Clear contents of Timer2 Register.
    T2CONbits.TCKPS = 0x02; //+++ Timer2 Input Clock Prescale Select. 1:64.
    PR2 = 128;  //+++ Load the Period Register 2.
    _T2IP = 0x01;   //+++ Timer2 Interrupt Priority.
    _T2IF = 0;  //+++ Clear Timer2 interrupt status flag.
    _T2IE = 1;  //+++ Enable Timer2 interrupts.    
    T2CONbits.TON = 1;  //+++ Timer started, prescaler .
}

void SetupADConverter(void)
{ 
    AD1CON1bits.ADON = 0;       //+++ Turn ADC OFF.
    
    //+++ AN0 (hwPin = 2), AN1 (hwPin = 3) input pins are analog.
    AD1PCFG = 0xFFFC;           
    AD1CSSL = 0x0003;           //+++ AN0 AN1 channels included in scan.
    
    //+++ Discontinue module operation when device enters Idle mode. Output 
    //+++ fractional. Internal counter ends sampling and triggers conversion: 
    //+++ auto-convert.
    AD1CON1 = 0x22E0;                                       
    AD1CON3 = 0x0F00;           //+++ Auto-sample time = 15 Tad. Tad = Tcy.
    
    //+++ Enable scanning of inputs for MUX A. Set AD1IF after every 2 samples.    
    AD1CON2 = 0x0404;       
    IEC0bits.AD1IE = 0; //+++ Disable A/D conversion interrupt.
    IFS0bits.AD1IF = 0; //+++ Clear A/D conversion interrupt flag.
    IPC3bits.AD1IP = 4; //+++ A/D interrupt priority.
    IEC0bits.AD1IE = 1; //+++ Enable A/D conversion interrupt.    
    AD1CON1bits.ADON = 1;   //+++ Turn ADC ON.
}

void ZeroAve(int iCount)
{
    gulUB_Sum[iCount] = 0;          
    gulLB_Sum[iCount] = 0;      
    guiAverage[iCount] = 0;
}

void _ISR _ADC1Interrupt(void)
{
    int aiAdcVal[N_SENS];    //+++ Store an ADC converted value for each sensor.
    int *piAdcBuff = (int*)&ADC1BUF0; //+++ Init pointer to ADC Data Buffer 0.
    AD1CON1bits.ASAM = 0; //+++ After end of conversion, stop sample / convert.
    
    //+++ Store converted values.
    int iCount;
    for (iCount = 0; iCount < N_SENS; iCount++)  
    {
        aiAdcVal[iCount] = *piAdcBuff++;
        guchUB[iCount] = aiAdcVal[iCount] >> 8; //+++ Upper byte.
        guchLB[iCount] = aiAdcVal[iCount];   //+++ Lower byte.  
        
        if (PORTBbits.RB5 == AVE_ADC)
        {
            gulUB_Sum[iCount] += guchUB[iCount];
            gulLB_Sum[iCount] += guchLB[iCount];

            guiAverage[iCount]++;
            if (guiAverage[iCount] == AVERAGE)
            {
                guchUB_Ave[iCount] = (unsigned char)(gulUB_Sum[iCount] / AVERAGE);
                guchLB_Ave[iCount] = (unsigned char)(gulLB_Sum[iCount] / AVERAGE);  
                ZeroAve(iCount);
            }            
        }            
    }
    
    IFS0bits.AD1IF = 0; //+++ Clear ADC interrupt flag.
}

void _ISR _T2Interrupt(void)
{
    AD1CON1bits.ASAM = 1; //+++ Run ADC. Auto start sampling then go to conversion.  
    
    _T2IF = 0;
}