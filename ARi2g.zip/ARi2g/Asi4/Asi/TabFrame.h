#pragma once

// CTabFrame

#define NUM_TABS 5	//+++ Number of tabbed dialog pages inserted into tab control.

class CTabFrame : public CTabCtrl
{
	DECLARE_DYNAMIC(CTabFrame)

public:
	CTabFrame();
	virtual ~CTabFrame();
	void Init();	//+++ Initialize the tabbed dialogs. Start communication threads.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
protected:
	DECLARE_MESSAGE_MAP()
private:
	CDialog *apjdlgTabPage[NUM_TABS];
	int iTabCurrent;	//+++ Index of the tab dialog holding the focus.	
	void SetRect(int iFocus);	//+++ Dimension and position the tabbed dialogs inside the frame. Show one.
};


