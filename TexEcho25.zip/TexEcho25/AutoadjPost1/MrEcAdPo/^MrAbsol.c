/*
 * ^MrAbTx.c
 *
 *  Created on: 01 feb 2019
 *      Author: andre
 */

#include "^Common.h"
#include <string.h>

/***** Variable declarations *****/
static RF_Object rfObject;
static RF_Handle rfHandle;
/* Buffer which contains all Data Entries for receiving data.
 * Pragmas are needed to make sure this buffer is aligned to a 4 byte boundary (requirement from the RF core).
 */
#pragma DATA_ALIGN(rxDataEntryBuffer, 4)
static uint8_t rxDataEntryBuffer[RF_QUEUE_DATA_ENTRY_BUFFER_SIZE(NUM_DATA_ENTRIES, PAYLOAD_LENGTH, NUM_APPENDED_BYTES)];

#pragma DATA_ALIGN(MrAbsolTaskStack, 8)  //+++ 1-byte alignment on the stack to avoid wasting memory.
static uint8_t MrAbsolTaskStack[STACKSIZE];//---
Task_Struct MrAbsolTr;
///////////////////////////////////////////////////////////////////////////////
/* Receive dataQueue for RF Core to fill in data */
static dataQueue_t dataQueue;
static rfc_dataEntryGeneral_t* currentDataEntry;
static uint8_t packetLength;
static uint8_t* packetDataPointer;

static uint8_t txPacket[PAYLOAD_LENGTH];
static uint8_t rxPacket[PAYLOAD_LENGTH + NUM_APPENDED_BYTES - 1];	//---
RF_RatConfigCompare ratConfCmp;
RF_RatHandle ratHandle;
static Semaphore_Handle hsemMrAbTx;
extern uint32_t uiTimestamp2;
static uint16_t seqNumber = 0;
static uint32_t uiTimestampNow;
struct Match
{
	uint32_t uiHit, uiMiss, uiRoundAbout;
} stMatch;
#define SLOW 20
#define MAX_SPEED 40
static uint32_t uiDelayRx = 0;
static bool bIncrem = true;
static uint8_t txPacketCopy[PAYLOAD_LENGTH];

static void LedFlicker(uint8_t *ucSlowDown, uint32_t uiLed);
Void MrAbsolTf(UArg arg0, UArg arg1);
static void MrAbTxCb(RF_Handle h, RF_CmdHandle ch, RF_EventMask e);
static void MrAbRxCb(RF_Handle h, RF_CmdHandle ch, RF_EventMask e);

void onRatTriggered(RF_Handle h, RF_RatHandle rh, RF_EventMask e, uint32_t compareCaptureTime);

void StartMrAbsolTf(void)
{
	Semaphore_Params semParams;
	Semaphore_Params_init(&semParams);
	hsemMrAbTx = Semaphore_create(0, &semParams, NULL);
	if (hsemMrAbTx == NULL) //+++ Check if the handle is valid.
		while(1);

    Task_Params taskParams;
    Task_Params_init(&taskParams);
    taskParams.stackSize = STACKSIZE;
    taskParams.priority = 5;    //+++ More than 1 or is preempted by while (1) in mainThread.
    taskParams.stack = &MrAbsolTaskStack;

    Task_construct(&MrAbsolTr, MrAbsolTf, &taskParams, NULL);
}

Void MrAbsolTf(UArg arg0, UArg arg1)
{
    RF_Params rfParams;
    RF_Params_init(&rfParams);
    rfParams.nInactivityTimeout = 50;	//---
    memset(&stMatch, 0, sizeof(stMatch));

    if(RFQueue_defineQueue(&dataQueue, rxDataEntryBuffer, sizeof(rxDataEntryBuffer),
										   NUM_DATA_ENTRIES, PAYLOAD_LENGTH + NUM_APPENDED_BYTES))
	{
		/* Failed to allocate space for all data entries */
		PIN_setOutputValue(hDynPin, GREEN_LED, 1);
		PIN_setOutputValue(hDynPin, RED_LED, 1);
		while(1);
	}

    /* Modify CMD_PROP_TX and CMD_PROP_RX commands for application needs */

    RF_cmdPropTx.pktLen = PAYLOAD_LENGTH;
    RF_cmdPropTx.pPkt = txPacket;
    RF_cmdPropTx.startTrigger.triggerType = TRIG_NOW;

    RF_cmdPropRx.pQueue = &dataQueue;	//+++ Set the Data Entity queue for received data.
	RF_cmdPropRx.rxConf.bAutoFlushIgnored = 1;	//+++ Discard ignored packets from Rx queue.
	RF_cmdPropRx.rxConf.bAutoFlushCrcErr = 1;	//+++ Discard packets with CRC error from Rx queue.
	RF_cmdPropRx.maxPktLen = PAYLOAD_LENGTH;	//+++ Implement packet length filtering to avoid PROP_ERROR_RXBUF.
	RF_cmdPropRx.pktConf.bRepeatOk = 0;
	RF_cmdPropRx.pktConf.bRepeatNok = 0;
	RF_cmdPropRx.startTrigger.triggerType = TRIG_ABSTIME;

    rfHandle = RF_open(&rfObject, &RF_prop, (RF_RadioSetup*)&RF_cmdPropRadioDivSetup, &rfParams);	//+++ Request access to the radio.
    RF_postCmd(rfHandle, (RF_Op*)&RF_cmdFs, RF_PriorityNormal, NULL, 0);	//+++ Set the frequency.
    RF_RatConfigCompare_init(&ratConfCmp);
	ratConfCmp.callback = &onRatTriggered;
	ratConfCmp.channel = RF_RatChannelAny;
	ratConfCmp.timeout = uiTimestamp2 + 4 * PACKET_INTERVAL;	//+++ Common time base for slave.
	ratHandle = RF_ratCompare(rfHandle, &ratConfCmp, NULL);
	if (ratHandle == RF_ALLOC_ERROR)
		while(1);

    while(1)
    {
    	Semaphore_pend(hsemMrAbTx, BIOS_WAIT_FOREVER);//---
    	memset(txPacket, '0', PAYLOAD_LENGTH);	//---
    	memset(rxPacket, '0', PAYLOAD_LENGTH);	//---

    	/* Create packet with incrementing sequence number and payload */
		txPacket[0] = (uint8_t)(seqNumber >> 8);
		txPacket[1] = (uint8_t)(seqNumber++);

		uint8_t ucCount, ucShift;
		for (ucCount = TS2_TS1, ucShift = SHIFT24; ucCount < TS2_TS1 + sizeof(uint32_t); ucCount++, ucShift -= BYTELENGTH)
			txPacket[ucCount] = (uint8_t)(uiTimestampNow >> ucShift);

		static uint8_t ucData = 32;
		for (ucCount = START_DATA; ucCount < PAYLOAD_LENGTH; ucCount++)
			txPacket[ucCount] = ucData;

		ucData++;
		if (ucData == 128)
			ucData = 32;

		strcpy((char*)txPacketCopy, (char*)txPacket);
		uint32_t uiStartOper1 = RF_convertRatTicksToUs(RF_getCurrentTime());//---
		RF_CmdHandle firstCommand = RF_postCmd(rfHandle, (RF_Op*)&RF_cmdPropTx, RF_PriorityNormal, MrAbTxCb, RF_EventLastCmdDone);
		RF_pendCmd(rfHandle, firstCommand, RF_EventLastCmdDone);
        uint32_t uiSpanOper1 = RF_convertRatTicksToUs(RF_getCurrentTime()) - uiStartOper1;

        if (bIncrem == true)
        {
			uiDelayRx += 100;
			if (uiDelayRx > 10000)
				uiDelayRx = 0;
        }
        RF_cmdPropRx.startTime = RF_getCurrentTime() + RF_convertUsToRatTicks(uiDelayRx);

        uint32_t uiStartOper2 = RF_convertRatTicksToUs(RF_getCurrentTime());//---
		RF_CmdHandle lastCommand = RF_postCmd(rfHandle, (RF_Op*)&RF_cmdPropRx, RF_PriorityNormal, MrAbRxCb, RF_EventLastCmdDone);
		RF_pendCmd(rfHandle, lastCommand, RF_EventLastCmdDone);
		uint32_t uiSpanOper2 = RF_convertRatTicksToUs(RF_getCurrentTime()) - uiStartOper2;
//		RF_yield(rfHandle);	//+++ It degrades communications.
		uint32_t uiRatTrigPeriod = RF_convertRatTicksToUs(PACKET_INTERVAL / MAX_SPEED);
		/**
		 * 0.9 is a safety margin. uiSpanOper1 + uiSpanOper2 during the transitory is much bigger, but then it must be smaller or
		 * communications degrade.
		 */
		if (uiSpanOper1 + uiSpanOper2 > (uint32_t)(0.9 * uiRatTrigPeriod))
			uiSpanOper2 = 0;	//+++ test
    }
    //	Semaphore_delete(&hsemMrAbTx);//---
}

static void MrAbTxCb(RF_Handle h, RF_CmdHandle ch, RF_EventMask e)
{
    if(e & RF_EventLastCmdDone)
    {
    	static uint8_t ucSlow = 0;
    	LedFlicker(&ucSlow, GREEN_LED);	//+++ Successful TX, toggle LED.
    }
}

static void MrAbRxCb(RF_Handle h, RF_CmdHandle ch, RF_EventMask e)
{
    if(e & RF_EventLastCmdDone)
    {
    	static uint8_t ucSlow = 0;
    	LedFlicker(&ucSlow, RED_LED);	//+++ Successful RX, toggle LED.

    	currentDataEntry = RFQueue_getDataEntry();	//+++ Get current unhandled data entry.

		/* Handle the packet data, located at &(currentDataEntry->data):
		 * - Length is the first byte with the current configuration
		 * - Data starts from the second byte
		 */
		packetLength      = *(uint8_t *)(&(currentDataEntry->data));
		packetDataPointer = (uint8_t *)(&(currentDataEntry->data) + 1);

		memcpy(rxPacket, packetDataPointer, (packetLength + 1));	//+++ Copy the payload + status byte to the rxPacket variable.

		if (!strcmp((char*)txPacketCopy, (char*)rxPacket))
		{
			bIncrem = false;
			stMatch.uiHit++;
			PIN_setOutputValue(hDynPin, ORANGE_LED, true);
		}
		else
		{
			stMatch.uiMiss++;
			PIN_setOutputValue(hDynPin, ORANGE_LED, false);
		}

		RFQueue_nextEntry();
    }
}

void onRatTriggered(RF_Handle h, RF_RatHandle rh, RF_EventMask e, uint32_t compareCaptureTime)
{
    if (e & RF_EventError)
    {
		PIN_setOutputValue(hDynPin, YELLOW_LED, 0);
		while(1);	// RF driver failed to trigger the callback on time.
	}

    uiTimestampNow = RF_getCurrentTime();//---

    //+++ RAT has triggered at compareCaptureTime. Trigger precisely with the same period again.
	ratConfCmp.timeout = compareCaptureTime + PACKET_INTERVAL / MAX_SPEED;	//---
    rh = RF_ratCompare(h, &ratConfCmp, NULL);
    if (rh == RF_ALLOC_ERROR)
    	while(1);

    Semaphore_post(hsemMrAbTx);
    static uint8_t ucSlow = 0;
	LedFlicker(&ucSlow, YELLOW_LED);	//+++ Successful trigger, toggle LED.
}

static void LedFlicker(uint8_t *ucSlowDown, uint32_t uiLed)
{
	(*ucSlowDown)++;
	if (*ucSlowDown == SLOW)
	{
		*ucSlowDown = 0;
		PIN_setOutputValue(hDynPin, uiLed, !PIN_getOutputValue(uiLed));	//+++ Toggle LED.
	}
}
