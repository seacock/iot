#include "SharA.h"

CRy gRy;
CAff gAff;
CUart gUart;
CSpi gSpi;
CI2c gI2c;

void LocalIpFromGoogle(); 	//+++ Get the IP address that is currently used for Internet connections. No need to know which interface is used.
void InterfacesIp(); 	//+++ Fill a structure. //???
void TomcatSetUp(bool bCmd);
void* BroadTp(void *arg); 	//+++ Uses the broadcast address obtained from InterfacesIp(). Raspberry initiates the broadcast sending a greeting msg to the remote LaptopASUS. Then Raspberry receives from LaptopASUS: SsrLANServerPort.
void* LanTp(void *arg);
void* I2cServTp(void *arg); 	//+++ Server for client laptop ASUS: exchange commands/data for I2C. It can immediately stay in receive mode. If broadcasting or handshaking or communication fail, it times out and terminates.
void* WebServUartTp(void *arg); 	//+++ Server called through internet from a Java WebSite. It communicates with Pic 24 via Uart and sends back info to WebSite.

int main(int argc, char *argv[])
{
	LocalIpFromGoogle();

#ifdef _WEBTOM8_
	TomcatSetUp(true);
#endif // _WEBTOM8_	

	gRy.FillCoupleId();
	InterfacesIp();
	gAff.SchedAff();
	
	if (wiringPiSetup() == -1)
	{
		cout << "Unable to start wiringPi\n";
		return 1 ;
	}
	pinMode(SWITCH_INC, INPUT);
	pinMode(SWITCH_DEC, INPUT);

	gUart.iUartHandle = gUart.UartSetup();
	
	wiringPiSPISetup(SPI_CHANNEL, SPI_SPEED);
	
	int iAddr = 0x04; 	//+++ ID. This device identifier can have other values.
	if((gI2c.stSync.SiFdI2c = wiringPiI2CSetup(iAddr)) == -1)	//+++ Initialize the interface by giving it ID. It returns a standard file descriptor.
		handle_error("wiringPiI2CSetup()");
	
	pthread_barrier_init(&gRy.stPortHost.barrier5, NULL, 5);
	
	gRy.afp[0] = BroadTp;
	gRy.afp[1] = LanTp;
	gRy.afp[2] = I2cServTp;
	gRy.afp[3] = WebServUartTp;
	gRy.PoolThread(NUM_THREADS); 	//+++ Create and wait for worker threads.

#ifdef _WEBTOM8_
	TomcatSetUp(false);		
#endif // _WEBTOM8_		

	exit(EXIT_SUCCESS);
}

void InterfacesIp()
{	
#define IFF_BROADCAST 0x2
	struct ifaddrs *pstIfAddr = NULL, *pstIfA = NULL;
	void *pTempor = NULL;
	
	//+++ Create a linked list of structures describing the network interfaces of this system.
	if(getifaddrs(&pstIfAddr) == -1)
		handle_error("getifaddrs()");
	    
	for (pstIfA = pstIfAddr; pstIfA != NULL; pstIfA = pstIfA->ifa_next)
	{
		if ((pstIfA->ifa_addr->sa_family == AF_INET) && (!strcmp(pstIfA->ifa_name, "wlan0")))
		{
			pTempor = &((struct sockaddr_in*)pstIfA->ifa_addr)->sin_addr;
			inet_ntop(pstIfA->ifa_addr->sa_family, pTempor, gSpi.stWlan0Inet4.acInternetAddress, INET_ADDRSTRLEN);      	//+++ Internet Address.

			strcpy(gSpi.stWlan0Inet4.acLineDescription, pstIfA->ifa_name);     	//+++ LineDescription.

			if((pstIfA->ifa_netmask != NULL) && (pstIfA->ifa_netmask->sa_family == AF_INET))
			{
				pTempor = &((struct sockaddr_in*)pstIfA->ifa_netmask)->sin_addr;
				inet_ntop(pstIfA->ifa_netmask->sa_family, pTempor, gSpi.stWlan0Inet4.acNetmask, INET_ADDRSTRLEN);     	//+++ Netmask.
			}
			if ((pstIfA->ifa_flags & IFF_BROADCAST) && (pstIfA->ifa_ifu.ifu_broadaddr != NULL) && (pstIfA->ifa_ifu.ifu_broadaddr->sa_family == AF_INET))	
			{
				pTempor = &((struct sockaddr_in*)pstIfA->ifa_ifu.ifu_broadaddr)->sin_addr;
				inet_ntop(pstIfA->ifa_ifu.ifu_broadaddr->sa_family, pTempor, gSpi.stWlan0Inet4.acBroadcastAddr, INET_ADDRSTRLEN);     	//+++ Broadcast Addr.
			}
		}
	}

	freeifaddrs(pstIfAddr); /* free the dynamic memory */
	pstIfAddr = NULL; /* prevent use after free  */	
}

void LocalIpFromGoogle()
{
	FILE* fp;
	char *pcRes = new char[BUFLEN];
	fp = popen("ip route get 8.8.8.8 | awk '{print $NF; exit}'", "r");
	fread(pcRes, 1, BUFLEN, fp);
	fclose(fp);	
	gRy.stPortHost.srRes += pcRes;
	delete[] pcRes;
	gRy.stPortHost.srRes += "  a GNU C++ server from RaspberryPi2, is answering back. To read a line the Java client reader needs only to find a new - line escape character or it gets stuck.\nThe last word End_Of_Transmission of this message is used by Java client to stop listening.\nThat allows the GNU C++ server to wait for a new message.This server adds to the received message a 0 escape sequence to avoid a dirty buffer in case of bad transmission (full capacity filled) from client Java: it's anyway not critical.An exceptional note over the internet: I'm no more sure about the causes of disaster in previous step. It goes against my little knowledge of C++. Even now that I'm using classes in Raspberry the same problem arises. So I've found the cause: bad routine in Uart.cpp . In other words: telecommunications are ideal till they work fine. One must allow for problems in some elements of the chain and recover from them: reset Microchip with little button on MicrostickII and improve routine in Uart.cpp .Good: I'm tidying code and I'll explain, not here.EndOfTransmission\n";
} 

void TomcatSetUp(bool bCmd)
{
	if (bCmd == true)
	{
		system("touch /mnt/Hjc/potentiometer.txt");
		system("chmod 7777 /mnt/Hjc/potentiometer.txt");
		system("truncate /mnt/Hjc/potentiometer.txt --size 0");
		system("touch /mnt/Hjc/thermometer.txt");
		system("chmod 7777 /mnt/Hjc/thermometer.txt"); 
		system("truncate /mnt/Hjc/thermometer.txt --size 0");
		system("/home/pi/apache-tomcat-8.5.23/bin/startup.sh");
	}
	else
	{
		system("/home/pi/apache-tomcat-8.5.23/bin/shutdown.sh");
		system("rm /mnt/Hjc/potentiometer.txt");
		system("rm /mnt/Hjc/thermometer.txt");
	}
}