#include "Spi.h"
#include "ShaDe.h"   
#include <PPS.h>    //+++ For PPSUnLock and similar.

#if __XC16_VERSION__ >= 0x0401
#undef _ISR
#define _ISR __attribute__((interrupt, auto_psv))
#endif

extern unsigned char guchUB[2], guchLB[2], guchUB_Ave[2], guchLB_Ave[2];

//+++ Last or average upper and lower bytes from AD to pass to SPI1BUF.
//+++ Conversion is so fast that, while Raspberry asks for lower byte of a sensor 
//+++ converted word (2 bytes), AD converter can perform many other conversions.
//+++ So, by the time Raspberry asks for upper byte of a sensor converted word 
//+++ (2 bytes), the lower byte has been replaced by another. This requires to 
//+++ freeze upper and lower bytes.
unsigned char guchUB_Ry[N_SENS], guchLB_Ry[N_SENS], guchUB_AveRy[N_SENS], guchLB_AveRy[N_SENS]; //??????
bool gbSpiTimeOut;//??????

int mainSpi(void) 
{       
    ConfigSpiPortPins();
    ConfigSpiPPS();
    SetupSpi();
    gbSpiTimeOut = false;
    Timer3TypeA();
    
    return 0;
}

void ConfigSpiPortPins(void)
{
    TRISBbits.TRISB14 = INPUT_PIN;   //+++ SDI1: hwPin = 25.
    TRISBbits.TRISB15 = OUTPUT_PIN;  //+++ SDO1: hwPin = 26.
    TRISBbits.TRISB2 = INPUT_PIN;   //+++ SCK1: hwPin = 6.
    TRISBbits.TRISB3 = INPUT_PIN;   //+++ SS1: hwPin = 7.
}

void ConfigSpiPPS(void)
{
    PPSUnLock;  //+++ Unlock the PPS functionality.
    iPPSInput(IN_FN_PPS_SDI1, IN_PIN_PPS_RP14);      //+++ SDI1: hwPin = 25.
    iPPSOutput(OUT_PIN_PPS_RP15, OUT_FN_PPS_SDO1);   //+++ SDO1: hwPin = 26.
    iPPSInput(IN_FN_PPS_SCK1IN, IN_PIN_PPS_RP2);    //+++ SCK1: hwPin = 6.
    iPPSInput(IN_FN_PPS_SS1IN, IN_PIN_PPS_RP3);     //+++ SS1: hwPin = 7.
    PPSLock;    //+++ Lock the PPS functionality.
}

void SetupSpi(void)
{
    //+++ SPI register configuration for Slave mode, byte-wide.
    IFS0bits.SPI1IF = 0;        //+++ Clear the Interrupt flag.
    IEC0bits.SPI1IE = 0;        //+++ Disable the interrupt.
    SPI1STATbits.SPIEN = 0;     //+++ Disable SPI module.
    
    //+++ The only valid combination with CKP. Serial output data changes on 
    //+++ transition from Active clock state to Idle clock state.
    SPI1CON1bits.CKE = 1;     
    SPI1CON1bits.SSEN = 1;      //+++ SS1 pin used for Slave mode.        
    IFS0bits.SPI1IF = 0;        //+++ Clear the Interrupt flag.
    IPC2bits.SPI1IP = 6;        //+++ SPI1 interrupt priority.
    IEC0bits.SPI1IE = 1;        //+++ Enable the interrupt.
    SPI1STATbits.SPIEN = 1;     //+++ Enable SPI module.
    
    SPI1BUF = 0;    //+++ Clear the register, to avoid dirty data.
}

void _ISR _SPI1Interrupt(void)
{        
    WORD data = SPI1BUF;    //+++ Read the data. No delay before this line.
    
    //+++ When Pic24 SPI blocks, it needs a local SPI reset as Rasperry wouldn't be able to enter
    //+++ this ISR anymore. If timer3 expires outside of here, it will reset SPI. Now reset timer3.
    T3CONbits.TON = 0;  //+++ Stop timer 3.
    TMR3 = 0;   //+++ Prepare zeroed timer.
    T3CONbits.TON = 1;  //+++ Start timer 3. 
    
	//+++ Write the next data byte: needs to happen before the next byte/word is received. This IRQ
    //+++ is triggered 1/2 bit time before the end of the last bit of this byte/word. So if the 
    //+++ master is fast, we must service to her before the start of the first bit of the next 
    //+++ byte/word. On first request from Raspberry, SPI1BUF is assigned the AD value. On second 
    //+++ identical request from Raspberry, SPI1BUF value will be sent back to Raspberry. Shift 
    //+++ register over network.    
    switch (PORTBbits.RB5)
    {
        case AVE_ADC:
            switch (data)
            {
                case CMD_UB_P:
                    SendValue(guchUB_AveRy[POTENT]);
                    break;
                case CMD_LB_P:
                    //+++ Raspberry asks for lower byte first: save lower and upper bytes 
                    //+++ avoiding an unwanted update from ADC.
                    guchUB_AveRy[POTENT] = guchUB_Ave[POTENT];
                    guchLB_AveRy[POTENT] = guchLB_Ave[POTENT];
                    SendValue(guchLB_AveRy[POTENT]);
                    break;                         
                case CMD_UB_T:
                    SendValue(guchUB_AveRy[THERMO]);
                    break;
                case CMD_LB_T:
                    //+++ Raspberry asks for lower byte first: save lower and upper bytes 
                    //+++ avoiding an unwanted update from ADC.
                    guchUB_AveRy[THERMO] = guchUB_Ave[THERMO];
                    guchLB_AveRy[THERMO] = guchLB_Ave[THERMO];
                    SendValue(guchLB_AveRy[THERMO]);
                    break;
            }
            break;    
        case LAST_ADC:
            switch (data)
            {
                case CMD_UB_P:                    	
                    SendValue(guchUB_Ry[POTENT]);
                    break;
                case CMD_LB_P:                    
                    //+++ Raspberry asks for lower byte first: save lower and upper bytes 
                    //+++ avoiding an unwanted update from ADC.
                    guchUB_Ry[POTENT] = guchUB[POTENT];
                    guchLB_Ry[POTENT] = guchLB[POTENT];                    
                    SendValue(guchLB_Ry[POTENT]);
                    break;
                case CMD_UB_T:
                    SendValue(guchUB_Ry[THERMO]);
                    break;
                case CMD_LB_T:
                    //+++ Raspberry asks for lower byte first: save lower and upper bytes 
                    //+++ avoiding an unwanted update from ADC.
                    guchUB_Ry[THERMO] = guchUB[THERMO];
                    guchLB_Ry[THERMO] = guchLB[THERMO];
                    SendValue(guchLB_Ry[THERMO]);
                    break;
            }
            break;    
    }
    
	IFS0bits.SPI1IF = 0;            //Clear the Interrupt Flag.
}

void ResetSpi(bool bTimeOut)
{
    gbSpiTimeOut = bTimeOut;
    
    SPI1STATbits.SPIEN = 0; //+++ Disable SPI module.
    SPI1BUF = 0;    //+++ Clear the register, to avoid dirty data.
    IFS0bits.SPI1IF = 0;    //+++ Clear the Interrupt flag.
    IEC0bits.SPI1IE = 1;    //+++ Enable the interrupt.
    SPI1STATbits.SPIEN = 1; //+++ Enable SPI module.   
    
    ZeroAve(POTENT);    //+++ Re-initialize variables, probably dirty, due to accidental SPI halt.
    ZeroAve(THERMO);    //+++ Re-initialize variables, probably dirty, due to accidental SPI halt.
}

void Timer3TypeA(void)
{
    T3CON = 0x00;   //+++ Reset Timer3 control register and stop Timer3.
    TMR3 = 0x00;    //+++ Clear contents of Timer3 Register.
    T3CONbits.TCKPS = 0x03; //+++ Timer3 Input Clock Prescale Select. 1:256.
    PR3 = 60000;  //+++ Load the Period Register 3. 960 msec Interval within which SPI reset doesn't occur.//??????
    IPC2bits.T3IP = 0x02;   //+++ Timer3 Interrupt Priority.
    _T3IF = 0;  //+++ Clear Timer3 interrupt status flag.
    _T3IE = 1;  //+++ Enable Timer3 interrupts. 
}

void _ISR _T3Interrupt(void)
{    
    //+++ The delay between each request from Raspberry to SPI ISR must be shorter than 
    //+++ TIMER3_PERIOD or this game doesn't work. If timer3 interval expires, that means that
    //+++ Raspberry is repeating regularly its requests, but SPI ISR is blocked. So timer3 
    //+++ intervenes resetting SPI.
    ResetSpi(TRUE);    
    
    _T3IF = 0;
}

void SendValue(unsigned char uchVal)
{
    if (gbSpiTimeOut)
        SPI1BUF = 0;    //+++ This signals Spi malfunctioning.
    else
        SPI1BUF = uchVal;	
}