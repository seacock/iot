#include "stdafx.h"
#include "ShaWa.h"

#define SELECT_TIMEOUT 30 * 1000 * 1000	//+++ x sec.
#define SELECT_TIME_LIMIT_ERROR 0
#define RECEIVED_STRING_LENGTH 10000
#define WAIT_TIMEOUT_B 25000
#define TEC_CONNECT 0
#define TEC_I2CMARX 1
#define TEC_I2CAURX 2

DWORD WINAPI ReceiveTp(LPVOID lpParam);	//+++ Worker thread: receives from RaspberryPi2 through 4 sockets, (5th temporary).
DWORD WINAPI I2cMaTxTp(LPVOID lpParam);	//+++ Worker thread: transmits to RaspberryPi2 through 5th socket acquired by ReceiveTp.
DWORD WINAPI I2cMaRxTp(LPVOID lpParam);
DWORD WINAPI I2cAuTxTp(LPVOID lpParam);	//+++ Worker thread: tests RaspberryPi2's I2C through 5th socket acquired by ReceiveTp.
DWORD WINAPI I2cAuRxTp(LPVOID lpParam);
SOCKET ConnectToServer(Hook *pstHook);
DWORD WINAPI ThreadExCoTp(LPVOID lpParam);

DWORD WINAPI ConnectTp(LPVOID lpParam)
{
	Hook *pstHook = (Hook*)lpParam;
	pstHook->astThreadExCo[TEC_CONNECT].hThreadExCo = pstHook->hConnectTp;
	pstHook->astThreadExCo[TEC_CONNECT].pAsiDlg = pstHook->pAsiDlg;
	CreateThread(NULL, 0, ThreadExCoTp, &pstHook->astThreadExCo[TEC_CONNECT], 0, NULL);
	CTabOne *pTabOne = pstHook->pTabOne;
	wstring wsrMonSoc = L"ConnectTp\r\n";
	wsrMonSoc += ThrAffinity(6);
	pTabOne->SendMessageW(RG_WM_ED_SOC_T, (WPARAM)wsrMonSoc.c_str());

	wsrMonSoc = L"Waiting for handshake from BroadTp...\n";
	pTabOne->SendMessageW(RG_WM_ED_SOC_T, (WPARAM)wsrMonSoc.c_str());

	DWORD dwExitCodeThread;
	DWORD dwWaitResult = WaitForSingleObject(pstHook->hBroadTp, WAIT_TIMEOUT_B);
	switch (dwWaitResult)
	{
	case WAIT_OBJECT_0:
		GetExitCodeThread(pstHook->hBroadTp, &dwExitCodeThread);
		CloseHandle(pstHook->hBroadTp);
		if (dwExitCodeThread == ERROR_COMM)
		{
			pstHook->pAsiDlg->SendMessageW(RG_WM_PIC_LIGHT, RED_LIGHT);
			return MsgWsaCMA(pstHook, L"ConnectTp waited for BroadTp failure." + (wstring)L"\r\n", false);
		}
		break;
	case WAIT_TIMEOUT:
		CloseHandle(pstHook->hBroadTp);
		pstHook->pAsiDlg->SendMessageW(RG_WM_PIC_LIGHT, RED_LIGHT);
		return MsgWsaCMA(pstHook, L"ConnectTp waited too long for BroadTp." + (wstring)L"\r\n", false);
		break;	//+++ Redundant.
	}

	//+++ Initialize Winsock.
	WSADATA wsaData;
	int iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
	if (iResult != NO_ERROR)
		return MsgWsaCMA(pstHook, L"WSAStartup failed with error: " + to_wstring(iResult) + L"\r\n", false);

	//+++ Create a SOCKET for listening for incoming connection requests.
	SOCKET ListenSocket;
	ListenSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (ListenSocket == INVALID_SOCKET)
		return MsgWsaCMA(pstHook, L"socket failed with error: " + to_wstring(WSAGetLastError()) + L"\r\n", true);

	//+++ The sockaddr_in structure specifies the address family, IP address, and port for the socket that is being bound.
	sockaddr_in stService;
	stService.sin_family = AF_INET;
	stService.sin_addr.s_addr = pTabOne->ulIPv4Addr;
	stService.sin_port = pTabOne->usPortTcpIp;

	if (bind(ListenSocket, (SOCKADDR*)&stService, sizeof(stService)) == SOCKET_ERROR)
		return MsgWsaCMA(pstHook, L"bind failed with error: " + to_wstring(WSAGetLastError()) + L"\r\n", true, ListenSocket);

	//+++ Listen for incoming connection requests on the created socket.
	if (listen(ListenSocket, 1) == SOCKET_ERROR)	//+++ backlog 1.
		return MsgWsaCMA(pstHook, L"listen failed with error: " + to_wstring(WSAGetLastError()) + L"\r\n", true, ListenSocket);

	//+++ Create a SOCKET for accepting incoming requests.
	wsrMonSoc = L"Waiting for client to connect...\n";
	pTabOne->SendMessageW(RG_WM_ED_SOC_T, (WPARAM)wsrMonSoc.c_str());

	timeval stTimeout;	//+++ Timeout for select.
	stTimeout.tv_sec = 0;
	stTimeout.tv_usec = SELECT_TIMEOUT;
	fd_set stRead;	//+++ Read set.
	FD_ZERO(&stRead);
	FD_SET(ListenSocket, &stRead);	//+++ Associate socket to read set.

	for (int iCount = 0; iCount < NUM_SOCKETS; iCount++)	//+++ Accept the connection.
	{
		//+++ Check if the socket is ready within timeout.
		int iSel = select(0, &stRead, NULL, NULL, &stTimeout);
		if (iSel == SELECT_TIME_LIMIT_ERROR || iSel == SOCKET_ERROR)
		{
			for (int iSock = 0; iSock < NUM_SOCKETS; iSock++)
				pTabOne->ShutCloseSocket(pstHook->astChann[iSock].AcceptSocket);

			return MsgWsaCMA(pstHook, L"select waited more than SELECT_TIMEOUT or SOCKET_ERROR: " + to_wstring(SELECT_TIMEOUT / (1000 * 1000)) + L" sec\n", true);
		}

		//+++ Blocking socket. From here to the recv function in ReceiveTp, operations must be as fast as possible or this server can miss data sent by client.
		pstHook->astChann[iCount].AcceptSocket = accept(ListenSocket, NULL, NULL);
		if (pstHook->astChann[iCount].AcceptSocket == INVALID_SOCKET)
		{
			for (int iSock = 0; iSock < NUM_SOCKETS; iSock++)
				pTabOne->ShutCloseSocket(pstHook->astChann[iSock].AcceptSocket);

			return MsgWsaCMA(pstHook, L"accept failed with error: " + to_wstring(WSAGetLastError()) + L"\r\n", true);
		}
		else
		{
			sockaddr stSockAddr;
			int iLen = sizeof(sockaddr);
			getpeername(pstHook->astChann[iCount].AcceptSocket, &stSockAddr, &iLen);
			USHORT usPort = ((sockaddr_in*)&stSockAddr)->sin_port;
			wsrMonSoc = L"Client connected at ephemeral port = " + to_wstring(usPort) + L"\r\n";
			pTabOne->SendMessageW(RG_WM_ED_SOC_T, (WPARAM)wsrMonSoc.c_str());

			pstHook->astChann[iCount].pHook = pstHook;
			pstHook->ahReceiveTp[iCount] = CreateThread(NULL, 0, ReceiveTp, &pstHook->astChann[iCount], 0, NULL);	//+++ Default security; default stack; thr func name; argument to thr func; default flags; no thr identifier.
		}
	}

	shutdown(ListenSocket, SD_RECEIVE);
	closesocket(ListenSocket);	//+++ No longer need server socket.	

	pTabOne->jedCuSocTh.bChangeBkgnd = true;
	pTabOne->jedCuSocTh.RedrawWindow();

	//+++ Wait till all ReceiveTp instances exit.
	dwWaitResult = WaitForMultipleObjects(ARRAY_SIZE(pstHook->ahReceiveTp), pstHook->ahReceiveTp, TRUE, INFINITE);
	switch (dwWaitResult)
	{
	case WAIT_OBJECT_0:
		for (int iCount = 0; iCount < ARRAY_SIZE(pstHook->ahReceiveTp); iCount++)	//+++ Close thread procedure handles.			
		{
			pstHook->pTabOne->ShutCloseSocket(pstHook->astChann[iCount].AcceptSocket);
			GetExitCodeThread(pstHook->ahReceiveTp[iCount], &dwExitCodeThread);
			CloseHandle(pstHook->ahReceiveTp[iCount]);
			if (dwExitCodeThread == ERROR_COMM)
				return MsgWsaCMA(pstHook, L"ConnectTp waited for ahReceiveTp failure." + (wstring)L"\r\n", true);
			if (dwExitCodeThread == ERROR_CLIENT_SIDE)
			{
				MsgWsaCMA(pstHook, L"ConnectTp waited for ahReceiveTp disconnection from client side." + (wstring)L"\r\n", true);
				return ERROR_CLIENT_SIDE;
			}
		}
		break;
	}

	WSACleanup();

	return NO_ERROR;
}

DWORD WINAPI ReceiveTp(LPVOID lpParam)
{
	Hook::Channel *pstChannel = (Hook::Channel*)lpParam;
	Hook *pstHook = (Hook*)pstChannel->pHook;
	CDialogEx *pCommon = NULL;
	CTabOne *pTabOne = pstHook->pTabOne;
	CTabTwo *pTabTwo = pstHook->pTabTwo;
	CTabThree *pTabThree = pstHook->pTabThree;
	CTabFour *pTabFour = pstHook->pTabFour;
	CTabFive *pTabFive = pstHook->pTabFive;
	int iResult, iBytesReceived = 0, iTimes = 0;	//+++ Result of recv; total bytes received from remote thread; number of strings received from RaspberryPi2 client.
	string srReceived;	//+++ Present string received from RaspberryPi2 client.
	char acReceived[BUFLEN];
	bool bStart = true;	//+++ Only first time each remote thread sends its name.
	UINT uiWmEdThrM, uiWmEdThrV, uiWmPgsThr;	//+++ WMsg for: Edit ctrl monitor; Edit ctrl value; Progress ctrl.
	wstring wsrRemoteThread, wsrMonitor, wsrTotRec;	//+++ Remote thread name; msg for Edit ctrl; total string received from RaspberryPi2 client.

													//+++ Receive until the peer closes the connection.
	do
	{
		iResult = recv(pstChannel->AcceptSocket, acReceived, BUFLEN, 0);	//+++ Never use string.c_str() : tricky sometimes works other times don't.

		if (iResult > 0)
		{
			iTimes++;
			iBytesReceived += iResult;
			srReceived = acReceived;
			wstring wsrReceived = StToWsUtf8(srReceived.c_str());	//+++ String received from RaspberryPi2 client.

			if (bStart == true)
			{
				bStart = false;
				wstring wsrAffinity;
				wsrRemoteThread = wsrReceived;

				if (wsrRemoteThread == L"ONE")
				{
					wsrAffinity = ThrAffinity(6);
					uiWmEdThrM = RG_WM_ED_THR1M;
					uiWmEdThrV = RG_WM_ED_THR1V;
					uiWmPgsThr = RG_WM_PGS_THR1;
					pTabTwo->jedThr1M.EnableWindow();
					pTabTwo->jedThr1V.EnableWindow();
					pTabTwo->jpgsThr1.EnableWindow();
					pTabTwo->jpgsThr1.SetPos(0);
					pstChannel->uiWmEdMonitor = RG_WM_ED_THR1M;
					pCommon = (pstChannel->pCommon = pTabTwo);
				}
				else if (wsrRemoteThread == L"TWO")
				{
					wsrAffinity = ThrAffinity(6);
					uiWmEdThrM = RG_WM_ED_THR2M;
					uiWmEdThrV = RG_WM_ED_THR2V;
					uiWmPgsThr = RG_WM_PGS_THR2;
					pTabThree->jedThr2M.EnableWindow();
					pTabThree->jedThr2V.EnableWindow();
					pTabThree->jpgsThr2.EnableWindow();
					pstChannel->uiWmEdMonitor = RG_WM_ED_THR2M;
					pCommon = (pstChannel->pCommon = pTabThree);
				}
				else if (wsrRemoteThread == L"THREE")
				{
					wsrAffinity = ThrAffinity(6);
					uiWmEdThrM = RG_WM_ED_THR3M;
					uiWmEdThrV = RG_WM_ED_THR3V;
					uiWmPgsThr = RG_WM_PGS_THR3;
					pTabThree->jedThr3M.EnableWindow();
					pTabThree->jedThr3V.EnableWindow();
					pTabThree->jpgsThr3.EnableWindow();
					pstChannel->uiWmEdMonitor = RG_WM_ED_THR3M;
					pCommon = (pstChannel->pCommon = pTabThree);
				}
				else if (wsrRemoteThread == L"TEMPORARY")
				{
					wsrAffinity = ThrAffinity(6);
					uiWmEdThrM = RG_WM_ED_THR4M;
					uiWmEdThrV = RG_WM_ED_THR4V;
					pstChannel->uiWmEdMonitor = RG_WM_ED_THR4M;
					pCommon = (pstChannel->pCommon = pTabFour);
				}

				pCommon->SendMessageW(uiWmEdThrM, (WPARAM)wsrAffinity.c_str());
				wsrMonitor = L"First bytes received: " + to_wstring(iResult) + L"\r\n";
				pCommon->SendMessageW(uiWmEdThrM, (WPARAM)wsrMonitor.c_str());
				pCommon->SendMessageW(uiWmEdThrM, (WPARAM)wsrReceived.c_str());
			}

			if (wsrTotRec.length() > RECEIVED_STRING_LENGTH)
				wsrTotRec.clear();

			wsrTotRec += wsrReceived + L"\r\n";

			if (wsrRemoteThread != L"TEMPORARY")
			{
				pCommon->SendMessageW(uiWmEdThrV, (WPARAM)wsrReceived.c_str());
				pCommon->SendMessageW(uiWmPgsThr, (WPARAM)wsrReceived.c_str());
			}
			else if (wsrRemoteThread == L"TEMPORARY" && wsrReceived != L"TEMPORARY")
			{
				static int siCountString = 0;
				if (siCountString == 0 || siCountString == 1)
				{
					pTabFour->jedThr4M.EnableWindow();
					pTabFour->jedThr4V.EnableWindow();
				}
				else if (siCountString == 2)
					strcpy_s(pstHook->stServerI2c.acIP, sizeof(pstHook->stServerI2c.acIP), srReceived.c_str());
				else if (siCountString == 3)
					strcpy_s(pstHook->stServerI2c.acPort, sizeof(pstHook->stServerI2c.acPort), srReceived.c_str());
				else if (siCountString == 4)
					strcpy_s(pstHook->stServerI2c.acWebPortR3, sizeof(pstHook->stServerI2c.acWebPortR3), srReceived.c_str());
				else if (siCountString == 5)
					strcpy_s(pstHook->stServerI2c.acWebPortNi, sizeof(pstHook->stServerI2c.acWebPortNi), srReceived.c_str());
				
				siCountString++;

				if (siCountString == 6)
				{
					pstHook->hI2cMaTxTp = CreateThread(NULL, 0, I2cMaTxTp, pstHook, 0, NULL);
					pTabFive->SendMessageW(RG_WM_INPUT_WEB);
					break;	//+++ This thread stops here and is replaced by I2cMaTxTp.
				}
			}
		}
		else
		{
			//+++ No messages sent to possible dismissed dialogs. They can't be delivered: exception or block of app. 
			pstChannel->wsrMonitor += L"Total bytes received: " + to_wstring(iBytesReceived) + L"\r\n";
			pstChannel->wsrMonitor += L"Total strings received: " + to_wstring(iTimes) + L"  Only last are shown.\r\n";
			pstChannel->wsrMonitor += wsrTotRec;
			pstChannel->wsrMonitor += L"Connection closed.\n";

			if (iResult == 0)
			{
				pstChannel->wsrMonitor += L"Connection closed by client: " + wsrRemoteThread + L"\r\n";
				pstHook->pAsiDlg->SendMessageW(RG_WM_PIC_LIGHT, INDIGO_LIGHT);
				return ERROR_CLIENT_SIDE;
			}

			if (iResult < 0)
			{
				pstChannel->wsrMonitor += L"Something wrong: " + wsrRemoteThread + L"\r\n";
				pstHook->pAsiDlg->SendMessageW(RG_WM_PIC_LIGHT, RED_LIGHT);
				return ERROR_COMM;
			}
		}
	} while (iResult > 0);

	return NO_ERROR;
}

DWORD WINAPI I2cMaTxTp(LPVOID lpParam)
{
	ThrAffinity(12);
	Hook *pstHook = (Hook*)lpParam;
	CAsiDlg *pAsiDlg = pstHook->pAsiDlg;
	CTabFour *pTabFour = pstHook->pTabFour;
	CTabOne *pTabOne = pstHook->pTabOne;

	pstHook->SockManual = ConnectToServer(pstHook);
	pstHook->hI2cMaRxTp = CreateThread(NULL, 0, I2cMaRxTp, pstHook, 0, NULL);

	string srBnShut;
	pstHook->pTabOne->jbnShut.EnableWindow();	

	//+++ Default event attributes; manual-reset event; initial state nonsignaled; no name.	
	pTabFour->hRbAdcEv = CreateEvent(NULL, TRUE, FALSE, NULL);
	pTabFour->hRbPwmEv = CreateEvent(NULL, TRUE, FALSE, NULL);
	pTabFour->hSliEv = CreateEvent(NULL, TRUE, FALSE, NULL);
	pTabFour->hI2cTestEv = CreateEvent(NULL, TRUE, FALSE, NULL);

	bool bCycle = true;
	pTabFour->InputCtrl(true);
	HANDLE ahKernelObj[5] = { pTabFour->hRbAdcEv, pTabFour->hRbPwmEv, pTabFour->hSliEv, pTabFour->hI2cTestEv, pAsiDlg->hShutI2cMaTxEv };
	while (bCycle == true)
	{
		DWORD dwWaitResults = WaitForMultipleObjects(ARRAY_SIZE(ahKernelObj), ahKernelObj, FALSE, INFINITE);
		switch (dwWaitResults)
		{
		case WAIT_OBJECT_0 + 0:	//+++ Radiobuttons of TabFour for ADC.
			send(pstHook->SockManual, pTabFour->srRbAdc.c_str(), (int)pTabFour->srRbAdc.size(), 0);
			ResetEvent(pTabFour->hRbAdcEv);
			break;
		case WAIT_OBJECT_0 + 1:	//+++ Radiobuttons of TabFour for PWM.
			send(pstHook->SockManual, pTabFour->srRbPwm.c_str(), (int)pTabFour->srRbPwm.size(), 0);
			ResetEvent(pTabFour->hRbPwmEv);
			break;
		case WAIT_OBJECT_0 + 2:	//+++ Slider of TabFour for PWM.
			send(pstHook->SockManual, pTabFour->srSlid.c_str(), (int)pTabFour->srSlid.size(), 0);
			ResetEvent(pTabFour->hSliEv);
			break;
		case WAIT_OBJECT_0 + 3:	//+++ Test I2C.	
			pstHook->hI2cAuTxTp = CreateThread(NULL, 0, I2cAuTxTp, pstHook, 0, NULL);
			ResetEvent(pTabFour->hI2cTestEv);
			break;
		case WAIT_OBJECT_0 + 4:		//+++ Shutting communication.			
			srBnShut = to_string(I2C_RY_SHUT_COMM);
			send(pstHook->SockManual, srBnShut.c_str(), (int)srBnShut.size(), 0);
			ResetEvent(pAsiDlg->hShutI2cMaTxEv);
			bCycle = false;
			break;
		}
	}

	//+++ Cleanup.
	shutdown(pstHook->SockManual, SD_SEND);	//+++ Not strictly necessary as it happens at dismissal of app, but it avoids rough termination of I2cMaRxTp with memory leaks.

	return NO_ERROR;
}

DWORD WINAPI I2cMaRxTp(LPVOID lpParam)
{
	ThrAffinity(12);
	Hook *pstHook = (Hook*)lpParam;
	pstHook->astThreadExCo[TEC_I2CMARX].hThreadExCo = pstHook->hI2cMaRxTp;
	pstHook->astThreadExCo[TEC_I2CMARX].pAsiDlg = pstHook->pAsiDlg;
	CreateThread(NULL, 0, ThreadExCoTp, &pstHook->astThreadExCo[TEC_I2CMARX], 0, NULL);

	CTabFour *pTabFour = pstHook->pTabFour;
	CTabOne *pTabOne = pstHook->pTabOne;
	int iResult;
	string srReceived;
	char acReceived[BUFLEN] = "";

	do
	{
		iResult = recv(pstHook->SockManual, acReceived, BUFLEN, 0);	//+++ Never use string.c_str() : tricky sometimes works other times don't.
		if (iResult > 0)
		{
			srReceived = acReceived;
			int iReceived = atoi(srReceived.c_str());
			if (iReceived >= 0 && iReceived < I2C_RY_SHUT_COMM)
				pTabFour->jpgsThr4.SetPos(iReceived);
		}
		else if (iResult == 0)
			pTabOne->SendMessageW(RG_WM_ED_SOC_T, (WPARAM)L"I2cMaRxTp connection closed\r\n");
		else
			return MsgWsaCMA(pstHook, L"recv() failed with error: " + to_wstring(WSAGetLastError()) + L"\r\n", false, pstHook->SockManual);
	} while (iResult > 0);

	//+++ Cleanup.
	closesocket(pstHook->SockManual);

	return NO_ERROR;
}

DWORD WINAPI I2cAuTxTp(LPVOID lpParam)
{
	ThrAffinity(12);
	Hook *pstHook = (Hook*)lpParam;
	CAsiDlg *pAsiDlg = pstHook->pAsiDlg;
	CTabFour *pTabFour = pstHook->pTabFour;

	pstHook->SockAutom = ConnectToServer(pstHook);
	pstHook->hI2cAuRxTp = CreateThread(NULL, 0, I2cAuRxTp, pstHook, 0, NULL);

	int iCount = 0;
	string srTestI2c;	//+++ Tests I2C, with feed back.
	bool bCycle = true;
	LARGE_INTEGER liDueTime;
	liDueTime.QuadPart = -10 * 1000 * 100;

	HANDLE hPeriodicTmr = CreateWaitableTimer(NULL, FALSE, NULL);	//+++ Create an unnamed synchronization waitable timer.
	SetWaitableTimer(hPeriodicTmr, &liDueTime, 100, NULL, NULL, 0);	//+++ Timer is periodic.

	HANDLE ahKernelObj[2] = { hPeriodicTmr, pAsiDlg->hShutI2cAuTxEv };
	while (bCycle == true)
	{
		DWORD dwWaitResults = WaitForMultipleObjects(ARRAY_SIZE(ahKernelObj), ahKernelObj, FALSE, INFINITE);
		switch (dwWaitResults)
		{
		case WAIT_OBJECT_0 + 0:	//+++ I2C test.
			srTestI2c = to_string(iCount);
			send(pstHook->SockAutom, srTestI2c.c_str(), (int)srTestI2c.size(), 0);
			iCount++;
			if (iCount == I2C_RY_SHUT_COMM)
			{
				srTestI2c = to_string(iCount - 1);
				send(pstHook->SockAutom, srTestI2c.c_str(), (int)srTestI2c.size(), 0);
				bCycle = false;
			}
			break;
		case WAIT_OBJECT_0 + 1:	//+++ Shutting communication: exit from thread.			
			ResetEvent(pAsiDlg->hShutI2cAuTxEv);
			bCycle = false;
			break;
		}
	}

	//+++ Cleanup.
	CloseHandle(hPeriodicTmr);
	shutdown(pstHook->SockAutom, SD_SEND);	//+++ When Raspberry receives this, it will close the socket and I2cAuRxTp will receive 0 bytes, breaking off recv loop.
	pTabFour->InputCtrl(true);

	return NO_ERROR;
}

DWORD WINAPI I2cAuRxTp(LPVOID lpParam)
{
	ThrAffinity(12);
	Hook *pstHook = (Hook*)lpParam;
	pstHook->astThreadExCo[TEC_I2CAURX].hThreadExCo = pstHook->hI2cAuRxTp;
	pstHook->astThreadExCo[TEC_I2CAURX].pAsiDlg = pstHook->pAsiDlg;
	CreateThread(NULL, 0, ThreadExCoTp, &pstHook->astThreadExCo[TEC_I2CAURX], 0, NULL);

	CTabFour *pTabFour = pstHook->pTabFour;
	CTabOne *pTabOne = pstHook->pTabOne;
	int iResult;
	string srReceived;
	char acReceived[BUFLEN] = "";

	do
	{
		iResult = recv(pstHook->SockAutom, acReceived, BUFLEN, 0);	//+++ Never use string.c_str() : tricky sometimes works other times don't.
		if (iResult > 0)
		{
			srReceived = acReceived;
			int iReceived = atoi(srReceived.c_str());
			if (iReceived >= 0 && iReceived < I2C_RY_SHUT_COMM)
				pTabFour->jpgsThr4.SetPos(iReceived);
		}
		else if (iResult == 0)
			pTabOne->SendMessageW(RG_WM_ED_SOC_T, (WPARAM)L"I2cAuRxTp connection closed\r\n");
		else
			return MsgWsaCMA(pstHook, L"recv() failed with error: " + to_wstring(WSAGetLastError()) + L"\r\n", false, pstHook->SockAutom);
	} while (iResult > 0);

	//+++ Cleanup.
	closesocket(pstHook->SockAutom);
	pTabFour->jpgsThr4.SetPos(0);

	return NO_ERROR;
}