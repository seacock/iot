#include "Spi.h"
#include "ShaDe.h"   
#include <PPS.h>    //+++ For PPSUnLock and similar.

#if __XC16_VERSION__ >= 0x0401
#undef _ISR
#define _ISR __attribute__((interrupt, auto_psv))
#endif

unsigned int guiSpiReset;
extern unsigned char guchUB[2], guchLB[2], guchUpdate[2], 
                            guchUBAveF[2], guchLBAveF[2], guchUpdateAve[2];

int mainSPIsX(void) 
{       
    ConfigSpiPortPins();
    ConfigSpiPPS();
    SetupSpi();
    Timer3TypeA();
    
    return 0;
}

void ConfigSpiPortPins(void)
{
    TRISBbits.TRISB14 = INPUT_PIN;   //+++ SDI1: hwPin = 25.
    TRISBbits.TRISB15 = OUTPUT_PIN;  //+++ SDO1: hwPin = 26.
    TRISBbits.TRISB2 = INPUT_PIN;   //+++ SCK1: hwPin = 6.
    TRISBbits.TRISB3 = INPUT_PIN;   //+++ SS1: hwPin = 7.
}

void ConfigSpiPPS(void)
{
    PPSUnLock;  //+++ Unlock the PPS functionality.
    iPPSInput(IN_FN_PPS_SDI1, IN_PIN_PPS_RP14);      //+++ SDI1: hwPin = 25.
    iPPSOutput(OUT_PIN_PPS_RP15, OUT_FN_PPS_SDO1);   //+++ SDO1: hwPin = 26.
    iPPSInput(IN_FN_PPS_SCK1IN, IN_PIN_PPS_RP2);    //+++ SCK1: hwPin = 6.
    iPPSInput(IN_FN_PPS_SS1IN, IN_PIN_PPS_RP3);     //+++ SS1: hwPin = 7.
    PPSLock;    //+++ Lock the PPS functionality.
}

void SetupSpi(void)
{
    //+++ SPI register configuration for Slave mode, byte-wide.
    IFS0bits.SPI1IF = 0;        //+++ Clear the Interrupt flag.
    IEC0bits.SPI1IE = 0;        //+++ Disable the interrupt.
    SPI1STATbits.SPIEN = 0;     //+++ Disable SPI module.
    
    //+++ The only valid combination with CKP. Serial output data changes on 
    //+++ transition from Active clock state to Idle clock state.
    SPI1CON1bits.CKE = 1;     
    SPI1CON1bits.SSEN = 1;      //+++ SS1 pin used for Slave mode.        
    IFS0bits.SPI1IF = 0;        //+++ Clear the Interrupt flag.
    IPC2bits.SPI1IP = 6;        //+++ SPI1 interrupt priority.
    IEC0bits.SPI1IE = 1;        //+++ Enable the interrupt.
    SPI1STATbits.SPIEN = 1;     //+++ Enable SPI module.
    
    SPI1BUF = 0;    //+++ Clear the register, to avoid dirty data.
}

void _ISR _SPI1Interrupt(void)
{        
    WORD data = SPI1BUF;    //+++ Read the data. No delay before this line.
    
    //+++ When Pic24 SPI blocks, it needs a local SPI reset as Rasperry wouldn't be able to enter
    //+++ this ISR anymore. If timer3 expires outside of here, it will reset SPI. Now reset timer3.
    T3CONbits.TON = 0;  //+++ Stop timer 3.
    TMR3 = 0;   //+++ Prepare zeroed timer.
    T3CONbits.TON = 1;  //+++ Start timer 3. 
    
	//+++ Write the next data byte: needs to happen before the next byte/word is received. This IRQ
    //+++ is triggered 1/2 bit time before the end of the last bit of this byte/word. So if the 
    //+++ master is fast, we must service to her before the start of the first bit of the next 
    //+++ byte/word. On first request from Raspberry, SPI1BUF is assigned the AD value. On second 
    //+++ identical request from Raspberry, SPI1BUF value will be sent back to Raspberry. Shift 
    //+++ register over network.    
    switch (data)
    {
        case CMD_UB_RS:
            SPI1BUF = guiSpiReset >> 8;
            break;
        case CMD_LB_RS:
            SPI1BUF = guiSpiReset;
            break;
    }
    
    switch (PORTBbits.RB5)
    {
        case AVE_ADC:
            switch (data)
            {
                case CMD_UB_P:  //+++ ADC stops updating average at first one.
                    guchUpdateAve[POTENT]++;    
                    SPI1BUF = guchUBAveF[POTENT];
                    break;
                case CMD_LB_P:
                    guchUpdateAve[POTENT]++;
                    SPI1BUF = guchLBAveF[POTENT];
                    break;                         
                case CMD_UB_T:  //+++ ADC stops updating average at first one.
                    guchUpdateAve[THERMO]++;                    
                    SPI1BUF = guchUBAveF[THERMO];
                    break;
                case CMD_LB_T:
                    guchUpdateAve[THERMO]++;
                    SPI1BUF = guchLBAveF[THERMO];  
                    break;
            }
            break;    
        case LAST_ADC:
            switch (data)
            {
                case CMD_UB_P:
                    guchUpdate[POTENT]++;
                    SPI1BUF = guchUB[POTENT];	
                    break;
                case CMD_LB_P:
                    guchUpdate[POTENT]++;
                    SPI1BUF = guchLB[POTENT];	
                    break;
                case CMD_UB_T:
                    guchUpdate[THERMO]++;
                    SPI1BUF = guchUB[THERMO];      
                    break;
                case CMD_LB_T:
                    guchUpdate[THERMO]++;
                    SPI1BUF = guchLB[THERMO];
                    break;
            }
            break;    
    }
    
    int iCount;
    for (iCount = 0; iCount < N_SENS; iCount++)
    {
        if (guchUpdate[iCount] == FOUR_STEPS)
            guchUpdate[iCount] = 0; //+++ ADC starts updating average.
        if (guchUpdateAve[iCount] == FOUR_STEPS)
            guchUpdateAve[iCount] = 0;  //+++ ADC starts updating average.    
    }
    
	IFS0bits.SPI1IF = 0;            //Clear the Interrupt Flag.
}

void ResetSpi(void)
{
    SPI1STATbits.SPIEN = 0; //+++ Disable SPI module.
    SPI1BUF = 0;    //+++ Clear the register, to avoid dirty data.
    IFS0bits.SPI1IF = 0;    //+++ Clear the Interrupt flag.
    IEC0bits.SPI1IE = 0;    //+++ Disable the interrupt.
    IEC0bits.SPI1IE = 1;    //+++ Enable the interrupt.
    SPI1STATbits.SPIEN = 1; //+++ Enable SPI module.   
    
    ZeroAve(POTENT);    //+++ Re-initialize variables, probably dirty, due to accidental SPI halt.
    ZeroAve(THERMO);    //+++ Re-initialize variables, probably dirty, due to accidental SPI halt.
    ZeroVal(POTENT);    //+++ Re-initialize variables, probably dirty, due to accidental SPI halt.
    ZeroVal(THERMO);    //+++ Re-initialize variables, probably dirty, due to accidental SPI halt.
}

void Timer3TypeA(void)
{
    T3CON = 0x00;   //+++ Reset Timer3 control register and stop Timer3.
    TMR3 = 0x00;    //+++ Clear contents of Timer3 Register.
    T3CONbits.TCKPS = 0x03; //+++ Timer3 Input Clock Prescale Select. 1:256.
    PR3 = 100;  //+++ Load the Period Register 3. 3.3 msec Interval within which SPI reset doesn't occur.
    IPC2bits.T3IP = 0x02;   //+++ Timer3 Interrupt Priority.
    _T3IF = 0;  //+++ Clear Timer3 interrupt status flag.
    _T3IE = 1;  //+++ Enable Timer3 interrupts. 
    
    guiSpiReset = 0;
}

void _ISR _T3Interrupt(void)
{    
    //+++ The delay between each request from Raspberry to SPI ISR must be shorter than 
    //+++ TIMER3_PERIOD or this game doesn't work. If timer3 interval expires, that means that
    //+++ Raspberry is repeating regularly its requests, but SPI ISR is blocked. So timer3 
    //+++ intervenes resetting SPI.
    ResetSpi();
    guiSpiReset++; 
    
    _T3IF = 0;
}