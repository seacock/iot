/*
 * RxQRf.c
 *
 *  Created on: 06 nov 2018
 *      Author: andre
 */

/*
 * Copyright (c) 2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/***** Includes *****/
/* Standard C Libraries */
#include <stdlib.h>

/* TI Drivers */
#include <ti/drivers/rf/RF.h>
#include <ti/drivers/PIN.h>


/* Driverlib Header files */
#include DeviceFamily_constructPath(driverlib/rf_prop_mailbox.h)

#include DeviceFamily_constructPath(driverlib/rf_data_entry.h)
#include DeviceFamily_constructPath(driverlib/rf_mailbox.h)


/* Board Header files */
#include "Board.h"

/* Application Header files */
#include "smartrf_settings/smartrf_settings.h"

#include <^Common.h>

/***** Defines *****/

/* Packet RX Configuration */
#define BUFFER_ENTRIES 5    //+++ Ad libitum.
#define TX_PAYLOAD_LENGTH 41    //+++ Starting point: Tx packet feature.
#define NUM_APPENDED_BYTES 2    //+++ The Data Entries data field will contain: 1 Header byte (RF_cmdPropRx.rxConf.bIncludeHdr = 0x1); Max 30 payload bytes; 1 status byte (RF_cmdPropRx.rxConf.bAppendStatus = 0x1) .
#define DATA_SECTION_SIZE (TX_PAYLOAD_LENGTH + NUM_APPENDED_BYTES) //+++ Must be word-aligned.
#define ENTRY_HEADER_SIZE 7 //+++ Ad libitum.
#define BUFFER_SIZE_BYTES (BUFFER_ENTRIES * (ENTRY_HEADER_SIZE + DATA_SECTION_SIZE))
#pragma DATA_ALIGN(buffer, 4)   //+++ Buffer contains all Data Entries for receiving data. Pragmas needed to make sure buffer is 4 byte aligned (requirement from the RF Core).
uint8_t buffer[BUFFER_SIZE_BYTES];

/***** Prototypes *****/
static void callback(RF_Handle h, RF_CmdHandle ch, RF_EventMask e);
void StartDisplayTf(void);

/***** Variable declarations *****/
static RF_Object rfObject;
static RF_Handle rfHandle;

/* Pin driver handle */
static PIN_Handle ledPinHandle;
static PIN_State ledPinState;

/* Receive dataQueue for RF Core to fill in data */

dataQueue_t queue;
rfc_dataEntryGeneral_t* rxEntry;
static uint8_t packet[TX_PAYLOAD_LENGTH]; //+++

//+++ Application pin configuration table: All board LEDs are off.
PIN_Config pinTable[] =
{
    BOARD_PIN_RED_LED | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
    PIN_TERMINATE
};

Void DisplayTf(UArg arg0, UArg arg1);
Task_Struct stDisplayTask;
#pragma DATA_ALIGN(aucDisplayTaskStack, 8)  //+++ 1-byte alignment on the stack to avoid wasting memory.
static uint8_t aucDisplayTaskStack[STACKSIZE];
Semaphore_Handle hSemQ; //+++ Semaphore to block slow display, leaving scheduler to decide.
Semaphore_Struct stSemQ;
Semaphore_Params stSemParamsQ;

static uint8_t packetTot[TX_PAYLOAD_LENGTH * 10] =""; //+++

/***** Function definitions *****/

Void RxRadioQTf(UArg arg0, UArg arg1)
{
    //+++ Semaphore initialization.
    Semaphore_Params_init(&stSemParamsQ);
    Semaphore_construct(&stSemQ, 0, &stSemParamsQ);
    hSemQ = Semaphore_handle(&stSemQ);

    StartDisplayTf();

    RF_Params rfParams;
    RF_Params_init(&rfParams);

    ledPinHandle = PIN_open(&ledPinState, pinTable);    //+++ Open pin configuration table.
    if (ledPinHandle == NULL)
        while(1);

    uint8_t i;
    rfc_dataEntryGeneral_t *item = (rfc_dataEntryGeneral_t*)&buffer[0];
    for (i = 0; i < BUFFER_ENTRIES; i++)
    {
        item->config.type = DATA_ENTRY_TYPE_GEN;    //+++ General Data Entry.
        item->config.lenSz  = 0;    //+++ No length indicator byte in data.
        item->length = DATA_SECTION_SIZE;   //+++ Total length of data field.
        item->status = DATA_ENTRY_PENDING;  //+++ Pending - starting state.

        uint8_t pad = 4 - ((DATA_SECTION_SIZE + ENTRY_HEADER_SIZE) % 4);    //+++ Padding needed for 4-byte alignment.
        item->pNextEntry = ((uint8_t*)item) + ENTRY_HEADER_SIZE + DATA_SECTION_SIZE + pad;

        /* Make circular Last.Next -> First */
        if (i == (BUFFER_ENTRIES - 1))
            item->pNextEntry = buffer;// Close the circle for the last item

        item = (rfc_dataEntryGeneral_t*)item->pNextEntry;
    }

    /* Create Data Entry Queue and configure for circular buffer Data Entries */
    queue.pCurrEntry = &buffer[0];
    queue.pLastEntry = NULL;

    rxEntry = (rfc_dataEntryGeneral_t*)queue.pCurrEntry;    //+++ Initialize read pointer to the first entry.

    /* Modify CMD_PROP_RX command for application needs */
    RF_cmdPropRx.pQueue = &queue;   //+++ Set the Data Entity queue for received data.
    RF_cmdPropRx.rxConf.bAutoFlushIgnored = 1;  //+++ Discard ignored packets from Rx queue.
    RF_cmdPropRx.rxConf.bAutoFlushCrcErr = 1;   //+++ Discard packets with CRC error from Rx queue.

    /* Implement packet length filtering to avoid PROP_ERROR_RXBUF */
    RF_cmdPropRx.maxPktLen = DATA_SECTION_SIZE;
    RF_cmdPropRx.pktConf.bRepeatOk = 1;
    RF_cmdPropRx.pktConf.bRepeatNok = 1;

    rfHandle = RF_open(&rfObject, &RF_prop, (RF_RadioSetup*)&RF_cmdPropRadioDivSetup, &rfParams);   //+++ Request access to the radio.
    RF_postCmd(rfHandle, (RF_Op*)&RF_cmdFs, RF_PriorityNormal, NULL, 0);    //+++ Set the frequency.

    /* Enter RX mode and stay forever in RX */
    RF_EventMask terminationReason = RF_runCmd(rfHandle, (RF_Op*)&RF_cmdPropRx, RF_PriorityNormal, &callback,
                                                                                                   RF_EventRxEntryDone);

    switch(terminationReason)
    {
        case RF_EventLastCmdDone:
            //+++ A stand-alone radio operation command or the last radio operation command in a chain finished.
            break;
        case RF_EventCmdCancelled:
            //+++ Command cancelled before it was started; it can be caused by RF_cancelCmd() or RF_flushCmd().
            break;
        case RF_EventCmdAborted:
            //+++ Abrupt command termination caused by RF_cancelCmd() or RF_flushCmd().
            break;
        case RF_EventCmdStopped:
            //+++ Graceful command termination caused by RF_cancelCmd() or RF_flushCmd().
            break;
        default:
            //+++ Uncaught error event.
            while(1);
    }

    uint32_t cmdStatus = ((volatile RF_Op*)&RF_cmdPropRx)->status;
    switch(cmdStatus)
    {
        case PROP_DONE_OK:
            //+++ Packet received with CRC OK.
            break;
        case PROP_DONE_RXERR:
            //+++ Packet received with CRC error.
            break;
        case PROP_DONE_RXTIMEOUT:
            //+++ Observed end trigger while in sync search.
            break;
        case PROP_DONE_BREAK:
            //+++ Observed end trigger while receiving packet when the command is configured with endType set to 1.
            break;
        case PROP_DONE_ENDED:
            //+++ Received packet after having observed the end trigger;
            //+++ if the command is configured with endType set to 0, the end trigger will not terminate an ongoing reception.
            break;
        case PROP_DONE_STOPPED:
            //+++ received CMD_STOP after command started and, if sync found, packet is received.
            break;
        case PROP_DONE_ABORT:
            //+++ Received CMD_ABORT after command started.
            break;
        case PROP_ERROR_RXBUF:
            //+++ No RX buffer large enough for the received data available at the start of a packet.
            break;
        case PROP_ERROR_RXFULL:
            //+++ Out of RX buffer space during reception in a partial read.
            break;
        case PROP_ERROR_PAR:
            //+++ Observed illegal parameter.
            break;
        case PROP_ERROR_NO_SETUP:
            //+++ Command sent without setting up the radio in a supported mode using CMD_PROP_RADIO_SETUP or CMD_RADIO_SETUP.
            break;
        case PROP_ERROR_NO_FS:
            //+++ Command sent without the synthesizer being programmed.
            break;
        case PROP_ERROR_RXOVF:
            //+++ RX overflow observed during operation.
            break;
        default:
            //+++ Uncaught error event - these could come from the pool of states defined in rf_mailbox.h .
            while(1);
    }

    while(1);
}

void callback(RF_Handle h, RF_CmdHandle ch, RF_EventMask e)
{
    static int yyy = 0;
    if (e & RF_EventRxEntryDone)
    {
        PIN_setOutputValue(ledPinHandle, BOARD_PIN_RED_LED, !PIN_getOutputValue(BOARD_PIN_RED_LED));    //+++ Toggle pin to indicate RX.

        uint8_t packetLength = *(uint8_t*)(&rxEntry->data); //+++ Packet starts with 1 byte length information (lenSz = 1).
        uint8_t* packetDataPointer = (uint8_t*)(&rxEntry->data + sizeof(packetLength)); //+++ Payload follows.
        memcpy(packet, packetDataPointer, packetLength);   //+++ Read the payload from the buffer.
        ((volatile rfc_dataEntryGeneral_t*)rxEntry)->status = DATA_ENTRY_PENDING;   //+++ Mark the entry as being read.
        rxEntry =  ((rfc_dataEntryGeneral_t*)rxEntry->pNextEntry);  //+++ Get the next entry.

        yyy++;
        //if (yyy == 30 || yyy == 41 || yyy == 52 || yyy == 63 || yyy == 74 || yyy == 80 || yyy == 91 || yyy == 102 || yyy == 113 || yyy == 124)


        if (yyy >= 30 && yyy <= 39)
            strcat((char*)packetTot, (char*)packet);

        if (yyy==50)
        {
            yyy = 200;
            Semaphore_post(hSemQ);   //+++ Post to semaphore.
        }
        if (yyy==250)
            yyy--;

    }
}

Void DisplayTf(UArg arg0, UArg arg1)
{
//    while (1)
//    {
//        Semaphore_pend(hSemQ, BIOS_WAIT_FOREVER);    //+++ Wait on sem indefinitely.
//        int uuu;
//        for (uuu = 0; uuu < TX_PAYLOAD_LENGTH; uuu++)
//            Display_printf(display, 0, 0, "Received: %c   seq: %d", packet[uuu], uuu);
//    }

    Semaphore_pend(hSemQ, BIOS_WAIT_FOREVER);    //+++ Wait on sem indefinitely.
    int uuu;
    for (uuu = 0; uuu < TX_PAYLOAD_LENGTH * 10; uuu++)
        Display_printf(display, 0, 0, "Received: %c   seq: %d", packetTot[uuu], uuu);
}

void StartDisplayTf(void)
{
    Task_Params stTaskParams;
    Task_Params_init(&stTaskParams);
    stTaskParams.stackSize = STACKSIZE;
    stTaskParams.priority = 4;
    stTaskParams.stack = &aucDisplayTaskStack;

    Task_construct(&stDisplayTask, DisplayTf, &stTaskParams, NULL);
}
