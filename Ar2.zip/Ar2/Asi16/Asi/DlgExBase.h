#pragma once

// CDlgExBase dialog

//+++ From this class are derived: all 5 Tab... dialog classes. So they can share custom features in addition to those of CDialogEx.
class CDlgExBase : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgExBase)
public:
	CDlgExBase(CWnd* pParent = NULL);   //+++ Standard constructor called by each derived class.
	virtual ~CDlgExBase();
	//+++ IDD_DLGEXBASE resource dialog and its enum have been eliminated: no AFX_DESIGN_TIME.
	SOCKET TieSockAddr(char *pcHostName, char *pcPortNumber, int iSide);	//+++ Given a host and its port, provides endpoint address to which to connect a socket.
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
private:
	template <typename T>
	string NumberToStringHex(T Number);	//+++ Transform a decimal number to a string of hex.
	DECLARE_MESSAGE_MAP()
};