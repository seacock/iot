#include "Ryie.h"

//+++ The delay between each of this calls must be shorter than TIMER3_PERIOD of Pic24 or the game doesn't work.
void SpiMaster(int iFdLas, Sensor &stSensor)
{
	timespec stTimeNano;
	stTimeNano.tv_sec = 0;
	stTimeNano.tv_nsec = (1000 * stSensor.uiDelay);	//+++  us

	unsigned char ucUpperByte, ucLowerByte;	//+++ Upper byte and lower byte of word (2 bytes) provided by AD converter of Pic24.
	int iVal;	//+++ Word (2 bytes) provided by AD converter of Pic24.	
	
	SpiDataRW(stSensor.ucUpper, ucUpperByte);
	clock_nanosleep(CLOCK_REALTIME, 0, &stTimeNano, NULL);	//+++ Important delay.
	SpiDataRW(stSensor.ucLower, ucLowerByte);
	iVal = (ucUpperByte << 8) + ucLowerByte;
#ifdef _TALKATIVE_
	if (stSensor.uiNumOfSpiCalls >= NUM_SPI_CALLS)
	{
		int iValReset;	//+++ Word (2 bytes) provided by AD converter of Pic24.
		SpiDataRW(CMD_UB_RS, ucUpperByte);
		clock_nanosleep(CLOCK_REALTIME, 0, &stTimeNano, NULL);	//+++ Important delay.
		SpiDataRW(CMD_LB_RS, ucLowerByte);
		iValReset = (ucUpperByte << 8) + ucLowerByte;	
		stSensor.ulTotNumOfSpiCalls += stSensor.uiNumOfSpiCalls;
		stSensor.uiNumOfSpiCalls = 0;
		cout << "----- " << stSensor.ulTotNumOfSpiCalls << " number of SPI calls--------" << endl;
		cout << "-----SPI resets: " << iValReset << endl;
		if (stSensor.ulTotNumOfSpiCalls > TOT_NUM_SPI_CALLS)
			stSensor.ulTotNumOfSpiCalls = 0;
		clock_nanosleep(CLOCK_REALTIME, 0, &stTimeNano, NULL);	//+++ Important delay.		
	}	  
#endif // _TALKATIVE_	
	if (stSensor.uiLaptopCounter >= LAPTOP_COUNTER)
	{
		SendValue(iFdLas, iVal, stSensor.srName);
#ifdef _TALKATIVE_
		cout << stSensor.srName << "   " << iVal << endl;
#endif // _TALKATIVE_
		stSensor.uiLaptopCounter = 0;
	}	

	if (stSensor.uiTomcatCounter >= TOMCAT_COUNTER)
	{
#ifdef _WEBTOM8_
		int iSock = SockAddrConn("localhost", atoi(ThreadInfo::SsrTom8ServerPort.c_str()));  //+++ Create the socket and connect to the server. Tomcat8 must be on, or connect() fails.
		CommServerWrite(iSock, iVal, stSensor.srName);	//+++ Send data to the server.
		close(iSock);  	  
#endif // _WEBTOM8_
#ifdef _TALKATIVE_
		cout << "+++++++++++++++ called Tomcat8   " << stSensor.srName << "   " << iVal << endl;	
#endif // _TALKATIVE_
		stSensor.uiTomcatCounter = 0;	
	}	
#ifdef _TALKATIVE_
	stSensor.uiNumOfSpiCalls++;
#endif // _TALKATIVE_
	stSensor.uiLaptopCounter++;	
	stSensor.uiTomcatCounter++;	

	clock_nanosleep(CLOCK_REALTIME, 0, &stTimeNano, NULL);	//+++ Important delay.
}

void SpiDataRW(unsigned char ucData, unsigned char &ucULByte)
{
	timespec stTimeNano;
	stTimeNano.tv_sec = 0;
	stTimeNano.tv_nsec = (1000 * 100);	//+++  us

	for (int iCount = 0; iCount < 2; iCount++)	//+++ First send command, second retrieve data. 	
	{
		wiringPiSPIDataRW(SPI_CHANNEL, &ucData, SPI_LENGTH);
		clock_nanosleep(CLOCK_REALTIME, 0, &stTimeNano, NULL);	//+++ Important delay.
	}		
		
	ucULByte = ucData;			
}

void CommServerWrite(int iFdTom8, int iValue, string srWho)
{
	vector<char> tchRecvLine(BUFLEN + 1);	//+++ Char array would do as well.
	string srPage = "/Inte/LocalComm", srHost = "localhost", srPostData, srRecv = "";	//+++ Server's page to ask for; name of server; data to send to server;	response from server.
	if (srWho == "Potentiometer")
		srPostData = "P";
	else if (srWho == "Thermometer")
		srPostData = "T";	
	
	srPostData += NumberToString(iValue);	//+++ Value to be written to RAM file.		
	
	//+++ Form request.
	string srSendLine = "POST " + srPage + " HTTP/1.0\r\n" + "Host: " + srHost + "\r\n" +    
		"Content-type: application/x-www-form-urlencoded\r\n" +	"Content-length: " + NumberToString(srPostData.length()) + "\r\n\r\n" +	srPostData + "\r\n";

	if (write(iFdTom8, srSendLine.c_str(), srSendLine.length()) >= 0)	 //+++ Write the request.
		while (read(iFdTom8, &tchRecvLine[0], BUFLEN) > 0)	 //+++ Read the response.
			srRecv += tchRecvLine.data();

	basic_string <char>::size_type kIndex;    
	const char *pcTrail = "\r\n\r\n";	//+++ Trailing chars to remove.
	kIndex = srRecv.find(pcTrail);
	string srOutput = "WWWSomething wrong...";
	if (kIndex != string::npos)
		srOutput = srRecv.substr(kIndex + strlen(pcTrail));	//+++ Remove the trailing chars.
#ifdef _BRIEF_
	cout << srOutput + "\r\n";	//+++ Output response.
#endif // _BRIEF_		
}