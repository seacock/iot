//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Asi.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_ASI_DIALOG                  102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDD_TAB_ONE                     104
#define IDD_TAB_TWO                     105
#define IDD_TAB_THREE                   106
#define IDD_TAB_FOUR                    107
#define IDD_TAB_FIVE                    108
#define IDD_DLGEXBASE                   109
#define IDR_MAINFRAME                   128
#define IDB_GREEN                       135
#define IDB_RED                         136
#define IDB_INDIGO                      137
#define IDC_TAB_FRAME                   1000
#define IDC_PIC_LIGHT                   1001
#define IDC_BN_LAN                      1002
#define IDC_BN_SHUT                     1003
#define IDC_ED_SYPRMT                   1004
#define IDC_ED_CU_SOCTH                 1005
#define IDC_ED_PORT                     1006
#define IDC_ED_THR4M                    1007
#define IDC_RB_THR4LASTADC              1008
#define IDC_RB_THR4AVEADC               1009
#define IDC_RB_THR4PWMC                 1010
#define IDC_RB_THR4PWMF                 1011
#define IDC_ED_THR4V                    1012
#define IDC_SL_THR4                     1013
#define IDC_BN_TEST_I2C                 1014
#define IDC_PGS_THR4                    1015
#define IDC_RB_NOIP                     1016
#define IDC_ED_THR1M                    1017
#define IDC_ED_THR1V                    1018
#define IDC_PGS_THR1                    1019
#define IDC_ED_THR2M                    1020
#define IDC_ED_THR3M                    1021
#define IDC_ED_THR2V                    1022
#define IDC_ED_THR3V                    1023
#define IDC_PGS_THR2                    1024
#define IDC_PGS_THR3                    1025
#define IDC_ED_TWEM                     1026
#define IDC_ED_TWHOS                    1027
#define IDC_BN_WEB                      1028
#define IDC_RB_REMOT3                   1029

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1030
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
