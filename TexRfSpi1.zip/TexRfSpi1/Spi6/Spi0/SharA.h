#pragma once

#include <string.h>

#define _BRIEF_
#define _TALKATIVE_

#define SUCCESS 0

#define GPIO3 3	//+++ Header pin 15
#define GPIO4 4	//+++ Header pin 16

#define handle_error_en(en, msg) \
               do { errno = en; cerr << msg << ": " << strerror(errno) << endl; exit(EXIT_FAILURE); } while (0)	//+++

#define handle_error(msg) \
               do { cerr << msg << ": " << strerror(errno) << endl; exit(EXIT_FAILURE); } while (0)	//+++ Print error message and exit app.

#define handle_error1(msg1) \
               do { cerr << msg1 << endl; exit(EXIT_FAILURE); } while (0)	

#define handle_error2(msg1, msg2) \
               do { cerr << msg1 << ": " << msg2 << endl; exit(EXIT_FAILURE); } while (0)

#define ARRAY_SIZE(array) (sizeof(array) / sizeof(array[0]))	