/*
 * Copyright (c) 2015-2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== ^Primary.c ========
 */
//+++ empty_CC1310_LAUNCHXL_tirtos_ccs Original project.

/* Driver Header files */
// #include <ti/drivers/GPIO.h>
// #include <ti/drivers/I2C.h>
// #include <ti/drivers/SDSPI.h>
// #include <ti/drivers/SPI.h>
// #include <ti/drivers/UART.h>
// #include <ti/drivers/Watchdog.h>

/* Board Header file */
#include "Board.h"

#include <^Common.h>
#include <^Adc.h>
#include <^Clock.h>

#pragma DATA_ALIGN(aucTxRadioTaskStack, 8)  //+++ 1-byte alignment on the stack to avoid wasting memory.
static uint8_t aucTxRadioTaskStack[STACKSIZE];

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    /* Call driver init functions */
    // GPIO_init();
    // I2C_init();
    // SDSPI_init();
    // SPI_init();
    // UART_init();
    // Watchdog_init();

    Semaphore_Struct stSemAdc, stSemTx;
    Semaphore_Params stSemParamsAdc, stSemParamsTx;

    ADC_init(); //+++ Call driver init functions.

    //+++ Dynamic pin configuration.
    PIN_Config DynPinCfg[] = {
        CC1310_LAUNCHXL_DIO15 | PIN_GPIO_OUTPUT_EN | PIN_GPIO_HIGH | PIN_PUSHPULL | PIN_INPUT_DIS | PIN_DRVSTR_MED, //+++ AdcTf
        CC1310_LAUNCHXL_DIO21 | PIN_GPIO_OUTPUT_EN | PIN_GPIO_HIGH | PIN_PUSHPULL | PIN_INPUT_DIS | PIN_DRVSTR_MED, //+++ AdcTf
        BOARD_PIN_GREEN_LED | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
        PIN_TERMINATE
    };
    PIN_State stPinState;
    hDynPin = PIN_open(&stPinState, DynPinCfg);

    //+++ Event initialization.
    Error_Block eb;
    Error_init(&eb);
    hEvnClockAndTx = Event_create(NULL, &eb);  //+++ Default instance configuration params.
    if (hEvnClockAndTx == NULL)
        System_abort("Event create failed");

    Types_FreqHz cpuFreq;
    BIOS_getCpuFreq(&cpuFreq);

    //+++ Semaphore initialization.
    Semaphore_Params_init(&stSemParamsAdc);
    Semaphore_construct(&stSemAdc, 0, &stSemParamsAdc);
    hSemAdc = Semaphore_handle(&stSemAdc);

    Semaphore_Params_init(&stSemParamsTx);
    Semaphore_construct(&stSemTx, 0, &stSemParamsTx);
    hSemTx = Semaphore_handle(&stSemTx);

    StartTxRadioTf();
    StartAdcTf();
    StartClockAdc();

    while (1) {
    }
}

void StartTxRadioTf(void)
{
    Task_Params stTaskParams;
    Task_Params_init(&stTaskParams);
    stTaskParams.stackSize = STACKSIZE;
    stTaskParams.priority = 4;
    stTaskParams.stack = &aucTxRadioTaskStack;

    Task_construct(&stTxRadioTask, TxRadioTf, &stTaskParams, NULL);
}
