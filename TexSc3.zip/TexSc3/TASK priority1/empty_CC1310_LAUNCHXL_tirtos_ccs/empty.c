/*
 * Copyright (c) 2015-2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== empty.c ========
 */

#include "scif.h"
#define BV(x)    (1 << (x))
//#define _MAIN_SQUARE_WAVE_
//#define _SERIAL_DISPLAY_

/* For usleep() */
#include <unistd.h>
#include <stdint.h>
#include <stddef.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/display/Display.h>

/* Board Header file */
#include "Board.h"

#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/BIOS.h>

PIN_Handle hDynPin;

Task_Struct stSquaWaTask;
/* Make sure we have nice 8-byte alignment on the stack to avoid wasting memory */
#pragma DATA_ALIGN(aucTaskStack, 8)
#define STACKSIZE 1024
static uint8_t aucTaskStack[STACKSIZE];
bool bHigh = false;

Void SquaWaTf(UArg arg0, UArg arg1)
{
  while (1) {
      bHigh = !bHigh;
      PIN_setOutputValue(hDynPin, CC1310_LAUNCHXL_DIO12, bHigh);
      Task_sleep(5);    //+++ Not too big.
  }
}

void StartTask(void)
{
    /* Set up the led task */
    Task_Params stTaskParams;
    Task_Params_init(&stTaskParams);
    stTaskParams.stackSize = STACKSIZE;
    stTaskParams.priority = 1;
    stTaskParams.stack = &aucTaskStack;

    Task_construct(&stSquaWaTask, SquaWaTf, &stTaskParams, NULL);
}

// Main loop Semaphore
Semaphore_Struct semMainLoop;
Semaphore_Handle hSemMainLoop;
uint32_t iCountLow = 0, iCountHigh = 0, iCycle = 0, iCountAve;
Display_Handle  displayHandle;

void processTaskAlert(void)
{
    scifClearAlertIntSource();  //+++ Clear the ALERT interrupt source.

    // Do SC Task processing here
    uint8_t high = scifTaskData.adcLevelTrigger.state.high; //+++ Fetch 'state.high' variable from SC.
    if (high == 0)
        iCountLow++;
    else if (high == 1)
        iCountHigh++;

    if (iCountLow == 4294967295)
        iCountLow = 0;

    if (iCountHigh == 4294967295)
        iCountHigh = 0;

    int iNumElem = sizeof(scifTaskData.adcLevelTrigger.output.pSamples) /
                                sizeof(scifTaskData.adcLevelTrigger.output.pSamples[0]);
#ifdef _SERIAL_DISPLAY_
    float fAve = 0;
    for (iCountAve = 0; iCountAve < iNumElem; iCountAve++)
        fAve += scifTaskData.adcLevelTrigger.output.pSamples[iCountAve];

    fAve = fAve / iNumElem;

    iCycle++;
    if (iCycle == 2000) {
        Display_printf(displayHandle, 1, 0, "ADC reading average of %d samples: %f    Low: %d     High: %d    every %d cycles",
                       iNumElem, fAve, iCountLow, iCountHigh, iCycle);
        iCycle = 0;
    }
#endif

    scifAckAlertEvents();   //+++ Acknowledge the ALERT event.
} // processTaskAlert

void scCtrlReadyCallback(void)
{
} // scCtrlReadyCallback

void scTaskAlertCallback(void)
{
    Semaphore_post(hSemMainLoop);   //+++ Post to main loop semaphore.
} // scTaskAlertCallback

/*
 *  ======== mainThread ========
 */
void *tirtosScThread(void *arg0)
{
    /* Call driver init functions */
    GPIO_init();

    /* Open Display Driver */
    Display_Params    displayParams;
    Display_Params_init(&displayParams);
    displayHandle = Display_open(Display_Type_UART, NULL);

    GPIO_setConfig(Board_GPIO_LED0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);   //+++ Configure the LED pin.

    //+++ Dynamic pin configuration.
    PIN_Config DynPinCfg[] = {

        CC1310_LAUNCHXL_DIO12 | PIN_GPIO_OUTPUT_EN | PIN_GPIO_HIGH | PIN_PUSHPULL |
                                                            PIN_INPUT_DIS | PIN_DRVSTR_MED,

        PIN_TERMINATE
    };
    PIN_State stPinState;
    hDynPin = PIN_open(&stPinState, DynPinCfg);

    //+++ Semaphore initialization.
    Semaphore_Params semParams;
    Semaphore_Params_init(&semParams);
    Semaphore_construct(&semMainLoop, 0, &semParams);
    hSemMainLoop = Semaphore_handle(&semMainLoop);

    //+++ Initialize the Sensor Controller.
    scifOsalInit();
    scifOsalRegisterCtrlReadyCallback(scCtrlReadyCallback);
    scifOsalRegisterTaskAlertCallback(scTaskAlertCallback);
    scifInit(&scifDriverSetup);

    //+++ Set the Sensor Controller task tick interval to 0.1 second.
    uint32_t rtc_Hz = 10;  // 10 Hz RTC
    scifStartRtcTicksNow(0x00010000 / rtc_Hz);

    //+++ Configure Sensor Controller tasks.
    scifTaskData.adcLevelTrigger.cfg.threshold = 1000;

    scifStartTasksNbl(BV(SCIF_GPIO_PIN_TRIGGER_TASK_ID));   //+++ Start the GPIO task.
    int iFlicker = 0;

#ifndef _MAIN_SQUARE_WAVE_
    StartTask();
#endif

    while (1) {
        //+++ Start the ADC Sampler task.
        while (scifWaitOnNbl(0) != SCIF_SUCCESS);
        scifResetTaskStructs(BV(SCIF_ADC_LEVEL_TRIGGER_TASK_ID), BV(SCIF_STRUCT_OUTPUT));
        scifExecuteTasksOnceNbl(BV(SCIF_ADC_LEVEL_TRIGGER_TASK_ID));

        Semaphore_pend(hSemMainLoop, BIOS_WAIT_FOREVER);    //+++ Wait on sem indefinitely.
        processTaskAlert(); //+++ Call process function.

#ifdef _MAIN_SQUARE_WAVE_
        bHigh = !bHigh;
        PIN_setOutputValue(hDynPin, CC1310_LAUNCHXL_DIO12, bHigh);
#endif
        iFlicker++;
        if (iFlicker == 1000) {
            GPIO_toggle(Board_GPIO_LED0);
            iFlicker = 0;
        }
    }
}
