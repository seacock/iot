/*
 * RxRf.c
 *
 *  Created on: 06 nov 2018
 *      Author: andre
 */

#include <^Common.h>
#include <^QueueRf.h>

uint8_t aucUpperLower[2 * TX_PAYLOAD_LENGTH];   //+++ 1) Each of RX_BUFFER_ENTRIES couples received. Apart the first sync couple, each remaining couple is upper and lower byte of Adc.
void ComposeCouple(uint8_t *pucRxPacket);

void RfTerminStatus(RF_EventMask terminationReason, uint32_t cmdStatus)
{
    switch(terminationReason)
    {
        case RF_EventLastCmdDone:
            //+++ A stand-alone radio operation command or the last radio operation command in a chain finished. Display_printf(DisplayH, 0, 0, "1");
            break;
        case RF_EventCmdCancelled:
            //+++ Command cancelled before it was started; it can be caused by RF_cancelCmd() or RF_flushCmd(). Display_printf(DisplayH, 0, 0, "2");
            break;
        case RF_EventCmdAborted:
            //+++ Abrupt command termination caused by RF_cancelCmd() or RF_flushCmd(). Display_printf(DisplayH, 0, 0, "3");
            break;
        case RF_EventCmdStopped:
            //+++ Graceful command termination caused by RF_cancelCmd() or RF_flushCmd(). Display_printf(DisplayH, 0, 0, "4");
            break;
        default:
            //+++ Uncaught error event. Display_printf(DisplayH, 0, 0, "5");
            while(1);
    }

    switch(cmdStatus)
    {
        case PROP_DONE_OK:
            //+++ Packet received with CRC OK. Display_printf(DisplayH, 0, 0, "6");
            break;
        case PROP_DONE_RXERR:
            //+++ Packet received with CRC error. Display_printf(DisplayH, 0, 0, "7");
            break;
        case PROP_DONE_RXTIMEOUT:
            //+++ Observed end trigger while in sync search. Display_printf(DisplayH, 0, 0, "8");
            break;
        case PROP_DONE_BREAK:
            //+++ Observed end trigger while receiving packet when the command is configured with endType set to 1. Display_printf(DisplayH, 0, 0, "9");
            break;
        case PROP_DONE_ENDED:
            //+++ Received packet after having observed the end trigger;
            //+++ if the command is configured with endType set to 0, the end trigger will not terminate an ongoing reception.Display_printf(DisplayH, 0, 0, "10");
            break;
        case PROP_DONE_STOPPED:
            //+++ received CMD_STOP after command started and, if sync found, packet is received. Display_printf(DisplayH, 0, 0, "11");
            break;
        case PROP_DONE_ABORT:
            //+++ Received CMD_ABORT after command started. Display_printf(DisplayH, 0, 0, "12");
            break;
        case PROP_ERROR_RXBUF:
            //+++ No RX buffer large enough for the received data available at the start of a packet. Display_printf(DisplayH, 0, 0, "13");
            break;
        case PROP_ERROR_RXFULL:
            //+++ Out of RX buffer space during reception in a partial read. Display_printf(DisplayH, 0, 0, "14");
            break;
        case PROP_ERROR_PAR:
            //+++ Observed illegal parameter. Display_printf(DisplayH, 0, 0, "15");
            break;
        case PROP_ERROR_NO_SETUP:
            //+++ Command sent without setting up the radio in a supported mode using CMD_PROP_RADIO_SETUP or CMD_RADIO_SETUP. Display_printf(DisplayH, 0, 0, "16");
            break;
        case PROP_ERROR_NO_FS:
            //+++ Command sent without the synthesizer being programmed. Display_printf(DisplayH, 0, 0, "17");
            break;
        case PROP_ERROR_RXOVF:
            //+++ RX overflow observed during operation. Display_printf(DisplayH, 0, 0, "18");
            break;
        default:
            //+++ Uncaught error event - these could come from the pool of states defined in rf_mailbox.h . Display_printf(DisplayH, 0, 0, "19");
            while(1);
    }

    if (enMode == CONTINUOUS)
        RF_close(rfHandle); //+++ Here.
}

 void RxRfCb(RF_Handle h, RF_CmdHandle ch, RF_EventMask e)
{
    if (e & RF_EventRxEntryDone)
    {
        PIN_setOutputValue(LedPinH, BOARD_PIN_RED_LED, !PIN_getOutputValue(BOARD_PIN_RED_LED));    //+++ Toggle pin to indicate RX.
        uint8_t packetLength = *(uint8_t*)(&rxEntry->data); //+++ Packet starts with 1 byte length information (lenSz = 1).
        uint8_t* packetDataPointer = (uint8_t*)(&rxEntry->data + sizeof(packetLength)); //+++ Payload follows.
        uint8_t aucRxPacket[TX_PAYLOAD_LENGTH]; //+++ Hold the payload.
        memcpy(aucRxPacket, packetDataPointer, packetLength);   //+++ Read the payload from the Rx buffer.
        ((volatile rfc_dataEntryGeneral_t*)rxEntry)->status = DATA_ENTRY_PENDING;   //+++ Mark the entry as being read.
        rxEntry = ((rfc_dataEntryGeneral_t*)rxEntry->pNextEntry);  //+++ Get the next entry.

        if ((bSynchro == false) && (!strncmp((char*)aucRxPacket, (char*)aucSynchro, TX_PAYLOAD_LENGTH)))
        {
            bSynchro = true;
            aucUpperLower[0] = '\0';    //+++ Avoid going out of bounds.
            memset(auiCoupled, 1234567890, COMPOSED_LENGTH);
        }

        if ((bSynchro == true) && (uiReceivedPacket < RX_BUFFER_ENTRIES * TX_PAYLOAD_FORMAT))
            ComposeCouple(aucRxPacket);
    }
}

 void ComposeCouple(uint8_t *pucRxPacket)
 {
     uiReceivedPacket++;
     strcat((char*)aucUpperLower, (char*)pucRxPacket);

     uiTwoSteps++;
     if (uiTwoSteps == 2)
     {
         //+++ For each couple: compose each position of first packet, with the same position of second packet.
         uint16_t usBound;
         for (usBound = 0; usBound < TX_PAYLOAD_LENGTH; usBound++)
             auiCoupled[uiComposed++] = (aucUpperLower[usBound] << 8) + aucUpperLower[usBound + TX_PAYLOAD_LENGTH];

         uiTwoSteps = 0;
         aucUpperLower[0] = '\0';    //+++ Avoid going out of bounds.
     }

     //+++ Last couple has been processed: start over counters and variables.
     if (uiReceivedPacket == RX_BUFFER_ENTRIES * TX_PAYLOAD_FORMAT)
     {
         uiReceivedPacket = 0;
         uiComposed = 0;
         bSynchro = false;
     }
 }
