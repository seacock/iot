/*
 * ^ClockSv.c
 *
 *  Created on: 07 apr 2019
 *      Author: andre
 */

#ifndef CLOCKSV_C_
#define CLOCKSV_C_

#include "^Common.h"

Void ClockTimSta(UArg arg0)
{
	Task_destruct(&TimestampRxTr);//---
	Task_destruct(&SvAbsolTr);//---
	Semaphore_post(hsemCycle);
}

void StartClockTimSta(void)
{
    Clock_Params clockParams;
    Error_Block eb;
    Error_init(&eb);
    Clock_Params_init(&clockParams);
    hClock = Clock_create(ClockTimSta, 1000, &clockParams, &eb);
    if (hClock == NULL)
        System_abort("Clock create failed");
}

#endif /* CLOCKSV_C_ */
