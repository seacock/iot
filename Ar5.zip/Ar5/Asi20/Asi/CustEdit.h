#pragma once

// CCustEdit

//+++ Custom Edit class to use text and background colors.
class CCustEdit : public CEdit
{
	DECLARE_DYNAMIC(CCustEdit)

public:
	bool bChangeBkgnd;	//+++ If true, show new text and background colors.
	CCustEdit();
	virtual ~CCustEdit();
	afx_msg HBRUSH CtlColor(CDC* pDC, UINT /*nCtlColor*/);
protected:
	DECLARE_MESSAGE_MAP()
private:
	COLORREF clrText, clrBkgnd;	//+++ New text and background colors.
	CBrush brBkgnd;	//+++ For CtlColor().
};