﻿#$MyCredential = Get-Credential
#"P@ssword1" | ConvertTo-SecureString -AsPlainText -Force
#"P@ssword1" | ConvertTo-SecureString -AsPlainText -Force | ConvertFrom-SecureString
"andrea" | ConvertTo-SecureString -AsPlainText -Force | ConvertFrom-SecureString | Out-File "C:\Users\Administrator\Documents\WindowsPowerShell\Scripts\Psw.txt"