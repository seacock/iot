#pragma once

#include <iostream>//??????

using namespace std; 

class CRy;   //+++ forward declaration

class CSpi
{
public:
	const int kiSpiChannel = 0;
	const int kiSpiSpeed = 500000 * 1;////////////////////////

	CRy *pRy;
	unsigned int uiNumOfSpiCalls;
	
	CSpi(CRy *pRaspberry); 	//+++ needs forward declaration//??????
	~CSpi();
	void SpiMaster();  	//+++ SPI master .
};