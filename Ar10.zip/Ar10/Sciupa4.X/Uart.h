/* 
 * File:   Uart.h
 * Author: Administrator
 *
 * Created on 19 April 2018, 17:43
 */

#ifndef UART_H
#define	UART_H

#ifdef	__cplusplus
extern "C" {
#endif

#define FP (CLOCK_FREQ / 2)
#define BAUDRATE 9600
#define BRGVAL (((FP / BAUDRATE) / 16) -1)
#define RASPBERRY_STRING_LENGTH 15  //+++ Length of string sent from Raspberry and received by Pic24. This value is known by both parties.
#define PIC24_STRING_LENGTH 39  //+++ Length of string sent from Pic24 and received by Raspberry. This value is known by both parties.

void mainUart(void);    //+++  Uart1.
void UartPins(void);    //+++ Configure pins for Uart1.
void UartChaN(void);    //+++ Input Change notification for Uart1.
void UartPPS(void);    //+++ Peripheral Pin Select for Uart1.
void UartConfig(void);  //+++ Configure Uart1.
void Timer1TypeA(void); //+++ 16-Bit Timer Using System Clock (internal instruction cycle).
void SendChar(void);    //+++ Send some characters to Raspberry.
void GetChar(void); //+++ Get some characters from Raspberry.

#ifdef	__cplusplus
}
#endif

#endif	/* UART_H */

