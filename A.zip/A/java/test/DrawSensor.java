/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author andre
 */
public class DrawSensor extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet DrawSensor</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet DrawSensor at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
//        processRequest(request, response);

        doPost(request, response);  
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
//        processRequest(request, response);

        response.setIntHeader("Refresh", 1);
//        boolean bOrientation = (boolean)getServletContext().getAttribute("orientation");
        TimerS timerS1 = (TimerS)getServletContext().getAttribute("timerS");
        boolean bOrientation = timerS1.bOrientation;
        if (bOrientation == true)
        {
            timerS1.bOrientation = false;

            // New location to be redirected
            String site = "/Orientation.jsp";
            response.sendRedirect(request.getContextPath() + site);            
        }
        
        Integer uuu=(Integer)request.getServletContext().getAttribute("MeMyself");               
        
//        RequestDispatcher rd = request.getRequestDispatcher(site);
//        rd.forward(request,response);
        
        
        
        String viewportwidth = request.getSession().getAttribute("viewportwidth").toString();
        String viewportheight = request.getSession().getAttribute("viewportheight").toString();
        int width = Integer.parseInt(viewportwidth);   // width of image
        int height = Integer.parseInt(viewportheight);   // height of image
        
         // Create image
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        // Get drawing context
        Graphics2D g2d = image.createGraphics();
        // Fill background
        g2d.setColor(Color.white);
        g2d.fillRect(0, 0, width, height);
        
        //+++ Draw a rectangle and fill it.
        g2d.setColor(Color.BLUE);
        g2d.setStroke(new BasicStroke(5F));  // set stroke width of 5
        g2d.drawRect(width / 10, height / 10, width / 5, height / 10);
        g2d.setColor(Color.ORANGE);
        TimerS timerS = (TimerS)getServletContext().getAttribute("timerS");
        int iTime = timerS.GetTime();
        if (iTime >= width / 5 - 4)
        {
            timerS.ResetTime();
            iTime = 0;
        }
        g2d.fillRect(width / 10 + 2, height / 10 + 2, iTime, height / 10 - 4);
        
        //+++ Draw a rectangle and fill it.
        g2d.setColor(Color.BLUE);
        g2d.setStroke(new BasicStroke(5F));  // set stroke width of 5
        g2d.drawRect(width / 10, 4 * height / 10, width / 5, height / 10);
        g2d.setColor(Color.ORANGE);
        g2d.fillRect(width / 10 + 2, 4 * height / 10 + 2, width / 5 - 4, height / 10 - 4);
        
        Font myFont = new Font("Courier New", 1, 80);
        g2d.setFont (myFont);
        g2d.drawString(uuu.toString(), 900, 400);
        
        // Dispose context
        g2d.dispose();
        // Send back image
        response.setContentType("image/jpeg"); 
        try (OutputStream out = response.getOutputStream()) {
            ImageIO.write(image, "jpg", out);
        }        
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
