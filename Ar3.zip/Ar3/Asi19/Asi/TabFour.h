#pragma once
#include "afxwin.h"

//+++ Commands for PIC.
#define ADC_AVERAGE 110	//+++ PICFJ64GB002 sends back average ADC values for potentiometer and thermometer. Defined in LaT, Ry, Mip.
#define ADC_LASTVAL 120	//+++ PICFJ64GB002 sends back last ADC value for potentiometer and thermometer. Defined in LaT, Ry, Mip.
#define PWM_CONTINUOUS 130	//+++ PICFJ64GB002 outputs PWM with duty cycle fixed by slider. Defined in LaT, Ry, Mip.
#define PWM_FUNCTION 140	//+++ PICFJ64GB002 outputs PWM with variable duty cycle depending on a local function. Defined in LaT, Ry, Mip.
#define I2C_RY_EXIT 201	//+++ RyS's communication threads stop communication and RyS exits. Defined in LaT, Ry.
#define I2C_RY_SHUT_COMM 202	//+++ RyS's communication threads stop communication, but RyS continues working. Defined in LaT, Ry.
#define I2C_LAPTOP_DISMISS 203	//+++ Laptop is dismissed, but RyS continues working. Defined in LaT, Ry.
#define I2C_RY_MAX_PROGRESS 100	//+++ Range of jpgsThr4 and upper limit of I2c test cycle. 
#define TEST_I2C 300
//+++ Commands for PIC.

// CTabFour dialog

class CTabFour : public CDlgExBase
{
	DECLARE_DYNAMIC(CTabFour)
public:
	CEdit jedThr4M;	//+++ Thread: monitor. 
	CEdit jedThr4V;	//+++ Thread: edit for continuous PWM.
	CProgressCtrl jpgsThr4;	//+++ Thread: progress for I2C test.
	int irbThr4LastAdc;	//+++ Dominant radiobutton for ADC.
	int irbThr4PwmC;	//+++ Dominant radiobutton for PWM.
	CSliderCtrl jslThr4;	//+++ Slider for continuous PWM.
	string srRbAdc;		//+++ Command message: ADC.	
	string srRbPwm;	//+++ Command message: PWM.		
	string srSlid;	//+++ Message: slider.
	HANDLE hE_RbAdc;	//+++ Event: T_I2cMaTx sends a command message (ADC) to RaspberryPi2, with feed back.
	HANDLE hE_RbPwm;	//+++ Event: T_I2cMaTx sends a command message (PWM) to RaspberryPi2, with feed back.
	HANDLE hE_Sli;	//+++ Event: T_I2cMaTx sends a message (slider) to RaspberryPi2, with periodic feed back. Speed is favourite.
	HANDLE hE_I2cTest;	//+++ Event: start T_I2cAuTx.
	CTabFour(CWnd* pParent = NULL);   // standard constructor
	virtual ~CTabFour();
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedRbThr4LastAdc();
	afx_msg void OnBnClickedRbThr4AveAdc();
	afx_msg void OnBnClickedRbThr4PwmC();
	afx_msg void OnBnClickedRbThr4PwmF();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnBnClickedBnTestI2c();
	void InputCtrl(bool bEnable);	//+++ Enable or disable input controls.
// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_TAB_FOUR };
#endif
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	DECLARE_MESSAGE_MAP()
private:
	CStatic jtxtPgsI2c;
	wstring wsrMtrThr4;		
	CButton jbnTestI2c;	//+++ Push button for I2C test.
	LRESULT OnEdThr4M(WPARAM wParam, LPARAM lParam);	//+++ Thread4 monitor.
	LRESULT OnEdThr4V(WPARAM wParam, LPARAM lParam);	//+++ Thread4: PWM of PICFJ64GB002.
	LRESULT OnRaspberrySettings(WPARAM wParam, LPARAM lParam);	//+++ Get Raspberry initial settings (ADC_LASTVAL, ADC_AVERAGE, PWM_CONTINUOUS, PWM_FUNCTION); set Raspberry settings (TEST_I2C).
};

static UINT RG_WM_ED_THR4M = RegisterWindowMessage(_T("EDIT THREAD4 MONITOR"));
static UINT RG_WM_ED_THR4V = RegisterWindowMessage(_T("EDIT THREAD4 VALUES"));
static UINT RG_WM_RASPBERRY_SETTINGS = RegisterWindowMessage(_T("RASPBERRY SETTINGS"));