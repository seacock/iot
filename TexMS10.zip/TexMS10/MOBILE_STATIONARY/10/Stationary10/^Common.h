/*
 * ^Common.h
 *
 *  Created on: 31 ott 2018
 *      Author: andre
 */

#ifndef COMMON_H_
#define COMMON_H_

/* Driver Header files */
#include <ti/drivers/GPIO.h>

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/display/Display.h>
#include <ti/sysbios/knl/Semaphore.h>

/* TI Drivers */
#include <ti/drivers/PIN.h>
#include <ti/drivers/pin/PINCC26XX.h>
#include <ti/drivers/rf/RF.h>

/* Board Header files */
#include "Board.h"

#define BOARD_PIN_GREEN_LED CC1310_LAUNCHXL_PIN_GLED
#define BOARD_PIN_RED_LED CC1310_LAUNCHXL_PIN_RLED
#define STACKSIZE 1024   //---

/* Packet RX Configuration */
#define RX_BUFFER_ENTRIES 5    //+++ Ad libitum.
#define TX_PAYLOAD_LENGTH 41    //+++ Starting point: Tx packet feature.
#define TX_PAYLOAD_FORMAT 4 //+++ Starting point: Tx packet feature.
#define QUEUE_RX RX_BUFFER_ENTRIES  //+++ For BUFFER_SIZE_BYTES, aucRxBuffer and QueueRx.
#define NUM_APPENDED_BYTES 2    //+++ The Data Entries data field will contain: 1 Header byte (RF_cmdPropRx.rxConf.bIncludeHdr = 0x1); Max 30 payload bytes; 1 status byte (RF_cmdPropRx.rxConf.bAppendStatus = 0x1) .
#define DATA_SECTION_SIZE (TX_PAYLOAD_LENGTH + NUM_APPENDED_BYTES) //+++ Must be word-aligned.
#define ENTRY_HEADER_SIZE 7 //+++ Ad libitum.
#define BUFFER_SIZE_BYTES (QUEUE_RX * (ENTRY_HEADER_SIZE + DATA_SECTION_SIZE))
#define COMPOSED_LENGTH (TX_PAYLOAD_LENGTH * TX_PAYLOAD_FORMAT * RX_BUFFER_ENTRIES / 2)
#define RAW_LENGTH (TX_PAYLOAD_LENGTH * TX_PAYLOAD_FORMAT * RX_BUFFER_ENTRIES * 2)  //+++ Oversized or isn't enough.

Display_Handle DisplayH;
PIN_Handle LedPinH, InputPinH, ButtonPinH; //+++ No static or green LED doesn't toggle.

void CC1310_LAUNCHXL_DIO12Cb(PIN_Handle handle, PIN_Id pinId);
void Board_PIN_BUTTON0Cb(PIN_Handle handle, PIN_Id pinId);
void StartRxRadioTf(void);  //+++ Set up and start RxRadioTf task.

#endif /* COMMON_H_ */
