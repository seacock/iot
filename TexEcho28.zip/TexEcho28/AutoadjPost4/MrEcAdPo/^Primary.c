/*
 * ^Primary.c
 *
 *  Created on: 21 gen 2019
 *      Author: andre
 */

#include "^Common.h"
#include <string.h>

void *mainThread(void *arg0)
{
	//+++ Dynamic pin configuration.
	PIN_Config DynPinCfg[] = {
			GREEN_LED | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
			RED_LED | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
			YELLOW_LED | PIN_GPIO_OUTPUT_EN | PIN_GPIO_HIGH | PIN_PUSHPULL | PIN_INPUT_DIS | PIN_DRVSTR_MED,
			CYAN_LED | PIN_GPIO_OUTPUT_EN | PIN_GPIO_HIGH | PIN_PUSHPULL | PIN_INPUT_DIS | PIN_DRVSTR_MED,
			ORANGE_LED | PIN_GPIO_OUTPUT_EN | PIN_GPIO_HIGH | PIN_PUSHPULL | PIN_INPUT_DIS | PIN_DRVSTR_MED,
		PIN_TERMINATE
	};
	PIN_State stPinState;
	hDynPin = PIN_open(&stPinState, DynPinCfg);
	if (hDynPin == NULL)
		while(1);

    Semaphore_Params semParams;
	Semaphore_Params_init(&semParams);
	hsemTimeStamp = Semaphore_create(0, &semParams, NULL);
	if (hsemTimeStamp == NULL) //+++ Check if the handle is valid.
		while(1);

	StartTimestampTxTf();
	Semaphore_pend(hsemTimeStamp, BIOS_WAIT_FOREVER);
	Semaphore_delete(&hsemTimeStamp);
	StartMrAbsolTf();

    return 0;
}
