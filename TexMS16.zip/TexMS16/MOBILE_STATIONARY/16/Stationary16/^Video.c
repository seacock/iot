/*
 * ^Video.c
 *
 *  Created on: 04 dic 2018
 *      Author: andre
 */

#include <^Common.h>
#include <stdlib.h>
#include <ti/display/AnsiColor.h>

void StartDisplayTf(void);
Void DisplayTf(UArg arg0, UArg arg1);
Task_Struct DisplayTr;
#pragma DATA_ALIGN(DisplayTaskStack, 8)  //+++ 1-byte alignment on the stack to avoid wasting memory.
static uint8_t DisplayTaskStack[STACKSIZE];

void StartDisplayTf(void)
{
    Task_Params taskParams;
    Task_Params_init(&taskParams);
    taskParams.stackSize = STACKSIZE;
    taskParams.priority = 2;    //+++ More than 1 or is preempted by while (1) in mainThread.
    taskParams.stack = &DisplayTaskStack;

    Task_construct(&DisplayTr, DisplayTf, &taskParams, NULL);
}

Void DisplayTf(UArg arg0, UArg arg1)
{
    while (1)
    {
        Semaphore_pend(DisplaySemH, BIOS_WAIT_FOREVER);    //+++ Wait on sem indefinitely.
        uint32_t *auiTemporary = (uint32_t*)malloc(COMPOSED_LENGTH * sizeof(uint32_t));

        int iBound;
        for (iBound = 0; iBound < COMPOSED_LENGTH; iBound++)    //---
            auiTemporary[iBound] = auiComposedP[iBound];
//        for (iBound = 0; iBound < COMPOSED_LENGTH; iBound++)    //---
//            Display_printf(DisplayH, 0, 0, "auiTemporary: %d     seq: %d", auiTemporary[iBound], iBound);

        for (iBound = 0; iBound < 2 * TX_PAYLOAD_LENGTH; iBound++)    //---
            Display_printf(DisplayH, 0, 0, ANSI_COLOR(FG_CYAN) "auiTemporary: %d     seq: %d" ANSI_COLOR(ATTR_RESET), auiTemporary[iBound], iBound);    //+++ Synchro.

        int iChangeColor = 0;
        for (iBound = 2 * TX_PAYLOAD_LENGTH; iBound < COMPOSED_LENGTH; iBound++, iChangeColor++)    //---
            if (iChangeColor < TX_PAYLOAD_LENGTH)
                Display_printf(DisplayH, 0, 0, ANSI_COLOR(FG_RED) "auiTemporary: %d     seq: %d" ANSI_COLOR(ATTR_RESET), auiTemporary[iBound], iBound); //+++ Channel 1 of ADC.
            else if (iChangeColor >= TX_PAYLOAD_LENGTH && iChangeColor < 2 * TX_PAYLOAD_LENGTH)
                Display_printf(DisplayH, 0, 0, ANSI_COLOR(FG_GREEN) "auiTemporary: %d     seq: %d" ANSI_COLOR(ATTR_RESET), auiTemporary[iBound], iBound);   //+++ Channel 2 of ADC.
            else
                iChangeColor = 0;

        free(auiTemporary);
        PIN_setInterrupt(DInPinH, CC1310_LAUNCHXL_DIO1 | PIN_IRQ_NEGEDGE);//---
    }
//    PIN_close(&ledPinHandle);//---
}
