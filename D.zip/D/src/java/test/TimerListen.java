/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import java.util.Timer;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

/**
 * Web application lifecycle listener.
 *
 * @author andre
 */
public class TimerListen implements ServletContextListener {
    TimerJ timerJPotentiom = new TimerJ(50, 500);
    TimerJ timerJThermom = new TimerJ(100, 800);
    
    @Override
    public void contextInitialized(ServletContextEvent sce) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    
        ServletContext servletContext = sce.getServletContext();
        System.out.println("*********ServletContextListener started*********");

        timerJPotentiom.Start();
        servletContext.setAttribute ("timerJPotentiom", timerJPotentiom);
        servletContext.setAttribute ("timerPotentiom", timerJPotentiom.timer);  
        
        timerJThermom.Start();
        servletContext.setAttribute ("timerJThermom", timerJThermom);
        servletContext.setAttribute ("timerThermom", timerJThermom.timer);      
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
        ServletContext servletContext = sce.getServletContext();        
        
        Timer timerPotentiom = (Timer)servletContext.getAttribute ("timerPotentiom"); //+++ Get the timer from the Context.

        //+++ Cancel all pending tasks in the timers queue.
        if (timerPotentiom != null)
            timerPotentiom.cancel();

        //+++ Remove attributes from the servlet context.
        servletContext.removeAttribute ("timer");
        servletContext.removeAttribute ("timerJPotentiom");
        
         Timer timerThermom = (Timer)servletContext.getAttribute ("timerThermom"); //+++ Get the timer from the Context.

        //+++ Cancel all pending tasks in the timers queue.
        if (timerThermom != null)
            timerThermom.cancel();

        //+++ Remove attributes from the servlet context.
        servletContext.removeAttribute ("timerThermom");
        servletContext.removeAttribute ("timerJThermom");
        
        System.out.println("ServletContextListener destroyed");
    }
}