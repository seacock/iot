/*
 * File:   Uart.c
 * Author: Administrator
 *
 * Created on 08 March 2018, 15:48
 */


#include "Uart.h"
#define TMR1_PERIOD_REG 0xFFFF

int iCountTx = 0, iCountRx = 0; //+++ 
char a2cMessage[2][40] = {
                        "123456789012345678901234567890123456789\0", 
                        "     Tx:  Pic24FJ64GB002\0"                        
                    }, acMsgRx[16] = "\0"; //+++ Length 16 is important: not more, not less...
bool bInit = 1; //+++ Only the very first time Pic transmits: otherways it misses the first char.

int main(void) 
{
    INTCON1bits.NSTDIS = 1;     //+++ Interrupt nesting is disabled.
    
    AD1PCFG = 0xFFFF;   //+++ Turn off analogue functions on all pins.
    SetupClock();
    ConfigUartPortPins();
    ConfigUartPPS();  
    ConfigUart();
    
    TRISBbits.TRISB2 = OUTPUT_PIN;  //+++ Pin 6.
    LATBbits.LATB2 = 0;
    
    SetupTimer();        

    while(1);

    return 0;
}

void ConfigUartPortPins(void)
{
    TRISBbits.TRISB10 = OUTPUT_PIN;  //+++ U1TX. Pin 21. RP10. 
    TRISBbits.TRISB11 = INPUT_PIN;   //+++ U1RX. Pin 22. RP11. 
    //////////////////////////////////////CN
    TRISBbits.TRISB4 = INPUT_PIN;  //+++ RB4 = CN1. Pin 11. Clear to send input. RP4.  
    CNPU1bits.CN1PUE = 1; //+++ Weak pull-up on RB4 enabled.
    CNEN1bits.CN1IE = 1; //+++ Change notification on RB4 enabled.
    IEC1bits.CNIE = 1;  //+++ Input Change Notification Interrupt Enabled.
    IFS1bits.CNIF = 0;  //+++ Input Change Notification Interrupt Flag Status Cleared.
    IPC4bits.CNIP = 2;
    //////////////////////////////////////CN
    
    
    TRISBbits.TRISB1 = OUTPUT_PIN;  //+++ Pin 5. Request to send output. RP1.
    CNPU1bits.CN5PUE = 1; //+++ Weak pull-up on RB1 enabled.////////////////////////////////
    
    LATBbits.LATB1 = 1; //+++ stop request to send//???
}

void ConfigUartPPS(void)
{
    PPSUnLock;  //+++ Unlock the PPS functionality.
    iPPSOutput(OUT_PIN_PPS_RP10, OUT_FN_PPS_U1TX);   //+++ U1TX. Pin 21. 
    iPPSInput(IN_FN_PPS_U1RX, IN_PIN_PPS_RP11);    //+++ U1RX. Pin 22. 
    iPPSInput(IN_FN_PPS_U1CTS, IN_PIN_PPS_RP4);    //+++ Assign U1CTS To Pin RP4.  
//    iPPSOutput(OUT_PIN_PPS_RP1, OUT_FN_PPS_U1RTS);   //+++ RP1 tied to U1RTS. NEVER!!! This causes malfunctioning: RB1 stuck low.
    PPSLock;    //+++ Lock the PPS functionality.
}

void ConfigUart(void)
{    
    U1MODEbits.UEN = 2; //+++ Control flow. RTSMD is cleared as default. //??? Not so important.
    U1MODEbits.STSEL = 0; // 1-Stop bit
    U1MODEbits.PDSEL = 0; // No Parity, 8-Data bits
    U1MODEbits.ABAUD = 0; // Auto-Baud disabled
    U1MODEbits.BRGH = 0; // Standard-Speed mode
    U1BRG = BRGVAL; // Baud Rate setting for 9600
    U1STAbits.UTXISEL0 = 0; // Interrupt after one TX character is transmitted
    U1STAbits.UTXISEL1 = 0;
    IEC0bits.U1TXIE = 1; // Enable UART TX interrupt
    U1STAbits.URXISEL = 0; // Interrupt after one RX character is received;
    IEC0bits.U1RXIE = 1; // Enable UART RX interrupt
    U1MODEbits.UARTEN = 1; // Enable UART
    U1STAbits.UTXEN = 1; // Enable UART TX
    IPC3bits.U1TXIP = 6;
    IPC2bits.U1RXIP = 6;
}

void SetupTimer(void)
{
    T1CON = 0x00; //Stops the Timer1 and reset control reg.
    TMR1 = 0x00; //Clear contents of the timer register
    PR1 = 128; //Load the Period register
    IPC0bits.T1IP = 0x01; //Setup Timer1 interrupt for level 1 priority)
    IFS0bits.T1IF = 0; //Clear the Timer1 interrupt status flag
    IEC0bits.T1IE = 1; //Enable Timer1 interrupts
    T1CONbits.TCKPS = 0x02; //+++ Prescaler settings at 64. Important.
}

void _ISR _U1TXInterrupt(void)
{
    IFS0bits.U1TXIF = 0; //+++ Clear TX Interrupt flag.
    
    if (bInit == 1)
        bInit = 0;
    else
    {
        iCountTx++;
        if (iCountTx == strlen(a2cMessage[0]))
        {
            iCountTx = 0;
            return;
        }
    }
    
    T1CONbits.TON = 1;
}

void _ISR _U1RXInterrupt(void)
{
    IFS0bits.U1RXIF = 0; //+++ Clear RX Interrupt flag.
    
    if(U1STAbits.FERR == 1) //+++ Check for receive errors.
        return;
    
    if(U1STAbits.OERR == 1) //+++ Must clear the overrun error to keep UART receiving.
    {
        U1STAbits.OERR = 0;
        return;
    }    

    if (U1STAbits.URXDA == 1)   //+++ Get the data. Not strictly necessary.
    {
        acMsgRx[iCountRx++] = U1RXREG;

        if (iCountRx > 14)
        {
            LATBbits.LATB1 = 1; //+++ Stop request to send.            
            iCountRx = 0;       
            LATBbits.LATB2 = !PORTBbits.RB2;       
            strcpy(a2cMessage[0], acMsgRx);
            strcat(a2cMessage[0], a2cMessage[1]);
        }      
    }
}

void _ISR _T1Interrupt(void)
{    
    T1CONbits.TON = 0;  //+++ Stop Timer1 with clock source set to the internal instruction cycle.
    TMR1 = 0x00;    //+++ Clear contents of the timer register.
    
    //+++ Delay 105uS = 1/9600. Important.
    U1TXREG = a2cMessage[0][iCountTx]; //+++ Transmit one character.
    
    IFS0bits.T1IF = 0; //Reset Timer1 interrupt flag and Return from ISR
}

void _ISR _CNInterrupt(void)
{
    if (PORTBbits.RB4 == 0)        
        SendChar();
    else
        GetChar();
    
    IFS1bits.CNIF = 0;  //+++ Input Change Notification Interrupt Flag Status Cleared.
}

void SendChar(void)
{
    while (U1STAbits.UTXBF != 0);   //+++ Wait while Tx buffer is still full.
    T1CONbits.TON = 1;  //+++ Start Timer1 with clock source set to the internal instruction cycle.
}

void GetChar(void)
{
    LATBbits.LATB1 = 0; //+++ Assert request to send.
}