/*
 * adc.c
 *
 *  Created on: 21 ott 2018
 *      Author: andre
 */

#include <^Adc.h>
#include <^Common.h>

#pragma DATA_ALIGN(aucADCTaskStack, 8)  /* Make sure we have nice 8-byte alignment on the stack to avoid wasting memory */
static uint8_t aucADCTaskStack[STACKSIZE];

Void AdcTf(UArg arg0, UArg arg1)
{
    ADC_Handle adc;
    ADC_Params params;
    uint16_t adcValue, uiCount = 0;
    int_fast16_t res;

    while (1) {
        /* Open ADC Driver */
        ADC_Params_init(&params);
        adc = ADC_open(Board_ADC3, &params);
        if (adc == NULL)
            while (1);// Error initializing ADC channel Board_ADC3

        res = ADC_convert(adc, &adcValue);
        if (res == ADC_STATUS_SUCCESS) {
            PIN_setOutputValue(hDynPin, CC1310_LAUNCHXL_DIO21, !PIN_getOutputValue(CC1310_LAUNCHXL_DIO21));
            AdcPacket[0][uiCount] = adcValue >> 8;
            AdcPacket[1][uiCount] = adcValue;
        }
        ADC_close(adc);

        /* Open ADC Driver */
        ADC_Params_init(&params);
        adc = ADC_open(Board_ADC4, &params);
        if (adc == NULL)
            while (1);// Error initializing ADC channel Board_ADC4

        res = ADC_convert(adc, &adcValue);
        if (res == ADC_STATUS_SUCCESS) {
        }
        ADC_close(adc);

        uiCount++;
        if (uiCount == ADC_COLUMNS)
        {
            uiCount = 0;
            Semaphore_post(hSemTx);   //+++ Post to semaphore.
            UInt uiEvents = Event_pend(hEvnClockAndTx, Event_Id_00 + Event_Id_01, Event_Id_NONE, BIOS_WAIT_FOREVER);    //+++ Wait on evn indefinitely.
            PIN_setOutputValue(hDynPin, CC1310_LAUNCHXL_DIO15, !PIN_getOutputValue(CC1310_LAUNCHXL_DIO15));
        }

        Semaphore_pend(hSemAdc, BIOS_WAIT_FOREVER);    //+++ Wait on sem indefinitely.
    }
}

void StartAdcTf(void)
{
    /* Set up AdcTf task */
    Task_Params stTaskParams;
    Task_Params_init(&stTaskParams);
    stTaskParams.stackSize = STACKSIZE;
    stTaskParams.priority = 4;
    stTaskParams.stack = &aucADCTaskStack;

    Task_construct(&stADCTask, AdcTf, &stTaskParams, NULL);
}
