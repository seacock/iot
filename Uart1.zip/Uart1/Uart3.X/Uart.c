/*
 * File:   Uart.c
 * Author: Administrator
 *
 * Created on 08 March 2018, 15:48
 */


#include "Uart.h"
#define TMR1_PERIOD_REG 0xFFFF
//+++ If PR1 = TMR1_PERIOD_REG, T1CONbits.TCKPS = 0x03 and yyy == 50 then _T1Interrupt lasts about 60 sec.
int yyy = 0, iii = 0;

int main(void) {
//    INTCON1bits.NSTDIS = 1;     //+++ Interrupt nesting is disabled.
    
    AD1PCFG = 0xFFFF;   //+++ Turn off analogue functions on all pins.
    
    SetupClock();
    ConfigUartPortPins();
    ConfigUartPPS();  
    ConfigUart();
    
    TRISBbits.TRISB2 = OUTPUT_PIN;  //+++ Phisical pin 6.
    LATBbits.LATB2 = 0;    
    
    SetupTimer();
    
    while(1);

    return 0;
}

void _ISR _U1TXInterrupt(void)
{
    IFS0bits.U1TXIF = 0; //+++ Clear TX Interrupt flag
    iCount++;
    if (iCount == 14)
    {
        iCount = 0;
        iii++;
    }
    if (iii == 2)
//        T1CONbits.TON = 0;
        bMode = MODE_RX;
}

void _ISR _U1RXInterrupt(void)
{
    IFS0bits.U1RXIF = 0; //+++ Clear RX Interrupt flag
    char ReceivedChar;    
    
    if(U1STAbits.FERR == 1)/* Check for receive errors */
        return;
    
    if(U1STAbits.OERR == 1)/* Must clear the overrun error to keep UART receiving */
    {
        U1STAbits.OERR = 0;
        return;
    }    
    
    if (U1STAbits.URXDA == 1)/* Get the data */
    {
        ReceivedChar = U1RXREG;
        if (ReceivedChar == 51)
            LATBbits.LATB2 = 1;
    }
}

void ConfigUartPortPins(void)
{
    TRISBbits.TRISB10 = OUTPUT_PIN;  //+++ U1TX: hwPin = 21.   RP10 //??? UPDATE SCHEMATICS!!!
    TRISBbits.TRISB11 = INPUT_PIN;   //+++ U1RX: hwPin = 22.   RP11 //??? UPDATE SCHEMATICS!!!
    //////////////////////////////////////CN
    TRISBbits.TRISB4 = INPUT_PIN;  //+++ RB4 = CN1. Phisical pin 11. Clear to send input.  RP4  
    CNPU1bits.CN1PUE = 1; //+++ Weak pull-up on RB4 enabled.
    CNEN1bits.CN1IE = 1; //+++ Change notification on RB4 enabled.
    
//    TRISBbits.TRISB0 = INPUT_PIN;  //+++ RB0 = CN4. Phisical pin 4. Clear to send input.  RP0  
//    CNPU1bits.CN4PUE = 1; //+++ Weak pull-up on RB0 enabled.
//    CNEN1bits.CN4IE = 1; //+++ Change notification on RB0 enabled.
    
    
    
    
    IEC1bits.CNIE = 1;  //+++ Input Change Notification Interrupt Enabled.
    IFS1bits.CNIF = 0;  //+++ Input Change Notification Interrupt Flag Status Cleared.
    IPC4bits.CNIP = 2;
    //////////////////////////////////////CN   
    //////////////////////////////////////FLOW control UART
    TRISBbits.TRISB1 = OUTPUT_PIN;  //+++ Phisical pin 5. Request to send output.RP1
    //////////////////////////////////////FLOW control UART
}

void ConfigUartPPS(void)
{
    PPSUnLock;  //+++ Unlock the PPS functionality.
    iPPSOutput(OUT_PIN_PPS_RP10, OUT_FN_PPS_U1TX);   //+++ U1TX: hwPin = 21.    //??? UPDATE SCHEMATICS!!!
    iPPSInput(IN_FN_PPS_U1RX, IN_PIN_PPS_RP11);    //+++ U1RX: hwPin = 22.  //??? UPDATE SCHEMATICS!!!    
    iPPSInput(IN_FN_PPS_U1CTS, IN_PIN_PPS_RP4);    //+++ Assign U1CTS To Pin RP4.  //??? UPDATE SCHEMATICS!!!
    iPPSOutput(OUT_PIN_PPS_RP1, OUT_FN_PPS_U1RTS);   //+++ RP1 tied to U1RTS.  ANYONE!!!  //??? UPDATE SCHEMATICS!!!    
    PPSLock;    //+++ Lock the PPS functionality.
}

void SetupClock(void)
{
    unsigned int pllCounter;
    OSCCONBITS OSCCONbitsCopy;

    // Copy the current Clock Setup
    OSCCONbitsCopy = OSCCONbits;
    // Slow output clock down to 4Mhz
    CLKDIVbits.CPDIV = 3;
    // Enable the PLL - Note: Fuse bits don't do this
    CLKDIVbits.PLLEN = 1;
    // Wait for the PLL to stabilise
    for (pllCounter = 0; pllCounter < 600; pllCounter++);

    // Check to see what clock setup is defined - either internal or external
    #ifdef USE_FRC_CLOCK
        // Setup the uC to use the internal FRCPLL mode
        OSCCONbitsCopy.NOSC = 1;
        OSCCONbitsCopy.OSWEN = 1;
    #else
        // Setup the uC to use the external crystal with the PLL
        OSCCONbitsCopy.NOSC = 3;
        OSCCONbitsCopy.OSWEN = 1;
    #endif

    // Switch over to the new clock setup
    __builtin_write_OSCCONH( BITS2BYTEH( OSCCONbitsCopy ) );
    __builtin_write_OSCCONL( BITS2BYTEL( OSCCONbitsCopy ) );
    // Wait for this transfer to take place
    while (OSCCONbits.COSC != OSCCONbits.NOSC);
    // Setup the DIV bits for the FRC, this values means the config word needs to be: PLLDIV_DIV2
    CLKDIVbits.RCDIV0 = 0;

    // Setup the PLL divider for the correct clock frequency
    if (CLOCK_FREQ == 32000000)
        CLKDIVbits.CPDIV = 0;
    else if (CLOCK_FREQ == 16000000)
        CLKDIVbits.CPDIV = 1;
    else if (CLOCK_FREQ == 8000000)
        CLKDIVbits.CPDIV = 2;
    else if (CLOCK_FREQ == 4000000)
        CLKDIVbits.CPDIV = 3;

    
    CLKDIVbits.PLLEN = 1;// Check that the PLL is enabled again and locked properly to the new setup
    // Note - don't want to do this check if we are running in the MPLAB X simulator as it won't work
    #ifndef __MPLAB_SIM
        while(_LOCK != 1);
    #endif

    // At this point the PIC24FJ64GB004 clock setup will be complete with the PLL
    // enabled and ready for operation with USB2.0
}

void ConfigUart(void)
{    
    U1MODEbits.UEN = 2; //+++ Control flow. RTSMD is cleared as default.
    U1MODEbits.STSEL = 0; // 1-Stop bit
    U1MODEbits.PDSEL = 0; // No Parity, 8-Data bits
    U1MODEbits.ABAUD = 0; // Auto-Baud disabled
    U1MODEbits.BRGH = 0; // Standard-Speed mode
    U1BRG = BRGVAL; // Baud Rate setting for 9600
    U1STAbits.UTXISEL0 = 0; // Interrupt after one TX character is transmitted
    U1STAbits.UTXISEL1 = 0;
    IEC0bits.U1TXIE = 1; // Enable UART TX interrupt
    
    //////////////////////////////
    U1STAbits.URXISEL = 0; // Interrupt after one RX character is received;
    IEC0bits.U1RXIE = 1; // Enable UART RX interrupt
    //////////////////////////////
    
    U1MODEbits.UARTEN = 1; // Enable UART
    U1STAbits.UTXEN = 1; // Enable UART TX
    
    //////////////////////////////
    IPC3bits.U1TXIP = 6;
    //////////////////////////////
}

void SetupTimer(void)
{
    T1CON = 0x00; //Stops the Timer1 and reset control reg.
    TMR1 = 0x00; //Clear contents of the timer register
    PR1 = TMR1_PERIOD_REG / (128 * 128); //Load the Period register
    IPC0bits.T1IP = 0x01; //Setup Timer1 interrupt for level 1 priority)
    IFS0bits.T1IF = 0; //Clear the Timer1 interrupt status flag
    IEC0bits.T1IE = 1; //Enable Timer1 interrupts
    T1CONbits.TCKPS = 0x02; //+++ Prescaler settings at 64
}

void _ISR _T1Interrupt(void)
{
    yyy++;
    if (yyy == 6)   //+++ Delay 105uS //+++ Important. 1/9600
    {
        if (bMode == MODE_TX)
            U1TXREG = acMessage[iCount]; //+++ Transmit one character.
        else if (bMode == MODE_RX)
            GetChar();
        
        yyy = 0;
    }        
    
    IFS0bits.T1IF = 0; //Reset Timer1 interrupt flag and Return from ISR
}

void SendChar(void)
{    
    while (U1STAbits.UTXBF != 0);   //+++ Wait while Tx buffer is still full.
    T1CONbits.TON = 1; //Start Timer1 with clock source set to the internal instruction cycle
}

char GetChar(void)
{
    LATBbits.LATB1 = 0; //+++ assert request to send
    while (U1STAbits.URXDA == 0);   //+++ wait for receive buffer.
    LATBbits.LATB1 = 1; //+++ stop request to send
    return U1RXREG; //+++Read from the receiver buffer
}

void _ISR _CNInterrupt(void)
{
    if (PORTBbits.RB4 == 0)
//    if (PORTBbits.RB0 == 0)
        SendChar();
    
    IFS1bits.CNIF = 0;  //+++ Input Change Notification Interrupt Flag Status Cleared.
}