/*
 * ^TermStat.c
 *
 *  Created on: 21 gen 2019
 *      Author: andre
 */

#include "^Common.h"
static uint16_t uuu=0;//---
void TermStat(RF_EventMask terminationReason, uint32_t cmdStatus)
{
	switch(terminationReason)
	{
		case RF_EventLastCmdDone:
			// A stand-alone radio operation command or the last radio
			// operation command in a chain finished.
			break;
		case RF_EventCmdCancelled:
			// Command cancelled before it was started; it can be caused
		// by RF_cancelCmd() or RF_flushCmd().
			uuu=1;//---
			break;
		case RF_EventCmdAborted:
			// Abrupt command termination caused by RF_cancelCmd() or
			// RF_flushCmd().
			uuu=1;//---
			break;
		case RF_EventCmdStopped:
			// Graceful command termination caused by RF_cancelCmd() or
			// RF_flushCmd().
			uuu=1;//---
			break;
		default:
			// Uncaught error event
			while(1);
	}

	switch(cmdStatus)
	{
		case PROP_DONE_OK:
			// Packet transmitted successfully
			break;
		case PROP_DONE_STOPPED:
			// received CMD_STOP while transmitting packet and finished
			// transmitting packet
			uuu=1;//---
			break;
		case PROP_DONE_ABORT:
			// Received CMD_ABORT while transmitting packet
			uuu=1;//---
			break;
		case PROP_ERROR_PAR:
			// Observed illegal parameter
			uuu=1;//---
			break;
		case PROP_ERROR_NO_SETUP:
			// Command sent without setting up the radio in a supported
			// mode using CMD_PROP_RADIO_SETUP or CMD_RADIO_SETUP
			uuu=0;//---
			break;
		case PROP_ERROR_NO_FS:
			// Command sent without the synthesizer being programmed
			uuu=0;//---
			break;
		case PROP_ERROR_TXUNF:
			// TX underflow observed during operation
			uuu=0;//---
			break;
		default:
			// Uncaught error event - these could come from the
			// pool of states defined in rf_mailbox.h
			while(1);
	}
}
