// Asi.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Asi.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CAsiApp

BEGIN_MESSAGE_MAP(CAsiApp, CWinApp)
	ON_COMMAND(ID_HELP, &CWinApp::OnHelp)
END_MESSAGE_MAP()

// CAsiApp construction

CAsiApp::CAsiApp()
{
	// support Restart Manager
	m_dwRestartManagerSupportFlags = AFX_RESTART_MANAGER_SUPPORT_RESTART;

	// TODO: add construction code here,
	// Place all significant initialization in InitInstance	
	//+++ Get processor set information. Set a processor affinity mask for the main thread.
	wchar_t wchBuf[BUFLEN];
	PDWORD_PTR ulProcessAffinityMask = new DWORD_PTR, ulSystemAffinityMask = new DWORD_PTR;
	GetProcessAffinityMask(GetCurrentProcess(), ulProcessAffinityMask, ulSystemAffinityMask);
	_itow_s((int)*ulProcessAffinityMask, wchBuf, sizeof(wchBuf) / sizeof(wchar_t), 10);
	wsrOut = L"ProcessAffinityMask " + (wstring)wchBuf + L"\r\n";
	_itow_s((int)*ulSystemAffinityMask, wchBuf, sizeof(wchBuf) / sizeof(wchar_t), 10);
	wsrOut += L"SystemAffinityMask " + (wstring)wchBuf + L"\r\n";
	DWORD dwCPU = GetActiveProcessorCount(ALL_PROCESSOR_GROUPS);
	_itow_s(dwCPU, wchBuf, sizeof(wchBuf) / sizeof(wchar_t), 10);
	wsrOut += L"Number of CPUs " + (wstring)wchBuf + L"\r\n";
	wsrOut += ThrAffinity(13);
	_itow_s(GetCurrentProcessorNumber(), wchBuf, sizeof(wchBuf) / sizeof(wchar_t), 10);
	wsrOut += L"CurrentProcessorNumber " + (wstring)wchBuf + L"\r\n";
	delete ulProcessAffinityMask;
	delete ulSystemAffinityMask;
}

// The one and only CAsiApp object

CAsiApp theApp;

// CAsiApp initialization

BOOL CAsiApp::InitInstance()
{
	// InitCommonControlsEx() is required on Windows XP if an application
	// manifest specifies use of ComCtl32.dll version 6 or later to enable
	// visual styles.  Otherwise, any window creation will fail.
	INITCOMMONCONTROLSEX InitCtrls;
	InitCtrls.dwSize = sizeof(InitCtrls);
	// Set this to include all the common control classes you want to use
	// in your application.
	InitCtrls.dwICC = ICC_WIN95_CLASSES;
	InitCommonControlsEx(&InitCtrls);

	CWinApp::InitInstance();

	if (!AfxSocketInit())
	{
		AfxMessageBox(IDP_SOCKETS_INIT_FAILED);
		return FALSE;
	}

	AfxEnableControlContainer();

	// Create the shell manager, in case the dialog contains
	// any shell tree view or shell list view controls.
	CShellManager *pShellManager = new CShellManager;

	// Activate "Windows Native" visual manager for enabling themes in MFC controls
	CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerWindows));

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	// of your final executable, you should remove from the following
	// the specific initialization routines you do not need
	// Change the registry key under which our settings are stored
	// TODO: You should modify this string to be something appropriate
	// such as the name of your company or organization
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	CAsiDlg dlg;
	m_pMainWnd = &dlg;
	INT_PTR nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}
	else if (nResponse == -1)
	{
		TRACE(traceAppMsg, 0, "Warning: dialog creation failed, so application is terminating unexpectedly.\n");
		TRACE(traceAppMsg, 0, "Warning: if you are using MFC controls on the dialog, you cannot #define _AFX_NO_MFC_CONTROLS_IN_DIALOGS.\n");
	}

	// Delete the shell manager created above.
	if (pShellManager != NULL)
	{
		delete pShellManager;
	}

#if !defined(_AFXDLL) && !defined(_AFX_NO_MFC_CONTROLS_IN_DIALOGS)
	ControlBarCleanUp();
#endif

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}

wstring CAsiApp::ThrAffinity(DWORD_PTR dwThreadAffinityMask)
{
	wstring wsrOut;
	wchar_t wchBuf[BUFLEN];
	DWORD_PTR dwOldThreadAffinityMask = SetThreadAffinityMask(GetCurrentThread(), dwThreadAffinityMask);
	_itow_s((int)dwOldThreadAffinityMask, wchBuf, sizeof(wchBuf) / sizeof(wchar_t), 10);
	wsrOut = L"OldThreadAffinityMask " + (wstring)wchBuf + L"\r\n";
	_itow_s((int)dwThreadAffinityMask, wchBuf, sizeof(wchBuf) / sizeof(wchar_t), 10);
	wsrOut += L"ThreadAffinityMask " + (wstring)wchBuf + L"\r\n";

	return wsrOut;
}

int CAsiApp::ErrWsaSock(wstring wsrMsg, bool bCleanup, SOCKET Socket)
{
	stHook.pTabOne->SendMessageW(RG_WM_ED_SOC_T, (WPARAM)wsrMsg.c_str());
	if (Socket != INVALID_SOCKET)
		closesocket(Socket);

	if (bCleanup == true)
		WSACleanup();

	return ERROR_COMM;
}