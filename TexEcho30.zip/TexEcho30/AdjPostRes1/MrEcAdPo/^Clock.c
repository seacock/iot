/*
 * ^Clock.c
 *
 *  Created on: 31 mar 2019
 *      Author: andre
 */

#include <^common.h>

Void ClockTimSta(UArg arg0)
{
	PIN_setOutputValue(hDynPin, ORANGE_LED, 1);
	Task_destruct(&TimestampTxTr);//---
	Task_destruct(&MrAbsolTr);//---
	Semaphore_post(hsemCycle);
}

void StartClockTimSta(void)
{
    Clock_Params clockParams;
    Error_Block eb;
    Error_init(&eb);
    Clock_Params_init(&clockParams);
    hClock = Clock_create(ClockTimSta, 500000, &clockParams, &eb);
    if (hClock == NULL)
        System_abort("Clock create failed");
}
