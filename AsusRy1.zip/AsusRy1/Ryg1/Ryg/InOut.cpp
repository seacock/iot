#include "Ryg.h"

void BtnIncDec(int iFdLas)
{
	static int siCount = 0;

	if (digitalRead(SWITCH_INC) == HIGH)
		SendValue(iFdLas, ++siCount, "Pushbutton");
	else if (digitalRead(SWITCH_DEC) == HIGH)
		SendValue(iFdLas, --siCount, "Pushbutton");

	delay(DELAY);
}

void SendValue(int iFdLas, int iValue, string srWho)
{
	string srValue = "something to initialize";
	sprintf((char*)srValue.c_str(), "%d", iValue);
	srWho += srValue;

	WriteToServer(iFdLas, srWho.c_str());
}

void WriteToServer(int iFdLas, const char* pcBuf)
{
	int iBytes = write(iFdLas, pcBuf, strlen(pcBuf) + 1);	//+++ +1 important or buffer gets dirty.
	if (iBytes < 0)
		handle_error_en(iBytes, "write");
	else if (iBytes == 0)
		handle_error("write: 0 bytes sent");
}

int SrNonblockFlag(int iDesc, int iValue)
{
	int iOldflags = fcntl(iDesc, F_GETFL, 0);
	if (iOldflags == -1)	//+++ If reading the flags failed, return error indication now.
		return -1;

	///+++ Set just the flag we want to set.
	if (iValue != 0)
		iOldflags |= O_NONBLOCK;	//+++ Set the O_NONBLOCK flag of iDesc.
	else
		iOldflags &= ~O_NONBLOCK;	//+++ Reset the O_NONBLOCK flag of iDesc.

	return fcntl(iDesc, F_SETFL, iOldflags);	//+++ Store modified flag word in the descriptor.
}