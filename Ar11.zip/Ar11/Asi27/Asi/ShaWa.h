#pragma once

#include "AsiDlg.h"
#include "DlgExBase.h"
#include "TabOne.h"
#include "TabTwo.h"
#include "TabThree.h"
#include "TabFour.h"
#include "TabFive.h"

namespace AsiConst
{	
	const int kiReceivedStringLength = 10000;	//+++ Max length of successive strings received from Raspberry and stored by each data thread.
	
	//+++ Commands for PIC.
	const int kiI2cRyMaxProgress = 100;	//+++ Range of jpgsThr4 and upper limit of I2c test cycle. 
	const int kiTestI2c = 300;
	const int kiRyExit = 201;	//+++ RyS's communication threads stop communication and RyS exit. Defined in Asi, RyS.
	const int kiRyShutComm = 202;	//+++ RyS's communication threads stop communication, but RyS continues working. Defined in Asi, RyS.
	const int kiLaptopDismiss = 203;	//+++ Laptop is dismissed, but RyS continues working. Defined in Asi, RyS.
	const int kiAdcAverage = 110;	//+++ PICFJ64GB002 sends back average ADC values for potentiometer and thermometer. Defined in Asi, RyS, Sciupa.
	const int kiAdcLastVal = 120;	//+++ PICFJ64GB002 sends back last ADC value for potentiometer and thermometer. Defined in Asi, RyS, Sciupa.
	const int kiPwmContinuous = 130;	//+++ PICFJ64GB002 outputs PWM with duty cycle fixed by slider. Defined in Asi, RyS, Sciupa.
	const int kiPwmFunction = 140;	//+++ PICFJ64GB002 outputs PWM with variable duty cycle depending on a local function. Defined in Asi, RyS, Sciupa.
									
	const int kiNumSockets = 4;	//+++ Number of threads of type T_Receive that manage remote connections established from Raspberry.
	const int kiBroadcastPort = 13;   //+++ The port on which to listen for incoming data at broadcast: daytime.
	const string ksrLANServerPort = "15000";	//+++ Sent to Raspberry when broadcasting: port of laptop server to which Raspberry client connects after broadcast.
	const int kiErrorCom = 5;
	const int kiClientClosedConnection =  4;
	const int kiNumWebThreads = 50;
	const int kiBufLen = 512;  //+++ Max length of buffer.	
	const int kiServerSide = 1000;	//+++ Value on which TieSockAddr will use bind() and listen() to implement a server.
	const int kiClientSide = 2000;	//+++ Value on which TieSockAddr will use connect() to implement a client.
	const int kiSshClientPowerShell = 0;
	const int kiSshClientPutty = 1;
}

#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))

//+++ It's elements are needed throughout application.
struct Hook
{
	CAsiDlg *pAsiDlg;	//+++ Pointer to parent dialog.

	//+++ Pointers to tabbed dialog pages.
	CTabOne *pTabOne;
	CTabTwo *pTabTwo;
	CTabThree *pTabThree;
	CTabFour *pTabFour;
	CTabFive *pTabFive;

	char acIP[AsiConst::kiBufLen];	//+++ Broadcast from Raspberry via T_Broad thread.
	
	//+++ One structure for each socket. One socket for each remote thread. Each thread needs its own set of variables to communicate. Local copies or references expire when thread exits and Postmessage delays. Global strings, if any, need CRITICAL_SECTION.
	struct Channel
	{
		Hook *pHook;
		SOCKET AcceptSocket;	//+++ Socket of RaspberryPi2 client.
		wstring wsrRemoteThread, wsrMonitor;	//+++ Remote thread name; total/partial string received from RaspberryPi2 client.
		CDialogEx *pTabbDlg;	//+++ Pointer to dialog associated with this socket.
		UINT uiWmEdMonitor, uiWmEdValue, uiWmProgress;	//+++ WMsg for: Edit ctrl monitor; Edit ctrl value; Progress ctrl.
	} astChann[AsiConst::kiNumSockets];	//+++ Array of structures for remote threads.	
	
	HANDLE ahT_Receive[AsiConst::kiNumSockets];	//+++ Array of handles to T_Receive.
	HANDLE hT_Broad;	//+++ Handle to T_Broad.
	HANDLE hT_Connect;	//+++ Handle to T_Connect.
	HANDLE hT_Shell;	//+++ Handle to T_Shell.
	HANDLE hT_RyExit;	//+++ Handle to T_RyExit.	
	HANDLE hT_ShutComm;	//+++ Handle to T_ShutComm.	
	HANDLE hT_I2cMaTx;	//+++ Handle to T_I2cMaTx.	
	HANDLE hT_I2cMaRx;	//+++ Handle to T_I2cMaRx.
	HANDLE hT_I2cAuTx;	//+++ Handle to T_I2cAuTx.
	HANDLE hT_I2cAuRx;	//+++ Handle to T_I2cAuRx.

	//+++ Values sent from Raspberry at the beginning of communications with laptop ASUS.
	struct ServerI2C
	{		
		char acPort[AsiConst::kiBufLen];	//+++ Sent from Raspberry via TEMPORARY thread: port on which Raspberry server listens. Client laptop ASUS uses this port to connect to server I2c.
		char acWebPortR3[AsiConst::kiBufLen];	//+++ Sent from Raspberry via TEMPORARY thread. Port number of port forwarding provider, for Tomcat WebServer hosted by Raspberry. 
		char acWebPortNi[AsiConst::kiBufLen];	//+++ Sent from Raspberry via TEMPORARY thread. Port number of port forwarding provider, for Tomcat WebServer hosted by Raspberry. 
	} stServerI2c;
	SOCKET SockManual, SockAutom;
	int iSshClient;
};

wstring StToWsUtf8(const string &str);
string WsToStUtf8(const wstring &wstr);