#include "RyS.h"

pthread_t gThrIdShutFromLaptop; 	//??????
extern string srToWww;
extern int iUartHandle;  //??????
string a4sr[4];
void* eee(void *arg);
extern pthread_t ulThread_id;

//extern int uuu, jjj;


void* ServerSocketTp(void *arg)
{
	gThrIdShutFromLaptop = pthread_self(); 	//??????
	bool bEndThread = false;
	while (bEndThread == false)
	{		
		int iOn = 1;  	//+++ Selector for socket options.
		int iListenSd, iMaxSd, iNewSd, iSd; //+++ Socket file descriptors: listening; max value in fd set; new accepted; generic.
		bool bEndServer = false, bCloseConn;
		sockaddr_in stAddrIn;  	//+++ Structure describing an Internet socket address.

		//+++ select() changes the working_set passed into it to reflect which sockets are ready to read. To keep track of the connections from one call of select() to the next, 
		//+++ these connections are safely stored away into master_set. At the last minute, I copy the master_set into the working_set, and then call select().	
		fd_set master_set, working_set;

		if ((iListenSd = socket(AF_INET, SOCK_STREAM, 0)) < 0)	//+++ Create an AF_INET stream socket to receive incoming connections on.
			handle_error("socket()");

		if (setsockopt(iListenSd, SOL_SOCKET, SO_REUSEADDR, (char*)&iOn, sizeof(iOn)) < 0)	//+++ Allow socket descriptor to be reuseable.
			CloseFdErr(iListenSd, "setsockopt()");

		if (SrNonblockFlag(iListenSd, iOn) < 0)	//+++ Set socket to be nonblocking. All of the sockets for the incoming connections will also be nonblocking since they will inherit that state from the listening socket. This status is valid only for the accept() step, i.e for iNewSd.  
			CloseFdErr(iListenSd, "fcntl()");

		memset(&stAddrIn, 0, sizeof(stAddrIn));
		stAddrIn.sin_family = AF_INET;
		stAddrIn.sin_addr.s_addr = htonl(INADDR_ANY);
		stAddrIn.sin_port = htons(atoi(ThreadInfo::SsrServerPort.c_str()));

		if (bind(iListenSd, (sockaddr*)&stAddrIn, sizeof(stAddrIn)) < 0)	//+++ Bind the socket.
			CloseFdErr(iListenSd, "bind()");

		if (listen(iListenSd, 32) < 0)	//+++ Set the listen back log.
			CloseFdErr(iListenSd, "listen()");

		//+++ Initialize the master fd_set.
		FD_ZERO(&master_set);
		iMaxSd = iListenSd;
		FD_SET(iListenSd, &master_set);
				
		do	//+++ Loop waiting for incoming connections or for incoming data on any of the connected sockets.	
		{
			memcpy(&working_set, &master_set, sizeof(master_set));  	//+++ Copy the master fd_set over to the working fd_set.
			cout << "\nWaiting on select()..." << endl;
			int iPresDescr = select(iMaxSd + 1, &working_set, NULL, NULL, NULL);	//+++ Call select() and wait for ever for it to complete. On success, it returns the total number of file descriptors still present in the file descriptor sets.

			if (iPresDescr < 0)	//+++ Check to see if select() failed.	
			{
				perror("select()");
				bEndServer = true;
				bEndThread = true;
				break;
			}
			
			for (iSd = 0; iSd <= iMaxSd && iPresDescr > 0 && bEndServer == false; ++iSd)	//+++ One or more descriptors are readable. Need to determine which ones they are.	
			{				
				if (FD_ISSET(iSd, &working_set))	//+++ Check to see if this descriptor is ready.	
				{
					iPresDescr -= 1;  	//+++ A descriptor was found that was readable: one less has to be looked for. This is being done so that we can stop looking at the working set once we have found all of the descriptors that were ready.
					if (iSd == iListenSd)	//+++ Check to see if this is the listening socket.	
					{
						cout << "Listening socket is readable." << endl;						
						do	//+++ Accept all incoming connections that are queued up on the listening socket before we loop back and call select again.	
						{
							iNewSd = accept(iListenSd, NULL, NULL);	//+++ Accept each incoming connection. If accept fails with EWOULDBLOCK, then we have accepted all of them. Any other failure on accept will cause us to end the server.
							if (iNewSd < 0)
							{
								if (errno != EWOULDBLOCK)
								{
									perror("accept()");
									bEndServer = true;
								}
								break;
							}

							cout << "New incoming connection: " << iNewSd << endl;
							FD_SET(iNewSd, &master_set);  	//+++ Add the new incoming connection to the master read set.
							if (iNewSd > iMaxSd)
								iMaxSd = iNewSd;
						} while (true);	//+++ Loop back up and accept another incoming connection.
					}
					else	//+++ This is not the listening socket, therefore an existing connection must be readable. All socket descriptors added to fd_set are blocking for default.
					{
						cout << "Descriptor " << iSd << " is readable" << endl;
						bCloseConn = false;
						char *pcBuffer = new char[BUFLEN_MJC];   	//+++ Outside below do cycle to avoid leaks when hitting break.
						
						do	//+++ Receive all incoming data on this socket before we loop back and call select again.
						{
							if (SrNonblockFlag(iSd, iOn) < 0)	//+++ Set each added socket to be non-blocking as it doesn't inherit that state from the listening socket. A way that allows also to set the timeout is: setsockopt(..., SOL_SOCKET, SO_RCVTIMEO, &timeout, ...)
								CloseFdErr(iSd, "fcntl()");

							//+++ Receive all incoming data on this socket before we loop back and call select again. Receive data on this connection until the recv fails with EWOULDBLOCK. If any other failure occurs, we will close the connection.
							bzero(pcBuffer, BUFLEN_MJC);
							int iLen = recv(iSd, pcBuffer, BUFLEN_MJC, 0);   	//+++ Upon successful completion, recv() shall return the length of the	message in bytes.
							if (iLen < 0)
							{
								if (errno != EWOULDBLOCK)
								{
									perror("recv(): laptop client has terminated.");
									bCloseConn = true;
								}
								break;
							}
							
							if (iLen == 0)	//+++ Check to see if the connection has been closed by the client. The socket, created by remote internet client Hjc in Java language, might have simply gone out of scope and the connection is abated.
							{
								cout << "Connection closed by laptop client either with close (both send recv), either with shutdown (send)." << endl;
								bCloseConn = true;
								break;
							}

							//////////////////////////////////////////////////////////
							string srWww(pcBuffer);
							cout << "The original string srWww is: " << srWww << endl;
							basic_string <char>::size_type index = 0;
							int iChunck = 0;

							string srDelim("???");
							

							while (1)
							{
								index = srWww.find(srDelim, index);
								if (index != string::npos)
								{
									index += 3;
									a4sr[iChunck++] = srWww.substr(index, 15);
								}
								else
									break;
							}
							for (int iCount = 0; iCount < iChunck; iCount++)
								cout << endl << a4sr[iCount];

							//UartWww(iUartHandle);///?????? Nooooooooooooo
							//pthread_create(&ulThread_id, NULL, eee, NULL);///?????? Nooooooooooooo
							//uuu = 1;
							//sleep(2);
							//pthread_join(ulThread_id, &res);///?????? Nooooooooooooo

							
							///////////////////////////////////////////////////////////////////
							///??????
							pthread_mutex_lock(&ServUart::SmutexServUart);
							ServUart::SenStateServUart = STATE_UartPic;
							pthread_cond_signal(&ServUart::ScondUartPic);
							pthread_mutex_unlock(&ServUart::SmutexServUart);

							///??????
							pthread_mutex_lock(&ServUart::SmutexServUart);
							while (ServUart::SenStateServUart != STATE_ServerJ)
								pthread_cond_wait(&ServUart::ScondServerJ, &ServUart::SmutexServUart);
							pthread_mutex_unlock(&ServUart::SmutexServUart);
							///////////////////////////////////////////////////////////////////


//							while(jjj==0);
//							jjj = 0;
							srToWww += ThreadInfo::SsrRes;
							send(iSd, srToWww.c_str(), srToWww.length(), 0);
//							send(iSd, ThreadInfo::SsrRes.c_str(), ThreadInfo::SsrRes.length(), 0);
						} while (true) ;

						delete[] pcBuffer;

						//+++ If the bCloseConn flag was turned on, we need to clean up this active connection. This clean up process includes removing the descriptor 
						//+++ from the master set and determining the new maximum descriptor value based on the bits that are still turned on in the master set.
						if (bCloseConn)
						{
							close(iSd);
							FD_CLR(iSd, &master_set);
							if (iSd == iMaxSd)
								while (FD_ISSET(iMaxSd, &master_set) == false)
									iMaxSd -= 1;
						}
					} //+++ End of readable existing connection.
				} //+++ End of if that checks for ready descriptors.
			} //+++ End of loop through selectable descriptors.	
		} while (bEndServer == false);

		cout << "Server within ServerSocketTp thread exited." << endl << endl;

		for (iSd = 0; iSd <= iMaxSd; ++iSd)	//+++ Clean up all of the sockets that are open.
			if (FD_ISSET(iSd, &master_set))
				close(iSd);
	}
	
	cout << "ServerSocketTp thread exited." << endl << endl;

	return 0;
}

void* eee(void *arg)
{
	while (ModeComm::SiMode != I2C_RY_EXIT)
	{
//		if (uuu != 0)
//		{
//			uuu = 0;
//			UartWww(iUartHandle);
//		}	
		



		///////////////////////////////////////////////////////////////////
		

		///??????
		pthread_mutex_lock(&ServUart::SmutexServUart);
		while (ServUart::SenStateServUart != STATE_UartPic)
			pthread_cond_wait(&ServUart::ScondUartPic, &ServUart::SmutexServUart);
		pthread_mutex_unlock(&ServUart::SmutexServUart);


		UartWww(iUartHandle);


		///??????
		pthread_mutex_lock(&ServUart::SmutexServUart);
		ServUart::SenStateServUart = STATE_ServerJ;
		pthread_cond_signal(&ServUart::ScondServerJ);
		pthread_mutex_unlock(&ServUart::SmutexServUart);
		///////////////////////////////////////////////////////////////////



	}

	return 0;
}