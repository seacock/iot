/* 
 * File:   Pwm.h
 * Author: Administrator
 *
 * Created on 22 April 2018, 10:31
 */

#ifndef PWM_H
#define	PWM_H

#ifdef	__cplusplus
extern "C" {
#endif
    
#define TIMER4_PERIOD 25 * 1000    
#define PWM_STEP_HIGH 1000
    
int mainPwm(void);
void Timer4TypeA(void); //+++ 16-Bit Timer Using System Clock (internal instruction cycle).

#ifdef	__cplusplus
}
#endif

#endif	/* PWM_H */

