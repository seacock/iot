#include <iostream>
#include <wiringPi.h>
#include <wiringSerial.h>

using namespace std;

#define CTS 5	//+++ Clear to send input.	wiringPi 5. GPIO pin 18. 
#define RTS 6	//+++ Request to send output. wiringPi 6. GPIO pin 22.

int main(int argc, char *argv[])
{
	if (wiringPiSetup() == -1)//???
	{
		cout << "Unable to start wiringPi\n";
		return 1 ;
	}
	pinMode(CTS, INPUT);
	pinMode(RTS, OUTPUT);
	digitalWrite(RTS, HIGH); 
	int handle = serialOpen("/dev/ttyAMA0", 9600);
	if (handle == -1)
		cout << "bad handle" << endl;
	int data, aaa = 0, eee = 0;
	long  uuu = 0;

//	serialFlush(handle);//??? It doesn't seem important.

//	if (argc == 2)
//	{
//		cout << argc << endl;
//		digitalWrite(RTS, HIGH);
//		digitalWrite(RTS, LOW);
//		
//	
//		while (uuu < 150 * 1000)   
//		{
//			eee = serialDataAvail(handle);
//			if (eee == 3)
//				break;
//			uuu++;
//		}
//		cout << "Num of cycles for initial phase " << uuu << endl;
//		while (aaa < 3)
//		{
//			data = serialGetchar(handle);
//			cout << (char)data;
//			aaa++;
//		}
//		digitalWrite(RTS, HIGH); 
//	}
//	serialFlush(handle);

	cout << endl << endl;

	for (int iii = 0; iii < 10; iii++)
	{
		aaa = 0;
		uuu = 0;
		eee = 0;

		digitalWrite(RTS, HIGH);
		digitalWrite(RTS, LOW);
//		delay(1500);
		while (uuu < 150 * 1000)   
		{
			eee = serialDataAvail(handle);
			if (eee == 84)
				break;
			uuu++;
		}

		cout << "Num of cycles for normal operation " << uuu << "		Data available " << eee << endl;

		while (aaa < eee)
		{
			data = serialGetchar(handle);
			cout << (char)data;
			aaa++;
		}
		digitalWrite(RTS, HIGH); 

//		serialFlush(handle);

		cout << endl;

//		delay(1500);
		while (digitalRead(CTS) == 1) 
		{
		}
//		delay(500);
		serialPutchar(handle, 'F');
		serialPutchar(handle, 'r');
		serialPutchar(handle, 'o');
		serialPutchar(handle, 'm');
		serialPutchar(handle, ' ');
		serialPutchar(handle, 'R');
		serialPutchar(handle, 'a');
		serialPutchar(handle, 's');
		serialPutchar(handle, 'p');
		serialPutchar(handle, 'b');
		serialPutchar(handle, 'e');
		serialPutchar(handle, 'r');
		serialPutchar(handle, 'r');
		serialPutchar(handle, 'y');
		serialPutchar(handle, ' ');
		serialPutchar(handle, '2');
		
		delay(1500);
	}
	
	return 0;
}