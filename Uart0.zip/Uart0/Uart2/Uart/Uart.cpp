#include <iostream>
#include <wiringPi.h>
#include <wiringSerial.h>

using namespace std;

int main(int argc, char *argv[])
{
	char sz[] = "Hello, World!";	//Hover mouse over "sz" while debugging to see its contents
	cout << sz << endl;	//<================= Put a breakpoint here
//	if(wiringPiSetup() == -1)//???
//	{
//		cout << "Unable to start wiringPi\n";
//		return 1 ;
//	}
	int handle = serialOpen("/dev/ttyAMA0", 9600);
	if (handle == -1)
		cout << "bad handle" << endl;
	int data, aaa = 0;
	while (aaa < 100)
	{
		data = serialGetchar(handle);
		cout << (char)data << endl;
		serialPutchar(handle, 51);
		aaa++;
	}
	
	return 0;
}