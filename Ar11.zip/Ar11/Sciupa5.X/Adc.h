/* 
 * File:   Adc.h
 * Author: Administrator
 *
 * Created on 19 April 2018, 17:10
 */

#ifndef ADC_H
#define	ADC_H

#ifdef	__cplusplus
extern "C" {
#endif
    
#define AVERAGE 2048

int mainAdc(void);
void Timer2TypeA(void); //+++ 16-Bit Timer Using System Clock (internal instruction cycle).
void SetupADConverter(void);    //+++ Set up Analog to Digital converter.
void ZeroAve(int iCount);   //+++ Zero all variables for average.

#ifdef	__cplusplus
}
#endif

#endif	/* ADC_H */