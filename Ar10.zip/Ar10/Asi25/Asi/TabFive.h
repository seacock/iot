#pragma once

// CTabFive dialog

class CTabFive : public CDlgExBase 
{
	DECLARE_DYNAMIC(CTabFive)
public:
	CButton jbnWeb;	//+++ Uses struct WebTie to create T_Tomcat threads and wait for them with T_TomcatFinish thread.
	int iBatch;//???

	//???
	struct WebTie
	{		
		HANDLE hT_Tomcat;	//+++ Handle to T_Tomcat.
		int iThreadNum;	//+++ User defined number of thread.
		string srHostName;//+++ URL input by user in jedThreadWebHostName.
		string srPortNumber;	//+++ Port number of port forwarding provider, for Tomcat WebServer hosted by Raspberry. 
		string srIO;//???
		wstring wsrTotOut, wsrError;
	} *pstWebTie;	
	CTabFive(CWnd* pParent = NULL);   // standard constructor
	virtual ~CTabFive();
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedBnWeb();
	afx_msg void OnEnUpdateEdTWHos();
	afx_msg void OnBnClickedRbRemot3();	//+++ Port number of port forwarding provider, for Tomcat WebServer hosted by Raspberry. 
	afx_msg void OnBnClickedRbNoip();	//+++ Port number of port forwarding provider, for Tomcat WebServer hosted by Raspberry. 
// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_TAB_FIVE };
#endif
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	DECLARE_MESSAGE_MAP()
private:
	CEdit jedThrWebMon;
	CEdit jedThreadWebHostName;	//+++ URL of port forwarding provider, for Tomcat WebServer hosted by Raspberry.
	int irbRemoteSvrPort;	//+++ Dominant radiobutton for port forwarding provider.
	string srPortNumber;	//+++ Port number of port forwarding provider, for Tomcat WebServer hosted by Raspberry. 
	wstring wsrThrWebMon;
	LRESULT OnInputWeb(WPARAM wParam, LPARAM lParam);	//+++ After TEMPORARY thread has acquired port numbers of port forwarding providers from Raspberry, enable TabFive gui.
	LRESULT OnEdTWeM(WPARAM wParam, LPARAM lParam);	//+++ Web thread.	
};

static UINT RG_WM_INPUT_WEB = RegisterWindowMessage(_T("INPUT CTRLS WEB THREAD"));
static UINT RG_WM_ED_T_WEM = RegisterWindowMessage(_T("EDIT WEB THREAD"));