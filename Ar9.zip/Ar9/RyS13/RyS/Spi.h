#pragma once

#include "SharA.h"

class CSpi
{
public:
	enum StateSpi { STATE_Potentiometer, STATE_Thermometer };//???
	struct Sync
	{
		StateSpi enStateSpi;
		pthread_cond_t condPotentiometer;
		pthread_cond_t condThermometer;
		pthread_mutex_t mutexSpi;
	} stSync;

	//+++ Local network interface.
	struct Wlan0Inet4
	{
		char acInternetAddress[INET_ADDRSTRLEN];
		char acLineDescription[INET_ADDRSTRLEN];
		char acNetmask[INET_ADDRSTRLEN];
		char acBroadcastAddr[INET_ADDRSTRLEN];     	//+++ The broadcast address is used to interrogate the remote LaptopASUS.
	} stWlan0Inet4;

	struct Sensor
	{
		string srIdMsg;
		uint uiDelay;    	//+++ Time to wait before asking for next value.
		unsigned char ucUpper;
		unsigned char ucLower;
		string srName;
		unsigned int uiNumOfSpiCalls;
		unsigned long ulTotNumOfSpiCalls;
		unsigned int uiTomcatCounter;
		unsigned int uiLaptopCounter;		
	} stPoten, stThermo;

	CSpi();
	~CSpi();
	void SpiMaster(int iFdLas, Sensor &stSensor); 	//+++ SPI master for PIC24 sensors.
	void SpiDataRW(unsigned char ucData, unsigned char &ucULByte); 	//+++ Communicate with MicroChip Pic24 via Spi.
	void CommServerWrite(int iFdTom8, int iValue, string srWho); 	//+++ Send value to RaspberryPi2's Tomcat8.
};

