/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import java.util.Timer;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

/**
 * Web application lifecycle listener.
 *
 * @author andre
 */
public class TimerListen implements ServletContextListener {
    TimerS timerS = new TimerS();
    
    @Override
    public void contextInitialized(ServletContextEvent sce) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    
        ServletContext servletContext = sce.getServletContext();
        System.out.println("*********ServletContextListener started*********");

        timerS.Start();
        servletContext.setAttribute ("timer", timerS.timer);
        servletContext.setAttribute ("timerS", timerS);
        Integer iii = 0;
        servletContext.setAttribute("MeMyself", iii);
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
        ServletContext servletContext = sce.getServletContext();
        // get our timer from the Context
        Timer timer = (Timer)servletContext.getAttribute ("timer");

        // cancel all pending tasks in the timers queue
        if (timer != null)
            timer.cancel();

        // remove attributes from the servlet context
        servletContext.removeAttribute ("timer");
        servletContext.removeAttribute ("timerS");
        servletContext.removeAttribute ("orientation");
        System.out.println("ServletContextListener destroyed");
    }
}
