/*
 * ^Common.h
 *
 *  Created on: 31 ott 2018
 *      Author: andre
 */

#ifndef COMMON_H_
#define COMMON_H_

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/knl/Clock.h>//---
#include <ti/display/Display.h>

/* TI Drivers */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/PIN.h>
#include <ti/drivers/pin/PINCC26XX.h>
#include <ti/drivers/rf/RF.h>

/* Board Header files */
#include "Board.h"

#define BOARD_PIN_GREEN_LED CC1310_LAUNCHXL_PIN_GLED
#define BOARD_PIN_RED_LED CC1310_LAUNCHXL_PIN_RLED
#define STACKSIZE 1024   //---

/* Packet RX Configuration */
#define RX_BUFFER_ENTRIES 5    //+++ Ad libitum.
#define TX_PAYLOAD_LENGTH 41    //+++ Starting point: Tx packet feature.
#define TX_PAYLOAD_FORMAT 4 //+++ Starting point: Tx packet feature.
#define NUM_APPENDED_BYTES 2    //+++ The Data Entries data field will contain: 1 Header byte (RF_cmdPropRx.rxConf.bIncludeHdr = 0x1); Max 30 payload bytes; 1 status byte (RF_cmdPropRx.rxConf.bAppendStatus = 0x1) .
#define DATA_SECTION_SIZE (TX_PAYLOAD_LENGTH + NUM_APPENDED_BYTES) //+++ Must be word-aligned.
#define ENTRY_HEADER_SIZE 7 //+++ Ad libitum.
#define BUFFER_SIZE_BYTES (RX_BUFFER_ENTRIES * (ENTRY_HEADER_SIZE + DATA_SECTION_SIZE))
#define COMPOSED_LENGTH (TX_PAYLOAD_LENGTH * TX_PAYLOAD_FORMAT * RX_BUFFER_ENTRIES / 2)

enum Mode {NOTHING, START_STOP, CONTINUOUS, END_START_STOP} enMode; //+++ Modes for receiver.
Display_Handle DisplayH;
PIN_Handle LedPinH, DInPinH; //+++ PIN handles 1) Output 2) Digital input.
Clock_Handle DInClockH;    //+++ Clock used for debounce logic.
PIN_Id ActiveWirePinId; //+++ PIN_Id for active button in debounce period.
Semaphore_Handle DisplaySemH; //+++ Semaphore for slow display.
RF_Object rfObject;
RF_Handle rfHandle;//---
dataQueue_t queue;  //+++ Receive dataQueue for RF Core to fill in data.
#pragma DATA_ALIGN(aucRxBuffer, 4)  //+++ Pragmas needed to make sure aucRxBuffer is 4 byte aligned: requirement from the RF Core.
uint8_t aucRxBuffer[BUFFER_SIZE_BYTES]; //+++ Buffer contains all Data Entries for receiving data.
bool bSynchro;  //+++ Synchronize Rx with Tx header.
uint32_t auiCoupled[COMPOSED_LENGTH]; //+++ Each element is composed of the corresponding couple of elements of aucUpperLower. Using uint16_t app goes nuts.
uint32_t uiReceivedPacket, uiComposed; //+++ Index of received single packet. 2) Index of composed packet.
uint32_t uiTwoSteps, uiStartBound;  //+++ 1) Every 2 steps a couple is ready to compose a value for auiCoupled. 2) Position of first element of first packet of couple.
uint8_t aucSynchro[TX_PAYLOAD_LENGTH];  //+++ Hold conventional word sent by transmitter, to be matched by receiver.

void CC1310_LAUNCHXL_DIOCb(PIN_Handle handle, PIN_Id pinId);
void StartRxRfCoTf(void);  //+++ Set up and start RxRfCoTf task.
void StartRxRfSsTf(void);  //+++ Set up and start RxRfSsTf task.
void RfTerminStatus(RF_EventMask terminationReason, uint32_t cmdStatus);

#endif /* COMMON_H_ */
