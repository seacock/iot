/* 
 * File:   ShaDe.h
 * Author: Administrator
 *
 * Created on 19 April 2018, 17:18
 */

#ifndef SHADE_H
#define	SHADE_H

#ifdef	__cplusplus
extern "C" {
#endif
    
#define OUTPUT_PIN 0
#define INPUT_PIN 1
#define LAST_ADC 1  //+++ Last converted value by ADC.    
#define AVE_ADC 0  //+++ Average of converted values by ADC.
#define PWM_PERIOD 4000
#define PWM_CONTINUOUS 130  //+++ Laptop ASUS-->Raspberry-->here. Default at startup. Defined in LaT, Ry, Mip.
#define PWM_FUNCTION 140    //+++ Laptop ASUS-->Raspberry-->here. Defined in LaT, Mip.
#define N_SENS 2    //+++ Number of sensors.
#define POTENT 0    //+++ Potentiometer.
#define THERMO 1    //+++ Thermometer.

#ifdef	__cplusplus
}
#endif

#endif	/* SHADE_H */

