#include "stdafx.h"
#include "Asi.h"

#define WAIT_THREAD_TIMEOUT 5000

void CloseHandleNull(HANDLE &hHan);
void WaitCollective(Hook *pstHook);

DWORD WINAPI T_RyExit(LPVOID lpParam)
{
	theApp.ThrAffinity(13);
	Hook *pstHook = (Hook*)lpParam;
	CTabFour *pTabFour = pstHook->pTabFour;

	HANDLE hKernelObj = pstHook->hT_Connect;
	DWORD dwWaitResult = WaitForSingleObject(hKernelObj, WAIT_THREAD_TIMEOUT);
	switch (dwWaitResult)
	{
	case WAIT_OBJECT_0:
		CloseHandleNull(pstHook->hT_Connect);
		CloseHandleNull(pTabFour->hE_RbAdc);
		CloseHandleNull(pTabFour->hE_RbPwm);
		CloseHandleNull(pTabFour->hE_Sli);
		CloseHandleNull(pTabFour->hE_I2cTest);
		break;
	case WAIT_TIMEOUT:
		MessageBox(NULL, L"T_RyExit WaitForMultipleObjects WAIT_TIMEOUT", L"Error", MB_ICONEXCLAMATION);
		break;
	case WAIT_FAILED:
		MessageBox(NULL, L"T_RyExit WaitForMultipleObjects WAIT_FAILED", L"Error", MB_ICONEXCLAMATION);
		break;
	}

	WaitCollective(pstHook);
	
	return NO_ERROR;
}

DWORD WINAPI T_ShutComm(LPVOID lpParam)
{
	theApp.ThrAffinity(13);
	Hook *pstHook = (Hook*)lpParam;

	WaitCollective(pstHook);

	return NO_ERROR;
}

void WaitCollective(Hook *pstHook)
{
	HANDLE ahKernelObjA[2] = { pstHook->hT_I2cMaTx, pstHook->hT_I2cMaRx };
	DWORD dwWaitResult = WaitForMultipleObjects(ARRAY_SIZE(ahKernelObjA), ahKernelObjA, TRUE, WAIT_THREAD_TIMEOUT);
	switch (dwWaitResult)
	{
	case WAIT_OBJECT_0:
		CloseHandleNull(pstHook->hT_I2cMaTx);
		CloseHandleNull(pstHook->hT_I2cMaRx);
		break;
	case WAIT_TIMEOUT:
		MessageBox(NULL, L"WaitCollectiveA WaitForMultipleObjects WAIT_TIMEOUT", L"Error", MB_ICONEXCLAMATION);
		break;
	case WAIT_FAILED:
		MessageBox(NULL, L"WaitCollectiveA WaitForMultipleObjects WAIT_FAILED", L"Error", MB_ICONEXCLAMATION);
		break;
	}

	if (pstHook->hT_I2cAuTx != NULL || pstHook->hT_I2cAuRx != NULL)
	{
		HANDLE ahKernelObjB[2] = { pstHook->hT_I2cAuTx, pstHook->hT_I2cAuRx };
		DWORD dwWaitResult = WaitForMultipleObjects(ARRAY_SIZE(ahKernelObjB), ahKernelObjB, TRUE, WAIT_THREAD_TIMEOUT);
		switch (dwWaitResult)
		{
		case WAIT_OBJECT_0:
			CloseHandleNull(pstHook->hT_I2cAuTx);
			CloseHandleNull(pstHook->hT_I2cAuRx);
			break;
		case WAIT_TIMEOUT:
			MessageBox(NULL, L"WaitCollectiveB WaitForMultipleObjects WAIT_TIMEOUT", L"Error", MB_ICONEXCLAMATION);
			break;
		case WAIT_FAILED:
			MessageBox(NULL, L"WaitCollectiveB WaitForMultipleObjects WAIT_FAILED", L"Error", MB_ICONEXCLAMATION);
			break;
		}
	}

	pstHook->pAsiDlg->PostMessageW(RG_WM_COMM_ABATED);	//+++ SendMessageW wouldn't fit.
}

//+++ Examine exit code of a thread.
DWORD WINAPI T_ThreadExCo(LPVOID lpParam)
{
	theApp.ThrAffinity(13);
	Hook::ThreadExCo *pstThExCo = (Hook::ThreadExCo*)lpParam;
	DWORD dwExitCodeThread;
	DWORD dwWaitResult = WaitForSingleObject(pstThExCo->hThreadExCo, INFINITE);
	switch (dwWaitResult)
	{
	case WAIT_OBJECT_0:
		GetExitCodeThread(pstThExCo->hThreadExCo, &dwExitCodeThread);
		if (dwExitCodeThread == ERROR_COMM)
			pstThExCo->pAsiDlg->SendMessageW(RG_WM_PIC_LIGHT, RED_LIGHT);
		break;
	}

	return NO_ERROR;
}

//+++ Must be a passage by reference or things don't work.
void CloseHandleNull(HANDLE &hHan)
{
	if (hHan)
	{
		CloseHandle(hHan);
		hHan = NULL;
	}
}