#include "Spi.h"
#include "Ry.h"
#include "SharA.h"
#include <wiringPiSPI.h>
#include "ColorText.h"
unsigned char eee[30] = "Mercore e nespoe Zioba e ova\0", eee1[30] = "Mercore e nespoe Zioba e ova\0";
CSpi::CSpi(CRy *pRaspberry)
{
	pRy = pRaspberry;
	uiNumOfSpiCalls = 0;
}

CSpi::~CSpi()
{
}

//+++ The delay between each of this calls must be shorter than TIMER3_PERIOD of Pic24 or the game doesn't work.
void CSpi::SpiMaster()
{	
	CColorText coltRed(CColorText::RED);	
	wiringPiSPIDataRW(kiSpiChannel, eee, 30);
	coltRed.ss << "----- " << eee << " received first--------" << endl;
	cout << coltRed;
	CColorText coltBlue(CColorText::BLUE);	
	wiringPiSPIDataRW(kiSpiChannel, eee, 30);
	coltBlue.ss << "----- " << eee << " received second--------" << endl;
	cout << coltBlue;
	strcpy((char*)eee, (char*)eee1);

#ifdef _TALKATIVE_
	cout << "----- " << uiNumOfSpiCalls << " number of SPI calls--------" << endl;
	uiNumOfSpiCalls++;
#endif // _TALKATIVE_
}