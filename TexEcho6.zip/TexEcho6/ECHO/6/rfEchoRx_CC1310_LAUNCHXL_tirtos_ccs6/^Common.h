/*
 * ^Common.h
 *
 *  Created on: 01 gen 2019
 *      Author: andre
 */

#ifndef COMMON_H_
#define COMMON_H_

/***** Includes *****/
/* Standard C Libraries */
#include <stdlib.h>

/* TI Drivers */
#include <ti/drivers/rf/RF.h>
#include <ti/drivers/PIN.h>

#include <ti/sysbios/knl/Task.h>

/* Driverlib Header files */
#include DeviceFamily_constructPath(driverlib/rf_prop_mailbox.h)

/* Board Header files */
#include "Board.h"

/* Application Header files */
#include "RFQueue.h"
#include "smartrf_settings/smartrf_settings.h"

/***** Defines *****/
/* Packet RX/TX Configuration */
/* Max length byte the radio will accept */
#define PAYLOAD_LENGTH         30
/* Set packet interval to 200ms */
#define PACKET_INTERVAL     (uint32_t)(0.2*4000000*1.0f)    //+++ Same as Tx app.
/* Set Transmit (echo) delay to 50ms */
#define TX_DELAY             (uint32_t)(0.05*4000000*1.0f)
/* NOTE: Only two data entries supported at the moment */
#define NUM_DATA_ENTRIES       2

#define TIMESTAMP 4 //+++ 4 bytes length
/* The Data Entries data field will contain:
 * 1 Header byte (RF_cmdPropRx.rxConf.bIncludeHdr = 0x1)
 * Max 30 payload bytes
 * 1 status byte (RF_cmdPropRx.rxConf.bAppendStatus = 0x1)
 * 4 timestamp bytes (TIMESTAMP preprocessor)*/
#ifdef TIMESTAMP
#define NUM_APPENDED_BYTES     6
#else
#define NUM_APPENDED_BYTES     2
#endif

#define STACKSIZE 1024
#define BYTELENGTH 8
#define OFFSET_UTIL_DATA 2
#define DELAY_FACTOR_SHORT 1
#define DELAY_FACTOR_LONG 5 //+++ Not all values would do.

/* Log radio events in the callback */
//#define LOG_RADIO_EVENTS

/***** Prototypes *****/
void StartEchoRxTf(void);
void Chase(RF_Params rfParams);
void OnlyRx(RF_Params rfParams);
void TermStat(RF_EventMask terminationReason, uint32_t cmdStatus);  //+++ RF events and status of commands.

/***** Variable declarations *****/
static RF_Object rfObject;
static RF_Handle rfHandle;

/* Pin driver handle */
/*static*/ PIN_Handle ledPinHandle; //+++ No static or only a file sees it.
/*static*/ PIN_State ledPinState;

/* Buffer which contains all Data Entries for receiving data.
 * Pragmas are needed to make sure this buffer is aligned to a 4 byte boundary
 * (requirement from the RF core)
 */
#if defined(__TI_COMPILER_VERSION__)
#pragma DATA_ALIGN(rxDataEntryBuffer, 4)
static uint8_t
rxDataEntryBuffer[RF_QUEUE_DATA_ENTRY_BUFFER_SIZE(NUM_DATA_ENTRIES,
                                                  PAYLOAD_LENGTH,
                                                  NUM_APPENDED_BYTES)];
#elif defined(__IAR_SYSTEMS_ICC__)
#pragma data_alignment = 4
static uint8_t
rxDataEntryBuffer[RF_QUEUE_DATA_ENTRY_BUFFER_SIZE(NUM_DATA_ENTRIES,
                                                  PAYLOAD_LENGTH,
                                                  NUM_APPENDED_BYTES)];
#elif defined(__GNUC__)
static uint8_t
rxDataEntryBuffer[RF_QUEUE_DATA_ENTRY_BUFFER_SIZE(NUM_DATA_ENTRIES,
                                                  PAYLOAD_LENGTH,
                                                  NUM_APPENDED_BYTES)]
                                                  __attribute__((aligned(4)));
#else
#error This compiler is not supported
#endif //defined(__TI_COMPILER_VERSION__)

static rfc_propRxOutput_t rxStatistics; //+++ Receive Statistics.

/* Receive dataQueue for RF Core to fill in data */
static dataQueue_t dataQueue;
static rfc_dataEntryGeneral_t* currentDataEntry;
static uint8_t packetLength;
static uint8_t* packetDataPointer;
static uint8_t txPacket[PAYLOAD_LENGTH];

#ifdef LOG_RADIO_EVENTS
static volatile RF_EventMask eventLog[32];
static volatile uint8_t evIndex = 0;
#endif // LOG_RADIO_EVENTS

uint8_t ucTimes, ucDelayFactor, ucOnlyRxTimes, ucRxTxTimes;
uint32_t uiOffsetMs[20];
uint64_t ullAverageOms;

#endif /* COMMON_H_ */
