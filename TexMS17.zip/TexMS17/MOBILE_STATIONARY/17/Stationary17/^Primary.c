/*
 *  ======== ^Primary.c ========
 */

/* Driver Header files */
// #include <ti/drivers/I2C.h>
// #include <ti/drivers/SDSPI.h>
// #include <ti/drivers/SPI.h>
// #include <ti/drivers/UART.h>
// #include <ti/drivers/Watchdog.h>

#include <^Common.h>

void StartDisplayTf(void);

//+++ Dynamic pin configuration. Application pin configuration tables. For input isn't possible for now to declare a single array...
PIN_Config LedPinCfg[] = {
    BOARD_PIN_RED_LED | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
    BOARD_PIN_GREEN_LED | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
    PIN_TERMINATE
};

PIN_Config DInPinCfg[] = {
    CC1310_LAUNCHXL_DIO1 | PIN_INPUT_EN | PIN_PULLUP | PIN_IRQ_NEGEDGE,
    CC1310_LAUNCHXL_DIO21 | PIN_INPUT_EN | PIN_PULLUP | PIN_IRQ_NEGEDGE,
    CC1310_LAUNCHXL_DIO22 | PIN_INPUT_EN | PIN_PULLUP | PIN_IRQ_NEGEDGE,
    PIN_TERMINATE
};

PIN_State LedPinState, DInPinState;
Clock_Struct DInClock, RxStandbyClock; //+++ 1) Clock used for debounce logic. 2) Clock for signalling the end of receiving.
Clock_Handle RxStandbyClockH;    //+++ Clock for signalling the end of receiving.
Semaphore_Struct DisplaySemStruct;

void DInClockCb(UArg arg)
{
    Clock_stop(DInClockH); //+++ .

    //+++ Check that there is active button for debounce logic.
    if (ActiveWirePinId != PIN_TERMINATE)
    {
        //+++ Debounce logic, only toggle if the button is still pushed (low).
        if (!PIN_getInputValue(ActiveWirePinId))
        {
            switch (ActiveWirePinId)
            {
            case CC1310_LAUNCHXL_DIO1:
                if (enMode == CONTINUOUS)
                    RF_flushCmd(rfHandle, RF_CMDHANDLE_FLUSH_ALL, 1);
                else if (enMode == START_STOP)
                    enMode = END_START_STOP;

                Clock_start(RxStandbyClockH);
                PIN_setOutputValue(LedPinH, BOARD_PIN_RED_LED, 0);    //+++ .//---
                PIN_setInterrupt(DInPinH, CC1310_LAUNCHXL_DIO21 | PIN_IRQ_NEGEDGE);
                PIN_setInterrupt(DInPinH, CC1310_LAUNCHXL_DIO22 | PIN_IRQ_NEGEDGE);
                Semaphore_post(DisplaySemH);   //+++ Post to semaphore.//---
                break;
            case CC1310_LAUNCHXL_DIO21:
                Clock_stop(RxStandbyClockH);
                PIN_setInterrupt(DInPinH, CC1310_LAUNCHXL_DIO21 | PIN_IRQ_DIS);//---
                PIN_setInterrupt(DInPinH, CC1310_LAUNCHXL_DIO22 | PIN_IRQ_DIS);//---
                PIN_setOutputValue(LedPinH, BOARD_PIN_GREEN_LED, 0); //+++ Toggle pin to indicate .
                StartRxRfCoTf();
                break;
            case CC1310_LAUNCHXL_DIO22:
                Clock_stop(RxStandbyClockH);
                PIN_setInterrupt(DInPinH, CC1310_LAUNCHXL_DIO21 | PIN_IRQ_DIS);//---
                PIN_setInterrupt(DInPinH, CC1310_LAUNCHXL_DIO22 | PIN_IRQ_DIS);//---
                PIN_setOutputValue(LedPinH, BOARD_PIN_GREEN_LED, 0); //+++ Toggle pin to indicate .
                StartRxRfSsTf();
                break;
            default:
                break;
            }
        }
    }

    ActiveWirePinId = PIN_TERMINATE;    //+++ Set ActiveWirePinId to none...
}

void RxStandbyClockCb(UArg arg)
{
    PIN_setOutputValue(LedPinH, BOARD_PIN_GREEN_LED, !PIN_getOutputValue(BOARD_PIN_GREEN_LED)); //+++ Toggle pin to indicate .
}

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    /* Call driver init functions */
    //GPIO_init();
    // I2C_init();
    // SDSPI_init();
    // SPI_init();
    // UART_init();
    // Watchdog_init();

    enMode = NOTHING;

    LedPinH = PIN_open(&LedPinState, LedPinCfg);    //+++ Open pin configuration table.
    if (LedPinH == NULL)
        while(1);

    DInPinH = PIN_open(&DInPinState, DInPinCfg);    //+++ Open pin configuration table.
    if (DInPinH == NULL)
        while(1);

    PIN_registerIntCb(DInPinH, CC1310_LAUNCHXL_DIOCb);//---

    //+++ Semaphore initialization.
    Semaphore_Params DisplaySemParams;
    Semaphore_Params_init(&DisplaySemParams);
    Semaphore_construct(&DisplaySemStruct, 0, &DisplaySemParams);
    DisplaySemH = Semaphore_handle(&DisplaySemStruct);

    //+++ Open Display Driver.
    Display_init(); //+++ Not necessary.
    Display_Params displayParams;
    Display_Params_init(&displayParams);
    DisplayH = Display_open(Display_Type_UART, NULL);

    StartDisplayTf();//---

    Clock_Params clockParams;
    Clock_Params_init(&clockParams);

    //+++ Construct clock for debounce.
    Clock_construct(&DInClock, DInClockCb, 0, &clockParams);
    DInClockH = Clock_handle(&DInClock);

    //+++ Construct clock for signalling the end of receiving.
    clockParams.period = 10000;
    Clock_construct(&RxStandbyClock, RxStandbyClockCb, 0, &clockParams);
    RxStandbyClockH = Clock_handle(&RxStandbyClock);
    Clock_start(RxStandbyClockH);

    while (1) {
    }
}
