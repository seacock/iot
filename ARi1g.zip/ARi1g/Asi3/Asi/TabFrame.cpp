// TabFrame.cpp : implementation file
//

#include "stdafx.h"
#include "Asi.h"
#include "TabFrame.h"


// CTabFrame

IMPLEMENT_DYNAMIC(CTabFrame, CTabCtrl)

CTabFrame::CTabFrame()
{
	//+++ Create pointers to tabbed dialogs.
	apjdlgTabPage[0] = new CTabOne();
	apjdlgTabPage[1] = new CTabTwo();
	apjdlgTabPage[2] = new CTabThree();
	apjdlgTabPage[3] = new CTabFour();
	apjdlgTabPage[4] = new CTabFive();

	//+++ Assign pointers to correspondent pointers used by global structure.	
	Hook &RstHook = theApp.stHook;
	RstHook.pTabOne = (CTabOne*)apjdlgTabPage[0];
	RstHook.pTabTwo = (CTabTwo*)apjdlgTabPage[1];
	RstHook.pTabThree = (CTabThree*)apjdlgTabPage[2];
	RstHook.pTabFour = (CTabFour*)apjdlgTabPage[3];
	RstHook.pTabFive = (CTabFive*)apjdlgTabPage[4];

	for (int iCount = 0; iCount < NUM_SOCKETS; iCount++)
	{
		RstHook.astChann[iCount].AcceptSocket = INVALID_SOCKET;
		RstHook.astChann[iCount].pCommon = NULL;
	}
}

CTabFrame::~CTabFrame()
{
	//+++ Delete pointers to tabbed dialogs.
	for (int iCount = 0; iCount < NUM_TABS; iCount++)
		delete apjdlgTabPage[iCount];
}


BEGIN_MESSAGE_MAP(CTabFrame, CTabCtrl)
	ON_WM_LBUTTONDOWN()
END_MESSAGE_MAP()



// CTabFrame message handlers

void CTabFrame::Init()
{
	iTabCurrent = 0;

	//+++ Create the tabbed dialogs.
	apjdlgTabPage[0]->Create(IDD_TAB_ONE, this);
	apjdlgTabPage[1]->Create(IDD_TAB_TWO, this);
	apjdlgTabPage[2]->Create(IDD_TAB_THREE, this);
	apjdlgTabPage[3]->Create(IDD_TAB_FOUR, this);
	apjdlgTabPage[4]->Create(IDD_TAB_FIVE, this);

	Hook &RstHook = theApp.stHook;
	RstHook.pAsiDlg = (CAsiDlg*)GetParent();	//+++ Here parent dialog is built: get it.

	SetRect(iTabCurrent);
}

void CTabFrame::SetRect(int iFocus)
{
	CRect tabRect, itemRect;
	int nX, nY, nXc, nYc;

	GetClientRect(&tabRect);
	GetItemRect(iFocus, &itemRect);
	nX = itemRect.left;
	nY = itemRect.bottom + 1;
	nXc = tabRect.right - itemRect.left - 1;
	nYc = tabRect.bottom - nY - 1;

	for (int iCount = 0; iCount < NUM_TABS; iCount++)
		if (iCount == iFocus)
			apjdlgTabPage[iCount]->SetWindowPos(&wndTop, nX, nY, nXc, nYc, SWP_SHOWWINDOW);
		else
			apjdlgTabPage[iCount]->SetWindowPos(&wndTop, nX, nY, nXc, nYc, SWP_HIDEWINDOW);
}

void CTabFrame::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: Add your message handler code here and/or call default

	CTabCtrl::OnLButtonDown(nFlags, point);	//+++ Below code doesn't go before this line of code.

	//+++ Hide deselected tab dialog, retrieve index of selected tab dialog and show it.
	if (iTabCurrent != GetCurFocus())
	{
		apjdlgTabPage[iTabCurrent]->ShowWindow(SW_HIDE);
		iTabCurrent = GetCurFocus();
		apjdlgTabPage[iTabCurrent]->ShowWindow(SW_SHOW);
	}
}

wstring StToWsUtf8(const string &str)
{
	if (str.empty())
		return wstring();

	int size_needed = MultiByteToWideChar(CP_UTF8, 0, &str[0], (int)str.size(), NULL, 0);
	wstring wstrTo(size_needed, 0);
	MultiByteToWideChar(CP_UTF8, 0, &str[0], (int)str.size(), &wstrTo[0], size_needed);
	return wstrTo;
}

string WsToStUtf8(const wstring &wstr)
{
	if (wstr.empty())
		return string();

	int size_needed = WideCharToMultiByte(CP_UTF8, 0, &wstr[0], (int)wstr.size(), NULL, 0, NULL, NULL);
	string strTo(size_needed, 0);
	WideCharToMultiByte(CP_UTF8, 0, &wstr[0], (int)wstr.size(), &strTo[0], size_needed, NULL, NULL);
	return strTo;
}
