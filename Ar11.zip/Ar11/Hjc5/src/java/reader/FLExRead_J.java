/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package reader;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.channels.OverlappingFileLockException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

/**
 *
 * @author Administrator
 */
public class FLExRead_J {
    public String strDeviceData = "\tReceived data:\t", strLockShot = "";  //+++ Output for client.
    private final String strInput;  //+++ Data from laptop browser, to be read from Raspberry RAM file.
    
    public FLExRead_J(String strInput)
    {
        this.strInput = strInput;
    }
        
    public void Read() throws IOException, InterruptedException {        
        String filePath = ""; //+++ Raspberry RAM file to be read by fileChannel on demand from laptop browser.   
        if (strInput.contains("P"))
            filePath = "/ramfs/potentiometer.txt";//???
//            filePath = "J:/potentiometer.txt";
        else if (strInput.contains("T"))
            filePath = "/ramfs/thermometer.txt";//???       
//            filePath = "J:/thermometer.txt";       
        
        Path path = Paths.get(filePath); 
        FileChannel fileChannel;
        
        //+++ Open for reading with obtained fileChannel. It needs write option too.
        fileChannel = FileChannel.open(path, StandardOpenOption.READ, StandardOpenOption.WRITE);  
        int iLockShot = 0;  //+++ Attempts to get an exclusive lock for reading.
        boolean bValidLock = false;
        
        //+++ Try getting an exclusive lock.
        while (bValidLock == false){
            try {  
                FileLock lock = fileChannel.lock();
                bValidLock = lock.isValid();
            } 
            catch (OverlappingFileLockException e) {
                e.getMessage();
                iLockShot++;
            }
        }        
        strLockShot = "\tLockShot:\t" + iLockShot;

        ByteBuffer buffer = ByteBuffer.allocate(200);   //+++ Buffer for successive readings.
        int iBytesRead = fileChannel.read(buffer);  //+++ Read from file into buffer.

        while (iBytesRead != -1) {
            buffer.flip();  //+++ Make buffer ready for reading.
            
            while (buffer.hasRemaining())
                strDeviceData += (char)buffer.get();  //+++ Read from buffer into string.   
            
            buffer.clear();    //+++ Make buffer ready for writing.        
            iBytesRead = fileChannel.read(buffer);
        }
        fileChannel.close(); //+++ Close fileChannel and release lock.
    }
}