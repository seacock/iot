#include "Spi.h"
#include "Ry.h"
#include "SharA.h"
#include <wiringPiSPI.h>
#include "ColorText.h"

#define SPI_MSG_LENGTH_TI 30
#define SPI_MSG_LENGTH_RY (SPI_MSG_LENGTH_TI - 1)
#define HEAD_SPACES 2

unsigned char aucMasterMsg[SPI_MSG_LENGTH_RY] = "Mercore e nespoe Zioba e ova";

CSpi::CSpi(CRy *pRaspberry)
{
	pRy = pRaspberry;
	uiNumOfSpiCalls = 0;
}

CSpi::~CSpi()
{
}

//+++ The delay between each of this calls must be shorter than TIMER3_PERIOD of Pic24 or the game doesn't work.
void CSpi::SpiMaster()
{	
	unsigned char aucMasterBuf[SPI_MSG_LENGTH_RY], *pucMasterBuf;
	strcpy((char*)aucMasterBuf, (char*)aucMasterMsg);

	CColorText coltRed(CColorText::RED);
	wiringPiSPIDataRW(kiSpiChannel, aucMasterBuf, SPI_MSG_LENGTH_RY);
	pucMasterBuf = aucMasterBuf;
	pucMasterBuf += HEAD_SPACES;
	coltRed.ss << "----- " << pucMasterBuf << " received first--------" << endl;
	cout << coltRed;

	CColorText coltBlue(CColorText::BLUE);	
	wiringPiSPIDataRW(kiSpiChannel, aucMasterBuf, SPI_MSG_LENGTH_RY);
	pucMasterBuf = aucMasterBuf;
	pucMasterBuf += HEAD_SPACES;
	coltBlue.ss << "----- " << pucMasterBuf << " received second--------" << endl;
	cout << coltBlue;

#ifdef _TALKATIVE_
	cout << "----- " << uiNumOfSpiCalls << " number of SPI calls--------" << endl;
	uiNumOfSpiCalls++;
#endif // _TALKATIVE_
}