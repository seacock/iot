/*
 * ^AbsolTx.c
 *
 *  Created on: 01 feb 2019
 *      Author: andre
 */

#include "^Common.h"

/***** Variable declarations *****/
static RF_Object rfObject;
static RF_Handle rfHandle;

static uint8_t txPacket[PAYLOAD_LENGTH];

#ifdef LOG_RADIO_EVENTS
static volatile RF_EventMask eventLog[32];
static volatile uint8_t evIndex = 0;
#endif // LOG_RADIO_EVENTS

#pragma DATA_ALIGN(AbsolTxTaskStack, 8)  //+++ 1-byte alignment on the stack to avoid wasting memory.
static uint8_t AbsolTxTaskStack[STACKSIZE];
Task_Struct AbsolTxTr;

RF_RatConfigCompare ratConfCmp;
RF_RatHandle ratHandle;
static Semaphore_Handle hsemAbsolTx;
extern uint32_t uiTimestamp2;
static uint16_t seqNumber = 0;

Void AbsolTxTf(UArg arg0, UArg arg1);
static void AbsolTxCb(RF_Handle h, RF_CmdHandle ch, RF_EventMask e);

void onRatTriggered(RF_Handle h, RF_RatHandle rh, RF_EventMask e, uint32_t compareCaptureTime);

void StartAbsolTxTf(void)
{
	Semaphore_Params semParams;
	Semaphore_Params_init(&semParams);
	hsemAbsolTx = Semaphore_create(0, &semParams, NULL);
	if (hsemAbsolTx == NULL) //+++ Check if the handle is valid.
		while(1);

    Task_Params taskParams;
    Task_Params_init(&taskParams);
    taskParams.stackSize = STACKSIZE;
    taskParams.priority = 2;    //+++ More than 1 or is preempted by while (1) in mainThread.
    taskParams.stack = &AbsolTxTaskStack;

    Task_construct(&AbsolTxTr, AbsolTxTf, &taskParams, NULL);
}

Void AbsolTxTf(UArg arg0, UArg arg1)
{
    RF_Params rfParams;
    RF_Params_init(&rfParams);

    /* Modify CMD_PROP_TX and CMD_PROP_RX commands for application needs */
    RF_cmdPropTx.pktLen = PAYLOAD_LENGTH;
    RF_cmdPropTx.pPkt = txPacket;
    RF_cmdPropTx.startTrigger.triggerType = TRIG_NOW;

    rfHandle = RF_open(&rfObject, &RF_prop, (RF_RadioSetup*)&RF_cmdPropRadioDivSetup, &rfParams);	//+++ Request access to the radio.
    RF_postCmd(rfHandle, (RF_Op*)&RF_cmdFs, RF_PriorityNormal, NULL, 0);	//+++ Set the frequency.
    RF_RatConfigCompare_init(&ratConfCmp);
	ratConfCmp.callback = &onRatTriggered;
	ratConfCmp.channel = RF_RatChannelAny;
	ratConfCmp.timeout = uiTimestamp2 + 4 * PACKET_INTERVAL;	//+++Common time base for slave.
	ratHandle = RF_ratCompare(rfHandle, &ratConfCmp, NULL);
	if (ratHandle == RF_ALLOC_ERROR)
		while(1);

    while(1)
    {
    	memset(txPacket, '0', PAYLOAD_LENGTH);	//---

    	/* Create packet with incrementing sequence number and payload */
		txPacket[0] = (uint8_t)(seqNumber >> 8);
		txPacket[1] = (uint8_t)(seqNumber++);

		Semaphore_pend(hsemAbsolTx, BIOS_WAIT_FOREVER);
		PIN_setOutputValue(ledPinHandle, Board_PIN_LED2, !PIN_getOutputValue(Board_PIN_LED2));

        RF_EventMask terminationReason = RF_runCmd(rfHandle, (RF_Op*)&RF_cmdPropTx, RF_PriorityNormal, AbsolTxCb, RF_EventCmdDone);//---

        uint32_t cmdStatus = ((volatile RF_Op*)&RF_cmdPropTx)->status;
		TermStat(terminationReason, cmdStatus);

		RF_yield(rfHandle);
    }
    //	Semaphore_delete(&hsemAbsolTx);//---
}

static void AbsolTxCb(RF_Handle h, RF_CmdHandle ch, RF_EventMask e)
{
    if(e & RF_EventCmdDone)
        PIN_setOutputValue(ledPinHandle, Board_PIN_LED2, !PIN_getOutputValue(Board_PIN_LED2));	//+++ Successful TX. Toggle LED2.
    else
    {
        /* Error Condition: set both LEDs */
        PIN_setOutputValue(ledPinHandle, Board_PIN_LED1, 1);
        PIN_setOutputValue(ledPinHandle, Board_PIN_LED2, 1);
    }
}

void onRatTriggered(RF_Handle h, RF_RatHandle rh, RF_EventMask e, uint32_t compareCaptureTime)
{
    if (e & RF_EventError)
    	while(1);	// RF driver failed to trigger the callback on time.

    //+++ RAT has triggered at compareCaptureTime. Trigger precisely with the same period again.
	ratConfCmp.timeout = compareCaptureTime + PACKET_INTERVAL;
    rh = RF_ratCompare(h, &ratConfCmp, NULL);
    if (rh == RF_ALLOC_ERROR)
    	while(1);

    Semaphore_post(hsemAbsolTx);
    PIN_setOutputValue(ledPinHandle, Board_PIN_LED1, !PIN_getOutputValue(Board_PIN_LED1));	//+++ Successful trigger. Toggle LED1.
}
