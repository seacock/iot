/*
 * ^SvTimestamp.c
 *
 *  Created on: 13 apr 2019
 *      Author: andre
 */

#include "^SvCommon.h"

#define RX_TIMEOUT_TIMESTAMP 4000 //+++ �s

/***** Variable declarations *****/
static RF_Object rfObject;
static RF_Handle rfHandle;
/* Buffer which contains all Data Entries for receiving data.
 * Pragmas are needed to make sure this buffer is aligned to a 4 byte boundary (requirement from the RF core).
 */
#pragma DATA_ALIGN(rxDataEntryBuffer, 4)
static uint8_t rxDataEntryBuffer[RF_QUEUE_DATA_ENTRY_BUFFER_SIZE(NUM_DATA_ENTRIES, PAYLOAD_LENGTH, NUM_APPENDED_BYTES)];

/* Receive dataQueue for RF Core to fill in data */
static dataQueue_t dataQueue;
static rfc_dataEntryGeneral_t* currentDataEntry;
static uint8_t packetLength;
static uint8_t* packetDataPointer;

static uint8_t txPacket[PAYLOAD_LENGTH];

#pragma DATA_ALIGN(SvTimestampTaskStack, 8)  //+++ 1-byte alignment on the stack to avoid wasting memory.
static uint8_t SvTimestampTaskStack[STACKSIZE];

static uint32_t auiMDeltaProc[3];	//+++ Each element of array: fixed delay for message processing on master.
static const uint8_t ucSizeMDP = ARRAY_SIZE(auiMDeltaProc);
static uint32_t uiSTimeStampRequest;	//+++ Slave timestamp: when request sent by slave.
int64_t llOffsetMs;	//+++ Slave clock offset, relative to master clock.
uint32_t uiMTimeStampCTB;	//+++ Timestamp sent by master after offset calculation: common time base for slave.
static uint8_t ucNumRoundTrip;	//+++ Counter of successful request/reply actions.
static bool bRxSuccess;

Void SvTimestampTf(UArg arg0, UArg arg1);
static void SvTimestampRxCb(RF_Handle h, RF_CmdHandle ch, RF_EventMask e);
static void SvTimestampTxCb(RF_Handle h, RF_CmdHandle ch, RF_EventMask e);

void StartTimestampRxTf(void)
{
    Task_Params taskParams;
    Task_Params_init(&taskParams);
    taskParams.stackSize = STACKSIZE;
    taskParams.priority = 2;    //+++ More than 1 or is preempted by while (1) in mainThread.
    taskParams.stack = &SvTimestampTaskStack;

    uiMTimeStampCTB = 0;
    ucNumRoundTrip = 0;
    bRxSuccess = false;
    SwitchOffLED();

    Task_construct(&SvTimestampTr, SvTimestampTf, &taskParams, NULL);
}

Void SvTimestampTf(UArg arg0, UArg arg1)
{
	RF_Params rfParams;
	RF_Params_init(&rfParams);

	if (RFQueue_defineQueue(&dataQueue,	rxDataEntryBuffer, sizeof(rxDataEntryBuffer),
												NUM_DATA_ENTRIES, PAYLOAD_LENGTH + NUM_APPENDED_BYTES))
	{
		/* Failed to allocate space for all data entries */
		PIN_setOutputValue(hDynPin, GREEN_LED, 1);//---
		PIN_setOutputValue(hDynPin, RED_LED, 1);
		while (1);
	}

	/* Modify CMD_PROP_TX and CMD_PROP_RX commands for application needs */
	RF_cmdPropRx.pQueue = &dataQueue;	//+++ Set the Data Entity queue for received data.
	RF_cmdPropRx.rxConf.bAutoFlushIgnored = 1;	//+++Discard ignored packets from Rx queue.
	RF_cmdPropRx.rxConf.bAutoFlushCrcErr = 1;	//+++Discard packets with CRC error from Rx queue.
	RF_cmdPropRx.rxConf.bAppendTimestamp = 1;	//+++ Append RX timestamp to the payload.
	RF_cmdPropRx.maxPktLen = PAYLOAD_LENGTH;	//+++ Implement packet length filtering to avoid PROP_ERROR_RXBUF.
	RF_cmdPropRx.pktConf.bRepeatOk = 0;	//+++ End RX operation when a packet is received correctly.
	RF_cmdPropRx.pktConf.bRepeatNok = 0;	//+++ End RX operation when a packet is received incorrectly.
	RF_cmdPropRx.startTrigger.triggerType = TRIG_NOW;
	RF_cmdPropRx.endTrigger.triggerType = TRIG_REL_START;
	RF_cmdPropRx.endTime = RF_convertUsToRatTicks(RX_TIMEOUT_TIMESTAMP);	//+++ .

	RF_cmdPropTx.pktLen = PAYLOAD_LENGTH;
	RF_cmdPropTx.pPkt = txPacket;
	RF_cmdPropTx.startTrigger.triggerType = TRIG_NOW;

	rfHandle = RF_open(&rfObject, &RF_prop, (RF_RadioSetup*)&RF_cmdPropRadioDivSetup, &rfParams);	//+++ Request access to the radio.
	RF_postCmd(rfHandle, (RF_Op*)&RF_cmdFs, RF_PriorityNormal, NULL, 0);	//+++ Set the frequency.

	while (ucNumRoundTrip <= ucSizeMDP)
	{
		RF_CmdHandle firstCommand = RF_postCmd(rfHandle, (RF_Op*)&RF_cmdPropRx, RF_PriorityNormal, SvTimestampRxCb, (RF_EventLastCmdDone | RF_EventRxEntryDone));
		RF_pendCmd(rfHandle, firstCommand, RF_EventLastCmdDone);

		RF_CmdHandle lastCommand = RF_postCmd(rfHandle, (RF_Op*)&RF_cmdPropTx, RF_PriorityNormal, SvTimestampTxCb, RF_EventLastCmdDone);
		RF_pendCmd(rfHandle, lastCommand, RF_EventLastCmdDone);
	}
	RF_close(rfHandle);//---
	Semaphore_post(hsemTimeStamp);
}

static void SvTimestampRxCb(RF_Handle h, RF_CmdHandle ch, RF_EventMask e)
{
    if (e & RF_EventRxEntryDone)
    {
        /* Successful RX. Toggle RED_LED, clear GREEN_LED to indicate RX */
        PIN_setOutputValue(hDynPin, GREEN_LED, 0);
        static uint8_t ucSlow = 0;
		LedFlicker(&ucSlow, RED_LED);

        bRxSuccess = true;	//+++ Successful RX.
        currentDataEntry = RFQueue_getDataEntry();	//+++ Get current unhandled data entry.

        /* Handle the packet data, located at &currentDataEntry->data:
         * - Length is the first byte with the current configuration
         * - Data starts from the second byte */
        packetLength      = *(uint8_t *)(&(currentDataEntry->data));
        packetDataPointer = (uint8_t *)(&(currentDataEntry->data) + 1);

        uint8_t ucCount;	//+++ Counter.
        uint8_t ucShift;	//+++ Shift bits.
        if (ucNumRoundTrip < ucSizeMDP)
		{
			/**
			 * The very first packet received from master has [TS2_MASTER] = TS2_IDLE. It will not be processed,
			 * but allows slave to specify [TS2_SLAVE] = TS2_OFFSET and initiate request for common absolute time.
			 */
			packetDataPointer[TS2_SLAVE] = TS2_OFFSET;
			if (packetDataPointer[TS2_MASTER] == TS2_OFFSET)
			{
				uint8_t *pucTxDeltaProc = packetDataPointer + TS2_DP1;
				auiMDeltaProc[ucNumRoundTrip] = 0;
				for (ucCount = 0, ucShift = SHIFT24; ucCount < sizeof(uint32_t); ucCount++, ucShift -= BYTELENGTH)
					auiMDeltaProc[ucNumRoundTrip] += (*(pucTxDeltaProc + ucCount)) << ucShift;

				if (ucNumRoundTrip == ucSizeMDP - 1)
				{
					uint32_t uiMTimeStampOC = 0;	//+++ Timestamp sent by master upon request received from slave: offset calculation.
					uint8_t *pucTxTimestamp = packetDataPointer + TS2_TS1;
					for (ucCount = 0, ucShift = SHIFT24; ucCount < sizeof(uint32_t); ucCount++, ucShift -= BYTELENGTH)
						uiMTimeStampOC += (*(pucTxTimestamp + ucCount)) << ucShift;

					uint32_t uiMDeltaProcAve = 0;	//+++ Average of elements of auiMDeltaProc.
					for (ucCount = 0; ucCount < ucSizeMDP; ucCount++)
						uiMDeltaProcAve += auiMDeltaProc[ucCount];

					uiMDeltaProcAve /= ucSizeMDP;

					uint8_t *pucRxTimestamp = packetDataPointer + packetLength;
					uint32_t uiSTimeStampReply;	//+++ Slave timestamp: when reply received from master.
					memcpy(&uiSTimeStampReply, pucRxTimestamp, TIMESTAMP);

					int64_t llSTimeStampRequest = uiSTimeStampRequest, llMTimeStampOC = uiMTimeStampOC, llSTimeStampReply = uiSTimeStampReply;
					llOffsetMs = llSTimeStampRequest - (llMTimeStampOC - (llSTimeStampReply - llSTimeStampRequest - uiMDeltaProcAve) / 2);
					packetDataPointer[TS2_SLAVE] = TS2_SYNCHRO;
				}
				ucNumRoundTrip++;
			}
		}
		else if (packetDataPointer[TS2_MASTER] == TS2_SYNCHRO)
		{
			uint8_t *pucTxTimestamp = packetDataPointer + TS2_TS1;
			for (ucCount = 0, ucShift = SHIFT24; ucCount < sizeof(uint32_t); ucCount++, ucShift -= BYTELENGTH)
				uiMTimeStampCTB += (*(pucTxTimestamp + ucCount)) << ucShift;

			packetDataPointer[TS2_SLAVE] = TS2_IDLE;//---
			ucNumRoundTrip++;
		}

        memcpy(txPacket, packetDataPointer, packetLength);	//+++ Copy the payload + status byte to the txPacket.

        RFQueue_nextEntry();
    }
    else if ((e & RF_EventLastCmdDone) && !(e & RF_EventRxEntryDone))
		if (bRxSuccess == true)
			bRxSuccess = false;	//+++ Last command (RX) completed after RX_ENTRY_DONE within RX_TIMEOUT_TIMESTAMP.
		else
		{
			static uint8_t ucSlow = 0;
			LedFlicker(&ucSlow, CYAN_LED);	//+++ RX timed out. Toggle CYAN_LED.
		}
}

static void SvTimestampTxCb(RF_Handle h, RF_CmdHandle ch, RF_EventMask e)
{
    if (e & RF_EventLastCmdDone)
    {
        /* Successful Echo (TX). Toggle GREEN_LED, clear RED_LED to indicate TX. */
        PIN_setOutputValue(hDynPin, RED_LED, 0);
        static uint8_t ucSlow = 0;
        LedFlicker(&ucSlow, GREEN_LED);

        if (ucNumRoundTrip == ucSizeMDP - 1)
			uiSTimeStampRequest = RF_getCurrentTime();
    }
}
