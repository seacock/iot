/*
 * ^Input.c
 *
 *  Created on: 04 dic 2018
 *      Author: andre
 */

#include <^Common.h>

void Board_PIN_BUTTONCb(PIN_Handle handle, PIN_Id pinId)
{
    CPUdelay(1000);  //+++ Debounce logic.
    if (!PIN_getInputValue(pinId))
        switch (pinId)
        {
            case Board_PIN_BUTTON0:
                StartRxRfCoTf();
                break;
            case Board_PIN_BUTTON1:
                StartRxRfSsTf();
                break;
            default:
                /* Do nothing */
                break;
        }
}

void CC1310_LAUNCHXL_DIO12Cb(PIN_Handle handle, PIN_Id pinId)
{
    ActiveWirePinId = pinId;    //+++ Set current pinId to active.
    PIN_setConfig(handle, PIN_BM_IRQ, ActiveWirePinId | PIN_IRQ_DIS);   //+++ Disable interrupts during debounce.
    Clock_setTimeout(WireClockH, (50 * (1000 / Clock_tickPeriod))); //+++ Set timeout 50 ms from now and re-start clock: Clock_tickPeriod is 10 microsec.
    Clock_start(WireClockH);
}
