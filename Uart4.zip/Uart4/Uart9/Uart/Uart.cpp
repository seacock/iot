#include <iostream>
#include <wiringPi.h>
#include <wiringSerial.h>

using namespace std;

#define CTS 5	//+++ Clear to send input.	wiringPi 5. GPIO pin 18. 
#define RTS 6	//+++ Request to send output. wiringPi 6. GPIO pin 22.

int main(int argc, char *argv[])
{
	if (sizeof(int) == 2)
	{
		printf("Storage size for int must be 4. Program terminates.\n");
		return 0;
	}

	if (wiringPiSetup() == -1)
	{
		cout << "Unable to start wiringPi\n";
		return 1 ;
	}

	pinMode(CTS, INPUT);
	pinMode(RTS, OUTPUT);
	digitalWrite(RTS, HIGH); 
	int handle = serialOpen("/dev/ttyAMA0", 9600);
	if (handle == -1)
		cout << "bad handle" << endl;

	int iData, iCharRx, iDataAvail, iNumCycle;

	cout << endl << endl;
//	serialFlush(handle);

	for (int iCount = 0; iCount < 10; iCount++)
	{
		iCharRx = 0;
		iNumCycle = 0;
		iDataAvail = 0;

		digitalWrite(RTS, HIGH);
		digitalWrite(RTS, LOW);
//		delay(1000);//************************************************************************** That would zero num of cycles.
		
		while (iNumCycle < 150000)   
		{
			iDataAvail = serialDataAvail(handle);
			if (iDataAvail == 84)
				break;
			iNumCycle++;
		}

		cout << "Num of cycles for normal operation " << iNumCycle << "		Data available " << iDataAvail << endl;

		while (iCharRx < iDataAvail)
		{
			iData = serialGetchar(handle);
			cout << (char)iData;
			iCharRx++;
		}
		digitalWrite(RTS, HIGH); 

		cout << endl;

		while (digitalRead(CTS) == 1) 
		{
		}

		char s[] = "From Raspberry 2";
		serialPuts(handle, s);
//		serialFlush(handle);
	}

	serialClose(handle);

	return 0;
}