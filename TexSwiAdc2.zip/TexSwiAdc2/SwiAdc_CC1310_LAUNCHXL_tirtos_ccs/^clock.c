/*
 * ^clock.c
 *
 *  Created on: 25 ott 2018
 *      Author: andre
 */

#include <^common.h>
#include <ti/sysbios/knl/Clock.h>

Void ClockAdc(UArg arg0)
{
    Semaphore_post(hSemADC);   //+++ Post to main loop semaphore.
}

void StartClockAdc(void)
{
    Clock_Params clockParams;
    Error_Block eb;
    Error_init(&eb);
    Clock_Params_init(&clockParams);
    clockParams.period = 30;
    clockParams.startFlag = TRUE;
    clockParams.arg = (UArg)0x1111;
    Clock_Handle myClock = Clock_create(ClockAdc, 5, &clockParams, &eb);
    if (myClock == NULL)
        System_abort("Clock create failed");
}

Void ClockSwi(UArg arg0)
{
    //Swi_post(swi0Handle);

//    Swi_andn(swi0Handle, 0x1);        /* swi0 trigger = 0x02 */
//    Swi_andn(swi0Handle, 0x2);        /* swi0 runs with trigger = 0x00 */
}

void StartClockSwi(void)
{
    Clock_Params clockParams;
    Error_Block eb;
    Error_init(&eb);
    Clock_Params_init(&clockParams);
    clockParams.period = 15;
    clockParams.startFlag = TRUE;
    clockParams.arg = (UArg)0x2222;
    Clock_Handle myClock = Clock_create(ClockSwi, 5, &clockParams, &eb);
    if (myClock == NULL)
        System_abort("Clock create failed");
}
