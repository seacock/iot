#pragma once

#include <iostream>
#include <sstream>
#include <vector>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <ifaddrs.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <time.h>
#include <signal.h>

#include <wiringPi.h>
#include <wiringPiSPI.h>
#include <wiringPiI2C.h>
#include <wiringSerial.h>

using namespace std;	//??????
#include "ColorText.h"
#include "Aff.h"
#include "Spi.h"
#include "I2c.h"
#include "Uart.h"

//#define _BRIEF_
//#define _TALKATIVE_
//#define _WEBTOM8_	//+++ Tomcat8 must be on and able to access its 2 local txt files.

#define SUCCESS 0
#define ERROR 1
#define INVALID_SOCKET -1
#define NUM_THREADS 7
#define PORT 13   //+++ The port on which to send data for broadcast: daytime.
#define SWITCH_INC 1	//+++ (RaspberryPi2 40-pin header J8: pin 12 hardware = GPIO 18 BCM) = (wiringPi: GPIO1 = pin 1 software)
#define SWITCH_DEC 4	//+++ (RaspberryPi2 40-pin header J8: pin 16 hardware = GPIO 23 BCM) = (wiringPi: GPIO4 = pin 4 software)
#define DELAY 500
#define THREAD_STACK_SIZE 40000	//+++ Enough to provide for getaddrinfo that uses stack and not heap.
#define SPI_CHANNEL 0
#define SPI_SPEED 500000
#define SPI_LENGTH 1
#define BUFLEN 512	//+++ initial size for dynamic C-style array vector; size of generic reading-writing buffer.
#define BUFLEN_MJC 1024
#define SELECT_TIMEOUT 0

#define I2C_RY_NORMAL 200	//+++ 
#define I2C_RY_EXIT 201	//+++ RyS's communication threads stop communication and RyS exit. Defined in Asi, RyS.
#define I2C_RY_SHUT_COMM 202	//+++ RyS's communication threads stop communication, but RyS continues working. Defined in Asi, RyS.
#define I2C_LAPTOP_DISMISS 203	//+++ Laptop is dismissed, but RyS continues working. Defined in Asi, RyS.
#include "Ry.h"	//??????

#define TOT_NUM_SPI_CALLS (1000 * 1000 * 1000)
#define NUM_SPI_CALLS 2000
#define TOMCAT_COUNTER 1000
#define LAPTOP_COUNTER 100

#define BROADCAST 1
#define ONE 2
#define TWO 3
#define THREE 4
#define TEMPORARY 5
#define SERVER_I2C 6
#define SERV_MIX_JC 7

#define INVALID_FD -1
#define END_SERVER 30	//???
#define END_THREAD 40	//???

//+++ Commands to retrieve AD converted physical quantities from Microchip PICFJ64GB002.
#define CMD_UB_P 0x01   //+++ Upper byte of potentiometer. Defined in RyS, Sciupa.
#define CMD_LB_P 0x02   //+++ Lower byte of potentiometer. Defined in RyS, Sciupa.
#define CMD_UB_T 0x04   //+++ Upper byte of thermometer. Defined in RyS, Sciupa.
#define CMD_LB_T 0x05   //+++ Lower byte of thermometer. Defined in RyS, Sciupa.
#define CMD_UB_RS 0x06   //+++ Upper byte of SPI resets. Defined in RyS, Sciupa.
#define CMD_LB_RS 0x07   //+++ Lower byte of SPI resets. Defined in RyS, Sciupa.

#define ARRAY_SIZE(array) (sizeof(array) / sizeof(array[0]))

#define handle_error_en(en, msg) \
               do { errno = en; cerr << msg << ": " << strerror(errno) << endl; exit(EXIT_FAILURE); } while (0)	//+++

#define handle_error(msg) \
               do { cerr << msg << ": " << strerror(errno) << endl; exit(EXIT_FAILURE); } while (0)	//+++ Print error message and exit app.

#define handle_error1(msg1) \
               do { cerr << msg1 << endl; exit(EXIT_FAILURE); } while (0)	

#define handle_error2(msg1, msg2) \
               do { cerr << msg1 << ": " << msg2 << endl; exit(EXIT_FAILURE); } while (0)	

#define ADC_AVERAGE 110	//+++ PICFJ64GB002 sends back average ADC values for potentiometer and thermometer. Defined in Asi, RyS, Sciupa.
#define ADC_LASTVAL 120	//+++ PICFJ64GB002 sends back last ADC value for potentiometer and thermometer. Defined in Asi, RyS, Sciupa.
#define PWM_CONTINUOUS 130	//+++ PICFJ64GB002 outputs PWM with duty cycle fixed by slider. Defined in Asi, RyS, Sciupa.
#define PWM_FUNCTION 140	//+++ PICFJ64GB002 outputs PWM with variable duty cycle depending on a local function. Defined in Asi, RyS, Sciupa.