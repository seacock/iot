#pragma once

#include <iostream>
#include <sstream>
using namespace std;

class CColorText
{
public:
	int iColorText;
	enum Color7 { RED, GREEN, YELLOW, BLU, MAGENTA, CYAN, WHITE };
	ostringstream ss;
	static string SasrColor[7];
	~CColorText();
	CColorText(int iColor);
	friend ostream& operator <<(ostream &os, const CColorText &obj);	//+++ Overloading the << Operator.
};

#define _RED_		"\x1B[31m"
#define _GREEN_		"\x1B[32m"
#define _YELLOW_	"\x1B[33m"
#define _BLUE_		"\x1B[34m"
#define _MAGENTA_	"\x1B[35m"
#define _CYAN_		"\x1B[36m"
#define _WHITE_		"\x1B[37m"

//FG_DEFAULT = 39, FG_BLACK = 30, FG_RED = 31, FG_GREEN = 32, FG_YELLOW = 33, FG_BLUE = 34, FG_MAGENTA = 35, FG_CYAN = 36, FG_LIGHT_GRAY = 37, FG_DARK_GRAY = 90, FG_LIGHT_RED = 91, FG_LIGHT_GREEN = 92, FG_LIGHT_YELLOW = 93, FG_LIGHT_BLUE = 94, FG_LIGHT_MAGENTA = 95, FG_LIGHT_CYAN = 96, FG_WHITE = 97, BG_RED = 41, BG_GREEN = 42, BG_BLUE = 44, BG_DEFAULT = 49