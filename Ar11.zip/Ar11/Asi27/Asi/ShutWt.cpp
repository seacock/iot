#include "stdafx.h"
#include "Asi.h"

int giWaitThreadTimeout = 5000;

void CloseHandleNull(HANDLE &hHan);
void WaitI2c(Hook *pstHook);	//+++ Browse the 4 handles related to I2c and wait only for the activated ones.

DWORD WINAPI T_RyExit(LPVOID lpParam)
{
	theApp.ThrAffinity(13);
	Hook *pstHook = (Hook*)lpParam;
	CTabFour *pTabFour = pstHook->pTabFour;

	HANDLE hKernelObj = pstHook->hT_Connect;
	DWORD dwWaitResult = WaitForSingleObject(hKernelObj, giWaitThreadTimeout);
	switch (dwWaitResult)
	{
	case WAIT_OBJECT_0:	//??? It should be adequate only CloseHandle...
		CloseHandleNull(pstHook->hT_Connect);
		CloseHandleNull(pTabFour->hE_RbAdc);
		CloseHandleNull(pTabFour->hE_RbPwm);
		CloseHandleNull(pTabFour->hE_Sli);
		CloseHandleNull(pTabFour->hE_I2cTest);
		break;
	case WAIT_TIMEOUT:
		MessageBox(NULL, L"T_RyExit WaitForMultipleObjects WAIT_TIMEOUT", L"Error", MB_ICONEXCLAMATION);
		break;
	case WAIT_FAILED:
		MessageBox(NULL, L"T_RyExit WaitForMultipleObjects WAIT_FAILED", L"Error", MB_ICONEXCLAMATION);
		break;
	}

	WaitI2c(pstHook);
	
	return NO_ERROR;
}

DWORD WINAPI T_ShutComm(LPVOID lpParam)
{
	theApp.ThrAffinity(13);
	Hook *pstHook = (Hook*)lpParam;

	WaitI2c(pstHook);

	return NO_ERROR;
}

void WaitI2c(Hook *pstHook)
{
	int iNumToWait = 0, iCheck;
	HANDLE ahTemp[4] = { pstHook->hT_I2cMaTx, pstHook->hT_I2cMaRx, pstHook->hT_I2cAuTx, pstHook->hT_I2cAuRx };
	for (iCheck = 0; iCheck < ARRAY_SIZE(ahTemp); iCheck++)
		if (ahTemp[iCheck] != NULL)
			iNumToWait++;

	HANDLE *pahToWait = new HANDLE[iNumToWait];
	iNumToWait = 0;
	for (iCheck = 0; iCheck < ARRAY_SIZE(ahTemp); iCheck++)
		if (ahTemp[iCheck] != NULL)
			pahToWait[iNumToWait++] = ahTemp[iCheck];

	DWORD dwWaitResult = WaitForMultipleObjects(iNumToWait, pahToWait, TRUE, giWaitThreadTimeout);
	switch (dwWaitResult)
	{
	case WAIT_OBJECT_0:
		for (iCheck = 0; iCheck < iNumToWait; iCheck++)	//??? There could be a choice between CloseHandleNull and CloseHandle: too punctilious.
			CloseHandleNull(pahToWait[iCheck]);
		break;
	case WAIT_TIMEOUT:
		MessageBox(NULL, L"WaitCollectiveA WaitForMultipleObjects WAIT_TIMEOUT", L"Error", MB_ICONEXCLAMATION);
		break;
	case WAIT_FAILED:
		MessageBox(NULL, L"WaitCollectiveA WaitForMultipleObjects WAIT_FAILED", L"Error", MB_ICONEXCLAMATION);
		break;
	}

	delete[] pahToWait;

	pstHook->pAsiDlg->PostMessageW(RG_WM_COMM_ABATED);	//+++ SendMessageW wouldn't fit.
}

//+++ Examine exit code of a thread.
DWORD WINAPI T_ThreadExCo(LPVOID lpParam)
{
	theApp.ThrAffinity(13);
	HANDLE *pstThExCo = (HANDLE*)lpParam;
	DWORD dwExitCodeThread;
	DWORD dwWaitResult = WaitForSingleObject(*pstThExCo, INFINITE);
	switch (dwWaitResult)
	{
	case WAIT_OBJECT_0:
		GetExitCodeThread(*pstThExCo, &dwExitCodeThread);
		if (dwExitCodeThread == AsiConst::kiErrorCom)
			((CAsiDlg*)theApp.m_pMainWnd)->SendMessageW(RG_WM_PIC_LIGHT, RED_LIGHT);
		break;
	}
	
	return NO_ERROR;
}

//+++ Must be a passage by reference or things don't work.
void CloseHandleNull(HANDLE &hHan)
{
	CloseHandle(hHan);
	hHan = NULL;
}