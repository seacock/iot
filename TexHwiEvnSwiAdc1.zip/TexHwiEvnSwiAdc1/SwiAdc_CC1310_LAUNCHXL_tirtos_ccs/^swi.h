/*
 * ^swi.h
 *
 *  Created on: 25 ott 2018
 *      Author: andre
 */

#ifndef SWI_H_
#define SWI_H_

char a2cSwiZeroInfo[5][100], a2cSwiOneInfo[5][100];
uint16_t uiZeroCycle, uiOneCycle;
bool bZeroDisplay, bOneDisplay;

Void ZeroSwf(UArg arg0, UArg arg1);
void StartZeroSwf(void);
Void OneSwf(UArg arg0, UArg arg1);
void StartOneSwf(void);

#endif /* SWI_H_ */
