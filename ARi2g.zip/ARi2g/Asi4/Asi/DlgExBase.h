#pragma once


// CDlgExBase dialog

class CDlgExBase : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgExBase)

public:
	CDlgExBase(CWnd* pParent = NULL);   // standard constructor
	virtual ~CDlgExBase();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DLGEXBASE };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	int SocketAddr1(HWND hWnd, wstring wsrClassName, char *pcHostName, char *pcPortNumber, sockaddr_in **sockaddr_ipv4);

	DECLARE_MESSAGE_MAP()
};
