#pragma once

#include "SharA.h"

class CAff
{
public:
	CAff();
	~CAff();
	int SchedAff(); 	//+++ Manages CPU mask for main and child threads. Set affinity and scheduling algorithm for main thread.
	void ThreadAttr(pthread_attr_t &unAttr); 	//+++ Set stack size, scheduling inheritance, policy and priority for child threads.
	void DisplayThreadSchedAttr(const char *msg); 	//+++ Display scheduling parameters( and CPU affinity) for calling thread.
};