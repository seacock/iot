/*
 * Common.h
 *
 *  Created on: 21 ott 2018
 *      Author: andre
 */

#ifndef COMMON_H_
#define COMMON_H_

/* Board Header file */
#include "Board.h"

#include <ti/sysbios/BIOS.h>

#include <ti/display/Display.h>
#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/knl/Task.h>

Display_Handle  displayHandle;
PIN_Handle hDynPin;
Semaphore_Handle hSemADC;   // Semaphore
Task_Struct stADCTask, stADCTask1;
bool bHigh1, bHigh2;

#endif /* COMMON_H_ */
