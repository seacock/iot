#include "Spi.h"
#include "ShaDe.h"   
#include <PPS.h>    //+++ For PPSUnLock and similar.

#if __XC16_VERSION__ >= 0x0401
#undef _ISR
#define _ISR __attribute__((interrupt, auto_psv))
#endif

bool gbSpiTimeOut;

int mainSpi(void) 
{       
    ConfigSpiPortPins();
    ConfigSpiPPS();
    SetupSpi();
    
    return 0;
}

void ConfigSpiPortPins(void)
{
    TRISBbits.TRISB14 = INPUT_PIN;   //+++ SDI1: hwPin = 25.
    TRISBbits.TRISB15 = OUTPUT_PIN;  //+++ SDO1: hwPin = 26.
    TRISBbits.TRISB2 = INPUT_PIN;   //+++ SCK1: hwPin = 6.
    TRISBbits.TRISB3 = INPUT_PIN;   //+++ SS1: hwPin = 7.
}

void ConfigSpiPPS(void)
{
    PPSUnLock;  //+++ Unlock the PPS functionality.
    iPPSInput(IN_FN_PPS_SDI1, IN_PIN_PPS_RP14);      //+++ SDI1: hwPin = 25. SPI1 Data Input.
    iPPSOutput(OUT_PIN_PPS_RP15, OUT_FN_PPS_SDO1);   //+++ SDO1: hwPin = 26. SPI1 Data Output.
    iPPSInput(IN_FN_PPS_SCK1IN, IN_PIN_PPS_RP2);    //+++ SCK1: hwPin = 6. SPI1 Clock Input.
    iPPSInput(IN_FN_PPS_SS1IN, IN_PIN_PPS_RP3);     //+++ SS1: hwPin = 7. SPI1 Slave Select Input.
    PPSLock;    //+++ Lock the PPS functionality.
}

void SetupSpi(void)
{
    //+++ SPI register configuration for Slave mode, byte-wide.
    IFS0bits.SPI1IF = 0;        //+++ Clear the Interrupt flag.
    IEC0bits.SPI1IE = 0;        //+++ Disable the interrupt.
    SPI1STATbits.SPIEN = 0;     //+++ Disable SPI module.
    
    //+++ The only valid combination with CKP. Serial output data changes on 
    //+++ transition from Active clock state to Idle clock state.
    SPI1CON1bits.CKE = 1;     
    SPI1CON1bits.SSEN = 1;      //+++ SS1 pin used for Slave mode.        
    IFS0bits.SPI1IF = 0;        //+++ Clear the Interrupt flag.
    IPC2bits.SPI1IP = 6;        //+++ SPI1 interrupt priority.
    IEC0bits.SPI1IE = 1;        //+++ Enable the interrupt.
    SPI1STATbits.SPIEN = 1;     //+++ Enable SPI module.
    
    SPI1BUF = 0;    //+++ Clear the register, to avoid dirty data.
}

void _ISR _SPI1Interrupt(void)
{        
    WORD data = SPI1BUF;    //+++ Read the data. No delay before this line.  
    
	//+++ Write the next data byte: needs to happen before the next byte/word is received. This IRQ
    //+++ is triggered 1/2 bit time before the end of the last bit of this byte/word. So if the 
    //+++ master is fast, we must service to her before the start of the first bit of the next 
    //+++ byte/word. 
    data = data * 3;
    SPI1BUF = data;
    
	IFS0bits.SPI1IF = 0;            //Clear the Interrupt Flag.
}