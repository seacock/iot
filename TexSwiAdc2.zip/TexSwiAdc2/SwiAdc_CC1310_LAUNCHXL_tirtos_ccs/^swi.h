/*
 * ^swi.h
 *
 *  Created on: 25 ott 2018
 *      Author: andre
 */

#ifndef SWI_H_
#define SWI_H_

char a2cSwiInfo[5][100];

Void swi0Fxn(UArg arg0, UArg arg1);
void Startswi0Fxn(void);

#endif /* SWI_H_ */
