/*
 *  ======== ^Primary.c ========
 */

/* Driver Header files */
// #include <ti/drivers/I2C.h>
// #include <ti/drivers/SDSPI.h>
// #include <ti/drivers/SPI.h>
// #include <ti/drivers/UART.h>
// #include <ti/drivers/Watchdog.h>

#include <^Common.h>

void StartDisplayTf(void);

//+++ Application pin configuration tables.
PIN_Config LedPinCfg[] = {
    BOARD_PIN_RED_LED | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,  //+++ Blink to indicate RX.
    BOARD_PIN_GREEN_LED | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,    //+++ Blink to indicate stop Rx i.e. standby.
    PIN_TERMINATE
};

PIN_Config DInPinCfg[] = {
    CC1310_LAUNCHXL_DIO1 | PIN_INPUT_EN | PIN_PULLUP | PIN_IRQ_NEGEDGE,     //+++ Stop Rx mode; reset buttons and LEDs; print results.
    CC1310_LAUNCHXL_DIO21 | PIN_INPUT_EN | PIN_PULLUP | PIN_IRQ_NEGEDGE,    //+++ Continuous mode.
    CC1310_LAUNCHXL_DIO22 | PIN_INPUT_EN | PIN_PULLUP | PIN_IRQ_NEGEDGE,    //+++ StartStop mode.
    PIN_TERMINATE
};

PIN_State LedPinState, DInPinState;
Clock_Struct DInClock, RxStandbyClock; //+++ 1) Clock used for debounce logic. 2) Clock for signalling the end of receiving.
Clock_Handle RxStandbyClockH;    //+++ Clock for signalling the end of receiving.
Semaphore_Struct DisplaySemStruct;

void DInClockCb(UArg arg)
{
    //+++ Debounce logic: button still pushed low.
    if (!PIN_getInputValue(ActiveWirePinId))
    {
        PIN_setInterrupt(DInPinH, CC1310_LAUNCHXL_DIO21 | PIN_IRQ_DIS); //+++ Disable further launchs.
        PIN_setInterrupt(DInPinH, CC1310_LAUNCHXL_DIO22 | PIN_IRQ_DIS); //+++ Disable further launchs.
        switch (ActiveWirePinId)
        {
        case CC1310_LAUNCHXL_DIO1:
            //+++ Stop Rx mode.
            if (enMode == CONTINUOUS)
                RF_flushCmd(rfHandle, RF_CMDHANDLE_FLUSH_ALL, 1);
            else if (enMode == START_STOP)
                enMode = END_START_STOP;

            Clock_start(RxStandbyClockH);   //+++ Switch on clock for standby LED.
            Semaphore_post(DisplaySemH);   //+++ Display results.
            break;
        case CC1310_LAUNCHXL_DIO21:
            Clock_stop(RxStandbyClockH);    //+++ Switch off clock for standby LED.
            PIN_setOutputValue(LedPinH, BOARD_PIN_GREEN_LED, 0); //+++ Switch off standby LED.
            StartRxRfCoTf();
            break;
        case CC1310_LAUNCHXL_DIO22:
            Clock_stop(RxStandbyClockH);    //+++ Switch off clock for standby LED.
            PIN_setOutputValue(LedPinH, BOARD_PIN_GREEN_LED, 0); //+++ Switch off standby LED.
            StartRxRfSsTf();
            break;
        default:
            break;
        }
    }
}

void RxStandbyClockCb(UArg arg)
{
    PIN_setOutputValue(LedPinH, BOARD_PIN_GREEN_LED, !PIN_getOutputValue(BOARD_PIN_GREEN_LED)); //+++ Toggle pin to indicate .
}

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    /* Call driver init functions */
    //GPIO_init();
    // I2C_init();
    // SDSPI_init();
    // SPI_init();
    // UART_init();
    // Watchdog_init();

    enMode = NOTHING;
    memset(aucSynchro, 'A', TX_PAYLOAD_LENGTH);

    LedPinH = PIN_open(&LedPinState, LedPinCfg);    //+++ Open pin configuration table.
    if (LedPinH == NULL)
        while(1);

    DInPinH = PIN_open(&DInPinState, DInPinCfg);    //+++ Open pin configuration table.
    if (DInPinH == NULL)
        while(1);

    PIN_registerIntCb(DInPinH, CC1310_LAUNCHXL_DIOCb);//---

    //+++ Semaphore initialization.
    Semaphore_Params DisplaySemParams;
    Semaphore_Params_init(&DisplaySemParams);
    Semaphore_construct(&DisplaySemStruct, 0, &DisplaySemParams);
    DisplaySemH = Semaphore_handle(&DisplaySemStruct);

    //+++ Open Display Driver.
    Display_init();
    Display_Params displayParams;
    Display_Params_init(&displayParams);
    DisplayH = Display_open(Display_Type_UART, NULL);

    StartDisplayTf();

    Clock_Params DInClockParams, RxStandbyClockParams;

    //+++ Construct clock for debounce. Set timeout 50 ms : Clock_tickPeriod is 10 microsec.
    Clock_Params_init(&DInClockParams);
    Clock_construct(&DInClock, DInClockCb, 50 * (1000 / Clock_tickPeriod), &DInClockParams);
    DInClockH = Clock_handle(&DInClock);

    //+++ Construct clock for signalling the end of receiving.
    Clock_Params_init(&RxStandbyClockParams);
    RxStandbyClockParams.period = 10000;
    Clock_construct(&RxStandbyClock, RxStandbyClockCb, 0, &RxStandbyClockParams);
    RxStandbyClockH = Clock_handle(&RxStandbyClock);
    Clock_start(RxStandbyClockH);

    while (1) {
    }
}
