#pragma once

// CCustEdit

class CCustEdit : public CEdit
{
	DECLARE_DYNAMIC(CCustEdit)

public:
	bool bChangeBkgnd;
	CCustEdit();
	virtual ~CCustEdit();
	afx_msg HBRUSH CtlColor(CDC* pDC, UINT /*nCtlColor*/);
protected:
	DECLARE_MESSAGE_MAP()
private:
	COLORREF clrText, clrBkgnd;
	CBrush brBkgnd;
};