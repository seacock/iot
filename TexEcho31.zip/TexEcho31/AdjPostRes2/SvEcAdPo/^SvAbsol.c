/*
 * ^SvAbsol.c
 *
 *  Created on: 13 apr 2019
 *      Author: andre
 */

#include "^SvCommon.h"

#define RX_TIMEOUT_ABSOL 4000 //+++ �s

/***** Variable declarations *****/
static RF_Object rfObject;
static RF_Handle rfHandle;
/* Buffer which contains all Data Entries for receiving data.
 * Pragmas are needed to make sure this buffer is aligned to a 4 byte boundary (requirement from the RF core).
 */
#pragma DATA_ALIGN(rxDataEntryBuffer, 4)
static uint8_t rxDataEntryBuffer[RF_QUEUE_DATA_ENTRY_BUFFER_SIZE(NUM_DATA_ENTRIES, PAYLOAD_LENGTH, NUM_APPENDED_BYTES)];

/* Receive dataQueue for RF Core to fill in data */
static dataQueue_t dataQueue;
static rfc_dataEntryGeneral_t* currentDataEntry;
static uint8_t packetLength;
static uint8_t* packetDataPointer;

static uint8_t txPacket[PAYLOAD_LENGTH];
static uint8_t rxPacket[PAYLOAD_LENGTH];

static volatile bool bRxSuccess;
static uint32_t uiCommunCycles;//---

static uint32_t uiPacketInterval;
extern uint32_t uiMTimeStampCTB; //+++ Value obtained from TimestampRx, used only once to start communications.
extern int64_t llOffsetMs;	//+++ Value obtained from TimestampRx is used only to start communications. Then it is updated to allow for time drift. Positive if slave forestalls master.

struct CheckCall
{
	uint16_t usRx, usTx, usRat; //+++ Check that usRat is about the same as usRx and usTx. If usRat is much more it ruins the flow.
} static volatile stCheckCall;

struct AutoAdj
{
	bool bAdjust;	//+++ Autoadjust.
	uint32_t uiTimestampNow; //+++ Present timestamp sent by Tx and measured at intervals DeltaX, to align Tx and Rx RATs.
	uint32_t uiMirror; //+++ Present timestamp of Rx measured at the same intervals DeltaX of Tx, to align Tx and Rx RATs.
	int64_t llDiffOff;	//+++ Adjustment addendum for ratConfCmp.timeout . It accounts for frequency drift between Tx RAT and Rx RAT.
	int64_t llOffsetOld;	//+++ Previous offset to be compared with present offset.
	int64_t llOffsetNow;	//+++  Present offset.
	float fAdjustmentFactor;	//+++ The smaller the factor, the longer the time of adjustment.
	float fDiffPercent;	//+++ Present value to be compared with fPercentThreshold.
	float fPercentThreshold;	//+++ Not too small or it ruins communication timing with loss of packets.
} static volatile stAutoAdj;

bool bSlaveDelaysOnMaster = true;

#pragma DATA_ALIGN(SvAbsolTaskStack, 8)  //+++ 1-byte alignment on the stack to avoid wasting memory.
static uint8_t SvAbsolTaskStack[STACKSIZE];//---
static bool bExitCycle;

RF_RatConfigCompare ratConfCmp;
RF_RatHandle ratHandle;
static Semaphore_Handle hsemAbsolRx;
#define SLOW 20	//+++ To slow down frequency of flickering of leds.
#define MAX32 4294967296	//+++ 2 pow 32
#define MAX_SPEED 60	//+++ It bears on ratConfCmp.timeout, i.e. frequency of callback. Not more than this or usRat exceeds too much usRx and usTx.

Void SvAbsolTf(UArg arg0, UArg arg1);
static void SvAbRxCb(RF_Handle h, RF_CmdHandle ch, RF_EventMask e);
static void SvAbTxCb(RF_Handle h, RF_CmdHandle ch, RF_EventMask e);

void onRatTriggered(RF_Handle h, RF_RatHandle rh, RF_EventMask e, uint32_t compareCaptureTime);

void StartSvAbsolTf(void)
{
	Semaphore_Params semParams;
	Semaphore_Params_init(&semParams);
	hsemAbsolRx = Semaphore_create(0, &semParams, NULL);
	if (hsemAbsolRx == NULL) //+++ Check if the handle is valid.
		while (1);

	bRxSuccess = false;
	uiPacketInterval = RF_convertMsToRatTicks(200);	//+++ Set packet interval in RAT ticks.

	memset((void*)&stCheckCall, 0, sizeof(stCheckCall));

	stAutoAdj.bAdjust = false;
	stAutoAdj.fAdjustmentFactor = 0.1;	//+++ This value is too big, but the transitory provides the right value.
	stAutoAdj.llOffsetOld = 0;
	stAutoAdj.llDiffOff = 0;
	stAutoAdj.fPercentThreshold = 0.001;	//+++ With 0.00001 it adjusts continuously.

	bExitCycle = false;
	SwitchOffLED();
	uiCommunCycles = 0;

    Task_Params taskParams;
    Task_Params_init(&taskParams);
    taskParams.stackSize = STACKSIZE;
    taskParams.priority = 2;    //+++ More than 1 or is preempted by while (1) in mainThread.
    taskParams.stack = &SvAbsolTaskStack;
    taskParams.priority = 5;

    Task_construct(&SvAbsolTr, SvAbsolTf, &taskParams, NULL);
}

Void SvAbsolTf(UArg arg0, UArg arg1)
{
	RF_Params rfParams;
	RF_Params_init(&rfParams);
	rfParams.nInactivityTimeout = 50;	//---

	if ( RFQueue_defineQueue(&dataQueue, rxDataEntryBuffer, sizeof(rxDataEntryBuffer),
										NUM_DATA_ENTRIES, PAYLOAD_LENGTH + NUM_APPENDED_BYTES))
	{
		/* Failed to allocate space for all data entries */
		PIN_setOutputValue(hDynPin, GREEN_LED, 1);//---
		PIN_setOutputValue(hDynPin, RED_LED, 1);
		while (1);
	}

	/* Modify CMD_PROP_TX and CMD_PROP_RX commands for application needs */
	RF_cmdPropRx.pQueue = &dataQueue;	//+++ Set the Data Entity queue for received data.
	RF_cmdPropRx.rxConf.bAutoFlushIgnored = 1;	//+++ Discard ignored packets from Rx queue.
	RF_cmdPropRx.rxConf.bAutoFlushCrcErr = 1;	//+++ Discard packets with CRC error from Rx queue.
	RF_cmdPropRx.rxConf.bAppendTimestamp = 1;	//+++ Append RX timestamp to the payload. It can be disabled with adequate changes.//---
	RF_cmdPropRx.maxPktLen = PAYLOAD_LENGTH;	//+++ Implement packet length filtering to avoid PROP_ERROR_RXBUF.
	RF_cmdPropRx.pktConf.bRepeatOk = 0;	//+++ End RX operation when a packet is received correctly.
	RF_cmdPropRx.pktConf.bRepeatNok = 0;	//+++ End RX operation when a packet is received incorrectly.
	RF_cmdPropRx.startTrigger.triggerType = TRIG_NOW;
	RF_cmdPropRx.endTrigger.triggerType = TRIG_REL_START;
	RF_cmdPropRx.endTime = RF_convertUsToRatTicks(RX_TIMEOUT_ABSOL);	//+++ It must be slightly longer than the roundtrip time.

	RF_cmdPropTx.pktLen = PAYLOAD_LENGTH;
	RF_cmdPropTx.pPkt = txPacket;
	RF_cmdPropTx.startTrigger.triggerType = TRIG_ABSTIME;
	RF_cmdPropTx.startTrigger.pastTrig = 1;

	rfHandle = RF_open(&rfObject, &RF_prop, (RF_RadioSetup*)&RF_cmdPropRadioDivSetup, &rfParams);	//+++ Request access to the radio.
	RF_postCmd(rfHandle, (RF_Op*)&RF_cmdFs, RF_PriorityNormal, NULL, 0);	//+++ Set the frequency.

	RF_RatConfigCompare_init(&ratConfCmp);
	ratConfCmp.callback = &onRatTriggered;
	ratConfCmp.channel = RF_RatChannelAny;
	/**
	 * Slave refers to common time base from master and no more to its own time.
	 */
	ratConfCmp.timeout = uiMTimeStampCTB + llOffsetMs + 4 * uiPacketInterval;
	ratHandle = RF_ratCompare(rfHandle, &ratConfCmp, NULL);
	if (ratHandle == RF_ALLOC_ERROR)
		while (1);

	stAutoAdj.llOffsetOld = -llOffsetMs;//---
	if (llOffsetMs > 0)
		bSlaveDelaysOnMaster = false;

	do
	{
		Semaphore_pend(hsemAbsolRx, BIOS_WAIT_FOREVER);
		uiCommunCycles++;

		RF_CmdHandle firstCommand = RF_postCmd(rfHandle, (RF_Op*)&RF_cmdPropRx, RF_PriorityNormal, SvAbRxCb, (RF_EventLastCmdDone | RF_EventRxEntryDone));
		RF_pendCmd(rfHandle, firstCommand, RF_EventRxEntryDone);

		RF_cmdPropTx.startTime = stAutoAdj.uiMirror + uiPacketInterval / (2 * MAX_SPEED);	//---
		if (RF_getCurrentTime() > RF_cmdPropTx.startTime)
		{
			static uint8_t ucSlow = 0;
			LedFlicker(&ucSlow, ORANGE_LED);	//+++ Rx and Tx intervals should be roughly the same. Toggle ORANGE_LED.
		}

		RF_CmdHandle lastCommand = RF_postCmd(rfHandle, (RF_Op*)&RF_cmdPropTx, RF_PriorityNormal, SvAbTxCb, RF_EventLastCmdDone);
		RF_pendCmd(rfHandle, lastCommand, RF_EventLastCmdDone);

		if (uiCommunCycles >= 50000)
			bExitCycle = true;
	} while (bExitCycle == false);

	Clock_start(hClock);
	RF_ratDisableChannel(rfHandle, ratHandle);//---
	RF_close(rfHandle);//---
	Semaphore_delete(&hsemAbsolRx);//---
}

static void SvAbRxCb(RF_Handle h, RF_CmdHandle ch, RF_EventMask e)
{
    if (e & RF_EventRxEntryDone)
	{
    	bRxSuccess = true;	//+++ Successful RX.
    	stCheckCall.usRx++;

		static uint8_t ucSlow = 0;
		LedFlicker(&ucSlow, RED_LED);	//+++ Successful RX. Toggle LED.

		currentDataEntry = RFQueue_getDataEntry();	//+++ Get current unhandled data entry.

		/* Handle the packet data, located at &currentDataEntry->data:
		 * - Length is the first byte with the current configuration
		 * - Data starts from the second byte */
		packetLength      = *(uint8_t *)(&(currentDataEntry->data));
		packetDataPointer = (uint8_t *)(&(currentDataEntry->data) + 1);

		memcpy(rxPacket, packetDataPointer, packetLength);	//+++ Copy the payload + status byte to the rxPacket variable.
		memcpy(txPacket, packetDataPointer, packetLength);	//+++ Copy the payload + status byte to the txPacket variable.

		stAutoAdj.uiTimestampNow = 0;
		uint8_t ucCount, ucShift;
		uint8_t *pucTxTimestamp = packetDataPointer + TS2_TS1;
		for (ucCount = 0, ucShift = SHIFT24; ucCount < sizeof(uint32_t); ucCount++, ucShift -= BYTELENGTH)
			stAutoAdj.uiTimestampNow += (*(pucTxTimestamp + ucCount)) << ucShift;

		stAutoAdj.llOffsetNow = (int64_t)stAutoAdj.uiTimestampNow - (int64_t)stAutoAdj.uiMirror;	//+++ Present offset to be compared with previous offset. Cast necessary for possible negative values.

		/**
		 * When RAT of Tx (uiTimestampNow) goes beyond MAX32, it starts anew from 0 and for a certain number of steps it is much
		 * smaller than RAT of Rx (uiMirror). These steps will end when RAT of Rx too goes beyond MAX32. Within these steps uiTimestampNow
		 * is smaller than uiMirror and llOffsetNow must be corrected. This reasoning is for the first branch of if. Similarly for the second
		 * branch of if. This number of steps depends on: offset between Tx-Rx's RATs; duration of transmission i.e. uiPacketInterval.
		 */
		if (bSlaveDelaysOnMaster == true && stAutoAdj.llOffsetNow < 0)
			stAutoAdj.llOffsetNow += MAX32;
		else if (bSlaveDelaysOnMaster == false && stAutoAdj.llOffsetNow > 0)
			stAutoAdj.llOffsetNow -= MAX32;

		stAutoAdj.llDiffOff = (llabs(stAutoAdj.llOffsetNow) - llabs(stAutoAdj.llOffsetOld)) * stAutoAdj.fAdjustmentFactor;

		//+++ If offset is increasing, llDiffOff will be subtracted. If offset is decreasing, llDiffOff will be added.
		if (llabs(stAutoAdj.llOffsetNow) < llabs(stAutoAdj.llOffsetOld))
			stAutoAdj.llDiffOff *= -1;

		int64_t llDiff = llabs(llabs(stAutoAdj.llOffsetNow) - llabs(stAutoAdj.llOffsetOld));
		stAutoAdj.fDiffPercent = (float)llDiff / (float)llabs(stAutoAdj.llOffsetNow);

		if (stAutoAdj.fDiffPercent > stAutoAdj.fPercentThreshold)
		{
			stAutoAdj.bAdjust = true;
			PIN_setOutputValue(hDynPin, CYAN_LED, 1);//---
		}

		stAutoAdj.llOffsetOld = stAutoAdj.llOffsetNow;

		RFQueue_nextEntry();
	}
    else if ((e & RF_EventLastCmdDone) && !(e & RF_EventRxEntryDone))
		if (bRxSuccess == true)
			bRxSuccess = false;	//+++ Last command (RX) completed after RX_ENTRY_DONE within RX_TIMEOUT_ABSOL.
		else
		{
			static uint8_t ucSlow = 0;
			LedFlicker(&ucSlow, CYAN_LED);	//+++ RX timed out. Toggle CYAN_LED.
		}
}

static void SvAbTxCb(RF_Handle h, RF_CmdHandle ch, RF_EventMask e)
{
    if (e & RF_EventLastCmdDone)
    {
    	stCheckCall.usTx++;
    	static uint8_t ucSlow = 0;
    	LedFlicker(&ucSlow, GREEN_LED);	//+++ Successful TX, toggle LED.//---
    }
}

void onRatTriggered(RF_Handle h, RF_RatHandle rh, RF_EventMask e, uint32_t compareCaptureTime)
{
    if (e & RF_EventError)
    {
    	PIN_setOutputValue(hDynPin, YELLOW_LED, 0);
    	while (1);	// RF driver failed to trigger the callback on time.
    }

    stAutoAdj.uiMirror = RF_getCurrentTime();//---

    stCheckCall.usRat++;//+++
	if (stCheckCall.usRat == 5000)
	{
		memset((void*)&stCheckCall, 0, sizeof(stCheckCall));
		PIN_setOutputValue(hDynPin, ORANGE_LED, 0);
	}
	if (stCheckCall.usRat > stCheckCall.usRx + 5 || stCheckCall.usRat > stCheckCall.usTx + 5)
		PIN_setOutputValue(hDynPin, ORANGE_LED, 1);

    //+++ RAT has triggered at compareCaptureTime. Trigger precisely with the same period again. Second condition avoids malfunctioning.
    if (stAutoAdj.bAdjust == true && (uiPacketInterval / MAX_SPEED) > stAutoAdj.llDiffOff)
		ratConfCmp.timeout = (compareCaptureTime - stAutoAdj.llDiffOff + uiPacketInterval / MAX_SPEED);
    else
    	ratConfCmp.timeout = (compareCaptureTime + uiPacketInterval / MAX_SPEED);

    PIN_setOutputValue(hDynPin, CYAN_LED, 0);	//---
    stAutoAdj.bAdjust = false;//---

    rh = RF_ratCompare(h, &ratConfCmp, NULL);
    if (rh == RF_ALLOC_ERROR)
    	while (1);

    Semaphore_post(hsemAbsolRx);
    static uint8_t ucSlow = 0;
    LedFlicker(&ucSlow, YELLOW_LED);	//+++ Successful trigger, toggle LED.
}

void LedFlicker(uint8_t *ucSlowDown, uint32_t uiLed)
{
	(*ucSlowDown)++;
	if (*ucSlowDown == SLOW)
	{
		*ucSlowDown = 0;
		PIN_setOutputValue(hDynPin, uiLed, !PIN_getOutputValue(uiLed));	//+++ Toggle LED.
	}
}
