/*
 * adc.h
 *
 *  Created on: 21 ott 2018
 *      Author: andre
 */

#ifndef ADC_H_
#define ADC_H_

#include <xdc/runtime/Types.h>

#define Board_ADC3  CC1310_LAUNCHXL_ADC3    //+++  CC1310_LAUNCHXL_DIO26_ANALOG order of CC1310_LAUNCHXL_ADCName within adcCC26xxHWAttrs
#define Board_ADC4  CC1310_LAUNCHXL_ADC4    //+++  CC1310_LAUNCHXL_DIO27_ANALOG order of CC1310_LAUNCHXL_ADCName within adcCC26xxHWAttrs

Void AdcTf(UArg arg0, UArg arg1);
void StartAdcTf(void);

#endif /* ADC_H_ */
