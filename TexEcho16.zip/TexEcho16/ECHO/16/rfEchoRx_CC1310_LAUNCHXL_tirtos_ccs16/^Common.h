/*
 * ^Common.h
 *
 *  Created on: 21 gen 2019
 *      Author: andre
 */

#ifndef COMMON_H_
#define COMMON_H_

/***** Includes *****/
/* Standard C Libraries */
#include <stdlib.h>

/* TI Drivers */
#include <ti/drivers/rf/RF.h>
#include <ti/drivers/PIN.h>

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Semaphore.h>

/* Driverlib Header files */
#include DeviceFamily_constructPath(driverlib/rf_prop_mailbox.h)

/* Board Header files */
#include "Board.h"

/* Application Header files */
#include "RFQueue.h"
#include "smartrf_settings/smartrf_settings.h"

/***** Defines *****/
/* Packet RX/TX Configuration */
/* Max length byte the radio will accept */
#define PAYLOAD_LENGTH         30
#define TX_DELAY (uint32_t)(4000000*0.00005f)	//+++ Set Transmit (echo) delay to 50us. Delay value in RAT ticks.
/* NOTE: Only two data entries supported at the moment */
#define NUM_DATA_ENTRIES       2

#define TIMESTAMP 4 //+++ 4 bytes length

/* The Data Entries data field will contain:
 * 1 Header byte (RF_cmdPropRx.rxConf.bIncludeHdr = 0x1)
 * Max 30 payload bytes
 * 1 status byte (RF_cmdPropRx.rxConf.bAppendStatus = 0x1)
 * 4 timestamp bytes (TIMESTAMP preprocessor)*/
#define NUM_APPENDED_BYTES     6	//+++ 1 Header byte + 1 status byte + 4 timestamp bytes

#define STACKSIZE 1024
#define BYTELENGTH 8
#define SHIFT24 ((sizeof(uint32_t) - sizeof(uint8_t)) * BYTELENGTH)
#define TS2_OFFSET 251    //+++ Slave asks offset. Master answers with offset.
#define TS2_SYNCHRO 252    //+++ Slave asks synchronization. Master answers with synchronization.
#define TS2_IDLE 253    //+++ Slave doesn't request anything. Master doesn't process any request.
#define TS2_SLAVE 4    //+++ Byte where slave writes.
#define TS2_MASTER 5    //+++ Byte where master writes.
#define TS2_TS1 6    //+++ Byte where timestamp starts: 4 bytes long.
#define TS2_DP1 10    //+++ Byte where delta processing starts: 4 bytes long. 2 bytes would be enough.
#define START_DATA 14	//+++ Byte where data start.

#define ARRAY_SIZE(array) (sizeof(array)/sizeof(array[0]))

/* Log radio events in the callback */
//#define LOG_RADIO_EVENTS

/***** Prototypes *****/
void TermStatA(RF_EventMask terminationReason, uint32_t cmdStatus);  //+++ RF events and status of commands.
void TermStatB(RF_EventMask terminationReason, uint32_t cmdStatus);  //+++ RF events and status of commands.
void StartTimestampRxTf(void);
void StartAbsolRxTf(void);

/***** Variable declarations *****/
PIN_Handle hDynPin;
bool bDIO21;
Semaphore_Handle hsemTimeStamp;

/* Pin driver handle */
PIN_Handle ledPinHandle;
PIN_State ledPinState;

#endif /* COMMON_H_ */
