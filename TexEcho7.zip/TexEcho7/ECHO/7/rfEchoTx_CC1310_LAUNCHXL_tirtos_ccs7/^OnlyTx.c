/*
 * ^OnlyTx.c
 *
 *  Created on: 03 gen 2019
 *      Author: andre
 */

#include "^Common.h"

static void OnlyTxCb(RF_Handle h, RF_CmdHandle ch, RF_EventMask e);

void OnlyTx(RF_Params rfParams)
{
    uint8_t ucTx = 0;

    rfHandle = RF_open(&rfObject, &RF_prop, (RF_RadioSetup*)&RF_cmdPropRadioDivSetup, &rfParams);   //+++ Request access to the radio.
    RF_postCmd(rfHandle, (RF_Op*)&RF_cmdFs, RF_PriorityNormal, NULL, 0);    //+++ Set the frequency.

    while(ucTx++ < NUM_TX)
    {
        uint32_t curtime = RF_getCurrentTime();  //+++ Set absolute TX time to utilize automatic power management.
        curtime += PACKET_INTERVAL;
        RF_cmdPropTx.startTime = curtime;

        /* Create packet with incrementing sequence number and random payload */
        txPacket[0] = (uint8_t)(seqNumber >> 8);
        txPacket[1] = (uint8_t)(seqNumber++);
        uint8_t i, ucShift = 24;
        for (i = 2; i < 6; i++)
        {
            txPacket[i] = (uint8_t)(curtime >> ucShift);
            ucShift -= 8;
        }

        for (i = 6; i < PAYLOAD_LENGTH; i++)
            txPacket[i] = 122;

        /* Transmit a packet and don't wait for its echo.*/
        RF_EventMask terminationReason = RF_runCmd(rfHandle, (RF_Op*)&RF_cmdPropTx, RF_PriorityNormal, OnlyTxCb, RF_EventLastCmdDone);
        uint32_t cmdStatus = ((volatile RF_Op*)&RF_cmdPropTx)->status;
        TermStat(terminationReason, cmdStatus);
    }
    RF_close(rfHandle);
}

static void OnlyTxCb(RF_Handle h, RF_CmdHandle ch, RF_EventMask e)
{
#ifdef LOG_RADIO_EVENTS
    eventLog[evIndex++ & 0x1F] = e;
#endif// LOG_RADIO_EVENTS

    if(e & RF_EventLastCmdDone)
    {
        //+++ Successful TX. Toggle LED1, clear LED2 to indicate TX.
        PIN_setOutputValue(ledPinHandle, Board_PIN_LED1, !PIN_getOutputValue(Board_PIN_LED1));
        PIN_setOutputValue(ledPinHandle, Board_PIN_LED2, 0);
    }
    else
    {
        /* Error Condition: set both LEDs */
        PIN_setOutputValue(ledPinHandle, Board_PIN_LED1, 1);
        PIN_setOutputValue(ledPinHandle, Board_PIN_LED2, 1);
    }
}
