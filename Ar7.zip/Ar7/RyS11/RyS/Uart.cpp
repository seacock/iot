#include "RyS.h"
#include <iostream>
#include <wiringSerial.h>

using namespace std;

#define CTS 5	//+++ Clear to send input.	wiringPi 5. GPIO pin 18. 
#define RTS 6	//+++ Request to send output. wiringPi 6. GPIO pin 22.
#define RASPBERRY_STRING_LENGTH 15  //+++ Length of string sent from Raspberry and received by Pic24. This value is known by both parties.
#define PIC24_STRING_LENGTH 39  //+++ Length of string sent from Pic24 and received by Raspberry. This value is known by both parties.
#define MAX_CHECK_CYCLES 300000

char a2cSend[10][RASPBERRY_STRING_LENGTH + 1] = { 
	"Monday*********", 
	"Tuesday********", 
	"Wednesday******", 
	"Thursday*******", 
	"Friday*********", 
	"Saturday*******", 
	"Sunday*********", 
	"January********", 
	"February*******", 
	"March**********"
};

string srToLaptop = "!!!???";
string srToWww;
extern string a4sr[4];
//int jjj = 0;

int UartSetup()
{
	pinMode(CTS, INPUT);
	pinMode(RTS, OUTPUT);
	digitalWrite(RTS, HIGH);  	//+++ Stop request to send.
	int iHandle = serialOpen("/dev/ttyAMA0", 9600);
	if (iHandle == -1)
		cout << "bad handle" << endl;

	return iHandle;
}

void UartTxRx(int iHandle, int iFdLas)
{
	int iData, iCharRx, iDataAvail, iNumCycle;

	cout << endl << endl;

	for (int iCount = 0; iCount < 10; iCount++)
	{
		iCharRx = 0;
		iNumCycle = 0;
		iDataAvail = 0;

		digitalWrite(RTS, LOW); 	//+++ Assert request to send.
		
		while(iNumCycle < MAX_CHECK_CYCLES)   
		{
			iDataAvail = serialDataAvail(iHandle);  	//+++ Check number of characters available for reading.
			if(iDataAvail == PIC24_STRING_LENGTH)
				break;
			iNumCycle++;
		}

		cout << "Num of cycles " << iNumCycle << "\tData available " << iDataAvail << endl;

		while (iCharRx < iDataAvail)
		{
			iData = serialGetchar(iHandle);	
			cout << (char)iData;
			srToLaptop += iData;
			iCharRx++;
		}

		digitalWrite(RTS, HIGH); 	//+++ Stop request to send.

		cout << endl << endl;
		
		while (digitalRead(CTS) == 1) ;	//+++ Wait till Pic24 asks for receiving.
		serialPuts(iHandle, a2cSend[iCount]);  	//+++ Send a string to Pic24.
		while(digitalRead(CTS) == 0); //+++ Wait till Pic24 asks for stopping receiving.
	}
			
	WriteToServer(iFdLas, srToLaptop.c_str());
	srToLaptop = "!!!???";
}

void UartClose(int iHandle)
{
	serialClose(iHandle);
}

void UartWww(int iHandle)
{
	int iData, iCharRx, iDataAvail, iNumCycle;
	srToWww = "";

	cout << endl << endl;

	for (int iCount = 0; iCount < 4; iCount++)
	{
		iCharRx = 0;
		iNumCycle = 0;
		iDataAvail = 0;

		digitalWrite(RTS, LOW);  	//+++ Assert request to send.
		
		while(iNumCycle < MAX_CHECK_CYCLES)   
		{
			iDataAvail = serialDataAvail(iHandle);   	//+++ Check number of characters available for reading.
			if(iDataAvail == PIC24_STRING_LENGTH)
				break;
			iNumCycle++;
		}

		cout << "Num of cycles " << iNumCycle << "\tData available " << iDataAvail << endl;

		while (iCharRx < iDataAvail)
		{
			iData = serialGetchar(iHandle);	
			cout << (char)iData;
			srToWww += iData;
			iCharRx++;
		}

		digitalWrite(RTS, HIGH);  	//+++ Stop request to send.

		cout << endl << endl;
		
		while (digitalRead(CTS) == 1) ;	//+++ Wait till Pic24 asks for receiving.
		serialPuts(iHandle, a4sr[iCount].c_str());    	//+++ Send a string to Pic24.
		while(digitalRead(CTS) == 0);  //+++ Wait till Pic24 asks for stopping receiving.
	}







//	jjj = 1;
}