/*
 * RxQRf.c
 *
 *  Created on: 06 nov 2018
 *      Author: andre
 */

/*
 * Copyright (c) 2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/***** Includes *****/
/* Standard C Libraries */
#include <stdlib.h>
#include <stdio.h>/////////////////////////////////sprintf
/* TI Drivers */
#include <ti/drivers/rf/RF.h>
#include <ti/drivers/PIN.h>


/* Driverlib Header files */
#include DeviceFamily_constructPath(driverlib/rf_prop_mailbox.h)

#include DeviceFamily_constructPath(driverlib/rf_data_entry.h)
#include DeviceFamily_constructPath(driverlib/rf_mailbox.h)


/* Board Header files */
#include "Board.h"

/* Application Header files */
#include "smartrf_settings/smartrf_settings.h"

#include <^Common.h>

int iReceivedPacket = 0;

/***** Defines *****/

/* Packet RX Configuration */
#define RX_BUFFER_ENTRIES 5    //+++ Ad libitum.
#define TX_PAYLOAD_LENGTH 41    //+++ Starting point: Tx packet feature.
#define TX_PAYLOAD_FORMAT 2 //+++ Starting point: Tx packet feature.
#define NUM_APPENDED_BYTES 2    //+++ The Data Entries data field will contain: 1 Header byte (RF_cmdPropRx.rxConf.bIncludeHdr = 0x1); Max 30 payload bytes; 1 status byte (RF_cmdPropRx.rxConf.bAppendStatus = 0x1) .
#define DATA_SECTION_SIZE (TX_PAYLOAD_LENGTH + NUM_APPENDED_BYTES) //+++ Must be word-aligned.
#define ENTRY_HEADER_SIZE 7 //+++ Ad libitum.
#define BUFFER_SIZE_BYTES (RX_BUFFER_ENTRIES * (ENTRY_HEADER_SIZE + DATA_SECTION_SIZE))
#pragma DATA_ALIGN(buffer, 4)   //+++ Buffer contains all Data Entries for receiving data. Pragmas needed to make sure buffer is 4 byte aligned (requirement from the RF Core).
uint8_t buffer[BUFFER_SIZE_BYTES];

/***** Prototypes *****/
static void callback(RF_Handle h, RF_CmdHandle ch, RF_EventMask e);
void StartDisplayTf(void);
void Sequence(void);
void Compose(void);

/***** Variable declarations *****/
static RF_Object rfObject;
static RF_Handle rfHandle;

/* Pin driver handle */
static PIN_Handle ledPinHandle;
static PIN_State ledPinState;

/* Receive dataQueue for RF Core to fill in data */

dataQueue_t queue;
rfc_dataEntryGeneral_t* rxEntry;
static uint8_t packet[TX_PAYLOAD_LENGTH]; //+++

//+++ Application pin configuration table: All board LEDs are off.
PIN_Config pinTable[] =
{
    BOARD_PIN_RED_LED | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
    PIN_TERMINATE
};

Void DisplayTf(UArg arg0, UArg arg1);
Task_Struct DisplayTr;
#pragma DATA_ALIGN(DisplayTaskStack, 8)  //+++ 1-byte alignment on the stack to avoid wasting memory.
static uint8_t DisplayTaskStack[STACKSIZE];
Semaphore_Handle DisplaySemH; //+++ Semaphore to block slow display, leaving scheduler to decide.
Semaphore_Struct DisplaySemStruct;
Semaphore_Params DisplaySemParams;
static uint8_t packetTot[TX_PAYLOAD_LENGTH * TX_PAYLOAD_FORMAT * RX_BUFFER_ENTRIES] = "", aucMatchStart[TX_PAYLOAD_FORMAT][TX_PAYLOAD_LENGTH]; //+++
static uint16_t packetTotEx[TX_PAYLOAD_LENGTH * RX_BUFFER_ENTRIES];
int iTwoSteps = 0, iStartBound, iEndBound = 0;

/***** Function definitions *****/

Void RxRadioTf(UArg arg0, UArg arg1)
{
    memset(aucMatchStart[0], 'A', TX_PAYLOAD_LENGTH);
    memset(aucMatchStart[1], 'Z', TX_PAYLOAD_LENGTH);

    //+++ Semaphore initialization.
    Semaphore_Params_init(&DisplaySemParams);
    Semaphore_construct(&DisplaySemStruct, 0, &DisplaySemParams);
    DisplaySemH = Semaphore_handle(&DisplaySemStruct);

    StartDisplayTf();

    RF_Params rfParams;
    RF_Params_init(&rfParams);

    ledPinHandle = PIN_open(&ledPinState, pinTable);    //+++ Open pin configuration table.
    if (ledPinHandle == NULL)
        while(1);

    uint8_t i;
    rfc_dataEntryGeneral_t *item = (rfc_dataEntryGeneral_t*)&buffer[0];
    for (i = 0; i < RX_BUFFER_ENTRIES; i++)
    {
        item->config.type = DATA_ENTRY_TYPE_GEN;    //+++ General Data Entry.
        item->config.lenSz  = 0;    //+++ No length indicator byte in data.
        item->length = DATA_SECTION_SIZE;   //+++ Total length of data field.
        item->status = DATA_ENTRY_PENDING;  //+++ Pending - starting state.

        uint8_t pad = 4 - ((DATA_SECTION_SIZE + ENTRY_HEADER_SIZE) % 4);    //+++ Padding needed for 4-byte alignment.
        item->pNextEntry = ((uint8_t*)item) + ENTRY_HEADER_SIZE + DATA_SECTION_SIZE + pad;

        /* Make circular Last.Next -> First */
        if (i == (RX_BUFFER_ENTRIES - 1))
            item->pNextEntry = buffer;// Close the circle for the last item

        item = (rfc_dataEntryGeneral_t*)item->pNextEntry;
    }

    /* Create Data Entry Queue and configure for circular buffer Data Entries */
    queue.pCurrEntry = &buffer[0];
    queue.pLastEntry = NULL;

    rxEntry = (rfc_dataEntryGeneral_t*)queue.pCurrEntry;    //+++ Initialize read pointer to the first entry.

    /* Modify CMD_PROP_RX command for application needs */
    RF_cmdPropRx.pQueue = &queue;   //+++ Set the Data Entity queue for received data.
    RF_cmdPropRx.rxConf.bAutoFlushIgnored = 1;  //+++ Discard ignored packets from Rx queue.
    RF_cmdPropRx.rxConf.bAutoFlushCrcErr = 1;   //+++ Discard packets with CRC error from Rx queue.

    /* Implement packet length filtering to avoid PROP_ERROR_RXBUF */
    RF_cmdPropRx.maxPktLen = DATA_SECTION_SIZE;
    RF_cmdPropRx.pktConf.bRepeatOk = 1;
    RF_cmdPropRx.pktConf.bRepeatNok = 1;

    rfHandle = RF_open(&rfObject, &RF_prop, (RF_RadioSetup*)&RF_cmdPropRadioDivSetup, &rfParams);   //+++ Request access to the radio.
    RF_postCmd(rfHandle, (RF_Op*)&RF_cmdFs, RF_PriorityNormal, NULL, 0);    //+++ Set the frequency.
    RF_EventMask terminationReason = RF_runCmd(rfHandle, (RF_Op*)&RF_cmdPropRx, RF_PriorityNormal, &callback, RF_EventRxEntryDone); //+++ Enter RX mode.

    switch(terminationReason)
    {
        case RF_EventLastCmdDone:
            //+++ A stand-alone radio operation command or the last radio operation command in a chain finished.
            break;
        case RF_EventCmdCancelled:
            //+++ Command cancelled before it was started; it can be caused by RF_cancelCmd() or RF_flushCmd().
            break;
        case RF_EventCmdAborted:
            //+++ Abrupt command termination caused by RF_cancelCmd() or RF_flushCmd().
            break;
        case RF_EventCmdStopped:
            //+++ Graceful command termination caused by RF_cancelCmd() or RF_flushCmd().
            Display_printf(DisplayH, 0, 0, "Graceful command termination: RF_EventCmdStopped.");
            break;
        default:
            //+++ Uncaught error event.
            while(1);
    }

    uint32_t cmdStatus = ((volatile RF_Op*)&RF_cmdPropRx)->status;
    switch(cmdStatus)
    {
        case PROP_DONE_OK:
            //+++ Packet received with CRC OK.
            break;
        case PROP_DONE_RXERR:
            //+++ Packet received with CRC error.
            break;
        case PROP_DONE_RXTIMEOUT:
            //+++ Observed end trigger while in sync search.
            break;
        case PROP_DONE_BREAK:
            //+++ Observed end trigger while receiving packet when the command is configured with endType set to 1.
            break;
        case PROP_DONE_ENDED:
            //+++ Received packet after having observed the end trigger;
            //+++ if the command is configured with endType set to 0, the end trigger will not terminate an ongoing reception.
            break;
        case PROP_DONE_STOPPED:
            //+++ received CMD_STOP after command started and, if sync found, packet is received.
            break;
        case PROP_DONE_ABORT:
            //+++ Received CMD_ABORT after command started.
            break;
        case PROP_ERROR_RXBUF:
            //+++ No RX buffer large enough for the received data available at the start of a packet.
            break;
        case PROP_ERROR_RXFULL:
            //+++ Out of RX buffer space during reception in a partial read.
            break;
        case PROP_ERROR_PAR:
            //+++ Observed illegal parameter.
            break;
        case PROP_ERROR_NO_SETUP:
            //+++ Command sent without setting up the radio in a supported mode using CMD_PROP_RADIO_SETUP or CMD_RADIO_SETUP.
            break;
        case PROP_ERROR_NO_FS:
            //+++ Command sent without the synthesizer being programmed.
            break;
        case PROP_ERROR_RXOVF:
            //+++ RX overflow observed during operation.
            break;
        default:
            //+++ Uncaught error event - these could come from the pool of states defined in rf_mailbox.h .
            while(1);
    }

    while(1);
}

void callback(RF_Handle h, RF_CmdHandle ch, RF_EventMask e)
{
    if (e & RF_EventRxEntryDone)
    {
        PIN_setOutputValue(ledPinHandle, BOARD_PIN_RED_LED, !PIN_getOutputValue(BOARD_PIN_RED_LED));    //+++ Toggle pin to indicate RX.

        uint8_t packetLength = *(uint8_t*)(&rxEntry->data); //+++ Packet starts with 1 byte length information (lenSz = 1).
        uint8_t* packetDataPointer = (uint8_t*)(&rxEntry->data + sizeof(packetLength)); //+++ Payload follows.
        memcpy(packet, packetDataPointer, packetLength);   //+++ Read the payload from the buffer.
        ((volatile rfc_dataEntryGeneral_t*)rxEntry)->status = DATA_ENTRY_PENDING;   //+++ Mark the entry as being read.
        rxEntry =  ((rfc_dataEntryGeneral_t*)rxEntry->pNextEntry);  //+++ Get the next entry.

        if (iReceivedPacket == 0 && strstr((char*)packet, "AAAAA") != NULL/*(strcmp((char*)packet, (char*)aucMatchStart[0]) == 0)*/)
            Sequence();
        else if (iReceivedPacket == 1 && strstr((char*)packet, "ZZZZZ") != NULL/*(strcmp((char*)packet, (char*)aucMatchStart[1]) == 0)*/)
            Sequence();
        else if (iReceivedPacket >= 2 && iReceivedPacket < RX_BUFFER_ENTRIES * TX_PAYLOAD_FORMAT)
            Sequence();

        if (iReceivedPacket == RX_BUFFER_ENTRIES * TX_PAYLOAD_FORMAT)
//            Semaphore_post(DisplaySemH);   //+++ Post to semaphore.
        {
            packetTot[0] = '\0';    //+++ Avoid going out of bounds.
            iReceivedPacket = 0;
        }
    }
}

Void DisplayTf(UArg arg0, UArg arg1)
{char ooo[10];
uint16_t aaa=64000;
    static int SiRepeat = 0;
    while (1) {
        Semaphore_pend(DisplaySemH, BIOS_WAIT_FOREVER);    //+++ Wait on sem indefinitely.

        int iCount;
//        for (iCount = 0; iCount < TX_PAYLOAD_LENGTH * TX_PAYLOAD_FORMAT * RX_BUFFER_ENTRIES; iCount++)
//            Display_printf(DisplayH, 0, 0, "Received: %d   seq: %d", packetTot[iCount], iCount);

//        Display_printf(DisplayH, 0, 0, "Received: %s", (char*)packetTot);

//        for (iCount = 0; iCount < TX_PAYLOAD_LENGTH * RX_BUFFER_ENTRIES; iCount++)
//                    Display_printf(DisplayH, 0, 0, "Received: %ld   seq: %d", packetTotEx[iCount], iCount);



//        sprintf(ooo, "%lu", packetTotEx[0]);
//        ltoa(packetTotEx[1], ooo);


//           sprintf(ooo, "%lu", 123456);
//           Display_printf(DisplayH, 0, 0, "Received: %s\n", (char*)ooo);
//           sprintf(ooo, "%lu", 654321);
//                      Display_printf(DisplayH, 0, 0, "Received: %s", (char*)ooo);

        Display_printf(DisplayH, 0, 0, "Received");
        Display_printf(DisplayH, 0, 0, "Received: %lu\n", aaa++);

        packetTot[0] = '\0';    //+++ Avoid going out of bounds.
        SiRepeat++;
        if (SiRepeat == 6)
            RF_flushCmd(rfHandle, RF_CMDHANDLE_FLUSH_ALL, 1);

        iReceivedPacket = 0;
    }
}

void StartDisplayTf(void)
{
    Task_Params taskParams;
    Task_Params_init(&taskParams);
    taskParams.stackSize = STACKSIZE;
    taskParams.priority = 4;
    taskParams.stack = &DisplayTaskStack;

    Task_construct(&DisplayTr, DisplayTf, &taskParams, NULL);
}

void Sequence(void)
{
    iReceivedPacket++;
    strcat((char*)packetTot, (char*)packet);

    iTwoSteps++;
    if (iTwoSteps == 2)
    {
        if (iEndBound == TX_PAYLOAD_LENGTH * TX_PAYLOAD_FORMAT * RX_BUFFER_ENTRIES)
            iEndBound = 0;
        iStartBound = iEndBound;
        iEndBound = strlen((char*)packetTot);
//        Display_printf(DisplayH, 0, 0, "iStartBound: %d     iEndBound: %d", iStartBound, iEndBound);
        Compose();
        iTwoSteps = 0;
    }
}

void Compose(void)
{
    uint16_t usUpper, usLower;
    uint32_t uiTot = 0;
    int iBound;
    for (iBound = iStartBound; iBound < iStartBound + TX_PAYLOAD_LENGTH; iBound++)
    {
        usUpper = packetTot[iBound] << 8;
        usLower = packetTot[iBound + TX_PAYLOAD_LENGTH];
//        packetTotEx[iii / 2] = upper + lower;
        uiTot += usUpper + usLower;
//        Display_printf(DisplayH, 0, 0, "packetTotEx: %d", tot);
    }
    uiTot /= TX_PAYLOAD_LENGTH;
    Display_printf(DisplayH, 0, 0, "packetTotEx: %ld", uiTot);
}
