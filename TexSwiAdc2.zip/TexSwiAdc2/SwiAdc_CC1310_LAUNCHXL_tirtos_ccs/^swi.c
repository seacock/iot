/*
 * ^swi.c
 *
 *  Created on: 25 ott 2018
 *      Author: andre
 */

/*
 *  ======== swi0Fxn =======
 */

#include <^common.h>
#include <^swi.h>

uint16_t uiCycle = 0;

Void swi0Fxn(UArg arg0, UArg arg1)
{
    bHigh2 = !bHigh2;
    PIN_setOutputValue(hDynPin, CC1310_LAUNCHXL_DIO12, bHigh2);
    uiCycle++;
    if (uiCycle == 4000) {
        GPIO_toggle(Board_GPIO_LED1);
        sprintf(a2cSwiInfo[0], "\n%d cycles", uiCycle);
        sprintf(a2cSwiInfo[1], "Enter swi0Fxn, a0 = %d, a1 = %d", (Int)arg0, (Int)arg1);
        sprintf(a2cSwiInfo[2], "swi0 trigger = %d", Swi_getTrigger());
        sprintf(a2cSwiInfo[3], "swi0 pri = %d", Swi_getPri(swi0Handle));
        sprintf(a2cSwiInfo[4], "Exit swi0Fxn\n");
        uiCycle = 0;
    }
    bHigh2 = !bHigh2;
    PIN_setOutputValue(hDynPin, CC1310_LAUNCHXL_DIO12, bHigh2);
}

void Startswi0Fxn(void)
{
    Swi_Params swiParams;
    Swi_Params_init(&swiParams);
    swiParams.arg0 = 1;
    swiParams.arg1 = 0;
    swiParams.priority = 2;
    swiParams.trigger = 3;

    Swi_construct(&swi0Struct, (Swi_FuncPtr)swi0Fxn, &swiParams, NULL);
    swi0Handle = Swi_handle(&swi0Struct);
}
