/*
 * ^AbsolCmu.c
 *
 *  Created on: 24 gen 2019
 *      Author: andre
 */

#include "^Common.h"

/* Set packet interval to 1000ms */
//#define PACKET_INTERVAL     (uint32_t)(4000000*1.0f)	//---DDD
#define PACKET_INTERVAL     (uint32_t)(4000000*0.2f)

/***** Variable declarations *****/
static RF_Object rfObject;
static RF_Handle rfHandle;
/* Buffer which contains all Data Entries for receiving data.
 * Pragmas are needed to make sure this buffer is aligned to a 4 byte boundary (requirement from the RF core).
 */
#pragma DATA_ALIGN(rxDataEntryBuffer, 4)
static uint8_t rxDataEntryBuffer[RF_QUEUE_DATA_ENTRY_BUFFER_SIZE(NUM_DATA_ENTRIES, PAYLOAD_LENGTH, NUM_APPENDED_BYTES)];

static rfc_propRxOutput_t rxStatistics;	//+++ Receive Statistics.

/* Receive dataQueue for RF Core to fill in data */
static dataQueue_t dataQueue;
static rfc_dataEntryGeneral_t* currentDataEntry;
static uint8_t packetLength;
static uint8_t* packetDataPointer;

static uint8_t txPacket[PAYLOAD_LENGTH];

#ifdef LOG_RADIO_EVENTS
static volatile RF_EventMask eventLog[32];
static volatile uint8_t evIndex = 0;
#endif // LOG_RADIO_EVENTS

extern uint32_t uiMTimeStampCTB;
extern int64_t llOffsetMs;

#pragma DATA_ALIGN(AbsolCmuTaskStack, 8)  //+++ 1-byte alignment on the stack to avoid wasting memory.
static uint8_t AbsolCmuTaskStack[STACKSIZE];
Task_Struct AbsolCmuTr;

RF_RatConfigCompare ratConfCmp;
RF_RatHandle ratHandle;
static Semaphore_Handle hsemAbsolCmu;
static uint16_t ooo = 0;
static uint16_t seqNumber = 1;

Void AbsolCmuTf(UArg arg0, UArg arg1);
static void AbsolCmuCb(RF_Handle h, RF_CmdHandle ch, RF_EventMask e);

void onRatTriggered(RF_Handle h, RF_RatHandle rh, RF_EventMask e, uint32_t compareCaptureTime);

void StartAbsolCmuTf(void)
{
	Semaphore_Params semParams;
	Semaphore_Params_init(&semParams);
	hsemAbsolCmu = Semaphore_create(0, &semParams, NULL);
	if (hsemAbsolCmu == NULL) //+++ Check if the handle is valid.
		while(1);

    Task_Params taskParams;
    Task_Params_init(&taskParams);
    taskParams.stackSize = STACKSIZE;
    taskParams.priority = 2;    //+++ More than 1 or is preempted by while (1) in mainThread.
    taskParams.stack = &AbsolCmuTaskStack;

    Task_construct(&AbsolCmuTr, AbsolCmuTf, &taskParams, NULL);
}

Void AbsolCmuTf(UArg arg0, UArg arg1)
{
	RF_Params rfParams;
	RF_Params_init(&rfParams);

	if( RFQueue_defineQueue(&dataQueue, rxDataEntryBuffer, sizeof(rxDataEntryBuffer),
										NUM_DATA_ENTRIES, PAYLOAD_LENGTH + NUM_APPENDED_BYTES))
	{
		/* Failed to allocate space for all data entries */
		PIN_setOutputValue(ledPinHandle, Board_PIN_LED1, 1);
		PIN_setOutputValue(ledPinHandle, Board_PIN_LED2, 1);
		while(1);
	}

	/* Modify CMD_PROP_TX and CMD_PROP_RX commands for application needs */
	RF_cmdPropRx.pQueue = &dataQueue;	//+++ Set the Data Entity queue for received data.
	RF_cmdPropRx.rxConf.bAutoFlushIgnored = 1;	//+++ Discard ignored packets from Rx queue.
	RF_cmdPropRx.rxConf.bAutoFlushCrcErr = 1;	//+++ Discard packets with CRC error from Rx queue.
	RF_cmdPropRx.rxConf.bAppendTimestamp = 1;	//+++ Append RX timestamp to the payload. It can be disabled with adequate changes.//---
	RF_cmdPropRx.maxPktLen = PAYLOAD_LENGTH;	//+++ Implement packet length filtering to avoid PROP_ERROR_RXBUF.
	RF_cmdPropRx.pktConf.bRepeatOk = 0;	//+++ End RX operation when a packet is received correctly.
	RF_cmdPropRx.pktConf.bRepeatNok = 1;	//+++ Move on to the next command in the chain.
	RF_cmdPropRx.startTrigger.triggerType = TRIG_ABSTIME;	//+++ Set absolute TX time to utilize automatic power management.
	RF_cmdPropRx.startTrigger.pastTrig = 1;
	RF_cmdPropRx.startTime = 0;	//--- No timeout for now.//---
	RF_cmdPropRx.pNextOp = (rfc_radioOp_t *)&RF_cmdPropTx;
	RF_cmdPropRx.condition.rule = COND_STOP_ON_FALSE;	//+++ Only run the TX command if RX is successful.
	RF_cmdPropRx.pOutput = (uint8_t *)&rxStatistics;

	RF_cmdPropTx.pktLen = PAYLOAD_LENGTH;
	RF_cmdPropTx.pPkt = txPacket;
	RF_cmdPropTx.startTrigger.triggerType = TRIG_REL_PREVEND;
	RF_cmdPropTx.startTime = TX_DELAY;

	rfHandle = RF_open(&rfObject, &RF_prop, (RF_RadioSetup*)&RF_cmdPropRadioDivSetup, &rfParams);	//+++ Request access to the radio.
	RF_postCmd(rfHandle, (RF_Op*)&RF_cmdFs, RF_PriorityNormal, NULL, 0);	//+++ Set the frequency.

	RF_RatConfigCompare_init(&ratConfCmp);
	ratConfCmp.callback = &onRatTriggered;
	ratConfCmp.channel = RF_RatChannelAny;
	/**
	 * Slave refers to common time base from master and no more to its own time. For more safety slave starts listening
	 * PACKET_INTERVAL / 10 before due time.
	 */
	ratConfCmp.timeout = uiMTimeStampCTB + llOffsetMs + PACKET_INTERVAL - PACKET_INTERVAL / 10;
	ratHandle = RF_ratCompare(rfHandle, &ratConfCmp, NULL);
	if (ratHandle == RF_ALLOC_ERROR)
		while(1);

	while(1)
	{
		Semaphore_pend(hsemAbsolCmu, BIOS_WAIT_FOREVER);
		RF_cmdPropRx.startTime = 0;//ratConfCmp.timeout + 10000; //--- Delay a little to avoid past trigger. No timeout for now...

		/* Wait for a packet
		 * - When the first of the two chained commands (RX) completes, the RF_EventCmdDone and RF_EventRxEntryDone events are
		 * raised on a successful packet reception, and then the next command in the chain (TX) is run.
		 * - If the RF core runs into an issue after receiving the packet incorrectly only the RF_EventCmdDone event is raised;
		 * this is an error condition.
		 * - If the RF core successfully echos the received packet the RF core should raise the RF_EventLastCmdDone event.
		 */
		RF_EventMask terminationReason = RF_runCmd(rfHandle, (RF_Op*)&RF_cmdPropRx, RF_PriorityNormal,
														AbsolCmuCb, (RF_EventRxEntryDone | RF_EventLastCmdDone));

		uint32_t cmdStatus = ((volatile RF_Op*)&RF_cmdPropRx)->status;
		TermStat(terminationReason, cmdStatus);
	}
//	Semaphore_delete(&hsemAbsolCmu);//---
}

static void AbsolCmuCb(RF_Handle h, RF_CmdHandle ch, RF_EventMask e)
{
#ifdef LOG_RADIO_EVENTS
    eventLog[evIndex++ & 0x1F] = e;
#endif// LOG_RADIO_EVENTS

    if (e & RF_EventRxEntryDone)
    {
        //+++ Successful RX. Toggle LED2, clear LED1 to indicate RX.
        PIN_setOutputValue(ledPinHandle, Board_PIN_LED1, 0);
        PIN_setOutputValue(ledPinHandle, Board_PIN_LED2, !PIN_getOutputValue(Board_PIN_LED2));

        currentDataEntry = RFQueue_getDataEntry();	//+++ Get current unhandled data entry.

        /* Handle the packet data, located at &currentDataEntry->data:
         * - Length is the first byte with the current configuration
         * - Data starts from the second byte */
        packetLength      = *(uint8_t *)(&(currentDataEntry->data));
        packetDataPointer = (uint8_t *)(&(currentDataEntry->data) + 1);

        //+++ Copy the payload + status byte to the rxPacket variable, and then over to the txPacket.
        memcpy(txPacket, packetDataPointer, packetLength);
        /* Create packet with incrementing sequence number and payload */
		txPacket[2] = (uint8_t)(seqNumber >> 8);
		txPacket[3] = (uint8_t)(seqNumber++);

		uint16_t seqNumberTx = (txPacket[0] << 8) + txPacket[1];

        ooo++;//---
        if (ooo == 1200)// && seqNumberTx == seqNumber - 1)
        	ooo = 1200;

        RFQueue_nextEntry();
    }
    else if (e & RF_EventLastCmdDone)
    {
        //+++ Successful Echo (TX). Toggle LED2, clear LED1 to indicate RX.
        PIN_setOutputValue(ledPinHandle, Board_PIN_LED1, 0);
        PIN_setOutputValue(ledPinHandle, Board_PIN_LED2, !PIN_getOutputValue(Board_PIN_LED2));
    }
    else // any uncaught event
    {
        /* Error Condition: set LED1, clear LED2 */
        PIN_setOutputValue(ledPinHandle, Board_PIN_LED1, 1);
        PIN_setOutputValue(ledPinHandle, Board_PIN_LED2, 0);
    }
}

void onRatTriggered(RF_Handle h, RF_RatHandle rh, RF_EventMask e, uint32_t compareCaptureTime)
{
    if (e & RF_EventError)
    {
        // RF driver failed to trigger the callback on time.
    }

    //+++ RAT has triggered at compareCaptureTime. Trigger precisely with the same period again.
	ratConfCmp.timeout = compareCaptureTime + PACKET_INTERVAL/* - PACKET_INTERVAL / 10*/;//---
    rh = RF_ratCompare(h, &ratConfCmp, NULL);
    if (rh == RF_ALLOC_ERROR)
    	while(1);

    Semaphore_post(hsemAbsolCmu);
    PIN_setOutputValue(ledPinHandle, Board_PIN_LED1, !PIN_getOutputValue(Board_PIN_LED1));
}
