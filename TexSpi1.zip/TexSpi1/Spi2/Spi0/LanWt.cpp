#include "SharA.h"
#include "ColorText.h"
#include "Aff.h"
#include "Ry.h"
#include "Spi.h"
#include <wiringPi.h>
extern int iReadSlaveStatus;

void* LanTp(void *arg)
{
	CColorText coltGreen(CColorText::GREEN);	
	CRy::ThreadInfo *pstThrInf = (CRy::ThreadInfo*)arg;
	CAff *pAff = pstThrInf->pstUtil->pAff;
	CRy *pRy = pstThrInf->pstUtil->pRy;
	CSpi *pSpi = pstThrInf->pstUtil->pSpi;

	int iRes;
	switch (pstThrInf->iThreadNum)
	{
	case CRy::TL_One:
		iRes = sched_setaffinity(0, sizeof(CRy::ThreadInfo::stSet1), &CRy::ThreadInfo::stSet1);
		break;
	case CRy::TL_Two:
		iRes = sched_setaffinity(0, sizeof(CRy::ThreadInfo::stSet2), &CRy::ThreadInfo::stSet2);
		break;
	}

	if (iRes == -1)
		handle_error_en(iRes, "sched_setaffinity");

#ifdef _BRIEF_
	pAff->DisplayThreadSchedAttr(pstThrInf->pcInfoArg);
	cpu_set_t stSet;
	sched_getaffinity(0, sizeof(stSet), &stSet);
	for (int iCount = 0; iCount < 4; iCount++)
		if (CPU_ISSET_S(iCount, sizeof(stSet), &stSet))
		{
			coltGreen.ss << "affinity: " << iCount << endl;
			cout << coltGreen;
		}
#endif // _BRIEF_
	
	//+++ Send data to the server.
	if(pstThrInf->iThreadNum == CRy::TL_One)
	{
		timespec stTimeNano;
		stTimeNano.tv_sec = 0;
		stTimeNano.tv_nsec = (100);  	//+++  us
		digitalWrite(GPIO3, HIGH);
		while (1)
		{
			if (((bool)iReadSlaveStatus) == false)
			{
				pSpi->SpiMaster();      	//+++ 
				iReadSlaveStatus = ((int)true);
			}
			
			clock_nanosleep(CLOCK_REALTIME, 0, &stTimeNano, NULL); 	//+++ It can't be taken away or prints bad characters.
		}		
	}

	return SUCCESS;
}