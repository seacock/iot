#pragma once

#include <iostream>	//+++ Includes also pthread.h .//??????

using namespace std; 

class CUart
{
public:
	int iUartHandle;
	enum State { STATE_NeutralUart, STATE_Lan, STATE_WebServUart };	//+++ To awake another thread or to procede with the present thread; to block the other thread; to block the other thread.
	struct Sync	//+++ Synchronization between web and local threads.
	{
		State enStateUart;  	//+++ Values for which threads WebServUartTp and LanTp wait or are woken up.
		pthread_cond_t condLan;  	//+++ Condition on which LanTp thread waits till WebServUartTp wakes it up.
		pthread_cond_t condWebServUart;  	//+++ Condition on which WebServUartTp thread waits till LanTp wakes it up.
		pthread_mutex_t mutexUart;  	//+++ Mutex called by WebServUartTp and LanTp threads to manage condWebServUart, condLan and enStateUart. Only one thread owns it at a time.
	} stSync;	
	
	string asrLocal[10] = { 
		"Monday*********", 
		"Tuesday********", 
		"Wednesday******", 
		"Thursday*******", 
		"Friday*********", 
		"Saturday*******", 
		"Sunday*********", 
		"January********", 
		"February*******", 
		"March**********"
	};
	string asrWeb[4];
	string srRecvUart;
private:
	const int kiCts = 5;	//+++ Clear to send input.	wiringPi 5. GPIO pin 18. 
	const int kiRts = 6;	//+++ Request to send output. wiringPi 6. GPIO pin 22.
	const int kiRaspberryStringLength = 15;	//+++ Length of string sent from Raspberry and received by Pic24. This value is known by both parties.//??????
	const int kiPic24StringLength = 39;	//+++ Length of string sent from Pic24 and received by Raspberry. This value is known by both parties.
public:
	CUart();
	~CUart();
	int UartSetup(); //??????
	void UartClose(int iHandle);  //??????
	void UartPic(int iHandle, string *psrSend, int iSizeSend, int iFdLas = -1);      	//??????
};