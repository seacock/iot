#pragma once

#include "SharA.h"

class CI2c
{
public:
	enum State { STATE_Off, STATE_On };	//+++ Values on which TEMPORARY thread waits till I2cServTp wakes it up.
	//+++ Information about incoming laptop ASUS client.
	struct Sync
	{
		static int SiFdI2c;  	//+++ File descriptor for I2C device.
		State enStateI2c;  	//+++ Values on which TEMPORARY thread waits till I2cServTp wakes it up.
		pthread_cond_t condI2c;  	//+++ Condition on which TEMPORARY thread waits till I2cServTp wakes it up.
		pthread_mutex_t mutexI2c;  	//+++ Mutex called by TEMPORARY and I2cServTp threads to manage ScondI2c and SenStateI2c. Only one thread owns it at a time.
	} stSync;

	CI2c();
	~CI2c();
	int I2cMaster(int iFdI2cM, unsigned char ucNumber, int iFdLas);	//+++ Communicate with MicroChip Pic24 via I2c and send back values to laptop ASUS. Depending on value of iFdLas, writing can be from client or from server.
};