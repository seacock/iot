/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * @author andre
 */
public class TimerJ {
    public int iSec = 0;
    int iPeriod;
    public int iMax;
    public TimerJ(int iPeriod, int iMax)
    {
        this.iPeriod = iPeriod;
        this.iMax = iMax;
    }
    
    Timer timer = new Timer();
    TimerTask timerTask = new TimerTask(){
        @Override
        public void run()
        {
            iSec++;
            if (iSec > iMax)
                iSec = 0;
        }
    };
    
    public void Start(){
        timer.scheduleAtFixedRate(timerTask, 100, iPeriod);
    }
}