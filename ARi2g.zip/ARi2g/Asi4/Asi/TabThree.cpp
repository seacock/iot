// TabThree.cpp : implementation file
//

#include "stdafx.h"
#include "Asi.h"
#include "TabThree.h"
#include "afxdialogex.h"

// CTabThree dialog

IMPLEMENT_DYNAMIC(CTabThree, CDialogEx)

CTabThree::CTabThree(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_TAB_THREE, pParent)
{
}

CTabThree::~CTabThree()
{
}

void CTabThree::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_ED_THR2M, jedThr2M);
	DDX_Control(pDX, IDC_ED_THR2V, jedThr2V);
	DDX_Control(pDX, IDC_PGS_THR2, jpgsThr2);
	DDX_Control(pDX, IDC_ED_THR3M, jedThr3M);
	DDX_Control(pDX, IDC_ED_THR3V, jedThr3V);
	DDX_Control(pDX, IDC_PGS_THR3, jpgsThr3);
}

BEGIN_MESSAGE_MAP(CTabThree, CDialogEx)
	ON_REGISTERED_MESSAGE(RG_WM_ED_THR2M, &CTabThree::OnEdThr2M)
	ON_REGISTERED_MESSAGE(RG_WM_ED_THR2V, &CTabThree::OnEdThr2V)
	ON_REGISTERED_MESSAGE(RG_WM_PGS_THR2, &CTabThree::OnPgsThr2)
	ON_REGISTERED_MESSAGE(RG_WM_ED_THR3M, &CTabThree::OnEdThr3M)
	ON_REGISTERED_MESSAGE(RG_WM_ED_THR3V, &CTabThree::OnEdThr3V)
	ON_REGISTERED_MESSAGE(RG_WM_PGS_THR3, &CTabThree::OnPgsThr3)
END_MESSAGE_MAP()

// CTabThree message handlers

BOOL CTabThree::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  Add extra initialization here
	jpgsThr2.SetRange32(0, +65535);
	jpgsThr3.SetRange32(0, +10000);
	jpgsThr2.SetPos(0);
	jpgsThr3.SetPos(0);

	SetWindowTheme(jpgsThr2.m_hWnd, L" ", L" ");
	SetWindowTheme(jpgsThr3.m_hWnd, L" ", L" ");
	jpgsThr2.SetBarColor(RGB(0, 100, 255));
	jpgsThr3.SetBarColor(RGB(0, 100, 255));

	RECT rect = { NULL };
	jpgsThr2.GetWindowRect(&rect);
	::MapWindowPoints(HWND_DESKTOP, m_hWnd, (LPPOINT)&rect, 2);
	jtxtPgsP.Create(_T(""), WS_CHILD | WS_VISIBLE | WS_BORDER, CRect(rect), this);
	jtxtPgsP.SetWindowPos(&wndBottom, rect.left - 1, rect.top - 1, 0, 0, SWP_NOSIZE);
	jpgsThr3.GetWindowRect(&rect);
	::MapWindowPoints(HWND_DESKTOP, m_hWnd, (LPPOINT)&rect, 2);
	jtxtPgsT.Create(_T(""), WS_CHILD | WS_VISIBLE | WS_BORDER, CRect(rect), this);
	jtxtPgsT.SetWindowPos(&wndBottom, rect.left - 1, rect.top - 1, 0, 0, SWP_NOSIZE);

	return TRUE;  // return TRUE unless you set the focus to a control
				  // EXCEPTION: OCX Property Pages should return FALSE
}

LRESULT CTabThree::OnEdThr2M(WPARAM wParam, LPARAM lParam)
{
	wsrMtrThr2 += (const wchar_t*)wParam + (wstring)L"\r\n";
	jedThr2M.SetWindowTextW(wsrMtrThr2.c_str());
	return NO_ERROR;
}

LRESULT CTabThree::OnEdThr3M(WPARAM wParam, LPARAM lParam)
{
	wsrMtrThr3 += (const wchar_t*)wParam + (wstring)L"\r\n";
	jedThr3M.SetWindowTextW(wsrMtrThr3.c_str());
	return NO_ERROR;
}

LRESULT CTabThree::OnEdThr2V(WPARAM wParam, LPARAM lParam)
{
	EdThrV((const wchar_t*)wParam, L"Potentiometer", &jedThr2V);
	return NO_ERROR;
}

LRESULT CTabThree::OnEdThr3V(WPARAM wParam, LPARAM lParam)
{
	EdThrV((const wchar_t*)wParam, L"Thermometer", &jedThr3V);
	return NO_ERROR;
}

void CTabThree::EdThrV(wstring wsrMix, wstring wsrName, CEdit *pjed)
{
	if (wsrMix.find(wsrName) != string::npos)
	{
		wsrMix = wsrMix.substr(wsrName.length(), wsrMix.length() - wsrName.length());
		pjed->SetWindowTextW(wsrMix.c_str());
	}
}

LRESULT CTabThree::OnPgsThr2(WPARAM wParam, LPARAM lParam)
{
	PgsThr((const wchar_t*)wParam, L"Potentiometer", &jpgsThr2);
	return NO_ERROR;
}

LRESULT CTabThree::OnPgsThr3(WPARAM wParam, LPARAM lParam)
{
	PgsThr((const wchar_t*)wParam, L"Thermometer", &jpgsThr3);
	return NO_ERROR;
}

void  CTabThree::PgsThr(wstring wsrMix, wstring wsrName, CProgressCtrl *pjpgs)
{
	if (wsrMix.find(wsrName) != string::npos)
	{
		wsrMix = wsrMix.substr(wsrName.length(), wsrMix.length() - wsrName.length());
		string str8CheckNum = WsToStUtf8(wsrMix);
		pjpgs->SetPos(atoi(str8CheckNum.c_str()));
	}
}