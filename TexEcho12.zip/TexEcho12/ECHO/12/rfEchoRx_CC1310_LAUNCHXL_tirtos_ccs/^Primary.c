/*
 * ^Primary.c
 *
 *  Created on: 21 gen 2019
 *      Author: andre
 */

#include "^Common.h"

/*
 * Application LED pin configuration table:
 *   - All LEDs board LEDs are off.
 */
PIN_Config pinTable[] =
{
#if defined(Board_CC1352R1_LAUNCHXL)
 Board_DIO30_RFSW | PIN_GPIO_OUTPUT_EN | PIN_GPIO_HIGH | PIN_PUSHPULL | PIN_DRVSTR_MAX,
#endif
#if defined(Board_CC1350_LAUNCHXL)
 Board_DIO30_SWPWR | PIN_GPIO_OUTPUT_EN | PIN_GPIO_HIGH | PIN_PUSHPULL | PIN_DRVSTR_MAX,
#endif
 Board_PIN_LED1 | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
 Board_PIN_LED2 | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
 PIN_TERMINATE
};

/***** Function definitions *****/

void *mainThread(void *arg0)
{
	/* Open LED pins */
	ledPinHandle = PIN_open(&ledPinState, pinTable);
	if (ledPinHandle == NULL)
		while(1);

	Semaphore_Params semParams;
	Semaphore_Params_init(&semParams);
	hsemTimeStamp = Semaphore_create(0, &semParams, NULL);
	if (hsemTimeStamp == NULL) //+++ Check if the handle is valid.
		while(1);

	StartTimestampRxTf();
	Semaphore_pend(hsemTimeStamp, BIOS_WAIT_FOREVER);
	Semaphore_delete(&hsemTimeStamp);
	StartAbsolCmuTf();

	return 0;
}
