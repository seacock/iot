#include "stdafx.h"
#include "Asi.h"

#define PORT 13   //+++ The port on which to listen for incoming data: daytime.
#define SOCK_RCVTIME 1000	//+++ ms More time than Raspberry to allow for Raspberry to be launched and work.
#define BROAD_ATTEMPTS 30

int MsgWsaB(wstring wsrMsg, CTabOne *pTabOne, bool bCleanup, SOCKET Socket = INVALID_SOCKET);	//+++ Dispatch msg, see to socket closure and WSA cleanup.

DWORD WINAPI T_Broad(LPVOID lpParam)
{
	theApp.ThrAffinity(13);
	CTabOne *pTabOne = ((Hook*)lpParam)->pTabOne;
	SOCKET uiSocket;
	sockaddr_in stSaiServer, stSaiOther;
	int iLenOther = sizeof(stSaiOther);
	WSADATA wsa;

	//+++ Initialise winsock.
	MsgWsaB(L"\nInitialising Winsock...", pTabOne, false);
	if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
		return MsgWsaB(L"Failed. Error Code: " + to_wstring(WSAGetLastError()), pTabOne, false);
	MsgWsaB(L"Initialised.\n", pTabOne, false);

	//+++ Create a socket.
	if ((uiSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == INVALID_SOCKET)
		return MsgWsaB(L"Could not create socket. Error Code: " + to_wstring(WSAGetLastError()), pTabOne, true);
	MsgWsaB(L"Socket created.\n", pTabOne, false);

	//+++ Prepare the sockaddr_in structure
	stSaiServer.sin_family = AF_INET;
	stSaiServer.sin_addr.s_addr = INADDR_ANY;
	stSaiServer.sin_port = htons(PORT);	//+++ It must be the same as the client's port. Then client's port stSaiOther.sin_port for received/sent data doesn't necessarily match this one. But then stSaiOther.sin_port must be used for received/sent data.

	//+++ Bind socket to port.
	if (bind(uiSocket, (sockaddr*)&stSaiServer, sizeof(stSaiServer)) == SOCKET_ERROR)
		return MsgWsaB(L"bind() failed. Error Code: " + to_wstring(WSAGetLastError()), pTabOne, true, uiSocket);
	MsgWsaB(L"Bind done.\nWaiting for data...\n", pTabOne, false);	//+++ Keep listening for data.

	char acRecvFrom[BUFLEN];
	memset(acRecvFrom, '\0', BUFLEN);	//+++ Clear the buffer by filling null, it might have previously received data.

	DWORD dwOptVal;
	int iOptLen = sizeof(dwOptVal), iNumAtt;

	if (getsockopt(uiSocket, SOL_SOCKET, SO_RCVTIMEO, (char*)&dwOptVal, &iOptLen) == SOCKET_ERROR)
		return MsgWsaB(L"getsockopt() for SO_RCVTIMEO failed. Error Code: " + to_wstring(WSAGetLastError()), pTabOne, true, uiSocket);
	MsgWsaB(L"SO_RCVTIMEO Value: " + to_wstring(dwOptVal) + (wstring)L"ms\r\n", pTabOne, false);

	dwOptVal = SOCK_RCVTIME;

	if (setsockopt(uiSocket, SOL_SOCKET, SO_RCVTIMEO, (char*)&dwOptVal, iOptLen) == SOCKET_ERROR)
		return MsgWsaB(L"setsockopt() for SO_RCVTIMEO failed. Error Code: " + to_wstring(WSAGetLastError()), pTabOne, true, uiSocket);
	MsgWsaB(L"Set SO_RCVTIMEO: ON\r\n", pTabOne, false);

	if (getsockopt(uiSocket, SOL_SOCKET, SO_RCVTIMEO, (char*)&dwOptVal, &iOptLen) == SOCKET_ERROR)
		return MsgWsaB(L"getsockopt() for SO_RCVTIMEO failed. Error Code: " + to_wstring(WSAGetLastError()), pTabOne, true, uiSocket);
	MsgWsaB(L"SO_RCVTIMEO Value: " + to_wstring(dwOptVal) + (wstring)L"ms\r\n", pTabOne, false);
	
	for (iNumAtt = 0; iNumAtt < BROAD_ATTEMPTS; iNumAtt++)
	{
		if (recvfrom(uiSocket, acRecvFrom, BUFLEN, 0, (sockaddr*)&stSaiOther, &iLenOther) == SOCKET_ERROR)	//+++ Try to receive broadcast message from Raspberry.This is a blocking call with timeout. It must use BUFLEN as buffer length is 0.
		{
			if (iNumAtt == BROAD_ATTEMPTS - 1)
				return MsgWsaB(L"recvfrom() failed with error code: " + to_wstring(WSAGetLastError()), pTabOne, true, uiSocket);
			else
				continue;
		}			
		
		if (strstr(acRecvFrom, "RaspberryPi is broadcasting.") != NULL)	//+++ Greeting from RaspberryPi to match.
			break;
		else
		{
			if (iNumAtt == BROAD_ATTEMPTS - 1)
				return MsgWsaB(L"recvfrom() failed with error code: " + to_wstring(WSAGetLastError()), pTabOne, true, uiSocket);
		}			
	}

	//+++ Print details of the client/peer and the data received. Store server IP.
	wchar_t awcBuff[BUFLEN];
	MsgWsaB(L"Received packet from " + (wstring)InetNtop(AF_INET, &stSaiOther.sin_addr, awcBuff, sizeof(awcBuff)) + L":" + to_wstring(ntohs(stSaiOther.sin_port)) + L" (on local port )" + to_wstring(PORT) + (wstring)L"\r\n", pTabOne, false);
	MsgWsaB(L"N� " + to_wstring(iNumAtt + 1) + L" attempts.   Data: " + StToWsUtf8((string)acRecvFrom), pTabOne, false);
	wstring wsrTemp(awcBuff);
	strcpy_s(((Hook*)lpParam)->stServerI2c.acIP, sizeof(((Hook*)lpParam)->stServerI2c.acIP), WsToStUtf8(wsrTemp).c_str());

	//+++ Now reply the client with local data.
	char acHostName[BUFLEN];
	gethostname(acHostName, BUFLEN);
	string srSendTo("Laptop ASUS answering to Raspberry's broadcast.*");
	srSendTo += acHostName + (string)"*" + pTabOne->srPortNumber.c_str() + (string)"*";
	
	if (sendto(uiSocket, srSendTo.c_str(), (int)srSendTo.length(), 0, (sockaddr*)&stSaiOther, iLenOther) == SOCKET_ERROR)
		return MsgWsaB(L"sendto() failed with error code: " + to_wstring(WSAGetLastError()), pTabOne, true, uiSocket);

	closesocket(uiSocket);
	WSACleanup();

	return NO_ERROR;
}

int MsgWsaB(wstring wsrMsg, CTabOne *pTabOne, bool bCleanup, SOCKET Socket)
{
	wstring wsrMsgWhich = L"T_Broad " + wsrMsg;
	pTabOne->SendMessageW(RG_WM_ED_SOC_T, (WPARAM)wsrMsgWhich.c_str());
	if (Socket != INVALID_SOCKET)
		closesocket(Socket);

	if (bCleanup == true)
		WSACleanup();

	return ERROR_COMM;
}

DWORD WINAPI T_Shell(LPVOID lpParam)
{
	//UINT WINAPI uiRes = WinExec("plink -ssh root@raspberrypi -pw andrea /tmp/VisualGDB/e/VisualStudio2017/Projects/RaspberryPi2/RyS1/RyS/Debug/RyS", SW_HIDE);
	
	
	//UINT WINAPI uiRes = WinExec("powershell -command \"New-SSHSession -ComputerName \"192.168.178.49\" -Credential(Get-Credential root) > F:\\aaa.txt\"", SW_SHOW);
		
	//UINT WINAPI uiRes = WinExec("powershell -command \"Get-Process | Out-File F:\test.txt\"", SW_SHOW);
	//ShellExecute(NULL, L"open", L"calc.exe", NULL, NULL, SW_SHOWNORMAL);
	//ShellExecute(NULL, L"open", L"powershell.exe", L"Get-Process | Out-File F:\\test.txt", NULL, SW_SHOWNORMAL);
	//ShellExecute(NULL, L"open", L"powershell.exe", L"New-SSHSession -ComputerName \"192.168.178.49\" -Credential(Get-Credential root) | Out-File F:\\test.txt", NULL, SW_SHOWNORMAL);
	//ShellExecute(NULL, L"open", L"powershell.exe", L"New-SSHSession -ComputerName \"192.168.178.49\" -Credential(Get-Credential) | Out-File F:\\test.txt", NULL, SW_HIDE);
	
	//ShellExecute(NULL, L"open", L"powershell.exe", L"New-SSHSession -ComputerName \"192.168.178.49\" -Credential(Get-Credential) ; Invoke-SSHCommand -Index 0 -Command \"uname - a\"", NULL, SW_SHOWNORMAL);
	//ShellExecute(NULL, L"open", L"powershell.exe", L"New-SSHSession -ComputerName \"192.168.178.49\" -Credential(Get-Credential) | Out-File F:\\test.txt", NULL, SW_SHOWNORMAL);
	//ShellExecute(NULL, L"open", L"powershell.exe", L"Invoke-SSHCommand -Index 0 -Command \"uname - a\" | Out-File F:\\test1.txt", NULL, SW_SHOWNORMAL);

	//ShellExecute(NULL, L"open", L"powershell.exe", L"New-SSHSession -ComputerName \"192.168.178.49\" -Credential(Get-Credential) | Out-File F:\\test.txt ; Invoke-SSHCommand -Index 0 -Command \"uname - a\" | Out-File F:\\test1.txt", NULL, SW_SHOWNORMAL);
	//ShellExecute(NULL, L"open", L"powershell.exe", L"New-SSHSession -ComputerName \"192.168.178.49\" -Credential(Get-Credential) | Out-File F:\\test.txt ; Get-SSHSession | Out-File F:\\test1.txt", NULL, SW_SHOWNORMAL);
	
	//ShellExecute(NULL, L"open", L"powershell.exe", L"New-SSHSession -ComputerName \"192.168.178.49\" -Credential(Get-Credential root) ; Invoke-SSHCommand -Index 0 -Command \"uname - a\" *> F:\\aaa.txt", NULL, SW_SHOWNORMAL);

	//UINT WINAPI uiRes = WinExec("powershell -noexit -command \"New-SSHSession -ComputerName \"192.168.178.49\" -Credential(Get-Credential root) > F:\\aaa.txt ; Invoke-SSHCommand -Index 0 -Command \"uname\" > F:\\bbb.txt \"", SW_SHOW);
	//UINT WINAPI uiRes = WinExec("powershell -noexit -command \"New-SSHSession -ComputerName \"192.168.178.49\" -Credential(Get-Credential root) > F:\\aaa.txt ; Invoke-SSHCommand -Index 0 -Command \"/tmp/VisualGDB/e/VisualStudio2017/Projects/RaspberryPi2/RyS1/RyS/Debug/RyS\"\"", SW_SHOW);
	//UINT WINAPI uiRes = WinExec("powershell -noexit -command \"New-SSHSession -ComputerName \"192.168.178.49\" -Credential(Get-Credential root) > F:\\aaa.txt ; Invoke-SSHCommand -Index 0 -Command \"/tmp/VisualGDB/e/VisualStudio2017/Projects/RaspberryPi2/RyS1/RyS/Debug/RyS\" ; Remove-SSHSession -Index 0 -Verbose\"", SW_SHOW);
	//UINT WINAPI uiRes = WinExec("powershell -command \"New-SSHSession -ComputerName \"192.168.178.49\" -Credential(Get-Credential root) > F:\\aaa.txt ; Invoke-SSHCommand -Index 0 -Command \"/tmp/VisualGDB/e/VisualStudio2017/Projects/RaspberryPi2/RyS1/RyS/Debug/RyS\" ; Remove-SSHSession -Index 0 -Verbose\"", SW_SHOW);
	UINT WINAPI uiRes = WinExec("powershell -command \"New-SSHSession -ComputerName \"192.168.178.49\" -Credential(Get-Credential) ; Invoke-SSHCommand -Index 0 -Command \"/tmp/VisualGDB/e/VisualStudio2017/Projects/RaspberryPi2/RyS1/RyS/Debug/RyS\" ; Remove-SSHSession -Index 0 -Verbose\"", SW_HIDE);
	
	return NO_ERROR;
}