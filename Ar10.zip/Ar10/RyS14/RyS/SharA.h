#pragma once

#include <string.h>

//#define _BRIEF_
//#define _TALKATIVE_
#define _WEBTOM8_	//+++ Tomcat8 must be on and able to access its 2 local txt files.

#define SUCCESS 0
#define INVALID_SD -1	//+++ Invalid socket descriptor.
#define BUFLEN 512	//+++ initial size for dynamic C-style array vector; size of generic reading-writing buffer.

#define handle_error_en(en, msg) \
               do { errno = en; cerr << msg << ": " << strerror(errno) << endl; exit(EXIT_FAILURE); } while (0)	//+++

#define handle_error(msg) \
               do { cerr << msg << ": " << strerror(errno) << endl; exit(EXIT_FAILURE); } while (0)	//+++ Print error message and exit app.

#define handle_error1(msg1) \
               do { cerr << msg1 << endl; exit(EXIT_FAILURE); } while (0)	

#define handle_error2(msg1, msg2) \
               do { cerr << msg1 << ": " << msg2 << endl; exit(EXIT_FAILURE); } while (0)

#define ARRAY_SIZE(array) (sizeof(array) / sizeof(array[0]))	//??????