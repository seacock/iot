/*
 * Copyright (c) 2015-2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== primary.c ========
 */

#include <^adc.h>
#include <^swi.h>
#include <^clock.h>
#include <^common.h>

extern uint16_t uiCycle;
#pragma DATA_ALIGN(aucGenericTaskStack, 8)  /* Make sure we have nice 8-byte alignment on the stack to avoid wasting memory */
static uint8_t aucGenericTaskStack[STACKSIZE];

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    bDIO15 = false;
    bDIO12 = false;
    bDIO21 = false;
    bDIO22 = false;
    bDIO1 = false;
    GPIO_init();/* Call driver init functions */

    Semaphore_Struct stSemMain;
    Semaphore_Params stSemParams;

    ADC_init();/* Call driver init functions */

    /* Open Display Driver */
    Display_Params    displayParams;
    Display_Params_init(&displayParams);
    displayHandle = Display_open(Display_Type_UART, NULL);

    GPIO_setConfig(Board_GPIO_LED0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);   //+++ Configure the LED pin.
    GPIO_setConfig(Board_GPIO_LED1, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_HIGH);   //+++ Configure the LED pin.

    //+++ Dynamic pin configuration.
    PIN_Config DynPinCfg[] = {
        CC1310_LAUNCHXL_DIO12 | PIN_GPIO_OUTPUT_EN | PIN_GPIO_HIGH | PIN_PUSHPULL | PIN_INPUT_DIS | PIN_DRVSTR_MED, //+++ ZeroSwf
        CC1310_LAUNCHXL_DIO15 | PIN_GPIO_OUTPUT_EN | PIN_GPIO_HIGH | PIN_PUSHPULL | PIN_INPUT_DIS | PIN_DRVSTR_MED, //+++ AdcTf
        CC1310_LAUNCHXL_DIO21 | PIN_GPIO_OUTPUT_EN | PIN_GPIO_HIGH | PIN_PUSHPULL | PIN_INPUT_DIS | PIN_DRVSTR_MED, //+++ ClockSwi
        CC1310_LAUNCHXL_DIO22 | PIN_GPIO_OUTPUT_EN | PIN_GPIO_HIGH | PIN_PUSHPULL | PIN_INPUT_DIS | PIN_DRVSTR_MED, //+++ GenericTf
        CC1310_LAUNCHXL_DIO1 | PIN_GPIO_OUTPUT_EN | PIN_GPIO_HIGH | PIN_PUSHPULL | PIN_INPUT_DIS | PIN_DRVSTR_MED, //+++ OneSwf
        PIN_TERMINATE
    };
    PIN_State stPinState;
    hDynPin = PIN_open(&stPinState, DynPinCfg);

    //+++ Semaphore initialization.
    Semaphore_Params_init(&stSemParams);
    Semaphore_construct(&stSemMain, 0, &stSemParams);
    hSemADC = Semaphore_handle(&stSemMain);

    //+++ Event initialization.
    Error_Block eb;
    Error_init(&eb);
    hEvnGeneric = Event_create(NULL, &eb);  //+++ Default instance configuration params.
    if (hEvnGeneric == NULL)
        System_abort("Event create failed");

    Types_FreqHz cpuFreq;
    BIOS_getCpuFreq(&cpuFreq);

    StartAdcTf();
    StartClockAdc();
    StartZeroSwf();
    StartOneSwf();
    StartClockSwi();
    StartGenericTf();
    StartClockGeneric();

    int iNum;
    while (1) {
//        if (uiCycle > 500 && uiCycle < 3500)
//            for (iNum = 0; iNum < 5; iNum++)
//                Display_printf(displayHandle, 1, 0, "%s", a2cSwiInfo[iNum]);

        GPIO_toggle(Board_GPIO_LED0);

    }
}

Void GenericTf(UArg arg0, UArg arg1)
{
    UInt uiEvents;

    while (TRUE)
    {
        uiEvents = Event_pend(hEvnGeneric, Event_Id_03 + Event_Id_08, Event_Id_NONE, BIOS_WAIT_FOREVER);    //+++ Wait on evn indefinitely.
        bDIO22 = !bDIO22;
        PIN_setOutputValue(hDynPin, CC1310_LAUNCHXL_DIO22, bDIO22);
    }
}

void StartGenericTf(void)
{
    /* Set up GenericTf task */
    Task_Params stTaskParams;
    Task_Params_init(&stTaskParams);
    stTaskParams.stackSize = STACKSIZE;
    stTaskParams.priority = 4;
    stTaskParams.stack = &aucGenericTaskStack;

    Task_construct(&stGenericTask, GenericTf, &stTaskParams, NULL);
}
