#pragma once

#include <iostream>//??????

using namespace std; 

class CRy;   //+++ forward declaration

class CSpi
{
public:
	const int kiSpiChannel = 0;
	const int kiSpiSpeed = 500000;
	const int kiSpiLength = 1;

	//+++ Commands to retrieve AD converted physical quantities from Microchip PICFJ64GB002.
	const int kiCmdUbP = 1;   //+++ Upper byte of potentiometer. Defined in RyS, Sciupa.
	const int kiCmdLbP = 2;   //+++ Lower byte of potentiometer. Defined in RyS, Sciupa.
	const int kiCmdUbT = 4;   //+++ Upper byte of thermometer. Defined in RyS, Sciupa.
	const int kiCmdLbT = 5;   //+++ Lower byte of thermometer. Defined in RyS, Sciupa.

	enum StateSpi { STATE_Potentiometer, STATE_Thermometer };//???
	struct Sync
	{
		StateSpi enStateSpi;
		pthread_cond_t condPotentiometer;
		pthread_cond_t condThermometer;
		pthread_mutex_t mutexSpi;
	} stSync;	

	struct Sensor
	{
		string srIdMsg;
		uint uiDelay;    	//+++ Time to wait before asking for next value.
		unsigned char ucUpper;
		unsigned char ucLower;
		string srName;
		unsigned int uiNumOfSpiCalls;
		unsigned long ulTotNumOfSpiCalls;
		unsigned int uiTomcatCounter;
		unsigned int uiLaptopCounter;		
	} stPoten, stThermo;

	CRy *pRy;
	
	CSpi(CRy *pRaspberry); 	//+++ needs forward declaration//??????
	~CSpi();
	void SpiMaster(int iFdLas, Sensor &stSensor); 	//+++ SPI master for PIC24 sensors.
	void SpiDataRW(unsigned char ucData, unsigned char &ucULByte); 	//+++ Communicate with MicroChip Pic24 via Spi.
	void CommServerWrite(int iFdTom8, int iValue, string srWho); 	//+++ Send value to RaspberryPi2's Tomcat8.
};