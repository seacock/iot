﻿$User = "root"
$File = "C:\Users\Administrator\Documents\WindowsPowerShell\Scripts\Psw.txt"
$MyCredential=New-Object -TypeName System.Management.Automation.PSCredential `
                                        -ArgumentList $User, (Get-Content $File | ConvertTo-SecureString)
New-SSHSession -ComputerName "192.168.178.49" -Credential $MyCredential
Invoke-SSHCommand -Index 0 -Command "/tmp/VisualGDB/e/VisualStudio2017/Projects/RaspberryPi2/DaemonSSH3/DaemonSSH/Debug/DaemonSSH" -TimeOut 10
Remove-SSHSession -Index 0 -Verbose