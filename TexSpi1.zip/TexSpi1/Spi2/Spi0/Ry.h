#pragma once

#include <iostream>
#include <unistd.h>

using namespace std;

typedef void *(*ThreadProcP)(void*);  	//+++ Declares a type of a ptr to a function that accepts a void ptr and returns a void ptr.

class CAff;   //+++ forward declaration
class CSpi;

class CRy
{
public:
	const int kiNumThreads = 2;
	enum ThreadList {TL_One = 1, TL_Two = 2} ;

	struct Util  //+++ needs forward declaration
	{
		CAff *pAff;		
		CRy *pRy;		
		CSpi *pSpi;
	} stUtil;
		
	struct ThreadInfo	//+++ Used as argument to LanTp()...
	{
		pthread_t ulThread_id; 	//+++ ID returned by pthread_create().
		int iThreadNum; 	//+++ Application-defined thread #.
		static cpu_set_t stSet1, stSet2, stSet3; //??????
		char pcInfoArg[50]; 	//+++ First argument sent to Asi server ReceiveTp. ReceiveTp uses that to recognize which kind of thread has connected.
		Util *pstUtil;
	};

	ThreadProcP afp[1];     //++ Declares the array of function ptrs.
	ThreadInfo *pstThrInf;
	
	CRy();
	~CRy();
	void PoolThread(int iNumThreads);  	//+++ Create and join kiNumThreads threads.
	void CreateThread(int iNThreads, void *(**ppStartRoutine)(void*));   	//+++ Create child threads.
};