#pragma once


// CDlgExBase dialog

class CDlgExBase : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgExBase)

public:
	CDlgExBase(CWnd* pParent = NULL);   // standard constructor
	virtual ~CDlgExBase();
	CDlgExBase(UINT nIDTemplate, CWnd* pParent /*=NULL*/);	//+++ Custom constructor.

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DLGEXBASE };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	int SocketAddr(wstring wsrClassName, char *pcHostName, char *pcPortNumber, sockaddr_in **sockaddr_ipv4);
private:
	int MsgWsa(wstring wsrWhich, wstring wsrMsg, bool bCleanup);
	template <typename T>
	string NumberToStringHex(T Number);	//+++ Transform a decimal number to a string of hex.

	DECLARE_MESSAGE_MAP()
};