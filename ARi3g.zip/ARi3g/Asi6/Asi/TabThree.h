#pragma once

// CTabThree dialog

class CTabThree : public CDlgExBase
{
	DECLARE_DYNAMIC(CTabThree)

public:
	CEdit jedThr2M;	//+++ Thread2 monitor.
	CEdit jedThr2V;	//+++ Thread2: potentiometer of PICFJ64GB002.
	CProgressCtrl jpgsThr2;	//+++ Thread2: potentiometer of PICFJ64GB002.
	CEdit jedThr3M;	//+++ Thread3 monitor.
	CEdit jedThr3V;	//+++ Thread3: thermometer of PICFJ64GB002.
	CProgressCtrl jpgsThr3;	//+++ Thread3: thermometer of PICFJ64GB002.
	CTabThree(CWnd* pParent = NULL);   // standard constructor
	virtual ~CTabThree();
	virtual BOOL OnInitDialog();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_TAB_THREE };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
private:
	CStatic jtxtPgsP, jtxtPgsT;	
	wstring wsrMtrThr2, wsrMtrThr3;	
	LRESULT OnEdThr2M(WPARAM wParam, LPARAM lParam);	//+++ Thread2 monitor.	
	LRESULT OnEdThr2V(WPARAM wParam, LPARAM lParam);	//+++ Thread2: potentiometer of PICFJ64GB002.	
	LRESULT OnPgsThr2(WPARAM wParam, LPARAM lParam);	//+++ Thread2: potentiometer of PICFJ64GB002.
	LRESULT OnEdThr3M(WPARAM wParam, LPARAM lParam);	//+++ Thread3 monitor.
	LRESULT OnEdThr3V(WPARAM wParam, LPARAM lParam);	//+++ Thread3: thermometer of PICFJ64GB002.
	LRESULT OnPgsThr3(WPARAM wParam, LPARAM lParam);	//+++ Thread3: thermometer of PICFJ64GB002.
	void EdThrV(wstring wsrMix, wstring wsrName, CEdit *pjed);	//+++ Common helper.
	void PgsThr(wstring wsrMix, wstring wsrName, CProgressCtrl *pjpgs);	//+++ Common helper.	
};

static UINT RG_WM_ED_THR2M = RegisterWindowMessage(_T("EDIT THREAD2 MONITOR"));
static UINT RG_WM_ED_THR2V = RegisterWindowMessage(_T("EDIT THREAD2 VALUES"));
static UINT RG_WM_PGS_THR2 = RegisterWindowMessage(_T("PROGRESS THREAD2 VALUES"));
static UINT RG_WM_ED_THR3M = RegisterWindowMessage(_T("EDIT THREAD3 MONITOR"));
static UINT RG_WM_ED_THR3V = RegisterWindowMessage(_T("EDIT THREAD3 VALUES"));
static UINT RG_WM_PGS_THR3 = RegisterWindowMessage(_T("PROGRESS THREAD3 VALUES"));