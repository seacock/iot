/*
 * File:   I2CsX.c
 * Author: MeMyselfAndI
 *
 * Created on 24 luglio 2016, 15.36
 */

#include "I2CsX.h"

int mainI2CsX(void) 
{
    InitI2C(); 
    
    return 0;
}

//+++ Perform initialisation of the I2C module to operate as a slave.
void InitI2C(void)
{
	CloseI2C1();
	OpenI2C1(I2C_ON & I2C_7BIT_ADD, SLAVE_MODE);
	
	I2C1ADD = SLAVE_ADDRESS; //+++ Address of slave module: no shift needed. 
    _SI2C1IP = 5;   //+++ Configure interrupt priority for I2C peripheral.
	_SI2C1IF = 0;   //+++ Clear I2C1 Slave interrupt flag.
    _SI2C1IE = 1;   //+++ Enable I2C interrupts.
}

//+++ Slave I2C interrupt handler. It's called for Slave, Master and Bus 
//+++ Collision events.
void _ISR _SI2C1Interrupt( void )
{
    int iWait;
        
    //+++ This delay avoids communication errors when transmitting from Pic24
    //+++ to Raspberry. No need when receiving, but this way is simpler. 
    //+++ Minimum value is 5. Maximum some tens. Fundamental.
    for (iWait = 0; iWait < 15; iWait++);    
    
	//+++ Handle the incoming message.
	if ((I2C1STATbits.R_W == 0) && (I2C1STATbits.D_A == 0)) 
    {
		//+++ R/W bit = 0 --> indicates data transfer is input to slave.
		//+++ D/A bit = 0 --> indicates last byte was address.  		
        SlaveReadI2C1(); //+++ Necessary dummy read of the address.
	} 
    else if ((I2C1STATbits.R_W == 0) && (I2C1STATbits.D_A == 1)) 
    {
		//+++ R/W bit = 0 --> indicates data transfer is input to slave.
		//+++ D/A bit = 1 --> indicates last byte was data.	                
        guchInOut = SlaveReadI2C1(); //+++ Get data from master.
        
        if (guchInOut == ADC_AVERAGE)
        {   
            ResetSpi();
            PORTBbits.RB10 = 0; //+++ Compute and send back average of values.
        }            
        else if (guchInOut == ADC_LASTVAL)
        {
            ResetSpi();
            PORTBbits.RB10 = 1; //+++ Send back last converted value.
        }        
        else if (guchInOut == PWM_CONTINUOUS || guchInOut == PWM_FUNCTION)
            guchPWMcf = guchInOut;
        else if (guchInOut >= 0 && guchInOut <= 100)    //+++ Pleonastic.
            guchPWMc = guchInOut;    
                
        I2C1CONbits.SCLREL = 1; //+++ Release clock stretch bit to restart I2C.
	} 
    else if ((I2C1STATbits.R_W == 1) && (I2C1STATbits.D_A == 0)) 
    {
		//+++ R/W bit = 1 --> indicates data transfer is output from slave.
		//+++ D/A bit = 0 --> indicates last byte was address.        
        SlaveWriteI2C1(guchInOut);//+++ Send data to master.
	} 
    else if ((I2C1STATbits.R_W == 1) && (I2C1STATbits.D_A == 1)) 
    {
		//+++ R/W bit = 1 --> indicates data transfer is output from slave.
		//+++ D/A bit = 1 --> indicates last byte was data.
        
        //+++ Possible post-send code.
	}
    
	_SI2C1IF = 0;   //+++ Clear I2C1 Slave interrupt flag.
}