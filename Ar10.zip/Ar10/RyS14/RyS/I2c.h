#pragma once

#include <pthread.h>

class CRy;   //+++ forward declaration

class CI2c
{
public:
	const int kiAdcAverage = 110;	//+++ PICFJ64GB002 sends back average ADC values for potentiometer and thermometer. Defined in Asi, RyS, Sciupa.
	const int kiAdcLastVal = 120;	//+++ PICFJ64GB002 sends back last ADC value for potentiometer and thermometer. Defined in Asi, RyS, Sciupa.
	const int kiPwmContinuous = 130;	//+++ PICFJ64GB002 outputs PWM with duty cycle fixed by slider. Defined in Asi, RyS, Sciupa.
	const int kiPwmFunction = 140;	//+++ PICFJ64GB002 outputs PWM with variable duty cycle depending on a local function. Defined in Asi, RyS, Sciupa.
	
	enum State { STATE_Off, STATE_On };	//+++ Values on which TEMPORARY thread waits till I2cServTp wakes it up.
	
	//+++ Information about incoming laptop ASUS client.
	struct Sync
	{
		int iFdI2c;  	//+++ File descriptor for I2C device.
		State enStateI2c;  	//+++ Values on which TEMPORARY thread waits till I2cServTp wakes it up.
		pthread_cond_t condI2c;  	//+++ Condition on which TEMPORARY thread waits till I2cServTp wakes it up.
		pthread_mutex_t mutexI2c;  	//+++ Mutex called by TEMPORARY and I2cServTp threads to manage ScondI2c and SenStateI2c. Only one thread owns it at a time.
	} stSync;

	CRy *pRy;
	
	CI2c(CRy *pRaspberry);   	//+++ needs forward declaration//??????
	~CI2c();
	int I2cMaster(int iFdI2cM, unsigned char ucNumber, int iFdLas);	//?????? Safer //+++ Communicate with MicroChip Pic24 via I2c and send back values to laptop ASUS. Depending on value of iFdLas, writing can be from client or from server.
};