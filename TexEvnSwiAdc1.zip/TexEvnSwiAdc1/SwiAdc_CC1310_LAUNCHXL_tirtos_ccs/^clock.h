/*
 * ^clock.h
 *
 *  Created on: 25 ott 2018
 *      Author: andre
 */

#ifndef CLOCK_H_
#define CLOCK_H_

Void ClockAdc(UArg arg0);
void StartClockAdc(void);
Void ClockSwi(UArg arg0);
void StartClockSwi(void);
Void ClockGeneric(UArg arg0);
void StartClockGeneric(void);

#endif /* CLOCK_H_ */
