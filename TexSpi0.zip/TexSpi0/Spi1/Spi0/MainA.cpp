#include "SharA.h"
#include "Aff.h"
#include "Ry.h"
#include "Spi.h"
#include <wiringPi.h>
#include <wiringPiSPI.h>

CAff gAff;
CRy gRy;//?????? important order....
CSpi gSpi(&gRy);//?????? important order....
int ooo = 0;
int uuu=1;

void Isr()
{
	int i = digitalRead(GPIO4);
	if (i == HIGH && ooo == 0)
	{
//		digitalWrite(GPIO3, HIGH);
		digitalWrite(GPIO3, LOW);
		ooo = 1;
	}
	else if (i == HIGH && ooo == 1)
	{
		uuu = 0;
		ooo = 1;
	}
	else if (i == LOW && ooo == 1)
	{
		uuu = 1;
		ooo = 1;
	}
}

void* LanTp(void *arg);

int main(int argc, char *argv[])
{
	gRy.stUtil.pRy = &gRy;
	gRy.stUtil.pAff = &gAff;
	gRy.stUtil.pSpi = &gSpi;

	gAff.SchedAff();
	
	wiringPiSetup();
	
	wiringPiSPISetup(gSpi.kiSpiChannel, gSpi.kiSpiSpeed);

	pinMode(GPIO3, OUTPUT); 	//+++ Board_SPI_MASTER_READY : RaspberryPi3
	pinMode(GPIO4, INPUT);  	//+++ Board_SPI_SLAVE_READY : CC1310Texas	

	wiringPiISR(GPIO4, INT_EDGE_BOTH, Isr);
	
	gRy.afp[0] = LanTp;
	gRy.PoolThread(gRy.kiNumThreads);  	//+++ Create and wait for worker threads.

	exit(EXIT_SUCCESS);
}