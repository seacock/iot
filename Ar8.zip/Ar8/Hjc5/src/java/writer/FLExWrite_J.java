/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package writer;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.channels.OverlappingFileLockException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

/**
 *
 * @author Administrator
 */
public class FLExWrite_J {
    public String strLockShot = "";  //+++ Message for Ry.
    private final String strInput;  //+++ Data from Ry, to be written into RAM file.
    
    public FLExWrite_J(String strInput)
    {
        this.strInput = strInput;
    }
    
    public void Write() throws IOException, InterruptedException {        
        String filePath = ""; //+++ RAM file to be written by fileChannel on demand from Ry.   
        if (strInput.contains("P"))
            filePath = "/mnt/Hjc/potentiometer.txt"; 
        else if (strInput.contains("T"))
            filePath = "/mnt/Hjc/thermometer.txt";
        
        String  strDataWrite = strInput.substring(1);
        ByteBuffer buffer = ByteBuffer.wrap(strDataWrite.getBytes());   //+++ Prepare data for fileChannel.
        Path path = Paths.get(filePath);    
        FileChannel fileChannel;
        
        //+++ Open for writing with obtained fileChannel.
        fileChannel = FileChannel.open(path, StandardOpenOption.WRITE, StandardOpenOption.TRUNCATE_EXISTING); 
        int iLockShot = 0;  //+++ Attempts to get an exclusive lock for writing.
        boolean bValidLock = false;
        
        //+++ Try getting an exclusive lock.
        while (bValidLock == false){
            try {  
                FileLock lock = fileChannel.lock();  
                bValidLock = lock.isValid();
            } 
            catch (OverlappingFileLockException e) {
                e.getMessage();
                iLockShot++;
            }
        } 
        
        strLockShot += "\tLockShot:\t" + iLockShot;                
        fileChannel.write(buffer);  //+++ Write from buffer to channel.  
        fileChannel.close(); //+++ Close fileChannel and release lock.
    }
}