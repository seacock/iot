/*
 * Copyright (c) 2015-2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== empty.c ========
 */

#include "scif.h"
#define BV(x)    (1 << (x))

/* For usleep() */
#include <unistd.h>
#include <stdint.h>
#include <stddef.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>
// #include <ti/drivers/I2C.h>
// #include <ti/drivers/SDSPI.h>
// #include <ti/drivers/SPI.h>
// #include <ti/drivers/UART.h>
// #include <ti/drivers/Watchdog.h>

/* Board Header file */
#include "Board.h"

#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/BIOS.h>

// Main loop Semaphore
Semaphore_Struct semMainLoop;
Semaphore_Handle hSemMainLoop;
uint32_t iCountLow = 0, iCountHigh = 0;

void processTaskAlert(void)
{
    // Clear the ALERT interrupt source
    scifClearAlertIntSource();

    // Do SC Task processing here
    // Fetch 'state.high' variable from SC
    uint8_t high = scifTaskData.adcLevelTrigger.state.high;
    if (high == 0)
        iCountLow++;
    else if (high == 1)
        iCountHigh++;

    // Acknowledge the ALERT event
    scifAckAlertEvents();
} // processTaskAlert

void scCtrlReadyCallback(void)
{

} // scCtrlReadyCallback

void scTaskAlertCallback(void)
{
    // Post to main loop semaphore
    Semaphore_post(hSemMainLoop);
} // scTaskAlertCallback

/*
 *  ======== mainThread ========
 */
void *tirtosScThread(void *arg0)
{
    /* Call driver init functions */
    GPIO_init();
    // I2C_init();
    // SDSPI_init();
    // SPI_init();
    // UART_init();
    // Watchdog_init();

    /* Configure the LED pin */
    GPIO_setConfig(Board_GPIO_LED0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    /*GPIO_PinConfig uuu;
    GPIO_getConfig(CC1310_LAUNCHXL_DIO12, &uuu);
    GPIO_setConfig(CC1310_LAUNCHXL_DIO12, PIN_GPIO_OUTPUT_EN | PIN_GPIO_HIGH | PIN_PUSHPULL | PIN_DRVSTR_MAX);
    GPIO_getConfig(CC1310_LAUNCHXL_DIO12, &uuu);*/
    //GPIO_setConfig(CC1310_LAUNCHXL_DIO21, GPIO_CFG_OUTPUT | GPIO_CFG_OUT_STD | GPIO_CFG_OUT_HIGH);



    PIN_Config ooo[] = {

                        CC1310_LAUNCHXL_DIO12 | PIN_GPIO_OUTPUT_EN | PIN_GPIO_HIGH | PIN_PUSHPULL |
                    PIN_INPUT_DIS | PIN_DRVSTR_MED,

            PIN_TERMINATE
        };
        PIN_State iii;
        PIN_Handle eee = PIN_open(&iii, ooo);





    // Semaphore initialization
    Semaphore_Params semParams;
    Semaphore_Params_init(&semParams);
    Semaphore_construct(&semMainLoop, 0, &semParams);
    hSemMainLoop = Semaphore_handle(&semMainLoop);

    // Initialize the Sensor Controller
    scifOsalInit();
    scifOsalRegisterCtrlReadyCallback(scCtrlReadyCallback);
    scifOsalRegisterTaskAlertCallback(scTaskAlertCallback);
    scifInit(&scifDriverSetup);

    // Set the Sensor Controller task tick interval to 1 second
    uint32_t rtc_Hz = 10;  // 10 Hz RTC
    scifStartRtcTicksNow(0x00010000 / rtc_Hz);

    // Configure Sensor Controller tasks
    scifTaskData.adcLevelTrigger.cfg.threshold = 1000;

    scifStartTasksNbl(BV(SCIF_GPIO_PIN_TRIGGER_TASK_ID));
    int iFlicker = 0;
    bool aaa = false;
    while (1) {
        // Start the ADC Sampler task
        while (scifWaitOnNbl(0) != SCIF_SUCCESS);
        scifResetTaskStructs(BV(SCIF_ADC_LEVEL_TRIGGER_TASK_ID), BV(SCIF_STRUCT_OUTPUT));
        scifExecuteTasksOnceNbl(BV(SCIF_ADC_LEVEL_TRIGGER_TASK_ID));

        Semaphore_pend(hSemMainLoop, BIOS_WAIT_FOREVER);    // Wait on sem indefinitely
        processTaskAlert(); // Call process function
        aaa=!aaa;
        PIN_setOutputValue(eee,CC1310_LAUNCHXL_DIO12,aaa);
        iFlicker++;
        if (iFlicker == 10){
            GPIO_toggle(Board_GPIO_LED0);

            iFlicker = 0;
        }
    }
}
