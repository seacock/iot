#include "Ryie.h"

cpu_set_t ThreadInfo::SstSet1, ThreadInfo::SstSet2, ThreadInfo::SstSet3;
bool ThreadInfo::SbExitThread = false;
StateSpi Sensor::SenStateSpi = STATE_Potentiometer;
pthread_cond_t Sensor::ScondPotentiometer = PTHREAD_COND_INITIALIZER;
pthread_cond_t Sensor::ScondThermometer = PTHREAD_COND_INITIALIZER;
pthread_mutex_t Sensor::SmutexSpi = PTHREAD_MUTEX_INITIALIZER;
string gsrNumber;
typedef void *(*ThreadProcP)(void*);	//+++ Declares a type of a void function that accepts a void.
ThreadProcP afp[3];  //++ Declares the array.
vector<string> ThreadInfo::SteHost;
char ThreadInfo::SacBroadcast[INET_ADDRSTRLEN];
string ThreadInfo::SsrI2cServerPort = "12300";
string ThreadInfo::SsrTom8ServerPort = "8080";
string ThreadInfo::SsrRemSvrPortR3 = "80";
string ThreadInfo::SsrRemSvrPortNi = "8080";
string ThreadInfo::SsrLANServerHost;
string ThreadInfo::SsrLANServerPort;
timeval I2c::SstTimeout;
int I2c::SiFdI2c;
StateI2c I2c::SenStateI2c = STATE_Off;
pthread_cond_t I2c::ScondI2c = PTHREAD_COND_INITIALIZER;
pthread_mutex_t I2c::SmutexI2c = PTHREAD_MUTEX_INITIALIZER;
pthread_barrier_t ThreadInfo::Sbarrier5;

int main(int argc, char *argv[])
{	
	if (argc == 3)
	{
		ThreadInfo::SsrI2cServerPort = argv[1];
		ThreadInfo::SsrTom8ServerPort = argv[2];
	}
	else if (argc != 1)
	{
		cout << "Specify I2cServerPort and Tom8ServerPort." << endl;
		exit(EXIT_FAILURE);
	}

	FillCoupleId();
	
	InterfacesIp(ThreadInfo::SacBroadcast);

	if (strcmp(ThreadInfo::SacBroadcast, "nothing") == 0)
		return ERROR;

	SchedAff();

	wiringPiSetup();
	pinMode(SWITCH_INC, INPUT);
	pinMode(SWITCH_DEC, INPUT);	

	wiringPiSPISetup(SPI_CHANNEL, SPI_SPEED);
	
	int iAddr = 0x04;	
	I2c::SiFdI2c = wiringPiI2CSetup(iAddr);	//+++ Initialize the interface by giving it ID. It returns a standard file descriptor.
	if (I2c::SiFdI2c == -1)
		handle_error("wiringPiI2CSetup:   ");

	pthread_barrier_init(&ThreadInfo::Sbarrier5, NULL, 5);

	afp[0] = BroadTp;
	afp[1] = SocTxRxTp;
	afp[2] = I2cServTp;
	PoolThread(NUM_THREADS);	

	exit(EXIT_SUCCESS);
}

void PoolThread(int iNumThreads)
{
	int iRes;
	ThreadInfo *pstThrInf = CreateThread(pstThrInf, iNumThreads, afp);
	
	for (int iNum = 0; iNum < iNumThreads; iNum++)	//+++ Now join with each thread.
	{
		void *res;
		iRes = pthread_join(pstThrInf[iNum].ulThread_id, &res);
		if (iRes != 0)
			handle_error_en(iRes, "pthread_join");
#ifdef _BRIEF_
		cout << "Thread " << iNum << " exiting with status :" << res << endl;
#endif // _BRIEF_
	}

	delete[] pstThrInf;

	pthread_barrier_destroy(&ThreadInfo::Sbarrier5);

#ifdef _BRIEF_
	cout << "Application exits." << endl;
#endif // _BRIEF_		
}

void* SocTxRxTp(void *arg)
{
	ThreadInfo *pstThrInf = (ThreadInfo*)arg;

	int iRes;
	switch (pstThrInf->iThreadNum)
	{
	case ONE:
		iRes = sched_setaffinity(0, sizeof(ThreadInfo::SstSet1), &ThreadInfo::SstSet1);
		break;
	case TWO:
		iRes = sched_setaffinity(0, sizeof(ThreadInfo::SstSet2), &ThreadInfo::SstSet2);
		break;
	case THREE:
		iRes = sched_setaffinity(0, sizeof(ThreadInfo::SstSet2), &ThreadInfo::SstSet2);
		break;
	case TEMPORARY:
		iRes = sched_setaffinity(0, sizeof(ThreadInfo::SstSet1), &ThreadInfo::SstSet1);
		break;
	}

	if (iRes == -1)
		handle_error_en(iRes, "sched_setaffinity");

	pthread_barrier_wait(&ThreadInfo::Sbarrier5);
	
#ifdef _BRIEF_
	DisplayThreadSchedAttr(pstThrInf->pcInfoArg);
	cpu_set_t stSet;
	sched_getaffinity(0, sizeof(stSet), &stSet);
	for (int iCount = 0; iCount < 4; iCount++)
		if (CPU_ISSET_S(iCount, sizeof(stSet), &stSet))
			cout << "affinity: " << iCount << endl << endl;
#endif // _BRIEF_

	int iSock = SockAddrConn(ThreadInfo::SsrLANServerHost.c_str(), atoi(ThreadInfo::SsrLANServerPort.c_str()));
			
	//+++ Send data to the server.
	if (pstThrInf->iThreadNum == ONE)
	{
		WriteToServer(iSock, pstThrInf->pcInfoArg);

		while (ThreadInfo::SbExitThread == false)
			BtnIncDec(iSock);
	}
	else if (pstThrInf->iThreadNum == TWO)
	{
		Sensor stPoten;
		stPoten.srIdMsg = pstThrInf->pcInfoArg;
		stPoten.uiDelay = 100;
		stPoten.ucUpper = CMD_UB_P;
		stPoten.ucLower = CMD_LB_P;
		stPoten.srName = "Potentiometer";
		stPoten.uiNumOfSpiCalls = 0;
		stPoten.ulTotNumOfSpiCalls = 0;
		stPoten.uiTomcatCounter = 0;
		stPoten.uiLaptopCounter = 0;

		WriteToServer(iSock, stPoten.srIdMsg.c_str());		
		
		while (ThreadInfo::SbExitThread == false)
		{
		    //+++ Wait for genStateSpi STATE_Potentiometer.
			pthread_mutex_lock(&Sensor::SmutexSpi);
			while (Sensor::SenStateSpi != STATE_Potentiometer)
				pthread_cond_wait(&Sensor::ScondPotentiometer, &Sensor::SmutexSpi);
			pthread_mutex_unlock(&Sensor::SmutexSpi);

			SpiMaster(iSock, stPoten);	//+++ Do stuff.
			
			//+++ Set genStateSpi to STATE_Thermometer and wake up thread 3.
			pthread_mutex_lock(&Sensor::SmutexSpi);
			Sensor::SenStateSpi = STATE_Thermometer;
			pthread_cond_signal(&Sensor::ScondThermometer);
			pthread_mutex_unlock(&Sensor::SmutexSpi);
		}
	}
	else if (pstThrInf->iThreadNum == THREE)	
	{
		Sensor stThermo;
		stThermo.srIdMsg = pstThrInf->pcInfoArg;
		stThermo.uiDelay = 100;
		stThermo.ucUpper = CMD_UB_T;
		stThermo.ucLower = CMD_LB_T;
		stThermo.srName = "Thermometer";
		stThermo.uiNumOfSpiCalls = 0;
		stThermo.ulTotNumOfSpiCalls = 0;
		stThermo.uiTomcatCounter = 0;
		stThermo.uiLaptopCounter = 0;

		WriteToServer(iSock, stThermo.srIdMsg.c_str());		

		while (ThreadInfo::SbExitThread == false)
		{
		    //+++ Wait for genStateSpi STATE_Thermometer.
			pthread_mutex_lock(&Sensor::SmutexSpi);
			while (Sensor::SenStateSpi != STATE_Thermometer)
				pthread_cond_wait(&Sensor::ScondThermometer, &Sensor::SmutexSpi);
			pthread_mutex_unlock(&Sensor::SmutexSpi);

			SpiMaster(iSock, stThermo);	//+++ Do stuff.	
			
			//+++ Set genStateSpi to STATE_Potentiometer and wake up thread 2.
			pthread_mutex_lock(&Sensor::SmutexSpi);
			Sensor::SenStateSpi = STATE_Potentiometer;
			pthread_cond_signal(&Sensor::ScondPotentiometer);
			pthread_mutex_unlock(&Sensor::SmutexSpi);
		}
	}
	else if (pstThrInf->iThreadNum == TEMPORARY)	
	{
		//+++ Wait for SenStateI2c STATE_On.
		pthread_mutex_lock(&I2c::SmutexI2c);
		while (I2c::SenStateI2c != STATE_On)
			pthread_cond_wait(&I2c::ScondI2c, &I2c::SmutexI2c);
		pthread_mutex_unlock(&I2c::SmutexI2c);

		timespec stTs;
		stTs.tv_sec = 0;	//+++ Server wants a time delay or can lose data: write doesn't guarantee delivery of data...
		stTs.tv_nsec = 1000 * 1000 * 100;	//+++ Initialize always or error occurs.		

		WriteToServer(iSock, pstThrInf->pcInfoArg);
		nanosleep(&stTs, NULL);
		I2cMaster(I2c::SiFdI2c, ADC_LASTVAL, iSock);
		nanosleep(&stTs, NULL);
		I2cMaster(I2c::SiFdI2c, PWM_CONTINUOUS, iSock);
		nanosleep(&stTs, NULL);
		WriteToServer(iSock, ThreadInfo::SteHost[0].c_str());
		nanosleep(&stTs, NULL);
		WriteToServer(iSock, ThreadInfo::SsrI2cServerPort.c_str());
		nanosleep(&stTs, NULL);
		WriteToServer(iSock, ThreadInfo::SsrRemSvrPortR3.c_str());
		nanosleep(&stTs, NULL);
		WriteToServer(iSock, ThreadInfo::SsrRemSvrPortNi.c_str());
	}		
		
	close(iSock);	//+++ This gets out from its endless loop, recv on laptop side (ReceiveFromMcTp).
}

ThreadInfo* CreateThread(ThreadInfo* pstThIn, int iNThreads, void *(*start_routine[3])(void*))
{
	int iRes;		
	pthread_attr_t unAttr;
	ThreadAttr(unAttr);

	pstThIn = new ThreadInfo[iNThreads];	//+++ Allocate memory for pthread_create arguments.
	if (pstThIn == NULL)
		handle_error1("new");

	for (int iNum = 0; iNum < iNThreads; iNum++)	//+++ Create all threads.
	{
		pstThIn[iNum].iThreadNum = SteCoupleID[iNum].iMessage;
		strcpy(pstThIn[iNum].pcInfoArg, SteCoupleID[iNum].srMessage.c_str());

		//+++ The pthread_create call stores the thread ID into corresponding element of pstThIn[].
		if (pstThIn[iNum].iThreadNum == BROADCAST)
			iRes = pthread_create(&pstThIn[iNum].ulThread_id, &unAttr, start_routine[0], &pstThIn[iNum]);
		else if (pstThIn[iNum].iThreadNum >= ONE && pstThIn[iNum].iThreadNum <= TEMPORARY)
			iRes = pthread_create(&pstThIn[iNum].ulThread_id, &unAttr, start_routine[1], &pstThIn[iNum]);
		else if (pstThIn[iNum].iThreadNum == SERVER_I2C)
			iRes = pthread_create(&pstThIn[iNum].ulThread_id, &unAttr, start_routine[2], &pstThIn[iNum]);
		if (iRes != 0)
			handle_error_en(iRes, "pthread_create");
	}	

	//+++ Destroy the thread attributes object, since it is no longer needed.
	iRes = pthread_attr_destroy(&unAttr);
	if (iRes != 0)
		handle_error_en(iRes, "pthread_attr_destroy");		

	return pstThIn;
}

void LeaveThreads()
{
	I2c::SstTimeout.tv_sec = 5;	//+++ Laptop asks for early closure.
	ThreadInfo::SbExitThread = true;
	pthread_cond_signal(&Sensor::ScondThermometer);
	pthread_cond_signal(&Sensor::ScondPotentiometer);
}

int SockAddrConn(const char* pcHostName, uint16_t usiPort)
{
	int iSockFd, iRes;	//+++ Socket file descriptor; result code.
	addrinfo stHints, *pstServInfo, *pstBrowse;	//+++ Criteria for selection; returned list of socket address structs; ptr for looking through returned list.

	memset(&stHints, 0, sizeof stHints);
	stHints.ai_family = AF_UNSPEC; //+++ Either IPv4 or IPv6.
	stHints.ai_socktype = SOCK_STREAM;
	if ((iRes = getaddrinfo(pcHostName, NumberToString(usiPort).c_str(), &stHints, &pstServInfo)) != 0)
		handle_error2("getaddrinfo", gai_strerror(iRes));

	//+++ Loop through all the results and connect to the first available.
	for (pstBrowse = pstServInfo; pstBrowse != NULL; pstBrowse = pstBrowse->ai_next) 
	{
		if ((iSockFd = socket(pstBrowse->ai_family, pstBrowse->ai_socktype, pstBrowse->ai_protocol)) == INVALID_SOCKET) 
		{
			perror("socket");
			continue;
		}

		timeval stTv;	//+++ Doesn't work in debug.
		stTv.tv_sec = 15;  //+++ 15 Secs Timeout. Then below connect fails and, with no connections, app eventually closes.
		stTv.tv_usec = 0;	//+++ Initialize always or error occurs.
		if (setsockopt(iSockFd, SOL_SOCKET, SO_SNDTIMEO, (timeval*)&stTv, sizeof(timeval)) == -1)
			handle_error("setsockopt");	  

		//+++ connect can fail also if the server isn't enabled by its firewall to communicate through public/private network.
		if (connect(iSockFd, pstBrowse->ai_addr, pstBrowse->ai_addrlen) == -1) 
		{
			perror("connect");
			close(iSockFd);
			continue;
		}

		break; //+++ Connection must have been successful.
	}
	string srThreadID = NumberToString(pthread_self());
	srThreadID += " --->Thread ID: failed to connect";
	if (pstBrowse == NULL) 
		handle_error1(srThreadID.c_str());	//+++ Looped off the end of the list with no connection.

	freeaddrinfo(pstServInfo); //+++ All done with this structure.

	return iSockFd;
}

void FillCoupleId()
{
	int iSize = SteCoupleID.size();
	for (int iCount = 0; iCount < iSize; iCount++)
		SteCoupleID.push_back(CoupleId());
	SteCoupleID[0].srMessage = "BROADCAST";
	SteCoupleID[0].iMessage = BROADCAST;
	SteCoupleID[1].srMessage = "ONE";
	SteCoupleID[1].iMessage = ONE;
	SteCoupleID[2].srMessage = "TWO";
	SteCoupleID[2].iMessage = TWO;
	SteCoupleID[3].srMessage = "THREE";
	SteCoupleID[3].iMessage = THREE;
	SteCoupleID[4].srMessage = "TEMPORARY";
	SteCoupleID[4].iMessage = TEMPORARY;
	SteCoupleID[5].srMessage = "SERVER_I2C";
	SteCoupleID[5].iMessage = SERVER_I2C;
}