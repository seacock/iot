/*
 * RxQRf.c
 *
 *  Created on: 06 nov 2018
 *      Author: andre
 */

/*
 * Copyright (c) 2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/***** Includes *****/
/* Standard C Libraries */

/* Application Header files */
#include "smartrf_settings/smartrf_settings.h"

#include <^QueueRf.h>
#include <^Common.h>

#include <stdlib.h>


//uint32_t auiTemporary[COMPOSED_LENGTH];//---
#pragma DATA_ALIGN(aucRxBuffer, 4)   //+++ Buffer contains all Data Entries for receiving data. Pragmas needed to make sure aucRxBuffer is 4 byte aligned (requirement from the RF Core).
uint8_t aucRxBuffer[BUFFER_SIZE_BYTES];

static uint8_t aucRawPackets[RAW_LENGTH]; //+++ 1) The sequence of RX_BUFFER_ENTRIES couples received. Apart the first sync couple, each remaining couple is upper and lower byte of Adc.
static uint32_t auiComposedP[COMPOSED_LENGTH]; //+++ Each element is composed of a corresponding couple of elements of aucRawPackets.    //--- uint16_t App goes nuts.
int iTwoSteps = 0, iStartBound = 0;  //+++ 1) Every 2 steps a couple is ready to compose a value for auiComposedP. 2) Position of first element of first packet of couple.
int iReceivedPacket = 0, iComposed = 0; //+++ Index of received single packet. 2) Index of composed packet.

/***** Prototypes *****/
static void callback(RF_Handle h, RF_CmdHandle ch, RF_EventMask e);
void StartDisplayTf(void);
void ComposeCouple(void);

/***** Variable declarations *****/
static RF_Object rfObject;
static RF_Handle rfHandle;

/* Receive dataQueue for RF Core to fill in data */
dataQueue_t queue;
rfc_dataEntryGeneral_t *rxEntry;
static uint8_t packet[TX_PAYLOAD_LENGTH]; //---

Void RxRadioTf(UArg arg0, UArg arg1);
Task_Struct RxRadioTr;
#pragma DATA_ALIGN(RxRadioTaskStack, 8)  //+++ 1-byte alignment on the stack to avoid wasting memory.
static uint8_t RxRadioTaskStack[STACKSIZE];

void StartDisplayTf(void);
Void DisplayTf(UArg arg0, UArg arg1);
Task_Struct DisplayTr;
#pragma DATA_ALIGN(DisplayTaskStack, 8)  //+++ 1-byte alignment on the stack to avoid wasting memory.
static uint8_t DisplayTaskStack[STACKSIZE];

Semaphore_Handle DisplaySemH; //+++ Semaphore to block slow display, leaving scheduler to decide.
Semaphore_Struct DisplaySemStruct;
Semaphore_Params DisplaySemParams;

bool bSynchro = false;

/***** Function definitions *****/

Void RxRadioTf(UArg arg0, UArg arg1)
{
    //+++ Semaphore initialization.
    Semaphore_Params_init(&DisplaySemParams);
    Semaphore_construct(&DisplaySemStruct, 0, &DisplaySemParams);
    DisplaySemH = Semaphore_handle(&DisplaySemStruct);

    StartDisplayTf();//---

    RF_Params rfParams;
    RF_Params_init(&rfParams);  //+++ Radio initialization.

    ArrangeQueueRf(aucRxBuffer, &queue, &rxEntry);

    /* Modify CMD_PROP_RX command for application needs */
    RF_cmdPropRx.pQueue = &queue;   //+++ Set the Data Entity queue for received data.
    RF_cmdPropRx.rxConf.bAutoFlushIgnored = 1;  //+++ Discard ignored packets from Rx queue.
    RF_cmdPropRx.rxConf.bAutoFlushCrcErr = 1;   //+++ Discard packets with CRC error from Rx queue.

    /* Implement packet length filtering to avoid PROP_ERROR_RXBUF */
    RF_cmdPropRx.maxPktLen = DATA_SECTION_SIZE;
    RF_cmdPropRx.pktConf.bRepeatOk = 1;
    RF_cmdPropRx.pktConf.bRepeatNok = 1;

    rfHandle = RF_open(&rfObject, &RF_prop, (RF_RadioSetup*)&RF_cmdPropRadioDivSetup, &rfParams);   //+++ Request access to the radio.
    RF_postCmd(rfHandle, (RF_Op*)&RF_cmdFs, RF_PriorityNormal, NULL, 0);    //+++ Set the frequency.

    RF_EventMask terminationReason = RF_runCmd(rfHandle, (RF_Op*)&RF_cmdPropRx, RF_PriorityNormal, &callback, RF_EventRxEntryDone); //+++ Enter RX mode.

    switch(terminationReason)
    {
        case RF_EventLastCmdDone:
            //+++ A stand-alone radio operation command or the last radio operation command in a chain finished.
            break;
        case RF_EventCmdCancelled:
            //+++ Command cancelled before it was started; it can be caused by RF_cancelCmd() or RF_flushCmd().
            break;
        case RF_EventCmdAborted:
            //+++ Abrupt command termination caused by RF_cancelCmd() or RF_flushCmd().
            break;
        case RF_EventCmdStopped:
            //+++ Graceful command termination caused by RF_cancelCmd() or RF_flushCmd().
            break;
        default:
            //+++ Uncaught error event.
            while(1);
    }

    uint32_t cmdStatus = ((volatile RF_Op*)&RF_cmdPropRx)->status;
    switch(cmdStatus)
    {
        case PROP_DONE_OK:
            //+++ Packet received with CRC OK. Display_printf(DisplayH, 0, 0, "1");
            break;
        case PROP_DONE_RXERR:
            //+++ Packet received with CRC error. Display_printf(DisplayH, 0, 0, "2");
            break;
        case PROP_DONE_RXTIMEOUT:
            //+++ Observed end trigger while in sync search. Display_printf(DisplayH, 0, 0, "3");
            break;
        case PROP_DONE_BREAK:
            //+++ Observed end trigger while receiving packet when the command is configured with endType set to 1. Display_printf(DisplayH, 0, 0, "4");
            break;
        case PROP_DONE_ENDED:
            //+++ Received packet after having observed the end trigger;
            //+++ if the command is configured with endType set to 0, the end trigger will not terminate an ongoing reception.Display_printf(DisplayH, 0, 0, "5");
            break;
        case PROP_DONE_STOPPED:
            //+++ received CMD_STOP after command started and, if sync found, packet is received. Display_printf(DisplayH, 0, 0, "6");
            break;
        case PROP_DONE_ABORT:
            //+++ Received CMD_ABORT after command started. Display_printf(DisplayH, 0, 0, "7");
            break;
        case PROP_ERROR_RXBUF:
            //+++ No RX buffer large enough for the received data available at the start of a packet. Display_printf(DisplayH, 0, 0, "8");
            break;
        case PROP_ERROR_RXFULL:
            //+++ Out of RX buffer space during reception in a partial read. Display_printf(DisplayH, 0, 0, "9");
            break;
        case PROP_ERROR_PAR:
            //+++ Observed illegal parameter. Display_printf(DisplayH, 0, 0, "10");
            break;
        case PROP_ERROR_NO_SETUP:
            //+++ Command sent without setting up the radio in a supported mode using CMD_PROP_RADIO_SETUP or CMD_RADIO_SETUP. Display_printf(DisplayH, 0, 0, "11");
            break;
        case PROP_ERROR_NO_FS:
            //+++ Command sent without the synthesizer being programmed. Display_printf(DisplayH, 0, 0, "12");
            break;
        case PROP_ERROR_RXOVF:
            //+++ RX overflow observed during operation. Display_printf(DisplayH, 0, 0, "13");
            break;
        default:
            //+++ Uncaught error event - these could come from the pool of states defined in rf_mailbox.h .
            while(1);
    }

//    while(1); //+++ Don't use or other tasks will starve.
    Display_printf(DisplayH, 0, 0, "RxRadioTf: exit.");
    RF_yield(rfHandle);//---
    RF_close(rfHandle);//---
}

void StartRxRadioTf(void)
{
    Task_Params taskParams;
    Task_Params_init(&taskParams);
    taskParams.stackSize = STACKSIZE;
    taskParams.priority = 2;    //+++ More than 1 or is preempted by while (1) in mainThread.
    taskParams.stack = &RxRadioTaskStack;

    Task_construct(&RxRadioTr, RxRadioTf, &taskParams, NULL);

    PIN_setInterrupt(InputPinH, CC1310_LAUNCHXL_DIO12 | PIN_IRQ_NEGEDGE);//---
}

void callback(RF_Handle h, RF_CmdHandle ch, RF_EventMask e)
{
    if (e & RF_EventRxEntryDone)
    {
        PIN_setOutputValue(LedPinH, BOARD_PIN_RED_LED, !PIN_getOutputValue(BOARD_PIN_RED_LED));    //+++ Toggle pin to indicate RX.

        uint8_t packetLength = *(uint8_t*)(&rxEntry->data); //+++ Packet starts with 1 byte length information (lenSz = 1).
        uint8_t* packetDataPointer = (uint8_t*)(&rxEntry->data + sizeof(packetLength)); //+++ Payload follows.
        memcpy(packet, packetDataPointer, packetLength);   //+++ Read the payload from the Rx buffer.
        ((volatile rfc_dataEntryGeneral_t*)rxEntry)->status = DATA_ENTRY_PENDING;   //+++ Mark the entry as being read.
        rxEntry = ((rfc_dataEntryGeneral_t*)rxEntry->pNextEntry);  //+++ Get the next entry.

        if (bSynchro == false)
        {
            uint8_t synchro[TX_PAYLOAD_LENGTH];
            memset(synchro, 'A', TX_PAYLOAD_LENGTH);
            if (!strncmp((char*)packet, (char*)synchro, TX_PAYLOAD_LENGTH))
                bSynchro = true;
        }

        if (bSynchro == true && iReceivedPacket < RX_BUFFER_ENTRIES * TX_PAYLOAD_FORMAT)
            ComposeCouple();
    }
}

Void DisplayTf(UArg arg0, UArg arg1)
{
    while (1)
    {
        Semaphore_pend(DisplaySemH, BIOS_WAIT_FOREVER);    //+++ Wait on sem indefinitely.
        uint32_t *auiTemporary = (uint32_t*)malloc(COMPOSED_LENGTH * sizeof(uint32_t));

        int iBound;
        for (iBound = 0; iBound < COMPOSED_LENGTH; iBound++)    //---
            auiTemporary[iBound] = auiComposedP[iBound];
        for (iBound = 0; iBound < COMPOSED_LENGTH; iBound++)    //---
            Display_printf(DisplayH, 0, 0, "auiTemporary: %d     seq: %d", auiTemporary[iBound], iBound);

        free(auiTemporary);
        PIN_setInterrupt(InputPinH, CC1310_LAUNCHXL_DIO12 | PIN_IRQ_NEGEDGE);
    }
//    PIN_close(&ledPinHandle);//---
}

void StartDisplayTf(void)
{
    Task_Params taskParams;
    Task_Params_init(&taskParams);
    taskParams.stackSize = STACKSIZE;
    taskParams.priority = 2;    //+++ More than 1 or is preempted by while (1) in mainThread.
    taskParams.stack = &DisplayTaskStack;

    Task_construct(&DisplayTr, DisplayTf, &taskParams, NULL);
}

void ComposeCouple(void)
{
    iReceivedPacket++;
    strcat((char*)aucRawPackets, (char*)packet);

    iTwoSteps++;
    if (iTwoSteps == 2)
    {
        if (iStartBound == TX_PAYLOAD_LENGTH * TX_PAYLOAD_FORMAT * RX_BUFFER_ENTRIES)
            iStartBound = 0;

        //+++ For each couple: compose each position of first packet, with the same position of second packet.
        uint16_t usUpper, usLower;
        int iBound;
        for (iBound = iStartBound; iBound < iStartBound + TX_PAYLOAD_LENGTH; iBound++)
        {
            usUpper = aucRawPackets[iBound] << 8;
            usLower = aucRawPackets[iBound + TX_PAYLOAD_LENGTH];
            auiComposedP[iComposed++] = usUpper + usLower;
        }
        iStartBound += TX_PAYLOAD_LENGTH * TX_PAYLOAD_FORMAT / iTwoSteps;   //+++
        iTwoSteps = 0;
    }

    //+++ Last couple has been processed: start over counters and variables.
    if (iReceivedPacket == RX_BUFFER_ENTRIES * TX_PAYLOAD_FORMAT)
    {
        aucRawPackets[0] = '\0';    //+++ Avoid going out of bounds.
        iReceivedPacket = 0;
        iComposed = 0;
        bSynchro = false;
    }
}

void CC1310_LAUNCHXL_DIO12Cb(PIN_Handle handle, PIN_Id pinId)
{
    CPUdelay(100); //+++ Not too long or Radio cmdStatus=PROP_ERROR_RXBUF .

    //+++ Debounce logic.
    if (PIN_getInputValue(CC1310_LAUNCHXL_DIO12) == 0)
    {
        PIN_setInterrupt(InputPinH, CC1310_LAUNCHXL_DIO12 | PIN_IRQ_DIS);
        PIN_setOutputValue(LedPinH, BOARD_PIN_GREEN_LED, !PIN_getOutputValue(BOARD_PIN_GREEN_LED)); //+++
        Semaphore_post(DisplaySemH);   //+++ Post to semaphore.//---
    }
}
