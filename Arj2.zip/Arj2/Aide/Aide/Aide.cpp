// Aide.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <stdlib.h>  

int main()
{
	char   psBuffer[128];
	FILE   *pPipe;

	if ((pPipe = _popen("plink root@raspberrypi -pw root pgrep -u root Rym", "rt")) == NULL)
		exit(1);

	/* Read pipe until end of file, or an error occurs. */
	while (fgets(psBuffer, 128, pPipe))
		printf(psBuffer);

	/* Close pipe and print return value of pPipe. */
	if (feof(pPipe))
		printf("\nProcess returned %d\n", _pclose(pPipe));
	else
		printf("Error: Failed to read the pipe to the end.\n");

	int   i;
	scanf("%d", &i);

    return 0;
}

