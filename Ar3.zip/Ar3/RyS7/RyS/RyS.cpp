#include "RyS.h"
cpu_set_t ThreadInfo::SstSet1, ThreadInfo::SstSet2, ThreadInfo::SstSet3;
StateSpi Sensor::SenStateSpi = STATE_Potentiometer;
pthread_cond_t Sensor::ScondPotentiometer = PTHREAD_COND_INITIALIZER;
pthread_cond_t Sensor::ScondThermometer = PTHREAD_COND_INITIALIZER;
pthread_mutex_t Sensor::SmutexSpi = PTHREAD_MUTEX_INITIALIZER;
string gsrNumber;
typedef void *(*ThreadProcP)(void*); 	//+++ Declares a type of a ptr to a function that accepts a void ptr and returns a void ptr.
ThreadProcP afp[4];   //++ Declares the array of function ptrs.
string ThreadInfo::SsrI2cServerPort = "12300";
string ThreadInfo::SsrTom8ServerPort = "8080";
string ThreadInfo::SsrRemSvrPortR3 = "80";
string ThreadInfo::SsrRemSvrPortNi = "8080";
string ThreadInfo::SsrLANServerHost;
string ThreadInfo::SsrLANServerPort;
int I2c::SiFdI2c;
StateI2c I2c::SenStateI2c = STATE_Off;
pthread_cond_t I2c::ScondI2c = PTHREAD_COND_INITIALIZER;
pthread_mutex_t I2c::SmutexI2c = PTHREAD_MUTEX_INITIALIZER;
pthread_barrier_t ThreadInfo::Sbarrier5;
int ModeComm::SiMode = I2C_RY_NORMAL;
char Wlan0Inet4::SacInternetAddress[INET_ADDRSTRLEN];
char Wlan0Inet4::SacLineDescription[INET_ADDRSTRLEN];
char Wlan0Inet4::SacNetmask[INET_ADDRSTRLEN];
char Wlan0Inet4::SacBroadcastAddr[INET_ADDRSTRLEN];
string ThreadInfo::SsrServerPort = "7000";
string ThreadInfo::SsrRes = "ServerMix ";
int iUartHandle;//??????

int main(int argc, char *argv[])
{
	if (argc == 3)
	{
		ThreadInfo::SsrI2cServerPort = argv[1];
		ThreadInfo::SsrTom8ServerPort = argv[2];
	}
	else if (argc != 1)
	{
		cout << "Specify I2cServerPort and Tom8ServerPort." << endl;
		exit(EXIT_FAILURE);
	}

	LocalIpFromGoogle();

#ifdef _WEBTOM8_
	TomcatSetUp(true);
#endif // _WEBTOM8_	

	FillCoupleId();
	InterfacesIp();
	SchedAff();
	
	if (wiringPiSetup() == -1)
	{
		cout << "Unable to start wiringPi\n";
		return 1 ;
	}
	pinMode(SWITCH_INC, INPUT);
	pinMode(SWITCH_DEC, INPUT);

	iUartHandle = UartSetup();
	
	wiringPiSPISetup(SPI_CHANNEL, SPI_SPEED);
	
	int iAddr = 0x04; 	//+++ ID. This device identifier can have other values.
	if ((I2c::SiFdI2c = wiringPiI2CSetup(iAddr)) == -1)	//+++ Initialize the interface by giving it ID. It returns a standard file descriptor.
		handle_error("wiringPiI2CSetup()");
	
	pthread_barrier_init(&ThreadInfo::Sbarrier5, NULL, 5);
	
	afp[0] = BroadTp;
	afp[1] = SocTxRxTp;
	afp[2] = I2cServTp;
	afp[3] = ServerSocketTp;
	PoolThread(NUM_THREADS);

#ifdef _WEBTOM8_
	TomcatSetUp(false);		
#endif // _WEBTOM8_		

	exit(EXIT_SUCCESS);
}

void PoolThread(int iNumThreads)
{
	int iRes;
	ThreadInfo *pstThrInf = CreateThread(pstThrInf, iNumThreads, afp);

	for (int iNum = 0; iNum < iNumThreads; iNum++)	//+++ Now join with each thread.
		{
			void *res;
			iRes = pthread_join(pstThrInf[iNum].ulThread_id, &res);
			if (iRes != 0)
				handle_error_en(iRes, "pthread_join");
#ifdef _BRIEF_
			CColorText coltGreen(CColorText::GREEN);
			coltGreen.ss << "Thread " << iNum << " exiting with status :" << res << endl;
			cout << coltGreen;
#endif // _BRIEF_
		}

	delete[] pstThrInf;

#ifdef _BRIEF_
	CColorText coltGreen(CColorText::GREEN);
	coltGreen.ss << "Application exits." << endl;
	cout << coltGreen;
#endif // _BRIEF_		
}

void* SocTxRxTp(void *arg)
{
	CColorText coltGreen(CColorText::GREEN);
	ThreadInfo *pstThrInf = (ThreadInfo*)arg;

	int iRes;
	switch (pstThrInf->iThreadNum)
	{
	case ONE:
		iRes = sched_setaffinity(0, sizeof(ThreadInfo::SstSet1), &ThreadInfo::SstSet1);
		break;
	case TWO:
		iRes = sched_setaffinity(0, sizeof(ThreadInfo::SstSet2), &ThreadInfo::SstSet2);
		break;
	case THREE:
		iRes = sched_setaffinity(0, sizeof(ThreadInfo::SstSet2), &ThreadInfo::SstSet2);
		break;
	case TEMPORARY:
		iRes = sched_setaffinity(0, sizeof(ThreadInfo::SstSet1), &ThreadInfo::SstSet1);
		break;
	}

	if (iRes == -1)
		handle_error_en(iRes, "sched_setaffinity");

	pthread_barrier_wait(&ThreadInfo::Sbarrier5);

#ifdef _BRIEF_
	DisplayThreadSchedAttr(pstThrInf->pcInfoArg);
	cpu_set_t stSet;
	sched_getaffinity(0, sizeof(stSet), &stSet);
	for (int iCount = 0; iCount < 4; iCount++)
		if (CPU_ISSET_S(iCount, sizeof(stSet), &stSet))
		{
			coltGreen.ss << "affinity: " << iCount << endl;
			cout << coltGreen;
		}

#endif // _BRIEF_

	int iSock = SockAddrConn(ThreadInfo::SsrLANServerHost.c_str(), atoi(ThreadInfo::SsrLANServerPort.c_str()));
	int iOn = 1; 	//+++ Selector for socket options.//???
	if (SrNonblockFlag(iSock, iOn) < 0)	//+++ Set socket to be non-blocking. In fact, when ModeComm::SiMode is set to I2C_RY_EXIT or to I2C_RY_SHUT_COMM, Asi has already closed its connection and this write would block. This can have two effects: 1)this app gets stuck; 2)Asi can block when trying to terminate because not all the threads it is waiting for from here are terminated.
		CloseFdErr(iSock, "fcntl()"); //???

	bool bOnlyOneTime = false;

	//+++ Send data to the server.
	if (pstThrInf->iThreadNum == ONE)
	{
		WriteToServer(iSock, pstThrInf->pcInfoArg);

		while (ModeComm::SiMode != I2C_RY_EXIT)
		{
			if (ModeComm::SiMode == I2C_LAPTOP_DISMISS && bOnlyOneTime == false)
			{
				close(iSock); 	//+++ This gets out from its endless loop, recv on laptop side (ReceiveFromMcTp).
				bOnlyOneTime = true;
			}
			BtnIncDec(iSock);
		}			
	}
	else if (pstThrInf->iThreadNum == TWO)
	{
		Sensor stPoten;
		stPoten.srIdMsg = pstThrInf->pcInfoArg;
		stPoten.uiDelay = 100;
		stPoten.ucUpper = CMD_UB_P;
		stPoten.ucLower = CMD_LB_P;
		stPoten.srName = "Potentiometer";
		stPoten.uiNumOfSpiCalls = 0;
		stPoten.ulTotNumOfSpiCalls = 0;
		stPoten.uiTomcatCounter = 0;
		stPoten.uiLaptopCounter = 0;

		WriteToServer(iSock, stPoten.srIdMsg.c_str());

		while (ModeComm::SiMode != I2C_RY_EXIT)
		{
			//+++ Wait for genStateSpi STATE_Potentiometer.
			pthread_mutex_lock(&Sensor::SmutexSpi);
			while (Sensor::SenStateSpi != STATE_Potentiometer)
				pthread_cond_wait(&Sensor::ScondPotentiometer, &Sensor::SmutexSpi);
			pthread_mutex_unlock(&Sensor::SmutexSpi);

			if (ModeComm::SiMode == I2C_LAPTOP_DISMISS && bOnlyOneTime == false)
			{
				close(iSock); 	//+++ This gets out from its endless loop, recv on laptop side (ReceiveFromMcTp).
				bOnlyOneTime = true;
			}

			SpiMaster(iSock, stPoten); 	//+++ Execute shared routine while thread THREE is waiting.//??????

			//+++ Set genStateSpi to STATE_Thermometer and wake up thread THREE.
			pthread_mutex_lock(&Sensor::SmutexSpi);
			Sensor::SenStateSpi = STATE_Thermometer;
			pthread_cond_signal(&Sensor::ScondThermometer);
			pthread_mutex_unlock(&Sensor::SmutexSpi);
		}
	}
	else if (pstThrInf->iThreadNum == THREE)
	{
		Sensor stThermo;
		stThermo.srIdMsg = pstThrInf->pcInfoArg;
		stThermo.uiDelay = 100;
		stThermo.ucUpper = CMD_UB_T;
		stThermo.ucLower = CMD_LB_T;
		stThermo.srName = "Thermometer";
		stThermo.uiNumOfSpiCalls = 0;
		stThermo.ulTotNumOfSpiCalls = 0;
		stThermo.uiTomcatCounter = 0;
		stThermo.uiLaptopCounter = 0;

		WriteToServer(iSock, stThermo.srIdMsg.c_str());

		while (ModeComm::SiMode != I2C_RY_EXIT)
		{
			//+++ Wait for genStateSpi STATE_Thermometer.
			pthread_mutex_lock(&Sensor::SmutexSpi);
			while (Sensor::SenStateSpi != STATE_Thermometer)
				pthread_cond_wait(&Sensor::ScondThermometer, &Sensor::SmutexSpi);
			pthread_mutex_unlock(&Sensor::SmutexSpi);

			if (ModeComm::SiMode == I2C_LAPTOP_DISMISS && bOnlyOneTime == false)
			{
				close(iSock); 	//+++ This gets out from its endless loop, recv on laptop side (ReceiveFromMcTp).
				bOnlyOneTime = true;
			}

			SpiMaster(iSock, stThermo); 	//+++ Execute shared routine while thread TWO is waiting.	//??????

			//+++ Set genStateSpi to STATE_Potentiometer and wake up thread TWO.
			pthread_mutex_lock(&Sensor::SmutexSpi);
			Sensor::SenStateSpi = STATE_Potentiometer;
			pthread_cond_signal(&Sensor::ScondPotentiometer);
			pthread_mutex_unlock(&Sensor::SmutexSpi);
		}
	}
	else if (pstThrInf->iThreadNum == TEMPORARY)
	{
		//+++ Wait for SenStateI2c STATE_On.
		pthread_mutex_lock(&I2c::SmutexI2c);
		while (I2c::SenStateI2c != STATE_On)
			pthread_cond_wait(&I2c::ScondI2c, &I2c::SmutexI2c);
		pthread_mutex_unlock(&I2c::SmutexI2c);

		//+++ Here I'm sending data to a receiver without a back confirmation: (local write)->(remote receive), without control of the stream. There isn't the certainty that a sequence of local write will produce the same sequence of remote receive. Instead it's possible that many local write compose a single remote receive if the remote buffer is big enough: this creates problems at receiver. It's better to send a single composite string and the receiver will break it up following instructions.
		string srDelim = "-_-_";
		string srComp = pstThrInf->pcInfoArg + srDelim + 
								"to_string(I2cMaster(I2c::SiFdI2c, ADC_AVERAGE, INVALID_FD))" + srDelim + //??????
								"to_string(I2cMaster(I2c::SiFdI2c, PWM_FUNCTION, INVALID_FD))" + srDelim + //??????
								ThreadInfo::SsrI2cServerPort + srDelim + 
								ThreadInfo::SsrRemSvrPortR3 + srDelim + 
								ThreadInfo::SsrRemSvrPortNi + srDelim;
		WriteToServer(iSock, srComp.c_str());
	}

	close(iSock); 	//+++ This gets out from its endless loop, recv on laptop side (ReceiveFromMcTp).
}

ThreadInfo* CreateThread(ThreadInfo* pstThIn, int iNThreads, void *(**ppStartRoutine)(void*))
{
	int iRes;
	pthread_attr_t unAttr;
	ThreadAttr(unAttr);

	pstThIn = new ThreadInfo[iNThreads]; 	//+++ Allocate memory for pthread_create arguments.
	if (pstThIn == NULL)
		handle_error1("new");

	for (int iNum = 0; iNum < iNThreads; iNum++)	//+++ Create all threads.
	{
		pstThIn[iNum].iThreadNum = SteCoupleID[iNum].iMessage;
		strcpy(pstThIn[iNum].pcInfoArg, SteCoupleID[iNum].srMessage.c_str());

		//+++ The pthread_create call stores the thread ID into corresponding element of pstThIn[].
		if (pstThIn[iNum].iThreadNum == BROADCAST)
			iRes = pthread_create(&pstThIn[iNum].ulThread_id, &unAttr, ppStartRoutine[0], &pstThIn[iNum]);
		else if (pstThIn[iNum].iThreadNum >= ONE && pstThIn[iNum].iThreadNum <= TEMPORARY)
			iRes = pthread_create(&pstThIn[iNum].ulThread_id, &unAttr, ppStartRoutine[1], &pstThIn[iNum]);
		else if (pstThIn[iNum].iThreadNum == SERVER_I2C)
			iRes = pthread_create(&pstThIn[iNum].ulThread_id, &unAttr, ppStartRoutine[2], &pstThIn[iNum]);
		else if (pstThIn[iNum].iThreadNum == SERV_MIX_JC)
			iRes = pthread_create(&pstThIn[iNum].ulThread_id, &unAttr, ppStartRoutine[3], &pstThIn[iNum]);
		if (iRes != 0)
			handle_error_en(iRes, "pthread_create");
	}

	//+++ Destroy the thread attributes object, since it is no longer needed.
	iRes = pthread_attr_destroy(&unAttr);
	if (iRes != 0)
		handle_error_en(iRes, "pthread_attr_destroy");

	return pstThIn;
}

int SockAddrConn(const char* pcHostName, uint16_t usiPort)
{
	int iSockFd, iRes; 	//+++ Socket file descriptor; result code.
	addrinfo stHints, *pstServInfo, *pstBrowse; 	//+++ Criteria for selection; returned list of socket address structs; ptr for looking through returned list.

	memset(&stHints, 0, sizeof stHints);
	stHints.ai_family = AF_UNSPEC;  //+++ Either IPv4 or IPv6.
	stHints.ai_socktype = SOCK_STREAM;//???
	if ((iRes = getaddrinfo(pcHostName, NumberToString(usiPort).c_str(), &stHints, &pstServInfo)) != 0)
		handle_error2("getaddrinfo", gai_strerror(iRes));

	//+++ Loop through all the results and connect to the first available.
	for(pstBrowse = pstServInfo ; pstBrowse != NULL ; pstBrowse = pstBrowse->ai_next)
	{
		if ((iSockFd = socket(pstBrowse->ai_family, pstBrowse->ai_socktype, pstBrowse->ai_protocol)) == INVALID_SOCKET)
		{
			perror("socket()");
			continue;
		}

		timeval stTv; 	//+++ Doesn't work in debug.
		stTv.tv_sec = 15;   //+++ 15 Secs Timeout. Then below connect fails and, with no connections, app eventually closes.
		stTv.tv_usec = 0; 	//+++ Initialize always or error occurs.
		if (setsockopt(iSockFd, SOL_SOCKET, SO_SNDTIMEO, (timeval*)&stTv, sizeof(timeval)) == -1)
			handle_error("setsockopt()");

		//+++ connect can fail also if the server isn't enabled by its firewall to communicate through public/private network.
		if (connect(iSockFd, pstBrowse->ai_addr, pstBrowse->ai_addrlen) == -1)
		{
			perror("connect()");
			close(iSockFd);
			continue;
		}

		break; //+++ Connection must have been successful.
	}
	string srThreadID = NumberToString(pthread_self());
	srThreadID += " --->Thread ID: failed to connect";
	if (pstBrowse == NULL)
		handle_error1(srThreadID.c_str()); 	//+++ Looped off the end of the list with no connection.

	freeaddrinfo(pstServInfo);  //+++ All done with this structure.

	return iSockFd;
}

void FillCoupleId()
{
	int iSize = SteCoupleID.size();
	for (int iCount = 0; iCount < iSize; iCount++)
		SteCoupleID.push_back(CoupleId());
	SteCoupleID[0].srMessage = "BROADCAST";
	SteCoupleID[0].iMessage = BROADCAST;
	SteCoupleID[1].srMessage = "ONE";
	SteCoupleID[1].iMessage = ONE;
	SteCoupleID[2].srMessage = "TWO";
	SteCoupleID[2].iMessage = TWO;
	SteCoupleID[3].srMessage = "THREE";
	SteCoupleID[3].iMessage = THREE;
	SteCoupleID[4].srMessage = "TEMPORARY";
	SteCoupleID[4].iMessage = TEMPORARY;
	SteCoupleID[5].srMessage = "SERVER_I2C";
	SteCoupleID[5].iMessage = SERVER_I2C;
	SteCoupleID[6].srMessage = "SERV_MIX_JC";
	SteCoupleID[6].iMessage = SERV_MIX_JC;
}