/*
 * File:   Uart.c
 * Author: Administrator
 *
 * Created on 08 March 2018, 15:48
 */


#include "Uart.h"

int main(void) {
//    INTCON1bits.NSTDIS = 1;     //+++ Interrupt nesting is disabled.
    SetupClock();
    ConfigUartPortPins();
    ConfigUartPPS();
    
    TRISBbits.TRISB2 = OUTPUT_PIN;
    PORTBbits.RB2 = 0;
    ConfigUart();
    /* Wait at least 105 microseconds (1/9600) before sending first char */
    DELAY_105uS
    U1TXREG = 'z'; // Transmit one character
    
    while(1);

    return 0;
}

void _ISR _U1TXInterrupt(void)
{
    IFS0bits.U1TXIF = 0; // Clear TX Interrupt flag
    DELAY_105uS //+++ Important.
    U1TXREG = acMessage[iCount++]; // Transmit one character
    if (iCount == 14)
        iCount = 0;  
}

void _ISR _U1RXInterrupt(void)
{
    IFS0bits.U1RXIF = 0; // Clear RX Interrupt flag
    DELAY_105uS //+++ Important.
    char ReceivedChar;
    
    int iii=1;
/* Check for receive errors */
//if(U1STAbits.FERR == 1)
//{
////continue;
//    return;
//}
/* Must clear the overrun error to keep UART receiving */
//if(U1STAbits.OERR == 1)
//{
//U1STAbits.OERR = 0;
////continue;
//return;
//}
/* Get the data */
//if(U1STAbits.URXDA == 1)
{
ReceivedChar = U1RXREG;
if (ReceivedChar==51)
{
    iii=0;
    PORTBbits.RB2 = 1;
}
}
}

void ConfigUartPortPins(void)
{    
    AD1PCFG = 0xFFFF;   //+++ Turn off analogue functions on all pins.

    TRISBbits.TRISB0 = OUTPUT_PIN;  //+++ U1TX: hwPin = 4.
    TRISBbits.TRISB1 = INPUT_PIN;   //+++ U1RX: hwPin = 5.
}

void ConfigUartPPS(void)
{
    PPSUnLock;  //+++ Unlock the PPS functionality.
    iPPSOutput(OUT_PIN_PPS_RP0, OUT_FN_PPS_U1TX);   //+++ U1TX: hwPin = 4.
    iPPSInput(IN_FN_PPS_U1RX, IN_PIN_PPS_RP1);    //+++ U1RX: hwPin = 5.
    PPSLock;    //+++ Lock the PPS functionality.
}

void SetupClock(void)
{
    unsigned int pllCounter;
    OSCCONBITS OSCCONbitsCopy;

    // Copy the current Clock Setup
    OSCCONbitsCopy = OSCCONbits;
    // Slow output clock down to 4Mhz
    CLKDIVbits.CPDIV = 3;
    // Enable the PLL - Note: Fuse bits don't do this
    CLKDIVbits.PLLEN = 1;
    // Wait for the PLL to stabalise
    for (pllCounter = 0; pllCounter < 600; pllCounter++);

    // Check to see what clock setup is defined - either internal or external
    #ifdef USE_FRC_CLOCK
        // Setup the uC to use the internal FRCPLL mode
        OSCCONbitsCopy.NOSC = 1;
        OSCCONbitsCopy.OSWEN = 1;
    #else
        // Setup the uC to use the external crystal with the PLL
        OSCCONbitsCopy.NOSC = 3;
        OSCCONbitsCopy.OSWEN = 1;
    #endif

    // Switch over to the new clock setup
    __builtin_write_OSCCONH( BITS2BYTEH( OSCCONbitsCopy ) );
    __builtin_write_OSCCONL( BITS2BYTEL( OSCCONbitsCopy ) );
    // Wait for this transfer to take place
    while (OSCCONbits.COSC != OSCCONbits.NOSC);
    // Setup the DIV bits for the FRC, this values means the config word needs to be: PLLDIV_DIV2
    CLKDIVbits.RCDIV0 = 0;

    // Setup the PLL divider for the correct clock frequency
    if (CLOCK_FREQ == 32000000)
    {
        CLKDIVbits.CPDIV = 0;
    }
    else if (CLOCK_FREQ == 16000000)
    {
        CLKDIVbits.CPDIV = 1;
    }
    else if (CLOCK_FREQ == 8000000)
    {
        CLKDIVbits.CPDIV = 2;
    }
    else if (CLOCK_FREQ == 4000000)
    {
        CLKDIVbits.CPDIV = 3;
    }

    // Check that the PLL is enabled again and locked properly to the new setup
    CLKDIVbits.PLLEN = 1;
    // Note - don't want to do this check if we are running in the MPLAB X simulator as it won't work
    #ifndef __MPLAB_SIM
        while(_LOCK != 1);
    #endif

    // At this point the PIC24FJ64GB004 clock setup will be complete with the PLL
    // enabled and ready for operation with USB2.0
}

void ConfigUart(void)
{
    U1MODEbits.STSEL = 0; // 1-Stop bit
    U1MODEbits.PDSEL = 0; // No Parity, 8-Data bits
    U1MODEbits.ABAUD = 0; // Auto-Baud disabled
    U1MODEbits.BRGH = 0; // Standard-Speed mode
    U1BRG = BRGVAL; // Baud Rate setting for 9600
    U1STAbits.UTXISEL0 = 0; // Interrupt after one TX character is transmitted
    U1STAbits.UTXISEL1 = 0;
    IEC0bits.U1TXIE = 1; // Enable UART TX interrupt
    
    //////////////////////////////
    U1STAbits.URXISEL = 0; // Interrupt after one RX character is received;
    IEC0bits.U1RXIE = 1; // Enable UART RX interrupt
    //////////////////////////////
    
    U1MODEbits.UARTEN = 1; // Enable UART
    U1STAbits.UTXEN = 1; // Enable UART TX
}