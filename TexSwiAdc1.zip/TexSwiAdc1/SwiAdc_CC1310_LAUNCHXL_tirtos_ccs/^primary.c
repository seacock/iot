/*
 * Copyright (c) 2015-2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== primary.c ========
 */
/* For usleep() */
#include <unistd.h>
#include <stdint.h>
#include <stddef.h>

#include <stdio.h>

#include <^adc.h>
#include <^common.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>

/* BIOS module Headers */
#include <ti/sysbios/knl/Clock.h>
#include <ti/sysbios/knl/Swi.h>

Swi_Struct swi0Struct;
Swi_Handle swi0Handle;
uint16_t uiCycle = 0;
char a5cSwiInfo[5][100];

/*
 *  ======== swi0Fxn =======
 */
Void swi0Fxn(UArg arg0, UArg arg1)
{
    uiCycle++;
    if (uiCycle == 4000) {
        GPIO_toggle(Board_GPIO_LED1);
        sprintf(a5cSwiInfo[0], "%d cycles", uiCycle);
        sprintf(a5cSwiInfo[1], "Enter swi0Fxn, a0 = %d, a1 = %d", (Int)arg0, (Int)arg1);
        sprintf(a5cSwiInfo[2], "swi0 trigger = %d", Swi_getTrigger());
        sprintf(a5cSwiInfo[3], "swi0 pri = %d", Swi_getPri(swi0Handle));
        sprintf(a5cSwiInfo[4], "Exit swi0Fxn");
        uiCycle = 0;
    }
    bHigh2 = !bHigh2;
    PIN_setOutputValue(hDynPin, CC1310_LAUNCHXL_DIO12, bHigh2);
}

Void TimerHandler(UArg arg0)
{
    Swi_post(swi0Handle);
    Semaphore_post(hSemADC);   //+++ Post to main loop semaphore.
}

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    bHigh1 = false;
    bHigh2 = false;
    GPIO_init();/* Call driver init functions */

    Semaphore_Struct stSemMain;
    Semaphore_Params stSemParams;

    ADC_init();/* Call driver init functions */

    /* Open Display Driver */
    Display_Params    displayParams;
    Display_Params_init(&displayParams);
    displayHandle = Display_open(Display_Type_UART, NULL);

    GPIO_setConfig(Board_GPIO_LED0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);   //+++ Configure the LED pin.
    GPIO_setConfig(Board_GPIO_LED1, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_HIGH);   //+++ Configure the LED pin.

    //+++ Dynamic pin configuration.
    PIN_Config DynPinCfg[] = {

        CC1310_LAUNCHXL_DIO12 | PIN_GPIO_OUTPUT_EN | PIN_GPIO_HIGH | PIN_PUSHPULL |
                                                            PIN_INPUT_DIS | PIN_DRVSTR_MED,

        CC1310_LAUNCHXL_DIO15 | PIN_GPIO_OUTPUT_EN | PIN_GPIO_HIGH | PIN_PUSHPULL |
                                                            PIN_INPUT_DIS | PIN_DRVSTR_MED,

        PIN_TERMINATE
    };
    PIN_State stPinState;
    hDynPin = PIN_open(&stPinState, DynPinCfg);

    //+++ Semaphore initialization.
    Semaphore_Params_init(&stSemParams);
    Semaphore_construct(&stSemMain, 0, &stSemParams);
    hSemADC = Semaphore_handle(&stSemMain);

    Clock_Params clockParams;
    Clock_Handle myClock;
    Error_Block eb;
    Error_init(&eb);
    Clock_Params_init(&clockParams);
    clockParams.period = 30;
    clockParams.startFlag = TRUE;
    clockParams.arg = (UArg)0x5555;
    myClock = Clock_create(TimerHandler, 5, &clockParams, &eb);
    if (myClock == NULL) {
        System_abort("Clock create failed");
    }

    Types_FreqHz cpuFreq;
    BIOS_getCpuFreq(&cpuFreq);
    StartADCTf();

    Swi_Params swiParams;
    Swi_Params_init(&swiParams);
    swiParams.arg0 = 1;
    swiParams.arg1 = 0;
    swiParams.priority = 2;
    swiParams.trigger = 0;

    Swi_construct(&swi0Struct, (Swi_FuncPtr)swi0Fxn, &swiParams, NULL);
    swi0Handle = Swi_handle(&swi0Struct);

    uint32_t time = 500000;  //+++ ~500 ms
    while (1) {

//        System_printf("ciao\n");
//        System_printf("salve\n");
//        System_flush();

        if (uiCycle == 10) {
            Display_printf(displayHandle, 1, 0, "\n%s", a5cSwiInfo[0]);
            Display_printf(displayHandle, 1, 0, "%s", a5cSwiInfo[1]);
            Display_printf(displayHandle, 1, 0, "%s", a5cSwiInfo[2]);
            Display_printf(displayHandle, 1, 0, "%s", a5cSwiInfo[3]);
            Display_printf(displayHandle, 1, 0, "%s\n", a5cSwiInfo[4]);
        }

        GPIO_toggle(Board_GPIO_LED0);
//        usleep(time);
    }
}
