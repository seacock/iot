#pragma once

#include <iostream>
#include <arpa/inet.h>
#include <sstream>
#include <vector>

using namespace std; 

template <typename T>	//+++ Transform a number to string.
string NumberToString(T Number)
{
	ostringstream ss;
	ss << Number;
	return ss.str();
}

typedef void *(*ThreadProcP)(void*);  	//+++ Declares a type of a ptr to a function that accepts a void ptr and returns a void ptr.

class CAff;   //+++ forward declaration
class CUart;
class CSpi;
class CI2c;

class CRy
{
public:
	const int kiNumThreads = 7;
	enum ThreadList {TL_Broadcast = 1, TL_One = 2, TL_Two = 3, TL_Three = 4, TL_Temporary = 5, TL_ServerI2c = 6, TL_ServMixJC = 7} ;

	struct Util  //+++ needs forward declaration
	{
		CAff *pAff;		
		CRy *pRy;		
		CSpi *pSpi;
		CI2c *pI2c;
		CUart *pUart;
	} stUtil;

	struct PortHost
	{
		string srI2cServerPort; 	//+++ Sent to client laptop ASUS after broadcasting, by TEMPORARY thread: port on which I2cServTp server listens.
		string srTom8ServerPort; 	//+++ Local port of Tomcat8. It's used by local ip address of this app. This app and Tomcat8 reside on RaspberryPi2. 	
		string srRemSvrPortR3; 	//+++ Sent to laptop ASUS after broadcasting, by TEMPORARY thread. For remot3.it it's 80. Given remot3.it host and its port (80), LaptopASUS can get an endpoint address to which to connect a socket.
		string srRemSvrPortNi; 	//+++ Sent to laptop ASUS after broadcasting, by TEMPORARY thread. For noip.com it's the same as srTom8ServerPort. Given noip.com host and its port (8080), LaptopASUS can get an endpoint address to which to connect a socket.
		string srLANServerHost; 	//+++ Received from laptop ASUS when broadcasting: numeric or literal dotted IP of laptop server to which LanTp client thread connects.
		string srLANServerPort; 	//+++ Received from laptop ASUS when broadcasting: port of laptop server to which LanTp client thread connects.
		string srServerPort; //???
		string srRes; //???
		pthread_barrier_t barrier5;  	//+++ Barrier for threads: BROADCAST, ONE, TWO, THREE, TEMPORARY. When barrier gives the go-ahead, SsrLANServerHost and SsrLANServerPort already initialized by BROADCAST, can be used by the other 4 threads.
	} stPortHost;

	//+++ Local network interface.
	struct Wlan0Inet4
	{
		char acInternetAddress[INET_ADDRSTRLEN];
		char acLineDescription[INET_ADDRSTRLEN];
		char acNetmask[INET_ADDRSTRLEN];
		char acBroadcastAddr[INET_ADDRSTRLEN];	//+++ The broadcast address is used to interrogate the remote LaptopASUS.
		const uint16_t kusiBroadcastPort = 13;	//+++ The port on which to send data for broadcast: daytime.
	} stWlan0Inet4;
	
	struct ThreadInfo	//+++ Used as argument to LanTp()...
	{
		pthread_t ulThread_id; 	//+++ ID returned by pthread_create().
		int iThreadNum; 	//+++ Application-defined thread #.
		static cpu_set_t stSet1, stSet2, stSet3; //??????
		char pcInfoArg[50]; 	//+++ First argument sent to Asi server ReceiveTp. ReceiveTp uses that to recognize which kind of thread has connected.
		Util *pstUtil;
	};
		
	struct CoupleId	//+++ First time identification msg for thread related to: broadcasting; local pushbuttons; SPI(potentiometer processed by Pic24); SPI (thermometer processed by Pic24); laptop client setup; I2C (Pic24). Not all are used.
	{
		string srMessage;
		int iMessage;
	};

	ThreadProcP afp[4];     //++ Declares the array of function ptrs.
	vector<CoupleId> teCoupleID; //+++ Store identification msg for all threads created by app.//??? AAA
	ThreadInfo *pstThrInf;
	enum State
	{
		RyNormal      = 200,	//+++ 
		RyExit        = 201,	//+++ RyS's communication threads stop communication and RyS exit. Defined in Asi, RyS.
		RyShutComm    = 202,	//+++ RyS's communication threads stop communication, but RyS continues working. Defined in Asi, RyS.
		LaptopDismiss = 203		//+++ Laptop is dismissed, but RyS continues working. Defined in Asi, RyS.
	} enStateDevice = RyNormal;

	const int kiButtonInc = 1;	//+++ (RaspberryPi2 40-pin header J8: pin 12 hardware = GPIO 18 BCM) = (wiringPi: GPIO1 = pin 1 software)
	const int kiButtonDec = 4;	//+++ (RaspberryPi2 40-pin header J8: pin 16 hardware = GPIO 23 BCM) = (wiringPi: GPIO4 = pin 4 software)

	CRy();
	~CRy();
	void CloseFdErr(int iFd, const char* pcErr = NULL);    	//???
	void FillCoupleId(); 	//+++ Populate vector holding identification msg for all threads created by app.	
	void PoolThread(int iNumThreads);  	//+++ Create and join kiNumThreads threads.
	void CreateThread(int iNThreads, void *(**ppStartRoutine)(void*));   	//+++ Create child threads.
	int SockAddrConn(const char* pcHostName, uint16_t usiPort); 	//+++ Get host's internet address from its name and service-port; connect to server laptop ASUS within Eolo Fritz!Box LAN router. getaddrinfo(): Jessie recognized "localhost" and other alphanumeric host names, instead Stretch doesn't; Stretch wants pcHostName in the dotted form: "aaa.bbb.ccc.ddd".
};