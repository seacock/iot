#include "I2c.h"
#include "Ry.h"
#include "Spi.h"
#include "SharA.h"
#include <unistd.h>
#include <wiringPiI2C.h>

CI2c::CI2c(CRy *pRaspberry)
{
	pRy = pRaspberry;
	stSync.enStateI2c = STATE_Off;
	stSync.condI2c = PTHREAD_COND_INITIALIZER;
	stSync.mutexI2c = PTHREAD_MUTEX_INITIALIZER;
}

CI2c::~CI2c()
{
}

int CI2c::I2cMaster(int iFdI2cM, unsigned char ucNumber, int iFdLas)
{
	if (wiringPiI2CWrite(iFdI2cM, ucNumber) == -1)	//+++ Send parameter to microcontroller.
		handle_error("wiringPiI2CWrite()");

	//+++ Read twice or can get errors...
	int iRead = wiringPiI2CRead(iFdI2cM); 	//+++ Get back parameter from microcontroller.
	iRead = wiringPiI2CRead(iFdI2cM);  	//+++ Get back parameter from microcontroller.

	if (iRead == -1)
		handle_error("wiringPiI2CRead()");
	else if(iRead == CRy::RyExit || iRead == CRy::RyShutComm || iRead == CRy::LaptopDismiss)
	{
		pRy->enStateDevice = (CRy::State)iRead;
		if (pRy->enStateDevice == CRy::RyExit)
		{
			CSpi *pSpi = pRy->stUtil.pSpi;
			pthread_cond_signal(&pSpi->stSync.condThermometer);
			pthread_cond_signal(&pSpi->stSync.condPotentiometer);			
		}
		return -1;
	}
	
	string srVal = NumberToString(iRead) + '\0'; 	//+++ Important \0 termination.
	if (iFdLas != INVALID_SD)
		return write(iFdLas, srVal.c_str(), srVal.length()); 	//+++ Send back parameter to laptop.
	else
		return iRead; 	//+++ Parameter given back to local app for successive use.
}