/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-E05
 */

#ifndef xconfig_release__
#define xconfig_release__



#endif /* xconfig_release__ */ 
