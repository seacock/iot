#include "stdafx.h"
#include "ShaWa.h"
#include <vector>

int SocketConn(CTabFive::WebTie *pstWebTie);
void CommServerRead(int iSockfd, CTabFive::WebTie *pstWebTie);
int MsgWsaW(wstring wsrMsg, bool bCleanup, CTabFive::WebTie *pstWebTie);
DWORD WINAPI TomcatTp(LPVOID lpParam);
DWORD WINAPI TomcatFinishTp(LPVOID lpParam);

DWORD WINAPI TomcatTp(LPVOID lpParam)
{
	CTabFive::WebTie *pstWebTie = (CTabFive::WebTie*)lpParam;

	wstring wsrMonSoc = L"TomcatTp\r\n";
	wsrMonSoc += ThrAffinity(pstWebTie->hTomcatTp, 1);

	//+++ Initialize Winsock
	WSADATA wsaData;
	int iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
	if (iResult != NO_ERROR)
	{
		wsrMonSoc += L"WSAStartup failed with error: " + to_wstring(iResult) + L"\r\n";
		return ERROR_COMM;
	}

	pstWebTie->srIO = "P";
	if (SocketConn(pstWebTie) == ERROR_COMM)	//+++ WSACleanup already called by SocketConn in case of error.
		return ERROR_COMM;
	Sleep(100);
	pstWebTie->srIO = "T";
	if (SocketConn(pstWebTie) == ERROR_COMM)	//+++ WSACleanup already called by SocketConn in case of error.
		return ERROR_COMM;
	Sleep(100);

	WSACleanup();

	return 0;
}

int SocketConn(CTabFive::WebTie *pstWebTie)
{
	//+++ Create a SOCKET for connecting to server.
	SOCKET ConnectSocket;
	ConnectSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (ConnectSocket == INVALID_SOCKET)
		return MsgWsaW(L"Socket failed with error: " + to_wstring(WSAGetLastError()) + L"\r\n", true, pstWebTie);

	sockaddr_in clientService;	//+++ Specify the address family, IP address, and port of the server to be connected to.
	clientService.sin_family = AF_INET;
	clientService.sin_addr.s_addr = pstWebTie->ulIPv4Ta;
	clientService.sin_port = htons(atoi(pstWebTie->pcPortNumber));

	//+++ Connect to server.
	if (connect(ConnectSocket, (SOCKADDR *)&clientService, sizeof(clientService)) == SOCKET_ERROR)
	{
		MsgWsaW(L"connect failed with error: " + to_wstring(WSAGetLastError()) + L"\r\n", false, pstWebTie);
		if (closesocket(ConnectSocket) == SOCKET_ERROR)
			MsgWsaW(L"closesocket failed with error: " + to_wstring(WSAGetLastError()) + L"\r\n", false, pstWebTie);

		WSACleanup();
		return ERROR_COMM;
	}

	CommServerRead(ConnectSocket, pstWebTie);

	if (closesocket(ConnectSocket) == SOCKET_ERROR)
		return MsgWsaW(L"closesocket failed with error: " + to_wstring(WSAGetLastError()) + L"\r\n", true, pstWebTie);

	return 0;
}

void CommServerRead(int iSockfd, CTabFive::WebTie *pstWebTie)
{
	vector<char> tchRecvLine(MAX_READ + 1);	//+++ Char array would do as well.
	string srPage = "/Inte/SensVa", srHost = pstWebTie->pcHostName + (string)":" + pstWebTie->pcPortNumber, srPostData = pstWebTie->srIO, srRecv = "";	//+++ Server's page to ask for; name of server; data to send to server; response from server.

																																						//+++ Form request.
	string srSendLine = "POST " + srPage + " HTTP/1.0\r\n" + "Host: " + srHost + "\r\n" +
		"Content-type: application/x-www-form-urlencoded\r\n" + "Content-length: " + to_string(srPostData.length()) + "\r\n\r\n" + srPostData + "\r\n";

	if (send(iSockfd, srSendLine.c_str(), srSendLine.size(), 0) >= 0)	 //+++ Write the request.
		while (recv(iSockfd, &tchRecvLine[0], MAX_READ, 0) > 0)	 //+++ Read the response.
			srRecv += tchRecvLine.data();

	basic_string <char>::size_type kIndex;
	const char *pcStart = "\r\n\r\n";	//+++ Trailing chars to remove.
	kIndex = srRecv.find(pcStart);
	pstWebTie->srIO = "RRRSomething wrong...";
	if (kIndex != string::npos)
		pstWebTie->srIO = srRecv.substr(kIndex + strlen(pcStart)) + "\r\n";	//+++ Remove the trailing chars.

	pstWebTie->wsrTotOut += StToWsUtf8(pstWebTie->srIO);
}

DWORD WINAPI TomcatFinishTp(LPVOID lpParam)
{
	CTabFive *pTabFive = (CTabFive*)lpParam;

	wstring wsrBatch = L"		End batch-------------------------------------------------------------\r\n";

	HANDLE ahTomcatTp[NUM_WEB_THREADS];	//+++ Handle to TomcatTp.
	for (int iCount = 0; iCount < NUM_WEB_THREADS; iCount++)
		ahTomcatTp[iCount] = pTabFive->pstWebTie[iCount].hTomcatTp;

	//+++ Wait till all TomcatTp instances exit.
	DWORD dwWaitResult = WaitForMultipleObjects(NUM_WEB_THREADS, ahTomcatTp, TRUE, INFINITE);
	switch (dwWaitResult)
	{
	case WAIT_OBJECT_0:
		for (int iCount = 0; iCount < NUM_WEB_THREADS; iCount++)	//+++ Close thread procedure handles.			
		{
			CloseHandle(ahTomcatTp[iCount]);
			pTabFive->SendMessageW(RG_WM_ED_T_WEM, (WPARAM)pTabFive->pstWebTie[iCount].wsrTotOut.c_str());
			pTabFive->SendMessageW(RG_WM_ED_T_WEM, (WPARAM)pTabFive->pstWebTie[iCount].wsrError.c_str());
		}
		pTabFive->iBatch++;
		wsrBatch = to_wstring(pTabFive->iBatch) + wsrBatch;
		pTabFive->SendMessageW(RG_WM_ED_T_WEM, (WPARAM)wsrBatch.c_str());
		break;
	}
	pTabFive->jbnWeb.EnableWindow();

	return 0;
}

int MsgWsaW(wstring wsrMsg, bool bCleanup, CTabFive::WebTie *pstWebTie)
{
	pstWebTie->wsrError += wsrMsg;

	if (bCleanup == true)
		WSACleanup();

	return ERROR_COMM;
}