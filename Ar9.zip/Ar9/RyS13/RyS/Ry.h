#pragma once

#include "SharA.h"

template <typename T>	//+++ Transform a number to string.
string NumberToString(T Number)
{
	ostringstream ss;
	ss << Number;
	return ss.str();
}

typedef void *(*ThreadProcP)(void*);  	//+++ Declares a type of a ptr to a function that accepts a void ptr and returns a void ptr.

class CRy
{
public:
	struct PortHost
	{
		string srI2cServerPort; 	//+++ Sent to client laptop ASUS after broadcasting, by TEMPORARY thread.
		string srTom8ServerPort; 	//+++ Local port of Tomcat8. It's used by local ip address of this app. This app and Tomcat8 reside on RaspberryPi2. 	
		string srRemSvrPortR3; 	//+++ Sent to laptop ASUS after broadcasting, by TEMPORARY thread. For remot3.it it's 80. Given remot3.it host and its port (80), LaptopASUS can get an endpoint address to which to connect a socket.
		string srRemSvrPortNi; 	//+++ Sent to laptop ASUS after broadcasting, by TEMPORARY thread. For noip.com it's the same as SsrTom8ServerPort. Given noip.com host and its port (8080), LaptopASUS can get an endpoint address to which to connect a socket.
		string srLANServerHost; 	//+++ Received from laptop ASUS when broadcasting.
		string srLANServerPort; 	//+++ Received from laptop ASUS when broadcasting.
		string srServerPort; //???
		string srRes; //???
		pthread_barrier_t barrier5;  	//+++ Barrier for threads: BROADCAST, ONE, TWO, THREE, TEMPORARY. When barrier gives the go-ahead, SsrLANServerHost and SsrLANServerPort already initialized by BROADCAST, can be used by the other 4 threads.
	} stPortHost;
	
	struct ThreadInfo	//+++ Used as argument to LanTp()...
	{
		pthread_t ulThread_id; 	//+++ ID returned by pthread_create().
		int iThreadNum; 	//+++ Application-defined thread #.
		static cpu_set_t stSet1, stSet2, stSet3; //??????
		char pcInfoArg[50]; 	//+++ First argument sent to Asi server ReceiveTp. ReceiveTp uses that to recognize which kind of thread has connected.
		void *pClassArg;
	};
		
	struct CoupleId	//+++ First time identification msg for thread related to: broadcasting; local pushbuttons; SPI(potentiometer processed by Pic24); SPI (thermometer processed by Pic24); laptop client setup; I2C (Pic24). Not all are used.
	{
		string srMessage;
		int iMessage;
	};

	ThreadProcP afp[4];     //++ Declares the array of function ptrs.
	vector<CoupleId> teCoupleID; //+++ Store identification msg for all threads created by app.//??? AAA
	ThreadInfo *pstThrInf;
	enum State
	{
		RyNormal      = I2C_RY_NORMAL,
		RyExit        = I2C_RY_EXIT,
		RyShutComm    = I2C_RY_SHUT_COMM,
		LaptopDismiss = I2C_LAPTOP_DISMISS
	} enStateDevice = RyNormal;

	CRy();
	~CRy();
	void FillCoupleId(); 	//+++ Populate vector holding identification msg for all threads created by app.	
	void PoolThread(int iNumThreads);  	//+++ Create and join NUM_THREADS threads.
	void CreateThread(int iNThreads, void *(**ppStartRoutine)(void*));   	//+++ Create child threads.
	int SockAddrConn(const char* pcHostName, uint16_t usiPort); 	//+++ Get host's internet address from its name and service-port; connect to server laptop ASUS within Eolo Fritz!Box LAN router. getaddrinfo(): Jessie recognized "localhost" and other alphanumeric host names, instead Stretch doesn't; Stretch wants pcHostName in the dotted form: "aaa.bbb.ccc.ddd".
};