// TabOne.cpp : implementation file
//

#include "stdafx.h"
#include "Asi.h"
#include "TabOne.h"
#include "afxdialogex.h"

DWORD WINAPI T_Connect(LPVOID lpParam);	//+++ Worker thread: manages NUM_SOCKETS sockets to communicate with RaspberryPi2.	
DWORD WINAPI T_Broad(LPVOID lpParam);	//+++ Worker thread: waits for Raspberry to broadcast and then answers back.
DWORD WINAPI T_Shell(LPVOID lpParam);	//+++ Worker thread: 
DWORD WINAPI T_I2cMaTx(LPVOID lpParam);

// CTabOne dialog

IMPLEMENT_DYNAMIC(CTabOne, CDlgExBase)

CTabOne::CTabOne(CWnd* pParent /*=NULL*/)
{	
}

CTabOne::~CTabOne()
{
}

void CTabOne::DoDataExchange(CDataExchange* pDX)
{
	CDlgExBase::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_BN_LAN, jbnLanServerStart);
	DDX_Control(pDX, IDC_BN_SHUT, jbnShut);
	DDX_Control(pDX, IDC_ED_SYPRMT, jedSyPrMt);
	DDX_Control(pDX, IDC_ED_CU_SOCTH, jedCuSocTh);
	DDX_Control(pDX, IDC_ED_PORT, jedLanServerPortNumber);
	DDX_Control(pDX, IDC_BN_OPEN, jbnOpen);
	DDX_Control(pDX, IDC_BN_DISMISS, jbnDismiss);
}

BEGIN_MESSAGE_MAP(CTabOne, CDlgExBase)
	ON_BN_CLICKED(IDC_BN_LAN, &CTabOne::OnBnClickedBnLan)
	ON_BN_CLICKED(IDC_BN_SHUT, &CTabOne::OnBnClickedBnShut)
	ON_EN_UPDATE(IDC_ED_PORT, &CTabOne::OnEnUpdateEdPort)
	ON_REGISTERED_MESSAGE(RG_WM_ED_SOC_T, &CTabOne::OnEdSocT)
	ON_BN_CLICKED(IDC_BN_OPEN, &CTabOne::OnBnClickedBnOpen)
	ON_BN_CLICKED(IDC_BN_DISMISS, &CTabOne::OnBnClickedBnDismiss)
END_MESSAGE_MAP()

// CTabOne message handlers

BOOL CTabOne::OnInitDialog()
{
	CDlgExBase::OnInitDialog();

	// TODO:  Add extra initialization here
	jedSyPrMt.SetWindowTextW(theApp.wsrOut.c_str());

	return TRUE;  // return TRUE unless you set the focus to a control
				  // EXCEPTION: OCX Property Pages should return FALSE
}

void CTabOne::OnBnClickedBnLan()
{
	// TODO: Add your control notification handler code here
	jbnLanServerStart.EnableWindow(false);
	jbnShut.EnableWindow(true);
	jbnDismiss.EnableWindow(true);
	CString strPortNumber;
	jedLanServerPortNumber.GetWindowTextW(strPortNumber);
	srPortNumber = WsToStUtf8(strPortNumber.GetBuffer());

	if (srPortNumber == "")
		srPortNumber = "15000";

	usPortTcpIp = htons(atoi(srPortNumber.c_str()));
	char acHostName[BUFLEN];
	gethostname(acHostName, ARRAY_SIZE(acHostName));
	srHostName = acHostName;

	theApp.stHook.hT_Broad = CreateThread(NULL, 0, T_Broad, &theApp.stHook, 0, NULL);
	theApp.stHook.hT_Connect = CreateThread(NULL, 0, T_Connect, &theApp.stHook, 0, NULL);
	theApp.stHook.hT_Shell = CreateThread(NULL, 0, T_Shell, NULL, 0, NULL);

	Hook &RstHook = theApp.stHook;//??? to move where can check for success creating suite...
	CMenu* pSysMenu = RstHook.pAsiDlg->GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
		pSysMenu->EnableMenuItem(SC_CLOSE, MF_ENABLED);
}

void CTabOne::OnBnClickedBnShut()
{
	// TODO: Add your control notification handler code here
	jbnShut.EnableWindow(false);
	jbnOpen.EnableWindow(true);
	jbnDismiss.EnableWindow(false);
	Hook &RstHook = theApp.stHook;
	RstHook.pTabFour->InputCtrl(false);
	RstHook.pAsiDlg->ShutComm();//???
}

void CTabOne::OnBnClickedBnOpen()
{
	// TODO: Add your control notification handler code here
	jbnOpen.EnableWindow(false);
	jbnShut.EnableWindow(true);
	jbnDismiss.EnableWindow(true);
	theApp.stHook.hT_I2cMaTx = CreateThread(NULL, 0, T_I2cMaTx, &theApp.stHook, 0, NULL);
}

void CTabOne::OnBnClickedBnDismiss()
{
	// TODO: Add your control notification handler code here
	jbnDismiss.EnableWindow(false);
	jbnOpen.EnableWindow(false);
	jbnShut.EnableWindow(false);
	Hook &RstHook = theApp.stHook;

	if (RstHook.hT_Broad != NULL)
		RstHook.pAsiDlg->LaptopDismiss();//???

	((CAsiDlg*)theApp.m_pMainWnd)->EndDialog(IDOK);
}

void CTabOne::OnEnUpdateEdPort()
{
	// TODO:  If this is a RICHEDIT control, the control will not send this notification unless you override the CDlgExBase::OnInitDialog() function to send the EM_SETEVENTMASK message to the control with the ENM_UPDATE flag ORed into the lParam mask.
	// TODO:  Add your control notification handler code here
	CString strPortNumber;
	jedLanServerPortNumber.GetWindowTextW(strPortNumber);
	bool bEmptyPortNumber = strPortNumber.IsEmpty();
	jbnLanServerStart.EnableWindow(!bEmptyPortNumber);
}

LRESULT CTabOne::OnEdSocT(WPARAM wParam, LPARAM lParam)
{
	wsrMtrSocThr += (const wchar_t*)wParam + (wstring)L"\r\n";
	jedCuSocTh.SetWindowTextW(wsrMtrSocThr.c_str());
	return NO_ERROR;
}

void CTabOne::ShutCloseSocket(SOCKET sock)
{
	if (sock != INVALID_SOCKET)
	{
		shutdown(sock, SD_RECEIVE);
		closesocket(sock);	//+++ No longer need socket.
		sock = INVALID_SOCKET;
	}
}