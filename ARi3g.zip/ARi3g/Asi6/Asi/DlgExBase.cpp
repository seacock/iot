// DlgExBase.cpp : implementation file
//

#include "stdafx.h"
#include "Asi.h"
#include "DlgExBase.h"
#include "afxdialogex.h"

// CDlgExBase dialog

IMPLEMENT_DYNAMIC(CDlgExBase, CDialogEx)

CDlgExBase::CDlgExBase(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DLGEXBASE, pParent)
{
}

CDlgExBase::~CDlgExBase()
{
}

CDlgExBase::CDlgExBase(UINT nIDTemplate, CWnd* pParent /*=NULL*/)
	: CDialogEx(nIDTemplate, pParent)
{
}

void CDlgExBase::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CDlgExBase, CDialogEx)
END_MESSAGE_MAP()

// CDlgExBase message handlers

int CDlgExBase::SocketAddr(wstring wsrClassName, char *pcHostName, char *pcPortNumber, sockaddr_in **sockaddr_ipv4)
{
	int iCount = 1;
	addrinfo *result = NULL, *ptr = NULL, hints;
	wstring wsrMonSoc;

	//+++ Initialize Winsock.
	WSADATA wsaData;
	if (WSAStartup(MAKEWORD(2, 2), &wsaData) != NO_ERROR)
		MsgWsa(wsrClassName, L" WSAStartup() failed with error: " + to_wstring(WSAGetLastError()) + L"\r\n", false);

	//+++ Setup the hints address info structure which is passed to the getaddrinfo() function.
	ZeroMemory(&hints, sizeof(hints));
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_protocol = IPPROTO_TCP;

	//+++ If the call succeeds, the result variable will hold a linked list of addrinfo structures containing response information.
	if (getaddrinfo(pcHostName, pcPortNumber, &hints, &result) != 0)
		MsgWsa(wsrClassName, L" getaddrinfo() failed with error: " + to_wstring(WSAGetLastError()) + L"\r\n", true);

	wsrMonSoc += L"getaddrinfo() returned success\n";

	//+++ Retrieve each address and print out the hex bytes.
	for (ptr = result; ptr != NULL; ptr = ptr->ai_next)
	{
		wsrMonSoc += L"getaddrinfo response " + to_wstring(iCount++) + L"\r\n" + L"\tFlags: " + StToWsUtf8(NumberToStringHex(ptr->ai_flags)) + L"\tFamily: ";
		switch (ptr->ai_family)
		{
		case AF_UNSPEC: case AF_INET6: case AF_NETBIOS: default:
			wsrMonSoc += L"This app considers only IPv4 address and not this family: " + to_wstring(ptr->ai_family) + L"\r\n";
			break;
		case AF_INET:
			*sockaddr_ipv4 = (sockaddr_in*)ptr->ai_addr;
			wchar_t awchStringBuf[BUFLEN];
			wsrMonSoc += L"\tAF_INET (IPv4) address " + (wstring)InetNtop(AF_INET, &(*sockaddr_ipv4)->sin_addr, awchStringBuf, ARRAY_SIZE(awchStringBuf));
			break;
		}

		wsrMonSoc += L"\tSocket type: ";
		switch (ptr->ai_socktype)
		{
		case 0:
			wsrMonSoc += L"Unspecified\r\n";
			break;
		case SOCK_STREAM:
			wsrMonSoc += L"\tSOCK_STREAM (stream)\r\n";
			break;
		case SOCK_DGRAM: case SOCK_RAW: case SOCK_RDM: case SOCK_SEQPACKET: default:
			wsrMonSoc += L"This app considers only SOCK_STREAM and not this type: " + to_wstring(ptr->ai_socktype) + L"\r\n";
			break;
		}

		wsrMonSoc += L"\tProtocol: ";
		switch (ptr->ai_protocol)
		{
		case 0:
			wsrMonSoc += L"Unspecified\r\n";
			break;
		case IPPROTO_TCP:
			wsrMonSoc += L"IPPROTO_TCP (TCP)  " + to_wstring(ptr->ai_protocol) + L"\r\n";
			break;
		case IPPROTO_UDP: default:
			wsrMonSoc += L"This app considers only IPPROTO_TCP and not this protocol: " + to_wstring(ptr->ai_protocol) + L"\r\n";
			break;
		}
	}

	freeaddrinfo(result);
	WSACleanup();

	Hook &RstHook = theApp.stHook;
	RstHook.pTabOne->SendMessageW(RG_WM_ED_SOC_T, (WPARAM)wsrMonSoc.c_str(), NULL);

	if (*sockaddr_ipv4 == NULL)
		return ERROR_COMM;

	return NO_ERROR;
}

int CDlgExBase::MsgWsa(wstring wsrWhich, wstring wsrMsg, bool bCleanup)
{
	wstring wsrWhichMsg = wsrWhich + wsrMsg;
	Hook &RstHook = theApp.stHook;
	RstHook.pTabOne->SendMessageW(RG_WM_ED_SOC_T, (WPARAM)wsrWhichMsg.c_str(), NULL);

	if (bCleanup == true)
		WSACleanup();

	return ERROR_COMM;
}

template <typename T>
string CDlgExBase::NumberToStringHex(T Number)
{
	ostringstream ss;
	ss << hex << Number;
	return ss.str();
}