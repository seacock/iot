// DlgExBase.cpp : implementation file
//

#include "stdafx.h"
#include "Asi.h"
#include "DlgExBase.h"
#include "afxdialogex.h"
#include <sstream>	//+++ For ostringstream.

// CDlgExBase dialog

IMPLEMENT_DYNAMIC(CDlgExBase, CDialogEx)

CDlgExBase::CDlgExBase(CWnd* pParent /*=NULL*/)
{
}

CDlgExBase::~CDlgExBase()
{
}

void CDlgExBase::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CDlgExBase, CDialogEx)
END_MESSAGE_MAP()

// CDlgExBase message handlers

template <typename T>
string CDlgExBase::NumberToStringHex(T Number)
{
	ostringstream ss;
	ss << hex << Number;
	return ss.str();
}

SOCKET CDlgExBase::TieSockAddr(char *pcHostName, char *pcPortNumber, int iSide)
{
	WSADATA wsaData;
	addrinfo *result = NULL, *ptr = NULL, hints;
	wstring wsrMonSoc;

	//+++ Initialize Winsock.
	if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
		theApp.ErrWsaSock(L"WSAStartup() failed with error: " + to_wstring(WSAGetLastError()) + L"\r\n", false);

	ZeroMemory(&hints, sizeof(hints));	//+++ Setup the hints address info structure which is passed to the getaddrinfo() function.
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_protocol = IPPROTO_TCP;

	//+++ If the call succeeds, the result variable will hold a linked list of addrinfo structures containing response information.
	if (getaddrinfo(pcHostName, pcPortNumber, &hints, &result) != 0)
		theApp.ErrWsaSock(L"getaddrinfo() failed with error: " + to_wstring(WSAGetLastError()) + L"\r\n", true);

	wsrMonSoc += L"getaddrinfo() returned success\n";

	//+++ Create a SOCKET for either listening for incoming connection requests from clients either connecting to a server.
	SOCKET sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (sock == INVALID_SOCKET)
		return theApp.ErrWsaSock(L"socket() failed with error: " + to_wstring(WSAGetLastError()) + L"\r\n", true);

	sockaddr_in *pstSaIpv4 = NULL;
	bool bValid = false;	//+++ Must be initialized.

	//+++ Attempt either to bind/listen either to connect to an address until one succeeds.
	for (ptr = result; ptr != NULL; ptr = ptr->ai_next)
	{
		bValid = false;
		pstSaIpv4 = NULL;
		switch (ptr->ai_family)
		{
		case AF_INET:
			pstSaIpv4 = (sockaddr_in*)ptr->ai_addr;
			wchar_t awcDotAdd[AsiConst::kiBufLen];
			wsrMonSoc += L"\tAF_INET (IPv4) address " + (wstring)InetNtop(AF_INET, &(pstSaIpv4)->sin_addr, awcDotAdd, ARRAY_SIZE(awcDotAdd));
			break;
		}

		if (pstSaIpv4 != NULL)
		{
			if (iSide == AsiConst::kiServerSide)
			{
				//+++ The sockaddr_in structure specifies the address family, IP address, and port for the socket that is being bound.
				if (bind(sock, (SOCKADDR*)pstSaIpv4, sizeof(*pstSaIpv4)) == SOCKET_ERROR)
				{
					theApp.ErrWsaSock(L"bind() failed with error: " + to_wstring(WSAGetLastError()) + L"\r\n", true, sock);
					continue;
				}

				//+++ Listen for incoming connection requests on the created socket.
				if (listen(sock, 1) == SOCKET_ERROR)	//+++ backlog 1.
				{
					theApp.ErrWsaSock(L"listen() failed with error: " + to_wstring(WSAGetLastError()) + L"\r\n", true, sock);
					continue;
				}
			}
			else if (iSide == AsiConst::kiClientSide)
			{
				//+++ Connect to server.
				if (connect(sock, ptr->ai_addr, (int)ptr->ai_addrlen) == SOCKET_ERROR)
				{
					theApp.ErrWsaSock(L"connect() failed with error: " + to_wstring(WSAGetLastError()) + L"\r\n", false, sock);
					continue;
				}
			}
		}
		else
			continue;

		bValid = true;	//+++ Either the server can bind()/listen() either the client can connect().
		break;
	}

	freeaddrinfo(result);

	WSACleanup();

	if (bValid == false)
		sock = INVALID_SOCKET;

	return sock; 
}