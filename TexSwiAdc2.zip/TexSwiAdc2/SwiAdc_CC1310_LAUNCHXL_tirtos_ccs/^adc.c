/*
 * adc.c
 *
 *  Created on: 21 ott 2018
 *      Author: andre
 */

#include <^common.h>
#include <^adc.h>

Void AdcTf(UArg arg0, UArg arg1)
{
    ADC_Handle adc;
    ADC_Params params;
    uint16_t adcValue, iCycle1 = 0, iCycle2 = 0;
    int_fast16_t res;

    while (1) {
        /* Open ADC Driver */
        ADC_Params_init(&params);
        adc = ADC_open(Board_ADC3, &params);
        if (adc == NULL)
            while (1);// Error initializing ADC channel Board_ADC3

        res = ADC_convert(adc, &adcValue);
        if (res == ADC_STATUS_SUCCESS) {
            iCycle1++;
            if (iCycle1 == 4) {
//                Display_printf(displayHandle, 1, 0, "ADC reading DIO26 %d     every %d cycles", adcValue, iCycle1);
                Swi_andn(swi0Handle, 0x1);  //+++ swi0 trigger = 0x03, 0x03, 0x03, 0x02, swi will start after next conversion...
                iCycle1 = 0;
            }
        }
        ADC_close(adc);

        /* Open ADC Driver */
        ADC_Params_init(&params);
        adc = ADC_open(Board_ADC4, &params);
        if (adc == NULL)
            while (1);// Error initializing ADC channel Board_ADC4

        res = ADC_convert(adc, &adcValue);
        if (res == ADC_STATUS_SUCCESS) {
            iCycle2++;
            if (iCycle2 == 2) {
//                Display_printf(displayHandle, 1, 0, "ADC reading DIO27 %d     every %d cycles", adcValue, iCycle2);
                    Swi_andn(swi0Handle, 0x2);  //+++ swi0 trigger = 0x03, 0x01, 0x03, 0x00, swi starts...
                iCycle2 = 0;
            }
        }
        ADC_close(adc);

        bHigh1 = !bHigh1;
        PIN_setOutputValue(hDynPin, CC1310_LAUNCHXL_DIO15, bHigh1);

        Semaphore_pend(hSemADC, BIOS_WAIT_FOREVER);    //+++ Wait on sem indefinitely.
    }
}

void StartAdcTf(void)
{
    /* Set up AdcTf task */
    Task_Params stTaskParams;
    Task_Params_init(&stTaskParams);
    stTaskParams.stackSize = STACKSIZE;
    stTaskParams.priority = 4;
    stTaskParams.stack = &aucADCTaskStack;

    Task_construct(&stADCTask, AdcTf, &stTaskParams, NULL);
}
