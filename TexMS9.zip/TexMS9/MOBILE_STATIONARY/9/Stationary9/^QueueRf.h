/*
 * ^QueueRf.h
 *
 *  Created on: 18 nov 2018
 *      Author: andre
 */

#ifndef QUEUERF_H_
#define QUEUERF_H_

#include <^Common.h>

/* Driverlib Header files */
#include DeviceFamily_constructPath(driverlib/rf_prop_mailbox.h)
#include DeviceFamily_constructPath(driverlib/rf_data_entry.h)
#include DeviceFamily_constructPath(driverlib/rf_mailbox.h)

void ArrangeQueueRf(uint8_t *aucRxBuffer, dataQueue_t *queue, rfc_dataEntryGeneral_t **rxEntry);

#endif /* QUEUERF_H_ */
