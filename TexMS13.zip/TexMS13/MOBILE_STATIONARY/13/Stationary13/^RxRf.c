/*
 * RxRf.c
 *
 *  Created on: 06 nov 2018
 *      Author: andre
 */

#include <^Common.h>
#include <^QueueRf.h>

void ComposeCouple(void);

void RxRfCb(RF_Handle h, RF_CmdHandle ch, RF_EventMask e)
{
    if (e & RF_EventRxEntryDone)
    {
        PIN_setOutputValue(LedPinH, BOARD_PIN_RED_LED, !PIN_getOutputValue(BOARD_PIN_RED_LED));    //+++ Toggle pin to indicate RX.

        uint8_t packetLength = *(uint8_t*)(&rxEntry->data); //+++ Packet starts with 1 byte length information (lenSz = 1).
        uint8_t* packetDataPointer = (uint8_t*)(&rxEntry->data + sizeof(packetLength)); //+++ Payload follows.
        memcpy(ucRxPacket, packetDataPointer, packetLength);   //+++ Read the payload from the Rx buffer.
        ((volatile rfc_dataEntryGeneral_t*)rxEntry)->status = DATA_ENTRY_PENDING;   //+++ Mark the entry as being read.
        rxEntry = ((rfc_dataEntryGeneral_t*)rxEntry->pNextEntry);  //+++ Get the next entry.

        if (bSynchro == false)
        {
            uint8_t synchro[TX_PAYLOAD_LENGTH];
            memset(synchro, 'A', TX_PAYLOAD_LENGTH);
            if (!strncmp((char*)ucRxPacket, (char*)synchro, TX_PAYLOAD_LENGTH))
                bSynchro = true;
        }

        if (bSynchro == true && iReceivedPacket < RX_BUFFER_ENTRIES * TX_PAYLOAD_FORMAT)
            ComposeCouple();
    }
}

void ComposeCouple(void)
{
    iReceivedPacket++;
    strcat((char*)aucRawPackets, (char*)ucRxPacket);

    iTwoSteps++;
    if (iTwoSteps == 2)
    {
        if (iStartBound == TX_PAYLOAD_LENGTH * TX_PAYLOAD_FORMAT * RX_BUFFER_ENTRIES)
            iStartBound = 0;

        //+++ For each couple: compose each position of first packet, with the same position of second packet.
        uint16_t usUpper, usLower;
        int iBound;
        for (iBound = iStartBound; iBound < iStartBound + TX_PAYLOAD_LENGTH; iBound++)
        {
            usUpper = aucRawPackets[iBound] << 8;
            usLower = aucRawPackets[iBound + TX_PAYLOAD_LENGTH];
            auiComposedP[iComposed++] = usUpper + usLower;
        }
        iStartBound += TX_PAYLOAD_LENGTH * TX_PAYLOAD_FORMAT / iTwoSteps;   //+++
        iTwoSteps = 0;
    }

    //+++ Last couple has been processed: start over counters and variables.
    if (iReceivedPacket == RX_BUFFER_ENTRIES * TX_PAYLOAD_FORMAT)
    {
        aucRawPackets[0] = '\0';    //+++ Avoid going out of bounds.
        iReceivedPacket = 0;
        iComposed = 0;
        bSynchro = false;
    }
}
