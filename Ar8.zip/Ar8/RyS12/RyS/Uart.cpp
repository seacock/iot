#include "Uart.h"
#include "RyS.h"
#include <wiringSerial.h>

StateUart Uart::SenStateUart = STATE_NeutralUart;
pthread_cond_t Uart::ScondWebServUart = PTHREAD_COND_INITIALIZER;
pthread_cond_t Uart::ScondSocTxRxUart = PTHREAD_COND_INITIALIZER;
pthread_mutex_t Uart::SmutexUart = PTHREAD_MUTEX_INITIALIZER;

CUart::CUart()
{
	for (int iCount = 0; iCount < ARRAY_SIZE(asrLocal); iCount++)
		if (asrLocal[iCount].length() != RASPBERRY_STRING_LENGTH)
			handle_error1("RASPBERRY_STRING_LENGTH");
}

CUart::~CUart()
{
}

int CUart::UartSetup()
{
	pinMode(CTS, INPUT);
	pinMode(RTS, OUTPUT);
	digitalWrite(RTS, HIGH);   	//+++ Stop request to send.
	int iHandle = serialOpen("/dev/ttyAMA0", 9600);
	if (iHandle == -1)
		cout << "bad handle" << endl;

	return iHandle;
}

void CUart::UartClose(int iHandle)
{
	serialClose(iHandle);
}

void CUart::UartPic(int iHandle, string *psrSend, int iSizeSend, int iFdLas)
{
	int iData, iCharRx, iDataAvail, iNumCycle;

	if (iFdLas > 0)
		srRecvUart = "!!!???";
	else
		srRecvUart = "";

	cout << endl << endl;

	for (int iCount = 0; iCount < iSizeSend; iCount++)
	{
		iCharRx = 0;
		iNumCycle = 0;
		iDataAvail = 0;

		digitalWrite(RTS, LOW);    	//+++ Assert request to send.
		
		while (iNumCycle < MAX_CHECK_CYCLES)   
		{
			iDataAvail = serialDataAvail(iHandle);     	//+++ Check number of characters available for reading.
			if (iDataAvail == PIC24_STRING_LENGTH)
				break;
			iNumCycle++;
		}

		cout << "Num of cycles " << iNumCycle << "\tData available " << iDataAvail << endl;

		while (iCharRx < iDataAvail)
		{
			iData = serialGetchar(iHandle);	
			cout << (char)iData;
			srRecvUart += iData;
			iCharRx++;
		}

		digitalWrite(RTS, HIGH);    	//+++ Stop request to send.

		cout << endl << endl;

		iNumCycle = 0;
		while (digitalRead(CTS) == 1) 	//+++ Wait till Pic24 asks for receiving.
		{
			iNumCycle++;
			if (iNumCycle == MAX_CHECK_CYCLES)
				handle_error1("Causes: 1) Change the value of MAX_CHECK_CYCLES. 2) Perhaps Pic24 is stuck: reset it.");
		}

		serialPuts(iHandle, psrSend[iCount].c_str());         	//+++ Send a string to Pic24.

		iNumCycle = 0;
		while (digitalRead(CTS) == 0)   //+++ Wait till Pic24 asks for stopping receiving.
		{
			iNumCycle++;
			if (iNumCycle == MAX_CHECK_CYCLES)
				handle_error1("Causes: 1) Change the value of MAX_CHECK_CYCLES. 2) Perhaps Pic24 is stuck: reset it.");
		}
	}

	if (iFdLas > 0)
		WriteToServer(iFdLas, srRecvUart.c_str());
}