/*
 * ^clock.c
 *
 *  Created on: 25 ott 2018
 *      Author: andre
 */

#include <^Common.h>
#include <ti/sysbios/knl/Clock.h>

Void ClockAdc(UArg arg0)
{
    Semaphore_post(AdcSemH);
}

void StartClockAdc(void)
{
    Clock_Params clockParams;
    Error_Block eb;
    Error_init(&eb);
    Clock_Params_init(&clockParams);
    clockParams.period = 500;
    clockParams.startFlag = TRUE;
    clockParams.arg = (UArg)0x1111;
    Clock_Handle hClock = Clock_create(ClockAdc, 5, &clockParams, &eb);
    if (hClock == NULL)
        System_abort("Clock create failed");
}
