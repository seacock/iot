/*
 * File:   MipX.c
 * Author: MeMyselfAndI
 *
 * Created on 20 luglio 2016, 14.59
 */

#include "MipX.h"

int main(void) 
{   
    //+++ calloc wants directive: project properties heap size in bytes xc16-ld.
    gpchPlaceHolder = (char*)calloc(MAX_HEAP, sizeof(char)); 
    if (gpchPlaceHolder != NULL)
    {
        free(gpchPlaceHolder);
        gpchPlaceHolder = NULL;
    }
    
    INTCON1bits.NSTDIS = 1;     //+++ Interrupt nesting is disabled.
    
    unsigned int pllCounter;
    OSCCONBITS OSCCONbitsCopy; 
    
    OSCCONbitsCopy = OSCCONbits;    //+++ Copy the current Clock Setup.    
    CLKDIVbits.CPDIV = 0x03;   //+++ Slow output clock down to 4Mhz.    
    CLKDIVbits.PLLEN = 1;   //+++ Enable the PLL - Fuse bits don't do this.
    
    //+++ Wait for the PLL to stabilize.
    for (pllCounter = 0; pllCounter < 600; pllCounter++);
    
    //+++ Setup the uC to use the internal FRCPLL mode.
    OSCCONbitsCopy.NOSC = 1;
    OSCCONbitsCopy.OSWEN = 1;    

    //+++ Switch over to the new clock setup.
    __builtin_write_OSCCONH(H_BY_BF(OSCCONbitsCopy));
    __builtin_write_OSCCONL(L_BY_BF(OSCCONbitsCopy));        
    
    //+++ Wait for this transfer to take place.
    while ((OSCCONbits.OSWEN == 1) && (OSCCONbits.COSC != OSCCONbits.NOSC));  
    
    //+++ Setup the PLL divider for the correct clock frequency.
    if (CLOCK_FREQ == 32000000)
        CLKDIVbits.CPDIV = 0x00;
    else if (CLOCK_FREQ == 16000000)
        CLKDIVbits.CPDIV = 0x01;
    else if (CLOCK_FREQ == 8000000)
        CLKDIVbits.CPDIV = 0x02;
    else if (CLOCK_FREQ == 4000000)
        CLKDIVbits.CPDIV = 0x03;

    //+++ Check that PLL is enabled again and locked properly to the new setup.
    CLKDIVbits.PLLEN = 1;
        
    TRISBbits.TRISB10 = OUTPUT_PIN;  //+++ hwPin = 21. AD: last value / average.        
    PORTBbits.RB10 = LAST_ADC;
    
    PR1 = TIMER1_PERIOD;    //+++ Manages AD converter.
    IPC0bits.T1IP = 2;  //+++  Interrupt priority.
    
    mainI2CsX();
    mainSPIsX();  
    mainADcX();
    mainPWMX();  
    
    guchPWMcf = PWM_FUNCTION;
    PR2 = TIMER2_PERIOD;    //+++ Manages increments of duty cycle for PWM.
    IPC1bits.T2IP = 2;  //+++  Interrupt priority.
    TMR2 = 0;   //+++ Prepare zeroed timer.
    _T2IF = 0;
    _T2IE = 1;
    T2CON = 0x8030; //+++ Timer started, prescaler 256.  
    
    PR3 = TIMER3_PERIOD;    //+++ .
    IPC2bits.T3IP = 2;  //+++  Interrupt priority.
    TMR3 = 0;   //+++ Prepare zeroed timer.
    _T3IF = 0;
    _T3IE = 1;
    T3CON = 0x0030; //+++ Timer stopped, prescaler 256.  
    
    guiSpiReset = 0;
    
    while (1);
    
    return 0;
}

void _ISR _T1Interrupt(void)
{   
    AD1CON1bits.ASAM = 1; //+++ Run ADC. Auto start sampling then go to conversion.
    
    _T1IF = 0;
}

void _ISR _T2Interrupt(void)
{
    if (guchPWMcf == PWM_FUNCTION)
    {
        OC1R = OC1R + PWM_STEP_HIGH;
    
        if (OC1R > PWM_PERIOD)
            OC1R = 0;
    }
    if (guchPWMcf == PWM_CONTINUOUS)
    {
        OC1R = guchPWMc * (PWM_PERIOD / 100);
    
        if (OC1R > PWM_PERIOD)
            OC1R = 0;
    }
    
    _T2IF = 0;
}

void _ISR _T3Interrupt(void)
{    
    //+++ The delay between each request from Raspberry to SPI ISR must be shorter than 
    //+++ TIMER3_PERIOD or this game doesn't work. If timer3 interval expires, that means that
    //+++ Raspberry is repeating regularly its requests, but SPI ISR is blocked. So timer3 
    //+++ intervenes resetting SPI.
    ResetSpi();
    guiSpiReset++; 
    
    _T3IF = 0;
}