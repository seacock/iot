#include "Cent.h"
#include "Adc.h"
#include "ShaDe.h"

#if __XC16_VERSION__ >= 0x0401
#undef _ISR
#define _ISR __attribute__((interrupt, auto_psv))
#endif

//+++ Upper and lower bytes from AD to pass to SPI1BUF or to average.
unsigned char guchUB[N_SENS], guchLB[N_SENS]; 

//+++ Allow to update upper and low bytes from AD. It's a 4 steps sequence as 
//+++ 2 steps are needed for upper byte and 2 steps are needed for lower byte.
unsigned char guchUpdate[N_SENS];    

//+++ Allow to update the average of upper and low bytes from AD: 4 steps seq.                   
unsigned char guchUpdateAve[N_SENS];
unsigned int guiAverage[N_SENS]; //+++ Number of values to average.

//+++ Partial sum of upper and lower bytes to average.
unsigned long gulUBSumP[N_SENS], gulLBSumP[N_SENS]; 
                               
//+++ Final average of upper and lower bytes to pass to SPI1BUF.
unsigned char guchUBAveF[N_SENS], guchLBAveF[N_SENS];

int mainADcX(void) 
{   
    ZeroAve(POTENT);
    ZeroAve(THERMO);
    ZeroVal(POTENT);
    ZeroVal(THERMO);    
    SetupADConverter();   
    Timer2TypeA();
    
    return 0;
}

void Timer2TypeA(void)
{
    T2CON = 0x00;   //+++ Reset Timer2 control register and stop Timer2.
    TMR2 = 0x00;    //+++ Clear contents of Timer2 Register.
    T2CONbits.TCKPS = 0x02; //+++ Timer2 Input Clock Prescale Select. 1:64.
    PR2 = 128;  //+++ Load the Period Register 2.
    _T2IP = 0x01;   //+++ Timer2 Interrupt Priority.
    _T2IF = 0;  //+++ Clear Timer2 interrupt status flag.
    _T2IE = 1;  //+++ Enable Timer2 interrupts.    
    T2CONbits.TON = 1;  //+++ Timer started, prescaler .
}

void SetupADConverter(void)
{ 
    AD1CON1bits.ADON = 0;       //+++ Turn ADC OFF.
    
    //+++ AN0 (hwPin = 2), AN1 (hwPin = 3) input pins are analog.
    AD1PCFG = 0xFFFC;           
    AD1CSSL = 0x0003;           //+++ AN0 AN1 channels included in scan.
    
    //+++ Discontinue module operation when device enters Idle mode. Output 
    //+++ fractional. Internal counter ends sampling and triggers conversion: 
    //+++ auto-convert.
    AD1CON1 = 0x22E0;                                       
    AD1CON3 = 0x0F00;           //+++ Auto-sample time = 15 Tad. Tad = Tcy.
    
    //+++ Enable scanning of inputs for MUX A. Set AD1IF after every 2 samples.    
    AD1CON2 = 0x0404;       
    IEC0bits.AD1IE = 0; //+++ Disable A/D conversion interrupt.
    IFS0bits.AD1IF = 0; //+++ Clear A/D conversion interrupt flag.
    IPC3bits.AD1IP = 4; //+++ A/D interrupt priority.
    IEC0bits.AD1IE = 1; //+++ Enable A/D conversion interrupt.    
    AD1CON1bits.ADON = 1;   //+++ Turn ADC ON.
}

void ZeroAve(int iCount)
{
    gulUBSumP[iCount] = 0;          
    gulLBSumP[iCount] = 0;      
    guiAverage[iCount] = 0;   
    guchUpdateAve[iCount] = 0;
}

void ZeroVal(int iCount)
{
    guchUpdate[iCount] = 0;
}

void _ISR _ADC1Interrupt(void)
{
    int aiAdcVal[N_SENS];    //+++ Store an ADC converted value for each sensor.
    int *piAdcBuff = (int*)&ADC1BUF0; //+++ Init pointer to ADC Data Buffer 0.
    AD1CON1bits.ASAM = 0; //+++ After end of conversion, stop sample / convert.
    
    //+++ Store converted values.
    int iCount;
    for (iCount = 0; iCount < N_SENS; iCount++)  
    {
        aiAdcVal[iCount] = *piAdcBuff++;
        if (guchUpdate[iCount] == 0)
        {
            guchUB[iCount] = aiAdcVal[iCount] >> 8; //+++ Upper byte.
            guchLB[iCount] = aiAdcVal[iCount];   //+++ Lower byte.   
        }
        
        if (PORTBbits.RB5 == AVE_ADC && guchUpdateAve[iCount] == 0)
        {
            gulUBSumP[iCount] += guchUB[iCount];
            gulLBSumP[iCount] += guchLB[iCount];   

            guiAverage[iCount]++;
            if (guiAverage[iCount] == AVERAGE)
            {
                guchUBAveF[iCount] = gulUBSumP[iCount] / guiAverage[iCount];
                guchLBAveF[iCount] = gulLBSumP[iCount] / guiAverage[iCount];    
                ZeroAve(iCount);
            }            
        }            
    }
    
    IFS0bits.AD1IF = 0; //+++ Clear ADC interrupt flag.
}

void _ISR _T2Interrupt(void)
{
    AD1CON1bits.ASAM = 1; //+++ Run ADC. Auto start sampling then go to conversion.  
    
    _T2IF = 0;
}