#include "Uart.h"
#include "Cent.h"
#include "Clock.h"

#define RASPBERRY_STRING_LENGTH 15  //+++ Length of string sent from Raspberry and received by Pic24. This value is known by both parties.
#define PIC24_STRING_LENGTH 39  //+++ Length of string sent from Pic24 and received by Raspberry. This value is known by both parties.

int iCountTx = 0, iCountRx = 0; //+++ Index of character to transmit; index of character to receive.
char a2cMsgTx[2][PIC24_STRING_LENGTH + 1] = {
                        "123456789012345678901234567890123456789\0", //+++ Length: PIC24_STRING_LENGTH.
                        "     Tx:  Pic24FJ64GB002\0"    //+++ Length: PIC24_STRING_LENGTH - RASPBERRY_STRING_LENGTH.                     
                    };
char acMsgRx[RASPBERRY_STRING_LENGTH + 1] = "\0"; //+++ Length RASPBERRY_STRING_LENGTH + 1 is important.
bool bInit = 1; //+++ Only the very first time Pic24 transmits: otherways Raspberry misses the first character.

void mainUart(void)
{
    UartPins();
    UartPPS();  
    UartConfig();    
    Timer1TypeA();  
}

void UartPins(void)
{
    TRISBbits.TRISB10 = OUTPUT_PIN;  //+++ U1TX.
    TRISBbits.TRISB11 = INPUT_PIN;   //+++ U1RX.
    TRISBbits.TRISB4 = INPUT_PIN;  //+++ %U1CTS.
    UartChaN();    
    TRISBbits.TRISB1 = OUTPUT_PIN;  //+++ %U1RTS. Pin 5. It must be free: don't use PPS.
    CNPU1bits.CN5PUE = 1; //+++ Weak pull-up on RB1 enabled.
    LATBbits.LATB1 = 1; //+++ Stop request to send.
}

void UartChaN(void)
{
    CNPU1bits.CN1PUE = 1; //+++ Weak pull-up on RB4 enabled.
    CNEN1bits.CN1IE = 1; //+++ Input Change notification on RB4 enabled.
    IEC1bits.CNIE = 1;  //+++ Input Change Notification Interrupt Enabled.
    IFS1bits.CNIF = 0;  //+++ Input Change Notification Interrupt Flag Status Cleared.
    IPC4bits.CNIP = 2;  //+++ Input Change Notification Interrupt Priority.
}

void UartPPS(void)
{
    PPSUnLock;  //+++ Unlock the PPS functionality.
    iPPSOutput(OUT_PIN_PPS_RP10, OUT_FN_PPS_U1TX);   //+++ U1TX. Pin 21. 
    iPPSInput(IN_FN_PPS_U1RX, IN_PIN_PPS_RP11);    //+++ U1RX. Pin 22. 
    iPPSInput(IN_FN_PPS_U1CTS, IN_PIN_PPS_RP4);    //+++ %U1CTS. Pin 11.  
//    iPPSOutput(OUT_PIN_PPS_RP1, OUT_FN_PPS_U1RTS);   //+++ RP1 tied to %U1RTS. Never! This causes malfunctioning: RB1 stuck low.
    PPSLock;    //+++ Lock the PPS functionality.
}

void UartConfig(void)
{    
    U1MODEbits.UEN = 2; //+++ U1TX, U1RX, %U1CTS and %U1RTS pins are enabled and used.
    U1MODEbits.STSEL = 0;   //+++ 1-Stop bit.
    U1MODEbits.PDSEL = 0;   //+++ No Parity, 8-Data bits.
    U1MODEbits.ABAUD = 0;   //+++ Auto-Baud disabled.
    U1MODEbits.BRGH = 0;    //+++ Standard-Speed mode.
    U1BRG = BRGVAL; //+++ Baud Rate setting for 9600.
    U1STAbits.UTXISEL0 = 0; //+++ Interrupt is generated when any character is transferred to the Transmit Shift Register and the
    U1STAbits.UTXISEL1 = 0; //+++ transmit buffer is empty (which implies at least one location is empty in the transmit buffer).
    IEC0bits.U1TXIE = 1;    //+++ Enable UART TX interrupt.
    U1STAbits.URXISEL = 0;  //+++ Interrupt flag bit is set when a character is received.
    IEC0bits.U1RXIE = 1;    //+++ Enable UART RX interrupt.
    U1MODEbits.UARTEN = 1;  //+++ Enable UART.
    U1STAbits.UTXEN = 1;    //+++ UART1 transmitter is enabled; U1TX pin is controlled by UART1.
    IPC3bits.U1TXIP = 6;    //+++ UART1 Transmitter Interrupt Priority.
    IPC2bits.U1RXIP = 6;    //+++ UART1 Receiver Interrupt Priority.
}

void Timer1TypeA(void)
{
    T1CON = 0x00;   //+++ Reset Timer1 control register and stop Timer1.
    TMR1 = 0x00;    //+++ Clear contents of Timer1 Register.
    T1CONbits.TCKPS = 0x02; //+++ Timer1 Input Clock Prescale Select. 1:64.
    PR1 = 128;  //+++ Load the Period Register 1.
    IPC0bits.T1IP = 0x01;   //+++ Timer1 Interrupt Priority.
    IFS0bits.T1IF = 0;  //+++ Clear Timer1 interrupt status flag.
    IEC0bits.T1IE = 1;  //+++ Enable Timer1 interrupts.    
}

void SendChar(void)
{
    while (U1STAbits.UTXBF != 0);   //+++ Wait while UART1 Transmit Buffer is still full (read-only).
    T1CONbits.TON = 1;  //+++ Start Timer1.
}

void GetChar(void)
{
    LATBbits.LATB1 = 0; //+++ Assert UART1 request to send.
}

void _ISR _U1TXInterrupt(void)
{
    IFS0bits.U1TXIF = 0; //+++ Clear TX Interrupt flag.
    
    if (bInit == 1)
        bInit = 0;
    else
    {
        iCountTx++;
        if (iCountTx == strlen(a2cMsgTx[0])) //+++ Check that entire string has been transmitted.
        {
            iCountTx = 0;   //+++ Reset index of character to transmit.
            return; //+++ Return without restarting Timer1. Next it's the turn of Pic24 to receive from Raspberry.
        }
    }
    
    T1CONbits.TON = 1;  //+++ Restart Timer1 to transmit next character.
}

void _ISR _U1RXInterrupt(void)
{
    IFS0bits.U1RXIF = 0; //+++ Clear RX Interrupt flag.
    
    if(U1STAbits.FERR == 1) //+++ Check for receive errors.
        return;
    
    if(U1STAbits.OERR == 1) //+++ Must clear the overrun error to keep UART receiving.
    {
        U1STAbits.OERR = 0;
        return;
    }    

    if (U1STAbits.URXDA == 1)   //+++ Get the data. Not strictly necessary. UART1 Receive Buffer Data Available bit (read-only).
    {
        acMsgRx[iCountRx++] = U1RXREG;  //+++ Character in UART1 Receive Register copied to user variable.

        if (iCountRx > (RASPBERRY_STRING_LENGTH - 1))
        {
            LATBbits.LATB1 = 1; //+++ Stop request to send: Raspberry will stop transmitting. Now Pic24 stops receiving and wait for its turn to transmit.             
            iCountRx = 0;   //+++ Reset index of character to receive.    
            strcpy(a2cMsgTx[0], acMsgRx); //+++ Compose message to send back to Raspberry: message received from Raspberry + Pic24 signature below.
            strcat(a2cMsgTx[0], a2cMsgTx[1]);   //+++ Add Pic24 signature.
        }      
    }
}

void _ISR _T1Interrupt(void)
{    
    T1CONbits.TON = 0;  //+++ Stop Timer1. It is used as a monostable for transmission only: delay time = 105uS = 1/9600.
    TMR1 = 0x00;    //+++ Clear contents of Timer1 Register.
    
    U1TXREG = a2cMsgTx[0][iCountTx]; //+++ Transmit one character.
    
    IFS0bits.T1IF = 0; //Reset Timer1 interrupt flag and Return from ISR.
}

void _ISR _CNInterrupt(void)
{
    if (PORTBbits.RB4 == 0)        
        SendChar(); //+++ Raspberry is asking to receive from Pic24.
    else
        GetChar();  //+++ Raspberry has finished receiving. It's the turn of Pic24 to receive from Raspberry.
    
    IFS1bits.CNIF = 0;  //+++ Clear Input Change Notification Interrupt flag.
}