#include "Rym.h"

int I2cMaster(int iFdI2cM, unsigned char ucNumber, int iFdLas)
{
	if (wiringPiI2CWrite(iFdI2cM, ucNumber) == -1)	//+++ Send parameter to microcontroller.
		handle_error("wiringPiI2CWrite()");

	int iRead = wiringPiI2CRead(iFdI2cM);	//+++ Get back parameter from microcontroller.
	if (iRead == -1)
		handle_error("wiringPiI2CRead()");
	else if (iRead == I2C_RY_SHUT_COMM)	//+++ Exit from threads. Laptop asks for early closure.
	{
		LeaveThreads();
		return -1;
	}

	string srVal = NumberToString(iRead) + '\0';	//+++ Important \0 termination.
	int iWrite = write(iFdLas, srVal.c_str(), srVal.length());	//+++ Send back parameter to laptop. 

	return iWrite;
}

void* I2cServTp(void *arg)
{
	int iRes, iOn = 1;
	int iListenSd, iMaxSd, iNewSd, iSd;	//+++ Socket file descriptors: listening; max value in fd set; new accepted; generic.
	bool bEndServer = false, bCloseConn;
	sockaddr_in addr;	//+++ Structure describing an Internet socket address.

	//+++ select() changes the working_set passed into it to reflect which sockets are ready to read. To keep track of the connections from one call of select() to the next, 
	//+++ these connections are safely stored away into master_set. At the last minute, I copy the master_set into the working_set, and then call select().	
	fd_set master_set, working_set;

	iListenSd = socket(AF_INET, SOCK_STREAM, 0);	//+++ Create an AF_INET stream socket to receive incoming connections on.
	if (iListenSd < 0)
		handle_error("socket()");

	iRes = setsockopt(iListenSd, SOL_SOCKET, SO_REUSEADDR, (char*)&iOn, sizeof(iOn));	//+++ Allow socket descriptor to be reuseable.
	if (iRes < 0)
	{
		close(iListenSd);
		handle_error("setsockopt()");
	}

	//+++ Set socket to be nonblocking. All of the sockets for the incoming connections will also be nonblocking since they will inherit that state from the listening socket. This status is valid only for the accept() step, i.e for iNewSd.  
	iRes = SrNonblockFlag(iListenSd, iOn);
	if (iRes < 0)
	{
		close(iListenSd);
		handle_error("fcntl()");
	}

	//+++ Bind the socket.
	memset(&addr, 0, sizeof(addr));
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = htonl(INADDR_ANY);
	addr.sin_port = htons(atoi(ThreadInfo::SsrI2cServerPort.c_str()));
	iRes = bind(iListenSd, (sockaddr*)&addr, sizeof(addr));
	if (iRes < 0)
	{
		close(iListenSd);
		handle_error("bind()");
	}

	iRes = listen(iListenSd, 32);	//+++ Set the listen back log.
	if (iRes < 0)
	{
		close(iListenSd);
		handle_error("listen()");
	}

	//+++ Initialize the master fd_set.
	FD_ZERO(&master_set);
	iMaxSd = iListenSd;
	FD_SET(iListenSd, &master_set);

	//+++ Initialize the timeval struct to x minutes. If no activity after x minutes this program will end.
	I2c::SstTimeout.tv_sec = 120 * 60;
	I2c::SstTimeout.tv_usec = 0;

	//+++ Set SenStateI2c to STATE_On and wake up thread TEMPORARY.
	pthread_mutex_lock(&I2c::SmutexI2c);
	I2c::SenStateI2c = STATE_On;
	pthread_cond_signal(&I2c::ScondI2c);
	pthread_mutex_unlock(&I2c::SmutexI2c);

	do	//+++ Loop waiting for incoming connections or for incoming data on any of the connected sockets.
	{
		CColorText coltRed(CColorText::RED);

		memcpy(&working_set, &master_set, sizeof(master_set));	//+++ Copy the master fd_set over to the working fd_set.
		cout << "Waiting on select()..." << endl;
		int iPresDescr = select(iMaxSd + 1, &working_set, NULL, NULL, &I2c::SstTimeout);	//+++ Call select() and wait x minutes for it to complete. On success, it returns the total number of file descriptors still present in the file descriptor sets.

		if (iPresDescr < 0)	//+++ Check to see if select() failed.
		{
			perror("select()");
			break;
		}

		if (iPresDescr == SELECT_TIMEOUT)	//+++ Check to see if the x minute time out expired.
		{
			coltRed.ss << "select() timed out. End program." << endl;
			cout << coltRed;
			break;
		}

		for (iSd = 0; iSd <= iMaxSd && iPresDescr > 0; ++iSd)	//+++ One or more descriptors are readable. Need to determine which ones they are.
		{
			if (FD_ISSET(iSd, &working_set))	//+++ Check to see if this descriptor is ready.
			{
				iPresDescr -= 1;	//+++ A descriptor was found that was readable: one less has to be looked for. This is being done so that we can stop looking at the working set once we have found all of the descriptors that were ready.
				if (iSd == iListenSd)	//+++ Check to see if this is the listening socket.
				{
					cout << "Listening socket is readable." << endl;
					do	//+++ Accept all incoming connections that are queued up on the listening socket before we loop back and call select again.
					{
						iNewSd = accept(iListenSd, NULL, NULL);	//+++ Accept each incoming connection. If accept fails with EWOULDBLOCK, then we have accepted all of them. Any other failure on accept will cause us to end the server.
						if (iNewSd < 0)
						{
							if (errno != EWOULDBLOCK)
							{
								perror("accept()");
								bEndServer = true;
							}
							break;
						}

						cout << "New incoming connection: " << iNewSd << endl;
						FD_SET(iNewSd, &master_set);	//+++ Add the new incoming connection to the master read set.
						if (iNewSd > iMaxSd)
							iMaxSd = iNewSd;
					} while (true);	//+++ Loop back up and accept another incoming connection.
				}
				else	//+++ This is not the listening socket, therefore an existing connection must be readable. All socket descriptors added to fd_set are blocking for default.
				{
					cout << "Descriptor " << iSd << " is readable" << endl;
					bCloseConn = false;

					do	//+++ Receive all incoming data on this socket before we loop back and call select again.
					{
						char *pcBuffer = new char[BUFLEN];

						//+++ Set each added socket to be non-blocking as it doesn't inherit that state from the listening socket. A way that allows also to set the timeout is: setsockopt(..., SOL_SOCKET, SO_RCVTIMEO, &timeout, ...)
						iRes = SrNonblockFlag(iSd, iOn);
						if (iRes < 0)
						{
							close(iSd);
							handle_error("fcntl()");
						}

						//+++ Receive all incoming data on this socket before we loop back and call select again. Receive data on this connection until the recv fails with EWOULDBLOCK. If any other failure occurs, we will close the connection.
						bzero(pcBuffer, BUFLEN);
						int iLen = recv(iSd, pcBuffer, BUFLEN, 0);	//+++ Upon successful completion, recv() shall return the length of the	message in bytes.
						if (iLen < 0)
						{
							if (errno != EWOULDBLOCK)
							{
								perror("recv(): laptop client has terminated.");
								bCloseConn = true;
							}
							break;
						}

						if (iLen == 0)	//+++ Check to see if the connection has been closed by the client.
						{
							cout << "Connection closed by laptop client either with close (both send recv), either with shutdown (send)." << endl;
							bCloseConn = true;
							break;
						}

						//+++ Data was received.
						CColorText coltCyan(CColorText::CYAN);
						coltCyan.ss << iLen << " bytes received\t\t" << pcBuffer << " value received." << endl << endl;
						cout << coltCyan;

						int iWrite = I2cMaster(I2c::SiFdI2c, atoi(pcBuffer), iSd);
						if (iWrite < 0)
						{
							coltRed.ss << "I2cMaster()" << strerror(errno) << endl;
							cout << coltRed;
							bCloseConn = true;
							break;
						}

						delete[] pcBuffer;
					} while (true);

					//+++ If the bCloseConn flag was turned on, we need to clean up this active connection. This clean up process includes removing the descriptor 
					//+++ from the master set and determining the new maximum descriptor value based on the bits that are still turned on in the master set.
					if (bCloseConn)
					{
						close(iSd);
						FD_CLR(iSd, &master_set);
						if (iSd == iMaxSd)
							while (FD_ISSET(iMaxSd, &master_set) == false)
								iMaxSd -= 1;
					}
				} //+++ End of readable existing connection.
			} //+++ End of if that checks for ready descriptors.
		} //+++ End of loop through selectable descriptors.	
	} while (bEndServer == false);

	for (iSd = 0; iSd <= iMaxSd; ++iSd)	//+++ Clean up all of the sockets that are open.
		if (FD_ISSET(iSd, &master_set))
			close(iSd);

	ThreadInfo::SbExitThread = true;	//+++ Laptop never asked for early closure: close here its remaining recv threads (ReceiveFromMcTp).
}