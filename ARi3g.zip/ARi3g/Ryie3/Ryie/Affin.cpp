#include "Ryie.h"

int SchedAff()
{
	cpu_set_t stSet0;
	CPU_ZERO(&stSet0);
	CPU_SET(0, &stSet0);
	int iRes = sched_setaffinity(0, sizeof(stSet0), &stSet0);
	if (iRes == -1)
		handle_error_en(iRes, "sched_setaffinity");

	sched_param stParam;
	stParam.__sched_priority = 0;
	if (sched_setscheduler(0, SCHED_OTHER, &stParam) == -1)
		handle_error("sched_setscheduler");
#ifdef _BRIEF_
	cout << "Main thread running on CPU: " << sched_getcpu() << endl;
	DisplayThreadSchedAttr("Main thread attributes:");
	cout << endl << "Handling of threads follows: ";
#endif // _BRIEF_
	CPU_ZERO(&ThreadInfo::SstSet1);
	CPU_SET(1, &ThreadInfo::SstSet1);
	CPU_ZERO(&ThreadInfo::SstSet2);
	CPU_SET(2, &ThreadInfo::SstSet2);
	CPU_ZERO(&ThreadInfo::SstSet3);	//+++ It's reserved for another purpose.
	CPU_SET(3, &ThreadInfo::SstSet3);

	return SUCCESS;
}

void DisplayThreadSchedAttr(const char *msg)
{
	int iPolicy, iRes;
	sched_param stParam;

	iRes = pthread_getschedparam(pthread_self(), &iPolicy, &stParam);
	if (iRes != 0)
		handle_error_en(iRes, "pthread_getschedparam");

	cout << msg << endl;	
	cout << "iPolicy = " << ((iPolicy == SCHED_FIFO) ? "SCHED_FIFO" : (iPolicy == SCHED_RR) ? "SCHED_RR" :
							(iPolicy == SCHED_OTHER) ? "SCHED_OTHER" : "???") << ", priority = " << stParam.sched_priority << endl;
}

void ThreadAttr(pthread_attr_t &unAttr)
{
	int iRes, iPolicy = SCHED_FIFO;	
	sched_param stParam;		

	//+++ Initialize thread attributes object.
	iRes = pthread_attr_init(&unAttr);	//+++ Initialize thread creation attributes.
	if (iRes != 0)
		handle_error_en(iRes, "pthread_attr_init");

	iRes = pthread_attr_setinheritsched(&unAttr, PTHREAD_EXPLICIT_SCHED);
	if (iRes != 0)
		handle_error_en(iRes, "pthread_attr_setinheritsched");	

	iRes = pthread_attr_setstacksize(&unAttr, THREAD_STACK_SIZE);
	if (iRes != 0)
		handle_error_en(iRes, "pthread_attr_setstacksize");

	iRes = pthread_attr_setschedpolicy(&unAttr, iPolicy);
	if (iRes != 0)
		handle_error_en(iRes, "pthread_attr_setschedpolicy");
		
	stParam.sched_priority = 10;	

	iRes = pthread_attr_setschedparam(&unAttr, &stParam);
	if (iRes != 0)
		handle_error_en(iRes, "pthread_attr_setschedparam");
#ifdef _BRIEF_
	cout << endl << "iMaxPrior: " << sched_get_priority_max(iPolicy) << endl << "iMinPrior: " << sched_get_priority_min(iPolicy) << endl << endl;
#endif // _BRIEF_		
}