#include "^Common.h"

extern const uint8_t CucTotElem;

#pragma DATA_ALIGN(EchoRxTaskStack, 8)  //+++ 1-byte alignment on the stack to avoid wasting memory.
static uint8_t EchoRxTaskStack[STACKSIZE];
Task_Struct EchoRxTr;
bool bOnce = false;

Void EchoRxTf(UArg arg0, UArg arg1);
static void EchoRxCb(RF_Handle h, RF_CmdHandle ch, RF_EventMask e);

void StartEchoRxTf(void)
{
    Task_Params taskParams;
    Task_Params_init(&taskParams);
    taskParams.stackSize = STACKSIZE;
    taskParams.priority = 2;    //+++ More than 1 or is preempted by while (1) in mainThread.
    taskParams.stack = &EchoRxTaskStack;

    Task_construct(&EchoRxTr, EchoRxTf, &taskParams, NULL);
}

Void EchoRxTf(UArg arg0, UArg arg1)
{
    RF_Params rfParams;
    RF_Params_init(&rfParams);

    if( RFQueue_defineQueue(&dataQueue,
                            rxDataEntryBuffer,
                            sizeof(rxDataEntryBuffer),
                            NUM_DATA_ENTRIES,
                            PAYLOAD_LENGTH + NUM_APPENDED_BYTES))
    {
        /* Failed to allocate space for all data entries */
        PIN_setOutputValue(ledPinHandle, Board_PIN_LED1, 1);
        PIN_setOutputValue(ledPinHandle, Board_PIN_LED2, 1);
        while(1);
    }

    /* Modify CMD_PROP_TX and CMD_PROP_RX commands for application needs */
    RF_cmdPropRx.pQueue = &dataQueue;   //+++ Set the Data Entity queue for received data.
    RF_cmdPropRx.rxConf.bAutoFlushIgnored = 1;  //+++ Discard ignored packets from Rx queue.
    RF_cmdPropRx.rxConf.bAutoFlushCrcErr = 1;   //+++ Discard packets with CRC error from Rx queue.
#ifdef TIMESTAMP
    RF_cmdPropRx.rxConf.bAppendTimestamp = 1;// Append RX timestamp to the payload
#endif
    /* Implement packet length filtering to avoid PROP_ERROR_RXBUF */
    RF_cmdPropRx.maxPktLen = PAYLOAD_LENGTH;

    /* End RX operation when a packet is received correctly and don't move on to the next command in the chain */
    RF_cmdPropRx.pktConf.bRepeatOk = 0;
    RF_cmdPropRx.pktConf.bRepeatNok = 0;
    RF_cmdPropRx.startTrigger.triggerType = TRIG_ABSTIME;
    RF_cmdPropRx.startTrigger.pastTrig = 1;
    RF_cmdPropRx.startTime = 0;

    Chase(rfParams);
    while(1)
    {
        if (bOnce == false)
            ucOnlyRxTimes--;

        OnlyRx(rfParams);

        RF_cmdPropRx.pktConf.bRepeatNok = 1;    //+++ Move on to the next command in the chain.
        RF_cmdPropRx.pNextOp = (rfc_radioOp_t *)&RF_cmdPropTx;
        RF_cmdPropRx.condition.rule = COND_STOP_ON_FALSE;   //+++ Only run the TX command if RX is successful.

        if (bOnce == false)
        {
            bOnce = true;
            ucOnlyRxTimes++;
            RF_cmdPropRx.pOutput = (uint8_t *)&rxStatistics;
            RF_cmdPropTx.pktLen = PAYLOAD_LENGTH;
            RF_cmdPropTx.pPkt = txPacket;
            RF_cmdPropTx.startTrigger.triggerType = TRIG_REL_PREVEND;
            RF_cmdPropTx.startTime = TX_DELAY;
        }

        /* Request access to the radio */
        rfHandle = RF_open(&rfObject, &RF_prop, (RF_RadioSetup*)&RF_cmdPropRadioDivSetup, &rfParams);
        RF_postCmd(rfHandle, (RF_Op*)&RF_cmdFs, RF_PriorityNormal, NULL, 0);    //+++ Set the frequency.

//        /* Set absolute RX time to utilize automatic power management */
//        uint32_t curtime = RF_getCurrentTime(); //+++ Get current time.

        uint8_t ucCount = 0;
        while(ucCount++ < ucRxTxTimes)
        {
//            /* Request access to the radio */
//            rfHandle = RF_open(&rfObject, &RF_prop, (RF_RadioSetup*)&RF_cmdPropRadioDivSetup, &rfParams);
//            RF_postCmd(rfHandle, (RF_Op*)&RF_cmdFs, RF_PriorityNormal, NULL, 0);    //+++ Set the frequency.

            /* Set absolute RX time to utilize automatic power management */
            uint32_t curtime = RF_getCurrentTime(); //+++ Get current time.

            curtime += ucDelayFactor * PACKET_INTERVAL;
            RF_cmdPropRx.startTime = curtime;

            /* Wait for a packet
             * - When the first of the two chained commands (RX) completes, the
             * RF_EventCmdDone and RF_EventRxEntryDone events are raised on a
             * successful packet reception, and then the next command in the chain
             * (TX) is run
             * - If the RF core runs into an issue after receiving the packet
             * incorrectly only the RF_EventCmdDone event is raised; this is an
             * error condition
             * - If the RF core successfully echos the received packet the RF core
             * should raise the RF_EventLastCmdDone event
             */
            RF_EventMask terminationReason = RF_runCmd(rfHandle, (RF_Op*)&RF_cmdPropRx, RF_PriorityNormal,
                                                       EchoRxCb, (RF_EventRxEntryDone/* | RF_EventLastCmdDone*/));

            uint32_t cmdStatus = ((volatile RF_Op*)&RF_cmdPropRx)->status;
            TermStat(terminationReason, cmdStatus);

//            RF_close(rfHandle);
        }
        RF_close(rfHandle);

        /* Reset CMD_PROP_RX. */
        RF_cmdPropRx.pktConf.bRepeatNok = 0;    //+++ Don't move on to the next command in the chain.
        RF_cmdPropRx.pNextOp = 0;
        RF_cmdPropRx.condition.rule = 0x1;
    }
}

static void EchoRxCb(RF_Handle h, RF_CmdHandle ch, RF_EventMask e)
{
#ifdef LOG_RADIO_EVENTS
    eventLog[evIndex++ & 0x1F] = e;
#endif// LOG_RADIO_EVENTS

    if (e & RF_EventRxEntryDone)
    {
        //+++ Successful RX. Toggle LED2, clear LED1 to indicate RX.
        PIN_setOutputValue(ledPinHandle, Board_PIN_LED1, 0);
        PIN_setOutputValue(ledPinHandle, Board_PIN_LED2, !PIN_getOutputValue(Board_PIN_LED2));

        currentDataEntry = RFQueue_getDataEntry();  //+++ Get current unhandled data entry.

        /* Handle the packet data, located at &currentDataEntry->data:
         * - Length is the first byte with the current configuration
         * - Data starts from the second byte */
        packetLength      = *(uint8_t *)(&(currentDataEntry->data));
        packetDataPointer = (uint8_t *)(&(currentDataEntry->data) + 1);
#ifdef TIMESTAMP
//        uint8_t *pucRxTimestamp = packetDataPointer + packetLength, *pucTxTimestamp = packetDataPointer + OFFSET_UTIL_DATA;
//        uint32_t rxTimestamp, txTimestamp = 0;
//        memcpy(&rxTimestamp, pucRxTimestamp, TIMESTAMP);
//
//        uint8_t ucCount, ucShift = (sizeof(uint32_t) - sizeof(uint8_t)) * BYTELENGTH;
//        for (ucCount = 0; ucCount < sizeof(uint32_t); ucCount++, ucShift -= BYTELENGTH)
//            txTimestamp += (*(pucTxTimestamp + ucCount)) << ucShift;
//
//        uiOffsetMs[ucTimes++] = txTimestamp - rxTimestamp;
//
//        if (ucTimes == CucTotElem)
//        {
//            for (ucCount = 0; ucCount < CucTotElem; ucCount++)
//                ullAverageOms += uiOffsetMs[ucCount];
//
//            ullAverageOms /= CucTotElem;
//            ucTimes = 0;
//            ullAverageOms = 0;
//        }
#endif
        //+++ Copy the payload + status byte to the rxPacket variable, and then over to the txPacket.
        memcpy(txPacket, packetDataPointer, packetLength);

        RFQueue_nextEntry();
    }
    else if (e & RF_EventLastCmdDone)
    {
        //+++ Successful Echo (TX). Toggle LED1 and LED2 to indicate TX.
        PIN_setOutputValue(ledPinHandle, Board_PIN_LED1, !PIN_getOutputValue(Board_PIN_LED1));
        PIN_setOutputValue(ledPinHandle, Board_PIN_LED2, !PIN_getOutputValue(Board_PIN_LED2));
    }
    else
    {
        //+++ Any uncaught event. Error Condition: set LED1, clear LED2.
        PIN_setOutputValue(ledPinHandle, Board_PIN_LED1, 1);
        PIN_setOutputValue(ledPinHandle, Board_PIN_LED2, 0);
    }
}
