/*
 * ^swi.h
 *
 *  Created on: 25 ott 2018
 *      Author: andre
 */

#ifndef SWI_H_
#define SWI_H_

char a2cSwiInfo[5][100];

Void ZeroSwf(UArg arg0, UArg arg1);
void StartZeroSwf(void);
Void OneSwf(UArg arg0, UArg arg1);
void StartOneSwf(void);

#endif /* SWI_H_ */
