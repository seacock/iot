#include "ColorText.h"

CColorText::CColorText(int iColor)
{
	iColorText = iColor;
}

CColorText::~CColorText()
{
}

ostream& operator <<(ostream &os, const CColorText &obj)
{
	// TODO: insert return statement here
	os << obj.asrColor[obj.iColorText] << obj.ss.str() << "\x1B[0m";
	return os;
}