/*
 * Copyright (c) 2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/***** Includes *****/
/* Standard C Libraries */

/* TI Drivers */
#include <ti/drivers/rf/RF.h>

/* Driverlib Header files */
#include DeviceFamily_constructPath(driverlib/rf_prop_mailbox.h)

/* Board Header files */
#include "smartrf_settings/smartrf_settings.h"

#include <^Common.h>

/***** Defines *****/
/* Do power measurement */
//#define POWER_MEASUREMENT
#define RX_BUFFER_ENTRIES 5 //+++ Rx packet feature.

/* Packet TX Configuration */
#ifdef POWER_MEASUREMENT
#define PACKET_INTERVAL     5  /* For power measurement set packet interval to 5s */
#endif

/***** Variable declarations *****/
static RF_Object rfObject;
static RF_Handle rfHandle;

static uint8_t packet[TX_PAYLOAD_LENGTH];

/***** Function definitions *****/

Void TxRadioTf(UArg arg0, UArg arg1)
{
    RF_Params rfParams;
    RF_Params_init(&rfParams);

    RF_cmdPropTx.pktLen = TX_PAYLOAD_LENGTH;
    RF_cmdPropTx.pPkt = packet;
    RF_cmdPropTx.startTrigger.triggerType = TRIG_NOW;

    rfHandle = RF_open(&rfObject, &RF_prop, (RF_RadioSetup*)&RF_cmdPropRadioDivSetup, &rfParams);   //+++ Request access to the radio.
    RF_postCmd(rfHandle, (RF_Op*)&RF_cmdFs, RF_PriorityNormal, NULL, 0);    //+++ Set the frequency.

    uint8_t ucRow, ucColumn, ucBufferEntry = 0;
    while(1)
    {
        for (ucRow = 0; ucRow < ADC_ROWS; ucRow++)
        {
            for (ucColumn = 0; ucColumn < ADC_COLUMNS; ucColumn++)
            {
                if (ucBufferEntry == 0)
                {
                    if (ucRow == 0)
                        packet[ucColumn] = 'A';
                    else
                        packet[ucColumn] = 'Z';
                }
                else
                    packet[ucColumn] = AdcPacket[ucRow][ucColumn];
            }

            RF_EventMask terminationReason = RF_runCmd(rfHandle, (RF_Op*)&RF_cmdPropTx, RF_PriorityNormal, NULL, 0);    //+++ Send packet.

            switch(terminationReason)
            {
                case RF_EventLastCmdDone:
                    //+++ A stand-alone radio operation command or the last radio operation command in a chain finished.
                    break;
                case RF_EventCmdCancelled:
                    //+++ Command cancelled before it was started; it can be caused by RF_cancelCmd() or RF_flushCmd().
                    break;
                case RF_EventCmdAborted:
                    //+++ Abrupt command termination caused by RF_cancelCmd() or RF_flushCmd().
                    break;
                case RF_EventCmdStopped:
                    //+++ Graceful command termination caused by RF_cancelCmd() or RF_flushCmd().
                    break;
                default:
                    //+++ Uncaught error event.
                    while(1);
            }

            uint32_t cmdStatus = ((volatile RF_Op*)&RF_cmdPropTx)->status;
            switch(cmdStatus)
            {
                case PROP_DONE_OK:
                    //+++ Packet transmitted successfully.
                    break;
                case PROP_DONE_STOPPED:
                    //+++ Received CMD_STOP while transmitting packet and finished transmitting packet.
                    break;
                case PROP_DONE_ABORT:
                    //+++ Received CMD_ABORT while transmitting packet.
                    break;
                case PROP_ERROR_PAR:
                    //+++ Observed illegal parameter.
                    break;
                case PROP_ERROR_NO_SETUP:
                    //+++ Command sent without setting up the radio in a supported mode using CMD_PROP_RADIO_SETUP or CMD_RADIO_SETUP.
                    break;
                case PROP_ERROR_NO_FS:
                    //+++ Command sent without the synthesizer being programmed.
                    break;
                case PROP_ERROR_TXUNF:
                    //+++ TX underflow observed during operation.
                    break;
                default:
                    //+++ Uncaught error event - these could come from the pool of states defined in rf_mailbox.h .
                    while(1);
               }

            #ifndef POWER_MEASUREMENT
            PIN_setOutputValue(DynPinH, BOARD_PIN_GREEN_LED, !PIN_getOutputValue(BOARD_PIN_GREEN_LED)); //+++ Toggle pin to indicate TX.
            #endif
        }

        if (++ucBufferEntry == RX_BUFFER_ENTRIES)
        {
            ucBufferEntry = 0;
            RF_yield(rfHandle); //+++ Power down the radio.
        }

        #ifdef POWER_MEASUREMENT
            sleep(PACKET_INTERVAL); //+++ Sleep for PACKET_INTERVAL s.
        #else
            Semaphore_post(SentPacketSemH);
            Semaphore_pend(TxSemH, BIOS_WAIT_FOREVER);
        #endif
    }
}
