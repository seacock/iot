// TabTwo.cpp : implementation file
//

#include "stdafx.h"
#include "Asi.h"
#include "TabTwo.h"
#include "afxdialogex.h"

// CTabTwo dialog

IMPLEMENT_DYNAMIC(CTabTwo, CDialogEx)

CTabTwo::CTabTwo(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_TAB_TWO, pParent)
{
}

CTabTwo::~CTabTwo()
{
}

void CTabTwo::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_ED_THR1M, jedThr1M);
	DDX_Control(pDX, IDC_ED_THR1V, jedThr1V);
	DDX_Control(pDX, IDC_PGS_THR1, jpgsThr1);
}

BEGIN_MESSAGE_MAP(CTabTwo, CDialogEx)
	ON_REGISTERED_MESSAGE(RG_WM_ED_THR1M, &CTabTwo::OnEdThr1M)
	ON_REGISTERED_MESSAGE(RG_WM_ED_THR1V, &CTabTwo::OnEdThr1V)
	ON_REGISTERED_MESSAGE(RG_WM_PGS_THR1, &CTabTwo::OnPgsThr1)
END_MESSAGE_MAP()

// CTabTwo message handlers

BOOL CTabTwo::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  Add extra initialization here
	jpgsThr1.SetRange32(-100, +100);

	int iLower, iUpper;
	jpgsThr1.GetRange(iLower, iUpper);
	jpgsThr1.SetStep((iUpper - iLower) / 10);	//+++ Set the step to be 1/10 of the total range. 

	jpgsThr1.SetPos(-100);	//+++ Hide indicator.

	return TRUE;  // return TRUE unless you set the focus to a control
				  // EXCEPTION: OCX Property Pages should return FALSE
}

LRESULT CTabTwo::OnEdThr1M(WPARAM wParam, LPARAM lParam)
{
	wsrMtrThr1 += (const wchar_t*)wParam + (wstring)L"\r\n";
	jedThr1M.SetWindowTextW(wsrMtrThr1.c_str());
	return NO_ERROR;
}

LRESULT CTabTwo::OnEdThr1V(WPARAM wParam, LPARAM lParam)
{
	wstring wsrMix((const wchar_t*)wParam), wsrName(L"Pushbutton");
	if (wsrMix.find(wsrName) != string::npos)
	{
		wsrMix = wsrMix.substr(wsrName.length(), wsrMix.length() - wsrName.length());
		jedThr1V.SetWindowTextW(wsrMix.c_str());
	}

	return NO_ERROR;
}

LRESULT CTabTwo::OnPgsThr1(WPARAM wParam, LPARAM lParam)
{
	wstring wsrMix((const wchar_t*)wParam), wsrName(L"Pushbutton");
	if (wsrMix.find(wsrName) != string::npos)
	{
		wsrMix = wsrMix.substr(wsrName.length(), wsrMix.length() - wsrName.length());
		string str8CheckNum = WsToStUtf8(wsrMix);
		jpgsThr1.SetPos(atoi(str8CheckNum.c_str()));
	}

	return NO_ERROR;
}