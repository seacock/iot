/*
 * ^Video.c
 *
 *  Created on: 04 dic 2018
 *      Author: andre
 */

#include <^Common.h>
#include <stdlib.h>
#include <ti/display/AnsiColor.h>

void StartDisplayTf(void);
Void DisplayTf(UArg arg0, UArg arg1);
Task_Struct DisplayTr;
#pragma DATA_ALIGN(DisplayTaskStack, 8)  //+++ 1-byte alignment on the stack to avoid wasting memory.
static uint8_t DisplayTaskStack[STACKSIZE];

void StartDisplayTf(void)
{
    Task_Params taskParams;
    Task_Params_init(&taskParams);
    taskParams.stackSize = STACKSIZE;
    taskParams.priority = 2;    //+++ More than 1 or is preempted by while (1) in mainThread.
    taskParams.stack = &DisplayTaskStack;

    Task_construct(&DisplayTr, DisplayTf, &taskParams, NULL);
}

Void DisplayTf(UArg arg0, UArg arg1)
{
    while (1)
    {
        Semaphore_pend(DisplaySemH, BIOS_WAIT_FOREVER);    //+++ Wait on semaphore till CC1310_LAUNCHXL_DIO1 is pushed.
        uint32_t *auiTemporary = (uint32_t*)malloc(COMPOSED_LENGTH * sizeof(uint32_t));

        uint16_t usBound;   //+++ Copy auiCoupled to auiTemporary as first is used intensively by ComposeCouple() .
        for (usBound = 0; usBound < COMPOSED_LENGTH; usBound++)
            auiTemporary[usBound] = auiCoupled[usBound];

        for (usBound = 0; usBound < 2 * TX_PAYLOAD_LENGTH; usBound++)    //---
            Display_printf(DisplayH, 0, 0, ANSI_COLOR(FG_CYAN) "auiTemporary: %d     seq: %d" ANSI_COLOR(ATTR_RESET), auiTemporary[usBound], usBound);    //+++ Synchro.

        int usChangeColor = 0;
        for (usBound = 2 * TX_PAYLOAD_LENGTH; usBound < COMPOSED_LENGTH; usBound++, usChangeColor++)
            if (usChangeColor < TX_PAYLOAD_LENGTH)
                Display_printf(DisplayH, 0, 0, ANSI_COLOR(FG_RED) "auiTemporary: %d     seq: %d" ANSI_COLOR(ATTR_RESET), auiTemporary[usBound], usBound); //+++ Channel 1 of ADC.
            else if (usChangeColor >= TX_PAYLOAD_LENGTH && usChangeColor < 2 * TX_PAYLOAD_LENGTH)
                Display_printf(DisplayH, 0, 0, ANSI_COLOR(FG_GREEN) "auiTemporary: %d     seq: %d" ANSI_COLOR(ATTR_RESET), auiTemporary[usBound], usBound);   //+++ Channel 2 of ADC.
            else
                usChangeColor = 0;

        free(auiTemporary);
        PIN_setInterrupt(DInPinH, CC1310_LAUNCHXL_DIO1 | PIN_IRQ_NEGEDGE);  //+++ Enable further stops.
        PIN_setInterrupt(DInPinH, CC1310_LAUNCHXL_DIO21 | PIN_IRQ_NEGEDGE); //+++ Enable further launchs.
        PIN_setInterrupt(DInPinH, CC1310_LAUNCHXL_DIO22 | PIN_IRQ_NEGEDGE); //+++ Enable further launchs.
    }
}
