#pragma once

#include <iostream>
#include <sstream>
#include <vector>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <ifaddrs.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <time.h>
#include <wiringPi.h>
#include <wiringPiSPI.h>
#include <wiringPiI2C.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include "ColorText.h"

using namespace std;

//#define _BRIEF_
//#define _TALKATIVE_
#define _WEBTOM8_	//+++ Tomcat8 must be on and able to access its 2 local txt files.

#define SUCCESS 0
#define ERROR 1
#define INVALID_SOCKET -1
#define NUM_THREADS 6
#define PORT 13   //+++ The port on which to send data for broadcast: daytime.
#define SWITCH_INC 1	//+++ (RaspberryPi2 40-pin header J8: pin 12 hardware = GPIO 18 BCM) = (wiringPi: GPIO1 = pin 1 software)
#define SWITCH_DEC 4	//+++ (RaspberryPi2 40-pin header J8: pin 16 hardware = GPIO 23 BCM) = (wiringPi: GPIO4 = pin 4 software)
#define DELAY 500
#define THREAD_STACK_SIZE 40000	//+++ Enough to provide for getaddrinfo that uses stack and not heap.
#define SPI_CHANNEL 0
#define SPI_SPEED 500000
#define SPI_LENGTH 1
#define BUFLEN 512	//+++ initial size for dynamic C-style array vector; size of generic reading-writing buffer.
#define SELECT_TIMEOUT 0
#define I2C_RY_NORMAL 200	//+++ 
#define I2C_RY_EXIT 201	//+++ Rym's communication threads stop communication and Rym exit. Defined in LaT, Ry.
#define I2C_RY_SHUT_COMM 202	//+++ Rym's communication threads stop communication, but Rym continues working. Defined in LaT, Ry.
#define I2C_LAPTOP_DISMISS 203	//+++ Laptop is dismissed, but Rym continues working. Defined in LaT, Ry.
#define TOT_NUM_SPI_CALLS (1000 * 1000 * 1000)
#define NUM_SPI_CALLS 2000
#define TOMCAT_COUNTER 1000
#define LAPTOP_COUNTER 100
#define BROADCAST 1
#define ONE 2
#define TWO 3
#define THREE 4
#define TEMPORARY 5
#define SERVER_I2C 6
#define INVALID_FD -1

//+++ First time identification msg for thread related to: broadcasting; local pushbuttons; SPI(potentiometer processed by Pic24); SPI (thermometer processed by Pic24); laptop client setup; I2C (Pic24). Not all are used.
struct CoupleId
{
	string srMessage;
	int iMessage;
};

static vector<CoupleId> SteCoupleID(NUM_THREADS);	//+++ Store identification msg for all threads created by app.

//+++ Commands to retrieve AD converted physical quantities from Microchip PICFJ64GB002.
#define CMD_UB_P 0x01   //+++ Upper byte of potentiometer. Defined in Ry, Mip.
#define CMD_LB_P 0x02   //+++ Lower byte of potentiometer. Defined in Ry, Mip.
#define CMD_UB_T 0x04   //+++ Upper byte of thermometer. Defined in Ry, Mip.
#define CMD_LB_T 0x05   //+++ Lower byte of thermometer. Defined in Ry, Mip.
#define CMD_UB_RS 0x06   //+++ Upper byte of SPI resets. Defined in Ry, Mip.
#define CMD_LB_RS 0x07   //+++ Lower byte of SPI resets. Defined in Ry, Mip.

#define handle_error_en(en, msg) \
               do { errno = en; cerr << msg << ": " << strerror(errno) << endl; exit(EXIT_FAILURE); } while (0)	//+++

#define handle_error(msg) \
               do { cerr << msg << ": " << strerror(errno) << endl; exit(EXIT_FAILURE); } while (0)	//+++ Print error message and exit app.

#define handle_error1(msg1) \
               do { cerr << msg1 << endl; exit(EXIT_FAILURE); } while (0)	

#define handle_error2(msg1, msg2) \
               do { cerr << msg1 << ": " << msg2 << endl; exit(EXIT_FAILURE); } while (0)	

#define ADC_AVERAGE 110	//+++ PICFJ64GB002 sends back average ADC values for potentiometer and thermometer. Defined in LaT, Ry, Mip.
#define ADC_LASTVAL 120	//+++ PICFJ64GB002 sends back last ADC value for potentiometer and thermometer. Defined in LaT, Ry, Mip.
#define PWM_CONTINUOUS 130	//+++ PICFJ64GB002 outputs PWM with duty cycle fixed by slider. Defined in LaT, Ry, Mip.
#define PWM_FUNCTION 140	//+++ PICFJ64GB002 outputs PWM with variable duty cycle depending on a local function. Defined in LaT, Ry, Mip.

enum StateI2c { STATE_Off, STATE_On };	//+++ Values on which TEMPORARY thread waits till I2cServTp wakes it up.
enum StateSpi { STATE_Potentiometer, STATE_Thermometer };//???
struct ModeComm
{
	static int SiMode;
};

//+++ Used as argument to SocTxRxTp()...
struct ThreadInfo
{
	pthread_t ulThread_id;	//+++ ID returned by pthread_create().
	int iThreadNum;	//+++ Application-defined thread #.
	static cpu_set_t SstSet1, SstSet2, SstSet3;//???
	char pcInfoArg[50];	//+++ First argument sent to Asi server ReceiveTp. ReceiveTp uses that to recognize which kind of thread has connected.
	static char SacBroadcast[INET_ADDRSTRLEN];//???
	static string SsrI2cServerPort;	//+++ Sent to client laptop ASUS after broadcasting, by TEMPORARY thread.
	static string SsrTom8ServerPort;	//+++ Local port of Tomcat8. It's used by local ip address of this app. This app and Tomcat8 reside on RaspberryPi2. 	
	static string SsrRemSvrPortR3;	//+++ Sent to laptop ASUS after broadcasting, by TEMPORARY thread. For remot3.it it's 80. Given remot3.it host and its port (80), LaptopASUS can get an endpoint address to which to connect a socket.
	static string SsrRemSvrPortNi;	//+++ Sent to laptop ASUS after broadcasting, by TEMPORARY thread. For noip.com it's the same as SsrTom8ServerPort. Given noip.com host and its port (8080), LaptopASUS can get an endpoint address to which to connect a socket.
	static string SsrLANServerHost;	//+++ Received from laptop ASUS when broadcasting.
	static string SsrLANServerPort;	//+++ Received from laptop ASUS when broadcasting.
	static pthread_barrier_t Sbarrier5;	//+++ Barrier for threads: BROADCAST, ONE, TWO, THREE, TEMPORARY. When barrier gives the go-ahead, SsrLANServerHost and SsrLANServerPort already initialized by BROADCAST, can be used by the other 4 threads.
};

struct Sensor
{
	string srIdMsg;
	uint uiDelay;	//+++ Time to wait before asking for next value.
	unsigned char ucUpper;
	unsigned char ucLower;
	string srName;
	unsigned int uiNumOfSpiCalls;
	unsigned long ulTotNumOfSpiCalls;
	unsigned int uiTomcatCounter;
	unsigned int uiLaptopCounter;
	static StateSpi SenStateSpi;
	static pthread_cond_t ScondPotentiometer;
	static pthread_cond_t ScondThermometer;
	static pthread_mutex_t SmutexSpi;
};

//+++ Information about incoming laptop ASUS client.
struct I2c
{
	static int SiFdI2c;	//+++ File descriptor for I2C device.
	static StateI2c SenStateI2c;	//+++ Values on which TEMPORARY thread waits till I2cServTp wakes it up.
	static pthread_cond_t ScondI2c;	//+++ Condition on which TEMPORARY thread waits till I2cServTp wakes it up.
	static pthread_mutex_t SmutexI2c;	//+++ Mutex called by TEMPORARY and I2cServTp threads to manage ScondI2c and SenStateI2c. Only one thread owns it at a time.
};

//+++ Local network interface.
struct Wlan0Inet4
{
	char acInternetAddress[INET_ADDRSTRLEN];
	char acLineDescription[INET_ADDRSTRLEN];
	char acNetmask[INET_ADDRSTRLEN];
	char acBroadcastAddr[INET_ADDRSTRLEN];	//+++ The broadcast address is used to interrogate the remote LaptopASUS.
};

int SchedAff();	//+++ Manages CPU mask for main and child threads. Set affinity and scheduling algorithm for main thread.
void PoolThread(int iNumThreads);	//+++ Create and join NUM_THREADS threads.
ThreadInfo* CreateThread(ThreadInfo* pstThIn, int iNThreads, void *(**ppStartRoutine)(void*));	//+++ Create child threads.
void ThreadAttr(pthread_attr_t &unAttr);	//+++ Set stack size, scheduling inheritance, policy and priority for child threads.
void* SocTxRxTp(void *arg);	//+++ Thread procedure.
void DisplayThreadSchedAttr(const char *msg);	//+++ Display scheduling parameters( and CPU affinity) for calling thread.
int SockAddrConn(const char* pcHostName, uint16_t usiPort);	//+++ Get host's internet address from its name and service-port; connect to server laptop ASUS within Eolo Fritz!Box LAN router. getaddrinfo(): Jessie recognized "localhost" and other alphanumeric host names, instead Stretch doesn't; Stretch wants pcHostName in the dotted form: "aaa.bbb.ccc.ddd".
void SendValue(int iFdLas, int iValue, string srWho);	//+++ Send value to laptop ASUS.
void WriteToServer(int iFdLas, const char* buf);	//+++ Send data to laptop ASUS.
void BtnIncDec(int iFdLas);	//+++ Manage 2 push buttons.
void SpiMaster(int iFdLas, Sensor &stSensor);	//+++ SPI master for PIC24 sensors.
void SpiDataRW(unsigned char ucData, unsigned char &ucULByte);	//+++ Communicate with MicroChip Pic24 for Spi.
int I2cMaster(int iFdI2cM, unsigned char ucNumber, int iFdLas);	//+++ Communicate with MicroChip Pic24 for I2c and send back values to laptop ASUS. Depending on value of iFdLas, writing can be from client or from server.
void CommServerWrite(int iFdTom8, int iValue, string srWho);	//+++ Send value to RaspberryPi2's Tomcat8.
void InterfacesIp(Wlan0Inet4 &stWlan0Inet4);	//+++ Fill a structure. malloc to eliminate, only used to refresh my knowledge of array of ptrs, struct is sufficient//???
void* BroadTp(void *arg);	//+++ Uses the broadcast address obtained from InterfacesIp(). Raspberry initiates the broadcast sending a greeting msg to the remote LaptopASUS. Then Raspberry receives from LaptopASUS: SsrLANServerPort.
int SrNonblockFlag(int iDesc, int iValue);	//+++ Set, reset the O_NONBLOCK flag of iDesc.
void* I2cServTp(void *arg);	//+++ Server for client laptop ASUS: exchange commands/data for I2C. It can immediately stay in receive mode. If broadcasting or handshaking or communication fail, it times out and terminates.
void CloseFdErr(int iFd, const char* pcErr);	//???
void FillCoupleId();	//+++ Populate vector holding identification msg for all threads created by app.						
template <typename T>	//+++ Transform a number to string.
string NumberToString(T Number)
{
	ostringstream ss;
	ss << Number;
	return ss.str();
}