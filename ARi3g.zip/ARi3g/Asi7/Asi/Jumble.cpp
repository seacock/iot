#include "stdafx.h"
#include "ShaWa.h"

wstring ThrAffinity(DWORD_PTR dwThreadAffinityMask)
{
	wstring wsrOut;
	wchar_t wchBuf[BUFLEN];
	DWORD_PTR dwOldThreadAffinityMask = SetThreadAffinityMask(GetCurrentThread(), dwThreadAffinityMask);
	_itow_s((int)dwOldThreadAffinityMask, wchBuf, sizeof(wchBuf) / sizeof(wchar_t), 10);
	wsrOut = L"OldThreadAffinityMask " + (wstring)wchBuf + L"\r\n";
	_itow_s((int)dwThreadAffinityMask, wchBuf, sizeof(wchBuf) / sizeof(wchar_t), 10);
	wsrOut += L"ThreadAffinityMask " + (wstring)wchBuf + L"\r\n";

	return wsrOut;
}

SOCKET ConnectToServer(Hook *pstHook)
{
	CTabOne *pTabOne = (CTabOne*)pstHook->pTabOne;

	WSADATA wsaData;
	SOCKET ConnectSocket = INVALID_SOCKET;
	addrinfo *result = NULL, *ptr = NULL, hints;
	int iResult;

	iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);	//+++ Initialize Winsock.
	if (iResult != 0)
		return MsgWsaCMA(pstHook, L"WSAStartup() failed with error: " + to_wstring(iResult) + L"\r\n", pTabOne, false);

	ZeroMemory(&hints, sizeof(hints));
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_protocol = IPPROTO_TCP;

	//+++ Resolve the server address and port.
	iResult = getaddrinfo(pstHook->stServerI2c.acIP, pstHook->stServerI2c.acPort, &hints, &result);
	if (iResult != 0)
		return MsgWsaCMA(pstHook, L"getaddrinfo() failed with error: " + to_wstring(WSAGetLastError()) + L"\r\n", true);

	//+++ Attempt to connect to an address until one succeeds.
	for (ptr = result; ptr != NULL; ptr = ptr->ai_next)
	{
		ConnectSocket = socket(ptr->ai_family, ptr->ai_socktype, ptr->ai_protocol);	//+++ Create a SOCKET for connecting to server.		
		if (ConnectSocket == INVALID_SOCKET)
			return MsgWsaCMA(pstHook, L"socket() failed with error: " + to_wstring(WSAGetLastError()) + L"\r\n", pTabOne, true);

		iResult = connect(ConnectSocket, ptr->ai_addr, (int)ptr->ai_addrlen);	//+++ Connect to server.
		if (iResult == SOCKET_ERROR)
		{
			MsgWsaCMA(pstHook, L"connect() failed with error: " + to_wstring(WSAGetLastError()) + L"\r\n", false, ConnectSocket);
			ConnectSocket = INVALID_SOCKET;
			continue;
		}
		break;
	}

	freeaddrinfo(result);

	if (ConnectSocket == INVALID_SOCKET)
		return MsgWsaCMA(pstHook, L"Unable to connect to server!\r\n", pTabOne, true);

	WSACleanup();

	return ConnectSocket;
}

int MsgWsaCMA(Hook *pstHook, wstring wsrMsg, bool bCleanup, SOCKET Socket)
{
	pstHook->pTabOne->SendMessageW(RG_WM_ED_SOC_T, (WPARAM)wsrMsg.c_str());
	if (Socket != INVALID_SOCKET)
		closesocket(Socket);

	if (bCleanup == true)
		WSACleanup();

	return ERROR_COMM;
}