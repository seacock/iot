/*
 * ^SvClock.c
 *
 *  Created on: 13 apr 2019
 *      Author: andre
 */

#include "^SvCommon.h"

Void ClockTimSta(UArg arg0)
{
	Task_destruct(&SvTimestampTr);//---
	Task_destruct(&SvAbsolTr);//---
	Semaphore_post(hsemCycle);
}

void StartClockTimSta(void)
{
    Clock_Params clockParams;
    Error_Block eb;
    Error_init(&eb);
    Clock_Params_init(&clockParams);
    hClock = Clock_create(ClockTimSta, 500, &clockParams, &eb);
    if (hClock == NULL)
        System_abort("Clock create failed");
}
