/* 
 * File:   ShaDe.h
 * Author: Administrator
 *
 * Created on 19 April 2018, 17:18
 */

#ifndef SHADE_H
#define	SHADE_H

#ifdef	__cplusplus
extern "C" {
#endif
    
#define OUTPUT_PIN 0
#define INPUT_PIN 1

#ifdef	__cplusplus
}
#endif

#endif	/* SHADE_H */

