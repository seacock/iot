/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author andre
 */
public class DrawSensor extends HttpServlet {
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet DrawSensor</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet DrawSensor at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
//        processRequest(request, response);

        doPost(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
//        processRequest(request, response);
       
        response.setIntHeader("Refresh", 1);
        
        String viewportwidth = request.getSession().getAttribute("viewportwidth").toString();
        String viewportheight = request.getSession().getAttribute("viewportheight").toString();
        Integer width = Integer.parseInt(viewportwidth);   //+++ Width of image.
        Integer height = Integer.parseInt(viewportheight);   //+++ Height of image.        
         
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB); //+++ Create image.        
        Graphics2D g2d = image.createGraphics();    //+++ Get drawing context.
        
        Font myFont = new Font("Courier New", 1, 80);
        g2d.setFont (myFont);
        
        //+++ Fill background.
        g2d.setColor(Color.white);
        g2d.fillRect(0, 0, width, height);
        
        //+++ Draw a rectangle and fill it.
        g2d.setColor(Color.BLUE);
        g2d.setStroke(new BasicStroke(5F));  //+++ Set stroke width of 5.
        g2d.drawRect(width / 10, height / 10, width / 5, height / 10);
        g2d.setColor(Color.ORANGE);
        TimerJ timerJPotentiom = (TimerJ)getServletContext().getAttribute("timerJPotentiom");
        Integer iTime = timerJPotentiom.GetTime();
        double dFract = ((double)iTime) / 500;
        double dRectLen = (double)width / 5 - (double)width / 10 - 2;
        g2d.fillRect(width / 10 + 2, height / 10 + 2, (int)(2 * dFract * dRectLen), height / 10 - 4);
        g2d.drawString(iTime.toString(), width / 5 + 150, height / 10 + 50);
        
        //+++ Draw a rectangle and fill it.
        g2d.setColor(Color.BLUE);
        g2d.setStroke(new BasicStroke(5F));  //+++ Set stroke width of 5.
        g2d.drawRect(width / 10, 4 * height / 10, width / 5, height / 10);
        g2d.setColor(Color.ORANGE);
        TimerJ timerJThermom = (TimerJ)getServletContext().getAttribute("timerJThermom");
        iTime = timerJThermom.GetTime();
        dFract = ((double)iTime) / 800;
        dRectLen = (double)width / 5 - (double)width / 10 - 2;
        g2d.fillRect(width / 10 + 2, 4 * height / 10 + 2, (int)(2 * dFract * dRectLen), height / 10 - 4);       
        g2d.drawString(iTime.toString(), width / 5 + 150, 4 * height / 10 + 50);
        
        myFont = new Font("Courier New", 1, 50);
        g2d.setFont (myFont);
        g2d.setColor(Color.GRAY);
        g2d.drawString(width.toString(), 100, 40);
        g2d.drawString(height.toString(), 400, 40);        
        
        g2d.dispose();  //+++ Dispose context.
        
        //+++ Send back image.
        response.setContentType("image/jpeg"); 
        try (OutputStream out = response.getOutputStream()) {
            ImageIO.write(image, "jpg", out);
        }        
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}