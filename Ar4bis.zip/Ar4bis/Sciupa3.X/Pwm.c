#include "Pwm.h"
#include "ShaDe.h"   
#include <PPS.h>    //+++ For PPSUnLock and similar.

#if __XC16_VERSION__ >= 0x0401
#undef _ISR
#define _ISR __attribute__((interrupt, auto_psv))
#endif

unsigned char guchPWMc;
unsigned char guchPWMcf;

int mainPWMX(void) 
{

    TRISBbits.TRISB7 = OUTPUT_PIN;  //+++ RP7-RB7: hwPin = 16. PWM output.
    LATBbits.LATB7 = 0; 
    
    PPSUnLock;  //+++ Unlock the PPS functionality.
    iPPSOutput(OUT_PIN_PPS_RP7, OUT_FN_PPS_OC1);   //+++ Out Compare1: RP7.???
    PPSLock;    //+++ Lock the PPS functionality.

    OC1CON1 = 0;    //+++ Clear off the control bits initially.
    OC1CON2 = 0;    //+++ Clear off the control bits initially.
    OC1CON1bits.OCTSEL = 0x07;  //+++ Peripheral ck is ck input to OC module.
    OC1R = 0;   //+++ Based on the waveform requirements and the system clock.
    OC1RS = PWM_PERIOD;     //+++ Period of the waveform.
    OC1CON2bits.SYNCSEL = 0x1F;     //+++ Synchronization source as itself.
    OC1CON1bits.OCM = 6;    //+++ Select and start the Edge Aligned PWM mode.
    
    Timer4TypeA();  
    
    return 0;
}

void Timer4TypeA(void)
{   
    guchPWMcf = PWM_FUNCTION;
    T4CON = 0x00;   //+++ Reset Timer4 control register and stop Timer4.
    TMR4 = 0x00;    //+++ Clear contents of Timer4 Register.
    T4CONbits.TCKPS = 3;    //+++ Timer4 Input Clock Prescale Select. 1:256.
    PR4 = TIMER4_PERIOD;    //+++ Manages increments of duty cycle for PWM.
    IPC6bits.T4IP = 2;  //+++ Timer4 Interrupt Priority.
    _T4IF = 0;  //+++ Clear Timer4 interrupt status flag.
    _T4IE = 1;  //+++ Enable Timer4 interrupts.   
    T4CONbits.TON = 1; //+++ Timer4 started. 
}

void _ISR _T4Interrupt(void)
{    
    if (guchPWMcf == PWM_FUNCTION)
    {
        OC1R = OC1R + PWM_STEP_HIGH;
    
        if (OC1R > PWM_PERIOD)
            OC1R = 0;
    }
    if (guchPWMcf == PWM_CONTINUOUS)
    {
        OC1R = guchPWMc * (PWM_PERIOD / 100);
    
        if (OC1R > PWM_PERIOD)
            OC1R = 0;
    }
    
    _T4IF = 0;
}