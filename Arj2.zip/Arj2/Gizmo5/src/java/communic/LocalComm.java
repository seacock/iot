/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package communic;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import writer.FLExWriteJ;

/**
 *
 * @author andre
 */
public class LocalComm extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet LocalComm</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet LocalComm at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
//        processRequest(request, response);
        doPost(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
//        processRequest(request, response);
        Integer iHitCount = 0;  //+++ Thread safe as it will be accessed by many threads. These threads are less disordered
                                //+++ than reading threads as they are created at a fixed rate by Ry. Nontheless they 
                                //+++ may possibly overlap too, causing a wrong enumeration of hits' count.
        //+++ Update of hits' count must be synchronized for above reason.
        synchronized(this) {            
            iHitCount = (int)request.getServletContext().getAttribute("LocalCommHC");
            iHitCount++;
            request.getServletContext().setAttribute("LocalCommHC", iHitCount);        
        }
        String strInput = request.getReader().readLine();   //+++ Get input from Ry client.

        FLExWriteJ flexw = new FLExWriteJ(strInput);  //+++ Write Ry's data to RAM file.
        try {
            flexw.Write();
        } catch (InterruptedException ex) {
            Logger.getLogger(LocalComm.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        response.getWriter().write("HitCountW:   " + iHitCount + flexw.strMessage); //+++ Send output to Ry client. 
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}