#pragma once
//#include "afxwin.h"
//#include "afxcmn.h"

// CTabTwo dialog

class CTabTwo : public CDialogEx
{
	DECLARE_DYNAMIC(CTabTwo)

public:
	CEdit jedThr1M;	//+++ Thread1: monitor.
	CEdit jedThr1V;	//+++ Thread1: push buttons of GPIO of RaspberryPi2.
	CProgressCtrl jpgsThr1;	//+++ Thread1: push buttons of GPIO of RaspberryPi2.
	CTabTwo(CWnd* pParent = NULL);   // standard constructor
	virtual ~CTabTwo();
	virtual BOOL OnInitDialog();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_TAB_TWO };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
private:		
	wstring wsrMtrThr1;	
	LRESULT OnEdThr1M(WPARAM wParam, LPARAM lParam);	//+++ Thread1 monitor.
	LRESULT OnEdThr1V(WPARAM wParam, LPARAM lParam);	//+++ Thread1: push buttons of GPIO of RaspberryPi2.
	LRESULT OnPgsThr1(WPARAM wParam, LPARAM lParam);	//+++ Thread1: push buttons of GPIO of RaspberryPi2.
};

static UINT RG_WM_ED_THR1M = RegisterWindowMessage(_T("EDIT THREAD1 MONITOR"));
static UINT RG_WM_ED_THR1V = RegisterWindowMessage(_T("EDIT THREAD1 VALUES"));
static UINT RG_WM_PGS_THR1 = RegisterWindowMessage(_T("PROGRESS THREAD1 VALUES"));