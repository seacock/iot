#pragma once

#include "CustEdit.h"
#include "afxwin.h"

#define NUM_SOCKETS 4

// CTabOne dialog

class CTabOne : public CDlgExBase
{
	DECLARE_DYNAMIC(CTabOne)
public:
	CButton jbnShut;
	CCustEdit jedCuSocTh;	//+++ ConnectTp will change this Edit's colors.
	string srHostName, srPortNumber;	//+++ This server name: host byte order; this server port: host byte order.	
	u_short usPortTcpIp;	//+++ Laptop server port: TCP/IP network byte order.
	CTabOne(CWnd* pParent = NULL);   // standard constructor
	virtual ~CTabOne();
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedBnLan();
	afx_msg void OnBnClickedBnShut();
	afx_msg void OnBnClickedBnOpen();
	afx_msg void OnBnClickedBnDismiss();
	afx_msg void OnEnUpdateEdPort();
	void ShutCloseSocket(SOCKET sock);	
// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_TAB_ONE };
#endif
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	DECLARE_MESSAGE_MAP()
private:
	CButton jbnLanServerStart;	
	CEdit jedSyPrMt;	//+++ Main thread system parameters.	
	CEdit jedLanServerPortNumber;
	wstring wsrMtrSocThr;
	wstring wsrMtrMain;
	LRESULT OnEdSocT(WPARAM wParam, LPARAM lParam);	//+++ Socket thread.
public:
	CButton jbnOpen;//???
	CButton jbnDismiss;
};

static UINT RG_WM_ED_SOC_T = RegisterWindowMessage(_T("EDIT SOCKET THREAD"));