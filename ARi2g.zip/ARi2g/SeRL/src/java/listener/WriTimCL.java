/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listener;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

/**
 * Web application lifecycle listener.
 *
 * @author andre
 */
public class WriTimCL implements ServletContextListener {
    @Override
    public void contextInitialized(ServletContextEvent sce) {
//        super.contextInitialized(sce); //To change body of generated methods, choose Tools | Templates.
        sce.getServletContext().setAttribute("SensVaHC", 0);    //+++ Initialize hits' count from reading threads of Ry.
        sce.getServletContext().setAttribute("LocalCommHC", 0); //+++ Initialize hits' count from writing threads of Ry.
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
//        super.contextDestroyed(sce); //To change body of generated methods, choose Tools | Templates.
    }
}