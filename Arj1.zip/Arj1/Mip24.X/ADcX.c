/*
 * File:   ADcX.c
 * Author: MeMyselfAndI
 *
 * Created on 14 agosto 2016, 8.08
 */

#include "ADcX.h"

int mainADcX(void) 
{
    T1CONbits.TON = 0;  //+++ Stop timer.
    
    ZeroAve(POTENT);
    ZeroAve(THERMO);
    ZeroVal(POTENT);
    ZeroVal(THERMO);    
    SetupADConverter();
    
    TMR1 = 0;   //+++ Prepare zeroed timer.
    _T1IF = 0;
    _T1IE = 1;
    T1CON = 0x8030; //+++ Timer started, prescaler .
    
    return 0;
}

void SetupADConverter(void)
{ 
    AD1CON1bits.ADON = 0;       //+++ Turn ADC OFF.
    
    //+++ AN0 (hwPin = 2), AN1 (hwPin = 3) input pins are analog.
    AD1PCFG = 0xFFFC;           
    AD1CSSL = 0x0003;           //+++ AN0 AN1 channels included in scan.
    
    //+++ Discontinue module operation when device enters Idle mode. Output 
    //+++ fractional. Internal counter ends sampling and triggers conversion: 
    //+++ auto-convert.
    AD1CON1 = 0x22E0;                                       
    AD1CON3 = 0x0F00;           //+++ Auto-sample time = 15 Tad. Tad = Tcy.
    
    //+++ Enable scanning of inputs for MUX A. Set AD1IF after every 2 samples.    
    AD1CON2 = 0x0404;       
    IEC0bits.AD1IE = 0; //+++ Disable A/D conversion interrupt.
    IFS0bits.AD1IF = 0; //+++ Clear A/D conversion interrupt flag.
    IPC3bits.AD1IP = 4; //+++ A/D interrupt priority.
    IEC0bits.AD1IE = 1; //+++ Enable A/D conversion interrupt.    
    AD1CON1bits.ADON = 1;   //+++ Turn ADC ON.
}

void ZeroAve(int iCount)
{
    gulUBSumP[iCount] = 0;          
    gulLBSumP[iCount] = 0;      
    guiAverage[iCount] = 0;   
    guchUpdateAve[iCount] = 0;
}

void ZeroVal(int iCount)
{
    guchUpdate[iCount] = 0;
}

void _ISR _ADC1Interrupt(void)
{
    int aiAdcVal[N_SENS];    //+++ Store an ADC converted value for each sensor.
    int *piAdcBuff = (int*)&ADC1BUF0; //+++ Init pointer to ADC Data Buffer 0.
    AD1CON1bits.ASAM = 0; //+++ After end of conversion, stop sample / convert.
    
    //+++ Store converted values.
    int iCount;
    for (iCount = 0; iCount < N_SENS; iCount++)  
    {
        aiAdcVal[iCount] = *piAdcBuff++;
        if (guchUpdate[iCount] == 0)
        {
            guchUB[iCount] = aiAdcVal[iCount] >> 8; //+++ Upper byte.
            guchLB[iCount] = aiAdcVal[iCount];   //+++ Lower byte.   
        }
        
        if (PORTBbits.RB10 == AVE_ADC && guchUpdateAve[iCount] == 0)
        {
            gulUBSumP[iCount] += guchUB[iCount];
            gulLBSumP[iCount] += guchLB[iCount];   

            guiAverage[iCount]++;
            if (guiAverage[iCount] == AVERAGE)
            {
                guchUBAveF[iCount] = gulUBSumP[iCount] / guiAverage[iCount];
                guchLBAveF[iCount] = gulLBSumP[iCount] / guiAverage[iCount];    
                ZeroAve(iCount);
            }            
        }            
    }
    
    IFS0bits.AD1IF = 0; //+++ Clear ADC interrupt flag.
}