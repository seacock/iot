/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/* 
 * File:   
 * Author: 
 * Comments:
 * Revision history: 
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef XC_HEADER_TEMPLATE_H_ADC
#define	XC_HEADER_TEMPLATE_H_ADC

#include <xc.h> // include processor files - each processor file is guarded.  

// TODO Insert appropriate #include <>
#include "ShaDe.h"
#include <stdbool.h>

// TODO Insert C++ class definitions if appropriate

// TODO Insert declarations

// Comment a function and leverage automatic documentation with slash star star
/**
    <p><b>Function prototype:</b></p>
  
    <p><b>Summary:</b></p>

    <p><b>Description:</b></p>

    <p><b>Precondition:</b></p>

    <p><b>Parameters:</b></p>

    <p><b>Returns:</b></p>

    <p><b>Example:</b></p>
    <code>
 
    </code>

    <p><b>Remarks:</b></p>
 */
// TODO Insert declarations or function prototypes (right here) to leverage 
// live documentation
#if __XC16_VERSION__ >= 0x0401
#undef _ISR
#define _ISR __attribute__((interrupt, auto_psv))
#endif

//+++ FOUR_STEPS are the 4 calls Raspberry makes to retrieve one 16 bit word 
//+++ from Pic24: 2 calls for higher byte and 2 calls for lower byte. That's 
//+++ for each sensor with SPI. So ADC is able to compute the average between 
//+++ each FOUR_STEPS task: from the end of one FOUR_STEPS task and the 
//+++ beginning of next FOUR_STEPS task. If AVERAGE leads to an interval 
//+++ smaller than the one spanning from the last step with changing value 4->0 
//+++ and the first step with changing value 0->1 needed for each sensor called 
//+++ by Raspberry, then the average can complete. Otherways the average will 
//+++ overlap over more FOUR_STEPS tasks.
#define AVERAGE 100

//+++ Upper and lower bytes from AD to pass to SPI1BUF or to average.
unsigned char guchUB[N_SENS], guchLB[N_SENS]; 

//+++ Allow to update upper and low bytes from AD. It's a 4 steps sequence as 
//+++ 2 steps are needed for upper byte and 2 steps are needed for lower byte.
unsigned char guchUpdate[N_SENS];    

//+++ Allow to update the average of upper and low bytes from AD: 4 steps seq.                   
unsigned char guchUpdateAve[N_SENS];
unsigned int guiAverage[N_SENS]; //+++ Number of values to average.

//+++ Partial sum of upper and lower bytes to average.
unsigned long gulUBSumP[N_SENS], gulLBSumP[N_SENS]; 
                               
//+++ Final average of upper and lower bytes to pass to SPI1BUF.
unsigned char guchUBAveF[N_SENS], guchLBAveF[N_SENS];

int mainADcX(void);
void Timer2TypeA(void); //+++ 16-Bit Timer Using System Clock (internal instruction cycle).
void SetupADConverter(void);    //+++ Set up Analog to Digital converter.
void ZeroAve(int iCount);   //+++ Zero all variables for average.
void ZeroVal(int iCount);   //+++ Zero variable for last value.

#ifdef	__cplusplus
extern "C" {
#endif /* __cplusplus */

    // TODO If C++ is being used, regular C code needs function names to have C 
    // linkage so the functions can be used by the c code. 

#ifdef	__cplusplus
}
#endif /* __cplusplus */

#endif	/* XC_HEADER_TEMPLATE_H */

