#include "SharA.h"
#include "Aff.h"
#include "Ry.h"
#include "Spi.h"
#include <wiringPi.h>
#include <wiringPiSPI.h>

CAff gAff;
CRy gRy;
CSpi gSpi(&gRy);
bool bHandshakeDone = false;
int iReadSlaveStatus = ((int)true);

void Isr()
{
	iReadSlaveStatus = digitalRead(GPIO4);
	
	if (bHandshakeDone == false && iReadSlaveStatus == HIGH)
	{
		digitalWrite(GPIO3, LOW);
		bHandshakeDone = true;
	}
}

void* LanTp(void *arg);

int main(int argc, char *argv[])
{
	gRy.stUtil.pRy = &gRy;
	gRy.stUtil.pAff = &gAff;
	gRy.stUtil.pSpi = &gSpi;

	gAff.SchedAff();
	
	wiringPiSetup();	
	wiringPiSPISetup(gSpi.kiSpiChannel, gSpi.kiSpiSpeed);

	pinMode(GPIO3, OUTPUT); 	//+++ Board_SPI_MASTER_READY : RaspberryPi3
	pinMode(GPIO4, INPUT);  	//+++ Board_SPI_SLAVE_READY : CC1310Texas	

	wiringPiISR(GPIO4, INT_EDGE_BOTH, Isr);
	
	gRy.afp[0] = LanTp;
	gRy.PoolThread(gRy.kiNumThreads);  	//+++ Create and wait for worker threads.

	exit(EXIT_SUCCESS);
}