#pragma once

//+++ Commands for PIC.
#define ADC_AVERAGE 110	//+++ PICFJ64GB002 sends back average ADC values for potentiometer and thermometer. Defined in LaT, Mip.
#define ADC_LASTVAL 120	//+++ PICFJ64GB002 sends back last ADC value for potentiometer and thermometer. Default at startup. Defined in LaT, Ry, Mip.
#define PWM_CONTINUOUS 130	//+++ PICFJ64GB002 outputs PWM with duty cycle fixed by slider. Default at startup. Defined in LaT, Ry, Mip.
#define PWM_FUNCTION 140	//+++ PICFJ64GB002 outputs PWM with variable duty cycle depending on a local function. Defined in LaT, Mip.
#define I2C_RY_EXIT 201	//+++ Rym's communication threads stop communication and Rym exit. Defined in LaT, Ry.
#define I2C_RY_SHUT_COMM 202	//+++ Rym's communication threads stop communication, but Rym continues working. Defined in LaT, Ry.
#define I2C_LAPTOP_DISMISS 203	//+++ Laptop is dismissed, but Rym continues working. Defined in LaT, Ry.
#define I2C_RY_MAX_PROGRESS 100	//+++ Range of jpgsThr4 and upper limit of I2c test cycle. 
//+++ Commands for PIC.

// CTabFour dialog

class CTabFour : public CDlgExBase
{
	DECLARE_DYNAMIC(CTabFour)
public:
	CEdit jedThr4M;	//+++ Thread: monitor. 
	CEdit jedThr4V;	//+++ Thread: edit for continuous PWM.
	CProgressCtrl jpgsThr4;	//+++ Thread: progress for I2C test.
	string srRbAdc;		//+++ Command message: ADC.	
	string srRbPwm;	//+++ Command message: PWM.		
	string srSlid;	//+++ Message: slider.
	HANDLE hRbAdcEv;	//+++ Event: I2cMaTxTp sends a command message (ADC) to RaspberryPi2, with feed back.
	HANDLE hRbPwmEv;	//+++ Event: I2cMaTxTp sends a command message (PWM) to RaspberryPi2, with feed back.
	HANDLE hSliEv;	//+++ Event: I2cMaTxTp sends a message (slider) to RaspberryPi2, with periodic feed back. Speed is favourite.
	HANDLE hI2cTestEv;	//+++ Event: start I2cAuTxTp.
	CTabFour(CWnd* pParent = NULL);   // standard constructor
	virtual ~CTabFour();
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedRbThr4LastAdc();
	afx_msg void OnBnClickedRbThr4AveAdc();
	afx_msg void OnBnClickedRbThr4PwmC();
	afx_msg void OnBnClickedRbThr4PwmF();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnBnClickedBnTestI2c();
	void InputCtrl(bool bEnable);	//+++ Enable or disable input controls.
// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_TAB_FOUR };
#endif
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	DECLARE_MESSAGE_MAP()
private:
	CStatic jtxtPgsI2c;
	int iCountTestI2c;
	wstring wsrMtrThr4;	
	CSliderCtrl jslThr4;	//+++ Thread: slider for continuous PWM.	//???
	CButton jbnTestI2c;	//+++ Thread: push button for I2C test.		//???
	int jrbThr4LastAdc;	//+++ Thread: dominant radiobutton for ADC.//???
	int jrbThr4PwmC;	//+++ Thread: dominant radiobutton for PWM.
	LRESULT OnEdThr4M(WPARAM wParam, LPARAM lParam);	//+++ Thread4 monitor.
	LRESULT OnEdThr4V(WPARAM wParam, LPARAM lParam);	//+++ Thread4: PWM of PICFJ64GB002.
};

static UINT RG_WM_ED_THR4M = RegisterWindowMessage(_T("EDIT THREAD4 MONITOR"));
static UINT RG_WM_ED_THR4V = RegisterWindowMessage(_T("EDIT THREAD4 VALUES"));