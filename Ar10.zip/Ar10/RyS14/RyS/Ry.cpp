#include "Ry.h"
#include "SharA.h"
#include "Aff.h"
#include "ColorText.h"
#include <unistd.h>
#include <netdb.h>

cpu_set_t CRy::ThreadInfo::stSet1, CRy::ThreadInfo::stSet2, CRy::ThreadInfo::stSet3;

CRy::CRy()
{
	stPortHost.srI2cServerPort = "12300";	//+++ User defined number.
	stPortHost.srTom8ServerPort = "8080";
	stPortHost.srRemSvrPortR3 = "80";
	stPortHost.srRemSvrPortNi = "8080";
	stPortHost.srServerPort = "7000";
	stPortHost.srRes = "ServerMix ";
}

CRy::~CRy()
{
}

void CRy::PoolThread(int iNumThreads)
{
	CreateThread(iNumThreads, afp);

	for (int iNum = 0; iNum < iNumThreads; iNum++)	//+++ Now join with each thread.
	{
		void *res;
		int iRes = pthread_join(pstThrInf[iNum].ulThread_id, &res);
		if (iRes != 0)
			handle_error_en(iRes, "pthread_join");
#ifdef _BRIEF_
		CColorText coltGreen(CColorText::GREEN);
		coltGreen.ss << "Thread " << iNum << " exiting with status :" << res << endl;
		cout << coltGreen;
#endif // _BRIEF_
	}

	delete[] pstThrInf;

#ifdef _BRIEF_
	CColorText coltGreen(CColorText::GREEN);
	coltGreen.ss << "Application exits." << endl;
	cout << coltGreen;
#endif // _BRIEF_		
}

int CRy::SockAddrConn(const char* pcHostName, uint16_t usiPort)
{
	int iSockFd, iRes;  	//+++ Socket file descriptor; result code.
	addrinfo stHints, *pstServInfo, *pstBrowse;  	//+++ Criteria for selection; returned list of socket address structs; ptr for looking through returned list.

	memset(&stHints, 0, sizeof stHints);
	stHints.ai_family = AF_UNSPEC;   //+++ Either IPv4 or IPv6.
	stHints.ai_socktype = SOCK_STREAM; //???
	if ((iRes = getaddrinfo(pcHostName, NumberToString(usiPort).c_str(), &stHints, &pstServInfo)) != 0)
		handle_error2("getaddrinfo", gai_strerror(iRes));

	//+++ Loop through all the results and connect to the first available.
	for(pstBrowse = pstServInfo ; pstBrowse != NULL ; pstBrowse = pstBrowse->ai_next)
	{
		if ((iSockFd = socket(pstBrowse->ai_family, pstBrowse->ai_socktype, pstBrowse->ai_protocol)) == INVALID_SD)
		{
			perror("socket()");
			continue;
		}

		timeval stTv;  	//+++ Doesn't work in debug.
		stTv.tv_sec = 15;    //+++ 15 Secs Timeout. Then below connect fails and, with no connections, app eventually closes.
		stTv.tv_usec = 0;  	//+++ Initialize always or error occurs.
		if(setsockopt(iSockFd, SOL_SOCKET, SO_SNDTIMEO, (timeval*)&stTv, sizeof(timeval)) == -1)
			handle_error("setsockopt()");

		//+++ connect can fail also if the server isn't enabled by its firewall to communicate through public/private network.
		if(connect(iSockFd, pstBrowse->ai_addr, pstBrowse->ai_addrlen) == -1)
		{
			perror("connect()");
			CloseFdErr(iSockFd);
			continue;
		}

		break; //+++ Connection must have been successful.
	}
	string srThreadID = NumberToString(pthread_self());
	srThreadID += " --->Thread ID: failed to connect";
	if (pstBrowse == NULL)
		handle_error1(srThreadID.c_str());  	//+++ Looped off the end of the list with no connection.//???AAA

	freeaddrinfo(pstServInfo);   //+++ All done with this structure.

	return iSockFd;
}

void CRy::FillCoupleId()
{
	for (int iCount = 0; iCount < kiNumThreads; iCount++)
		teCoupleID.push_back(CoupleId());
	teCoupleID[0].srMessage = "BROADCAST";
	teCoupleID[0].iMessage = TL_Broadcast;
	teCoupleID[1].srMessage = "ONE";
	teCoupleID[1].iMessage = TL_One;
	teCoupleID[2].srMessage = "TWO";
	teCoupleID[2].iMessage = TL_Two;
	teCoupleID[3].srMessage = "THREE";
	teCoupleID[3].iMessage = TL_Three;
	teCoupleID[4].srMessage = "TEMPORARY";
	teCoupleID[4].iMessage = TL_Temporary;
	teCoupleID[5].srMessage = "SERVER_I2C";
	teCoupleID[5].iMessage = TL_ServerI2c;
	teCoupleID[6].srMessage = "SERV_MIX_JC";
	teCoupleID[6].iMessage = TL_ServMixJC;
}

void CRy::CreateThread(int iNThreads, void *(**ppStartRoutine)(void*))
{
	int iRes;
	pthread_attr_t unAttr;
	stUtil.pAff->ThreadAttr(unAttr);

	pstThrInf = new ThreadInfo[iNThreads];   	//+++ Allocate memory for pthread_create arguments.
	if(pstThrInf == NULL)
		handle_error1("new");

	for (int iNum = 0; iNum < iNThreads; iNum++)	//+++ Create all threads.
		{
			pstThrInf[iNum].iThreadNum = teCoupleID[iNum].iMessage;
			strcpy(pstThrInf[iNum].pcInfoArg, teCoupleID[iNum].srMessage.c_str());
			pstThrInf[iNum].pstUtil = &stUtil;

			//+++ The pthread_create call stores the thread ID into corresponding element of pstThrInf[].
			if(pstThrInf[iNum].iThreadNum == TL_Broadcast)
				iRes = pthread_create(&pstThrInf[iNum].ulThread_id, &unAttr, ppStartRoutine[0], &pstThrInf[iNum]);
			else if(pstThrInf[iNum].iThreadNum >= TL_One && pstThrInf[iNum].iThreadNum <= TL_Temporary)
				iRes = pthread_create(&pstThrInf[iNum].ulThread_id, &unAttr, ppStartRoutine[1], &pstThrInf[iNum]);
			else if(pstThrInf[iNum].iThreadNum == TL_ServerI2c)
				iRes = pthread_create(&pstThrInf[iNum].ulThread_id, &unAttr, ppStartRoutine[2], &pstThrInf[iNum]);
			else if(pstThrInf[iNum].iThreadNum == TL_ServMixJC)
				iRes = pthread_create(&pstThrInf[iNum].ulThread_id, &unAttr, ppStartRoutine[3], &pstThrInf[iNum]);
			if (iRes != 0)
				handle_error_en(iRes, "pthread_create");
		}

	//+++ Destroy the thread attributes object, since it is no longer needed.
	iRes = pthread_attr_destroy(&unAttr);
	if (iRes != 0)
		handle_error_en(iRes, "pthread_attr_destroy");
}

void CRy::CloseFdErr(int iFd, const char* pcErr)
{
	close(iFd);
	if (pcErr != NULL)//???AAA
		handle_error(pcErr);
}