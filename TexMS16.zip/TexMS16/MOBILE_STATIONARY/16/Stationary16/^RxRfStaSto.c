/*
 * ^RxRfStaSto.c
 *
 *  Created on: 04 dic 2018
 *      Author: andre
 */

#include "smartrf_settings/smartrf_settings.h"
#include <^QueueRf.h>
#include <^Common.h>

#pragma DATA_ALIGN(RxRfSsTaskStack, 8)  //+++ 1-byte alignment on the stack to avoid wasting memory.
static uint8_t RxRfSsTaskStack[STACKSIZE];
Task_Struct RxRfSsTr;
const int CiMax = 100;
int iCountPacket;

Void RxRfSsTf(UArg arg0, UArg arg1);
void RxRfCb(RF_Handle h, RF_CmdHandle ch, RF_EventMask e);
void ComposeCouple(void);

void StartRxRfSsTf(void)
{
    bSynchro = false;
    iReceivedPacket = 0;
    iTwoSteps = 0;
    iStartBound = 0;
    iComposed = 0;
    iCountPacket = 0;
    PIN_setInterrupt(DInPinH, CC1310_LAUNCHXL_DIO1 | PIN_IRQ_DIS);//---

    Task_Params taskParams;
    Task_Params_init(&taskParams);
    taskParams.arg0 = START_STOP;
    taskParams.stackSize = STACKSIZE;
    taskParams.priority = 2;    //+++ More than 1 or is preempted by while (1) in mainThread.
    taskParams.stack = &RxRfSsTaskStack;

    Task_construct(&RxRfSsTr, RxRfSsTf, &taskParams, NULL);
}

Void RxRfSsTf(UArg arg0, UArg arg1)
{
    RF_Params rfParams;
    RF_Params_init(&rfParams);  //+++ Radio initialization.

    ArrangeQueueRf(aucRxBuffer, &queue, &rxEntry);

    /* Modify CMD_PROP_RX command for application needs */
    RF_cmdPropRx.pQueue = &queue;   //+++ Set the Data Entity queue for received data.
    RF_cmdPropRx.rxConf.bAutoFlushIgnored = 1;  //+++ Discard ignored packets from Rx queue.
    RF_cmdPropRx.rxConf.bAutoFlushCrcErr = 1;   //+++ Discard packets with CRC error from Rx queue.

    /* Implement packet length filtering to avoid PROP_ERROR_RXBUF */
    RF_cmdPropRx.maxPktLen = DATA_SECTION_SIZE;
    RF_cmdPropRx.pktConf.bRepeatOk = 0;
    RF_cmdPropRx.pktConf.bRepeatNok = 0;
    rfHandle = RF_open(&rfObject, &RF_prop, (RF_RadioSetup*)&RF_cmdPropRadioDivSetup, &rfParams);   //+++ Request access to the radio.
    RF_postCmd(rfHandle, (RF_Op*)&RF_cmdFs, RF_PriorityNormal, NULL, 0);    //+++ Set the frequency.

    while (iCountPacket <= CiMax)
    {
        RF_EventMask terminationReason = RF_runCmd(rfHandle, (RF_Op*)&RF_cmdPropRx, RF_PriorityNormal, &RxRfCb, RF_EventRxEntryDone); //+++ Enter RX mode.
        uint32_t cmdStatus = ((volatile RF_Op*)&RF_cmdPropRx)->status;
        RfTerminStatus(arg0, terminationReason, cmdStatus);
    }
    RF_close(rfHandle);

    PIN_setInterrupt(DInPinH, CC1310_LAUNCHXL_DIO22 | PIN_IRQ_NEGEDGE);
    PIN_setInterrupt(DInPinH, CC1310_LAUNCHXL_DIO1 | PIN_IRQ_NEGEDGE);//---
}
