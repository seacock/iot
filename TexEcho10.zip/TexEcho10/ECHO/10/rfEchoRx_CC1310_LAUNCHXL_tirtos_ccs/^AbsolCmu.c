/*
 * ^AbsolCmu.c
 *
 *  Created on: 24 gen 2019
 *      Author: andre
 */

#include "^Common.h"

#pragma DATA_ALIGN(AbsolCmuTaskStack, 8)  //+++ 1-byte alignment on the stack to avoid wasting memory.
static uint8_t AbsolCmuTaskStack[STACKSIZE];
Task_Struct AbsolCmuTr;

RF_RatConfigCompare ratConfCmp;
RF_RatHandle ratHandle;

Void AbsolCmuTf(UArg arg0, UArg arg1);
static void AbsolCmuCb(RF_Handle h, RF_CmdHandle ch, RF_EventMask e);

void onRatTriggered(RF_Handle h, RF_RatHandle rh, RF_EventMask e, uint32_t compareCaptureTime);

void StartAbsolCmuTf(void)
{
    Task_Params taskParams;
    Task_Params_init(&taskParams);
    taskParams.stackSize = STACKSIZE;
    taskParams.priority = 2;    //+++ More than 1 or is preempted by while (1) in mainThread.
    taskParams.stack = &AbsolCmuTaskStack;

    Task_construct(&AbsolCmuTr, AbsolCmuTf, &taskParams, NULL);
}

Void AbsolCmuTf(UArg arg0, UArg arg1)
{
	RF_Params rfParams;
	RF_Params_init(&rfParams);

	if( RFQueue_defineQueue(&dataQueue,
							rxDataEntryBuffer,
							sizeof(rxDataEntryBuffer),
							NUM_DATA_ENTRIES,
							PAYLOAD_LENGTH + NUM_APPENDED_BYTES))
	{
		/* Failed to allocate space for all data entries */
		PIN_setOutputValue(ledPinHandle, Board_PIN_LED1, 1);
		PIN_setOutputValue(ledPinHandle, Board_PIN_LED2, 1);
		while(1);
	}

	/* Modify CMD_PROP_TX and CMD_PROP_RX commands for application needs */
	/* Set the Data Entity queue for received data */
	RF_cmdPropRx.pQueue = &dataQueue;
	/* Discard ignored packets from Rx queue */
	RF_cmdPropRx.rxConf.bAutoFlushIgnored = 1;
	/* Discard packets with CRC error from Rx queue */
	RF_cmdPropRx.rxConf.bAutoFlushCrcErr = 1;
	RF_cmdPropRx.rxConf.bAppendTimestamp = 1;	//+++ Append RX timestamp to the payload. It can be disabled with adequate changes.
	/* Implement packet length filtering to avoid PROP_ERROR_RXBUF */
	RF_cmdPropRx.maxPktLen = PAYLOAD_LENGTH;
	/* End RX operation when a packet is received correctly and move on to the
	 * next command in the chain */
	RF_cmdPropRx.pktConf.bRepeatOk = 0;
	RF_cmdPropRx.pktConf.bRepeatNok = 1;
	RF_cmdPropRx.startTrigger.triggerType = TRIG_NOW;
	RF_cmdPropRx.pNextOp = (rfc_radioOp_t *)&RF_cmdPropTx;
	/* Only run the TX command if RX is successful */
	RF_cmdPropRx.condition.rule = COND_STOP_ON_FALSE;
	RF_cmdPropRx.pOutput = (uint8_t *)&rxStatistics;

	RF_cmdPropTx.pktLen = PAYLOAD_LENGTH;
	RF_cmdPropTx.pPkt = txPacket;
	RF_cmdPropTx.startTrigger.triggerType = TRIG_REL_PREVEND;
	RF_cmdPropTx.startTime = TX_DELAY;

	/* Request access to the radio */
	rfHandle = RF_open(&rfObject, &RF_prop,
					   (RF_RadioSetup*)&RF_cmdPropRadioDivSetup, &rfParams);

	RF_RatConfigCompare_init(&ratConfCmp);
	ratConfCmp.callback = &onRatTriggered;
	ratConfCmp.channel = RF_RatChannelAny;
	ratConfCmp.timeout = RF_getCurrentTime() + RF_convertMsToRatTicks(10000);
	ratHandle = RF_ratCompare(rfHandle, &ratConfCmp, NULL);
	if (ratHandle == RF_ALLOC_ERROR)
		while(1);

	/* Set the frequency */
	RF_postCmd(rfHandle, (RF_Op*)&RF_cmdFs, RF_PriorityNormal, NULL, 0);

	while(1)
	{
		/* Wait for a packet
		 * - When the first of the two chained commands (RX) completes, the
		 * RF_EventCmdDone and RF_EventRxEntryDone events are raised on a
		 * successful packet reception, and then the next command in the chain
		 * (TX) is run
		 * - If the RF core runs into an issue after receiving the packet
		 * incorrectly onlt the RF_EventCmdDone event is raised; this is an
		 * error condition
		 * - If the RF core successfully echos the received packet the RF core
		 * should raise the RF_EventLastCmdDone event
		 */
		RF_EventMask terminationReason =
				RF_runCmd(rfHandle, (RF_Op*)&RF_cmdPropRx, RF_PriorityNormal,
						AbsolCmuCb, (RF_EventRxEntryDone |
						  RF_EventLastCmdDone));

		uint32_t cmdStatus = ((volatile RF_Op*)&RF_cmdPropRx)->status;
		TermStat(terminationReason, cmdStatus);
	}
}

static void AbsolCmuCb(RF_Handle h, RF_CmdHandle ch, RF_EventMask e)
{
#ifdef LOG_RADIO_EVENTS
    eventLog[evIndex++ & 0x1F] = e;
#endif// LOG_RADIO_EVENTS

    if (e & RF_EventRxEntryDone)
    {
        /* Successful RX */
        /* Toggle LED2, clear LED1 to indicate RX */
        PIN_setOutputValue(ledPinHandle, Board_PIN_LED1, 0);
        PIN_setOutputValue(ledPinHandle, Board_PIN_LED2,
                           !PIN_getOutputValue(Board_PIN_LED2));

        /* Get current unhandled data entry */
        currentDataEntry = RFQueue_getDataEntry();

        /* Handle the packet data, located at &currentDataEntry->data:
         * - Length is the first byte with the current configuration
         * - Data starts from the second byte */
        packetLength      = *(uint8_t *)(&(currentDataEntry->data));
        packetDataPointer = (uint8_t *)(&(currentDataEntry->data) + 1);

        /* Copy the payload + status byte to the rxPacket variable, and then
         * over to the txPacket
         */
        memcpy(txPacket, packetDataPointer, packetLength);

        RFQueue_nextEntry();
    }
    else if (e & RF_EventLastCmdDone)
    {
        /* Successful Echo (TX)*/
        /* Toggle LED2, clear LED1 to indicate RX */
        PIN_setOutputValue(ledPinHandle, Board_PIN_LED1, 0);
        PIN_setOutputValue(ledPinHandle, Board_PIN_LED2,
                           !PIN_getOutputValue(Board_PIN_LED2));
    }
    else // any uncaught event
    {
        /* Error Condition: set LED1, clear LED2 */
        PIN_setOutputValue(ledPinHandle, Board_PIN_LED1, 1);
        PIN_setOutputValue(ledPinHandle, Board_PIN_LED2, 0);
    }
}

void onRatTriggered(RF_Handle h, RF_RatHandle rh, RF_EventMask e, uint32_t compareCaptureTime)
{
    if (e & RF_EventError)
    {
        // RF driver failed to trigger the callback on time.
    }
//    printf("RAT has triggered at %u.", compareCaptureTime);
    // Trigger precisely with the same period again
    ratConfCmp.timeout = compareCaptureTime + RF_convertMsToRatTicks(10000);
    rh = RF_ratCompare(h, &ratConfCmp, NULL);
    if (rh == RF_ALLOC_ERROR)
    	while(1);

    PIN_setOutputValue(ledPinHandle, Board_PIN_LED1, !PIN_getOutputValue(Board_PIN_LED1));
}
