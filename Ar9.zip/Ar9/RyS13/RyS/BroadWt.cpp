#include "SharA.h"

extern CAff gAff;
extern CRy gRy;
extern CSpi gSpi;

#define SOCK_RCVTIME_SEC 1	//+++ sec.
#define BROAD_ATTEMPTS 30

void* BroadTp(void *arg)
{
	CRy::ThreadInfo *pstThrInf = (CRy::ThreadInfo*)arg;
#ifdef _BRIEF_
	gAff.DisplayThreadSchedAttr(pstThrInf->pcInfoArg);
	cpu_set_t stSet;

	sched_getaffinity(0, sizeof(stSet), &stSet);
	for (int iCount = 0; iCount < 4; iCount++)
		if ( CPU_ISSET_S(iCount, sizeof(stSet), &stSet) )
			cout << "affinity: " << iCount << endl << endl;
#endif // _BRIEF_

	int iSocket;
	if ((iSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == INVALID_SOCKET)
		handle_error("socket()");

	int iBroadcastOpt;
	socklen_t optLen = sizeof(iBroadcastOpt);
#ifdef _TALKATIVE_
	if (getsockopt(iSocket, SOL_SOCKET, SO_BROADCAST, &iBroadcastOpt, &optLen) == -1)
		handle_error("getsockopt()");
	else
		cout << "SO_BROADCAST : " << iBroadcastOpt << endl;
#endif // _TALKATIVE_
	iBroadcastOpt = 1;
	if (setsockopt(iSocket, SOL_SOCKET, SO_BROADCAST, &iBroadcastOpt, optLen) == -1)
		handle_error("setsockopt()");
#ifdef _BRIEF_
	if (getsockopt(iSocket, SOL_SOCKET, SO_BROADCAST, &iBroadcastOpt, &optLen) == -1)
		handle_error("getsockopt()");
	else
		cout << "SO_BROADCAST : " << iBroadcastOpt << endl << endl;
#endif // _BRIEF_

	sockaddr_in stSaiOther;
	int iLenOther = sizeof(stSaiOther), iNumAtt;

	//+++ Zero struct and fill in its members.
	memset((char*)&stSaiOther, 0, sizeof(stSaiOther));
	stSaiOther.sin_family = AF_INET;
	stSaiOther.sin_port = htons(PORT);
	if (inet_aton(gSpi.stWlan0Inet4.acBroadcastAddr, &stSaiOther.sin_addr) == 0)
		handle_error1("inet_aton() failed\n");

	char acRecvFrom[BUFLEN], acSendTo[BUFLEN] = "RaspberryPi is broadcasting.\n";

	timeval tv;
	socklen_t lenTV = sizeof(tv);
	tv.tv_sec = SOCK_RCVTIME_SEC;
	tv.tv_usec = 0;
	if (setsockopt(iSocket, SOL_SOCKET, SO_RCVTIMEO, &tv, lenTV) == -1)	//+++ Blocking socket with timeout.
		handle_error("setsockopt()");
#ifdef _BRIEF_
	if (getsockopt(iSocket, SOL_SOCKET, SO_RCVTIMEO, &tv, &lenTV) == -1)
		handle_error("getsockopt()");
	else
		cout << "SO_RCVTIMEO : " << tv.tv_sec * 1000 * 1000 + tv.tv_usec << " micros" << endl << endl;
#endif // _BRIEF_

	memset(acRecvFrom, '\0', BUFLEN);	//+++ Important: clear the buffer by filling null, it might have previously received data.
	for (iNumAtt = 0; iNumAtt < BROAD_ATTEMPTS; iNumAtt++)
	{		
		if (sendto(iSocket, acSendTo, strlen(acSendTo), 0, (sockaddr*)&stSaiOther, iLenOther) == -1)
			handle_error("sendto()");

		if (recvfrom(iSocket, acRecvFrom, BUFLEN, 0, (sockaddr*)&stSaiOther, (socklen_t*)&iLenOther) <= 0)	//+++ It must use BUFLEN as buffer length is 0.
		{
			if (iNumAtt == BROAD_ATTEMPTS - 1)
				handle_error("recvfrom()");
			else
				continue;
		}			

		if (strstr(acRecvFrom, "Laptop ASUS answering to Raspberry's broadcast.") != NULL)	//+++ Greeting from Laptop ASUS to match.
			break;
		else
		{
			if (iNumAtt == BROAD_ATTEMPTS - 1)
				handle_error("recvfrom()");
		}
	}	

	//+++ Print details of the server/peer and the data received.
	string srRecvFrom(acRecvFrom);
	basic_string <char>::size_type indexStart, indexEnd;
	indexStart = srRecvFrom.find_first_of("*", 0);
	indexEnd = srRecvFrom.find_first_of("*", indexStart + 1);
	gRy.stPortHost.srLANServerPort = srRecvFrom.substr(indexStart + 1, indexEnd - indexStart - 1);
	char acHost[NI_MAXHOST], acService[NI_MAXSERV];	
	getnameinfo((struct sockaddr*)&stSaiOther, iLenOther, acHost, NI_MAXHOST, acService, NI_MAXSERV, NI_NUMERICSERV);
	gRy.stPortHost.srLANServerHost = acHost;  	//+++ See SockAddrConn declaration.
	cout << "Nr " << iNumAtt + 1 << " attempts.\tReceived packet from\t" << gRy.stPortHost.srLANServerHost.c_str() << ":" << acService << endl;
	puts(acRecvFrom);

	close(iSocket);

	pthread_barrier_wait(&gRy.stPortHost.barrier5);
	pthread_barrier_destroy(&gRy.stPortHost.barrier5);

	system("pkill DaemonSSH");//?????? 

	return SUCCESS;
}