#include "RyS.h"

#define SOCK_RCVTIME_SEC 1	//+++ sec.
#define BROAD_ATTEMPTS 30

void* BroadTp(void *arg)
{
	ThreadInfo *pstThrInf = (ThreadInfo*)arg;
#ifdef _BRIEF_
	DisplayThreadSchedAttr(pstThrInf->pcInfoArg);
	cpu_set_t stSet;

	sched_getaffinity(0, sizeof(stSet), &stSet);
	for (int iCount = 0; iCount < 4; iCount++)
		if ( CPU_ISSET_S(iCount, sizeof(stSet), &stSet) )
			cout << "affinity: " << iCount << endl << endl;
#endif // _BRIEF_

	int iSocket;
	if ((iSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == INVALID_SOCKET)
		handle_error("socket()");

	int iBroadcastOpt;
	socklen_t optLen = sizeof(iBroadcastOpt);
#ifdef _TALKATIVE_
	if (getsockopt(iSocket, SOL_SOCKET, SO_BROADCAST, &iBroadcastOpt, &optLen) == -1)
		handle_error("getsockopt()");
	else
		cout << "SO_BROADCAST : " << iBroadcastOpt << endl;
#endif // _TALKATIVE_
	iBroadcastOpt = 1;
	if (setsockopt(iSocket, SOL_SOCKET, SO_BROADCAST, &iBroadcastOpt, optLen) == -1)
		handle_error("setsockopt()");
#ifdef _BRIEF_
	if (getsockopt(iSocket, SOL_SOCKET, SO_BROADCAST, &iBroadcastOpt, &optLen) == -1)
		handle_error("getsockopt()");
	else
		cout << "SO_BROADCAST : " << iBroadcastOpt << endl << endl;
#endif // _BRIEF_

	sockaddr_in stSaiOther;
	int iLenOther = sizeof(stSaiOther), iNumAtt;

	//+++ Zero struct and fill in its members.
	memset((char*)&stSaiOther, 0, sizeof(stSaiOther));
	stSaiOther.sin_family = AF_INET;
	stSaiOther.sin_port = htons(PORT);
	if (inet_aton(ThreadInfo::SacBroadcast, &stSaiOther.sin_addr) == 0)
		handle_error1("inet_aton() failed\n");

	char acRecvFrom[BUFLEN], acSendTo[BUFLEN] = "RaspberryPi is broadcasting.\n";

	timeval tv;
	socklen_t lenTV = sizeof(tv);
	tv.tv_sec = SOCK_RCVTIME_SEC;
	tv.tv_usec = 0;
	if (setsockopt(iSocket, SOL_SOCKET, SO_RCVTIMEO, &tv, lenTV) == -1)	//+++ Blocking socket with timeout.
		handle_error("setsockopt()");
#ifdef _BRIEF_
	if (getsockopt(iSocket, SOL_SOCKET, SO_RCVTIMEO, &tv, &lenTV) == -1)
		handle_error("getsockopt()");
	else
		cout << "SO_RCVTIMEO : " << tv.tv_sec * 1000 * 1000 + tv.tv_usec << " micros" << endl << endl;
#endif // _BRIEF_

	memset(acRecvFrom, '\0', BUFLEN);	//+++ Important: clear the buffer by filling null, it might have previously received data.
	for (iNumAtt = 0; iNumAtt < BROAD_ATTEMPTS; iNumAtt++)
	{		
		if (sendto(iSocket, acSendTo, strlen(acSendTo), 0, (sockaddr*)&stSaiOther, iLenOther) == -1)
			handle_error("sendto()");

		if (recvfrom(iSocket, acRecvFrom, BUFLEN, 0, (sockaddr*)&stSaiOther, (socklen_t*)&iLenOther) <= 0)	//+++ It must use BUFLEN as buffer length is 0.
		{
			if (iNumAtt == BROAD_ATTEMPTS - 1)
				handle_error("recvfrom()");
			else
				continue;
		}			

		if (strstr(acRecvFrom, "Laptop ASUS answering to Raspberry's broadcast.") != NULL)	//+++ Greeting from Laptop ASUS to match.
			break;
		else
		{
			if (iNumAtt == BROAD_ATTEMPTS - 1)
				handle_error("recvfrom()");
		}
	}	

	//+++ Print details of the server/peer and the data received.
	char acServerAddr[BUFLEN];
	inet_ntop(AF_INET, (sockaddr_in*)&stSaiOther.sin_addr, acServerAddr, sizeof(acServerAddr));
	cout << "Nr " << iNumAtt + 1 << " attempts.   Received packet from " << acServerAddr << ":" << ntohs(stSaiOther.sin_port) << endl;
	puts(acRecvFrom);

	string srRecvFrom(acRecvFrom);
	basic_string <char>::size_type indexCh1a, indexCh1b;

	indexCh1a = srRecvFrom.find_first_of("*", 0);
	indexCh1b = srRecvFrom.find_first_of("*", indexCh1a + 1);
	ThreadInfo::SsrLANServerHost = srRecvFrom.substr(indexCh1a + 1, indexCh1b - indexCh1a - 1);

	indexCh1a = srRecvFrom.find_first_of("*", indexCh1b + 1);
	ThreadInfo::SsrLANServerPort = srRecvFrom.substr(indexCh1b + 1, indexCh1a - indexCh1b - 1);

	close(iSocket);

	pthread_barrier_wait(&ThreadInfo::Sbarrier5);
	pthread_barrier_destroy(&ThreadInfo::Sbarrier5);

	return SUCCESS;
}

void InterfacesIp(char *pBroadcast)
{
	FILE *pstFile = fopen("/proc/net/route", "r");	//+++ The contents of files in the /proc directory is generated on the fly.The filesystem related system calls are directed at the VFS layer in the Linux kernel to the proc code, which obtains the information from in-memory data structures inside the kernel memory space.
	char acLine[BUFLEN], *pcDefIf, *pcZeroes;	//+++ Retrieved line; interface (first column); destination (second column). The interface whose destination is 00000000 is the interface of the default gateway.

	//+++ For each line, test interface and destination columns.
	while (fgets(acLine, sizeof(acLine), pstFile))
	{
		pcDefIf = strtok(acLine, " \t");
		pcZeroes = strtok(NULL, " \t");

		if (pcDefIf != NULL && pcZeroes != NULL)
			if (strcmp(pcZeroes, "00000000") == 0)
			{
#ifdef _TALKATIVE_
				cout << "Default interface is : " << pcDefIf << endl;
#endif // _TALKATIVE_
				break;
			}
	}

	ifaddrs *pstIfaddr, *pstIfa;
	char acHostLocation[NI_MAXHOST];

	//+++ Create a linked list of structures describing the network interfaces of this system.
	if (getifaddrs(&pstIfaddr) == -1)
		handle_error("getifaddrs()");

	//+++ Walk through linked list, maintaining head pointer so we can free list later.
	for (pstIfa = pstIfaddr; pstIfa != NULL; pstIfa = pstIfa->ifa_next)
	{
		if (pstIfa->ifa_addr == NULL || strcmp(pstIfa->ifa_name, pcDefIf) != 0)
			continue;

		int iFamily = pstIfa->ifa_addr->sa_family;
#ifdef _TALKATIVE_		
		cout << pstIfa->ifa_name << " " << ((iFamily == AF_INET) ? "AF_INET " : "other family ") << iFamily << endl;	//+++ Display interface name and family (including symbolic form of the latter for the common families).
#endif // _TALKATIVE_
		//+++ For an AF_INET* interface address, display the address.
		if (iFamily == AF_INET)
		{
			if (inet_ntop(AF_INET, &((sockaddr_in*)pstIfa->ifa_ifu.ifu_broadaddr)->sin_addr, pBroadcast, INET_ADDRSTRLEN) == NULL)
				handle_error("inet_ntop()");
			
			cout << "presentation form broadcast address: " << pBroadcast << endl;
			break;
		}
	}

	freeifaddrs(pstIfaddr);
}