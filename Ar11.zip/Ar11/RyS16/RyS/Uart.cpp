#include "Uart.h"
#include "SharA.h"
#include <wiringPi.h>
#include <wiringSerial.h>

void WriteToServer(int iFdLas, const char* buf);   	//+++ Send data to laptop ASUS.

CUart::CUart()
{
	stSync.enStateUart = STATE_NeutralUart;
	stSync.condWebServUart = PTHREAD_COND_INITIALIZER;
	stSync.condLan = PTHREAD_COND_INITIALIZER;
	stSync.mutexUart = PTHREAD_MUTEX_INITIALIZER;

	for (int iCount = 0; iCount < ARRAY_SIZE(asrLocal); iCount++)
		if (asrLocal[iCount].length() != kiRaspberryStringLength)
			handle_error1("kiRaspberryStringLength");
}

CUart::~CUart()
{
}

int CUart::UartSetup()
{
	pinMode(kiCts, INPUT);
	pinMode(kiRts, OUTPUT);
	digitalWrite(kiRts, HIGH);   	//+++ Stop request to send.
	int iHandle = serialOpen("/dev/ttyAMA0", 9600);
	if (iHandle == -1)
		cout << "bad handle" << endl;

	return iHandle;
}

void CUart::UartClose(int iHandle)
{
	serialClose(iHandle);
}

void CUart::UartPic(int iHandle, string *psrSend, int iSizeSend, int iFdLas)
{
	int iData, iCharRx, iDataAvail, iNumCycle;

	if (iFdLas > 0)
		srRecvUart = "!!!???";
	else
		srRecvUart = "";

	cout << endl << endl;

	const int kiMaxCheckCycles = 300000;
	for (int iCount = 0; iCount < iSizeSend; iCount++)
	{
		iCharRx = 0;
		iNumCycle = 0;
		iDataAvail = 0;

		digitalWrite(kiRts, LOW);    	//+++ Assert request to send.
		
		while (iNumCycle < kiMaxCheckCycles)   
		{
			iDataAvail = serialDataAvail(iHandle);     	//+++ Check number of characters available for reading.
			if(iDataAvail == kiPic24StringLength)
				break;
			iNumCycle++;
		}

		cout << "Num of cycles " << iNumCycle << "\tData available " << iDataAvail << endl;

		while (iCharRx < iDataAvail)
		{
			iData = serialGetchar(iHandle);	
			cout << (char)iData;
			srRecvUart += iData;
			iCharRx++;
		}

		digitalWrite(kiRts, HIGH);    	//+++ Stop request to send.

		cout << endl << endl;

		iNumCycle = 0;
		while (digitalRead(kiCts) == 1) 	//+++ Wait till Pic24 asks for receiving.
		{
			iNumCycle++;
			if (iNumCycle == kiMaxCheckCycles)
				handle_error1("Causes: 1) Change the value of kiMaxCheckCycles. 2) Perhaps Pic24 is stuck: reset it.");
		}

		serialPuts(iHandle, psrSend[iCount].c_str());         	//+++ Send a string to Pic24.

		iNumCycle = 0;
		while (digitalRead(kiCts) == 0)   //+++ Wait till Pic24 asks for stopping receiving.
		{
			iNumCycle++;
			if (iNumCycle == kiMaxCheckCycles)
				handle_error1("Causes: 1) Change the value of kiMaxCheckCycles. 2) Perhaps Pic24 is stuck: reset it.");
		}
	}

	if (iFdLas > 0)
		WriteToServer(iFdLas, srRecvUart.c_str());
}