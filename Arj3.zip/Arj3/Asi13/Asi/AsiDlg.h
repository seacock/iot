// AsiDlg.h : header file
//

#pragma once

#include "TabFrame.h"
#include "afxwin.h"
#include <iostream>	//+++ For string and wstring.
#include <string>	//+++ For to_wstring.

using namespace std;	//+++ For string and wstring.

// CAsiDlg dialog
class CAsiDlg : public CDialogEx
{
// Construction
public:	
	HANDLE hRyExitI2cMaTxEv, hRyShutCommI2cMaTxEv, hLaptopDismissI2cMaTxEv, hShutI2cAuTxEv;	//+++ Events: terminate app in RaspberryPi2; shut I2C communication with RaspberryPi2; dismiss Laptop; shut I2C test for RaspberryPi2.
	CAsiDlg(CWnd* pParent = NULL);	// standard constructor
	void RyExit();	//+++ Terminate app in RaspberryPi2. 
	void ShutComm();	//+++ Shut communication with RaspberryPi2, but app in RaspberryPi2 goes on.
	void LaptopDismiss();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ASI_DIALOG };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();

	DECLARE_MESSAGE_MAP()
private:
	CTabFrame jtabFrame;	//+++ Container of tabbed dialogs.
	HBITMAP hBmpGreen, hBmpRed, hBmpIndigo;	//+++ Bitmap handles to load from resource.
	LRESULT OnPicLight(WPARAM wParam, LPARAM lParam);	//+++ Signalling light.	
};

static UINT RG_WM_COMM_ABATED = RegisterWindowMessage(_T("COMMUNICATION ABATED"));	//+++ Communication threads abated. RyExitTp uses PostMessageW.
static UINT RG_WM_PIC_LIGHT = RegisterWindowMessage(_T("PICTURE_CTRL LIGHT"));	//+++ Signalling light.	

//+++ WPARAM parameters for RG_WM_PIC_LIGHT message.
static UINT GREEN_LIGHT = 6000;	
static UINT RED_LIGHT = 6001;
static UINT INDIGO_LIGHT = 6002;