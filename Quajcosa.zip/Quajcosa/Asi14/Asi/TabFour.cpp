// TabFour.cpp : implementation file
//

#include "stdafx.h"
#include "Asi.h"
#include "TabFour.h"
#include "afxdialogex.h"

#include <chrono>

using namespace std::chrono;

#define SOCKET_I2C_AUTOMATIC 5

high_resolution_clock::time_point t1;

// CTabFour dialog

IMPLEMENT_DYNAMIC(CTabFour, CDlgExBase)

CTabFour::CTabFour(CWnd* pParent /*=NULL*/)
	: jrbThr4LastAdc(0)
	, jrbThr4PwmC(0)	
{
}

CTabFour::~CTabFour()
{
}

void CTabFour::DoDataExchange(CDataExchange* pDX)
{
	CDlgExBase::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_ED_THR4M, jedThr4M);
	DDX_Control(pDX, IDC_ED_THR4V, jedThr4V);
	DDX_Control(pDX, IDC_SL_THR4, jslThr4);
	DDX_Control(pDX, IDC_PGS_THR4, jpgsThr4);
	DDX_Control(pDX, IDC_BN_TEST_I2C, jbnTestI2c);
	DDX_Radio(pDX, IDC_RB_THR4LASTADC, jrbThr4LastAdc);
	DDV_MinMaxInt(pDX, jrbThr4LastAdc, 0, 1);
	DDX_Radio(pDX, IDC_RB_THR4PWMC, jrbThr4PwmC);
	DDV_MinMaxInt(pDX, jrbThr4PwmC, 0, 1);	
}

BEGIN_MESSAGE_MAP(CTabFour, CDlgExBase)
	ON_BN_CLICKED(IDC_RB_THR4LASTADC, &CTabFour::OnBnClickedRbThr4LastAdc)
	ON_BN_CLICKED(IDC_RB_THR4AVEADC, &CTabFour::OnBnClickedRbThr4AveAdc)
	ON_BN_CLICKED(IDC_RB_THR4PWMC, &CTabFour::OnBnClickedRbThr4PwmC)
	ON_BN_CLICKED(IDC_RB_THR4PWMF, &CTabFour::OnBnClickedRbThr4PwmF)
	ON_WM_HSCROLL()
	ON_BN_CLICKED(IDC_BN_TEST_I2C, &CTabFour::OnBnClickedBnTestI2c)
	ON_REGISTERED_MESSAGE(RG_WM_ED_THR4M, &CTabFour::OnEdThr4M)
	ON_REGISTERED_MESSAGE(RG_WM_ED_THR4V, &CTabFour::OnEdThr4V)
END_MESSAGE_MAP()

// CTabFour message handlers

BOOL CTabFour::OnInitDialog()
{
	CDlgExBase::OnInitDialog();

	// TODO:  Add extra initialization here
	jpgsThr4.SetRange32(0, I2C_RY_MAX_PROGRESS);
	jpgsThr4.SetPos(0);
	SetWindowTheme(jpgsThr4.m_hWnd, L" ", L" ");
	jpgsThr4.SetBarColor(RGB(0, 100, 255));
	RECT rect = { NULL };
	jpgsThr4.GetWindowRect(&rect);
	::MapWindowPoints(HWND_DESKTOP, m_hWnd, (LPPOINT)&rect, 2);
	jtxtPgsI2c.Create(_T(""), WS_CHILD | WS_VISIBLE | WS_BORDER, CRect(rect), this);
	jtxtPgsI2c.SetWindowPos(&wndBottom, rect.left - 1, rect.top - 1, 0, 0, SWP_NOSIZE);
	iCountTestI2c = 0;
	t1 = high_resolution_clock::now();

	return TRUE;  // return TRUE unless you set the focus to a control
				  // EXCEPTION: OCX Property Pages should return FALSE
}

void CTabFour::OnBnClickedRbThr4LastAdc()
{
	// TODO: Add your control notification handler code here
	srRbAdc = to_string(ADC_LASTVAL);
	SetEvent(hE_RbAdc);
}

void CTabFour::OnBnClickedRbThr4AveAdc()
{
	// TODO: Add your control notification handler code here
	srRbAdc = to_string(ADC_AVERAGE);
	SetEvent(hE_RbAdc);
}

void CTabFour::OnBnClickedRbThr4PwmC()
{
	// TODO: Add your control notification handler code here
	srRbPwm = to_string(PWM_CONTINUOUS);
	jslThr4.EnableWindow();
	SetEvent(hE_RbPwm);
}

void CTabFour::OnBnClickedRbThr4PwmF()
{
	// TODO: Add your control notification handler code here
	jslThr4.SetPos(0);
	jedThr4V.SetWindowTextW(L"0");
	srSlid = to_string(0);
	SetEvent(hE_Sli);
	srRbPwm = to_string(PWM_FUNCTION);
	jslThr4.EnableWindow(0);
	SetEvent(hE_RbPwm);
}

void CTabFour::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	// TODO: Add your message handler code here and/or call default
	if (strcmp(pScrollBar->GetRuntimeClass()->m_lpszClassName, "CSliderCtrl") == 0)
		if (nSBCode != TB_ENDTRACK)
		{
			high_resolution_clock::time_point t2 = high_resolution_clock::now();
			int dif = (int)duration_cast<milliseconds>(t2 - t1).count();
			if (dif >= 10)
			{
				srSlid = to_string(nPos);
				SendMessageW(RG_WM_ED_THR4V, (WPARAM)to_wstring(nPos).c_str());
				SetEvent(hE_Sli);
			}		
			t1 = t2;
		}

	CDlgExBase::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CTabFour::OnBnClickedBnTestI2c()
{
	// TODO: Add your control notification handler code here
	jrbThr4LastAdc = 0;
	jrbThr4PwmC = 0;
	jslThr4.SetPos(0);
	jedThr4V.SetWindowTextW(L"0");
	UpdateData(FALSE);
	srRbAdc = to_string(ADC_LASTVAL);
	SetEvent(hE_RbAdc);
	srRbPwm = to_string(PWM_CONTINUOUS);
	SetEvent(hE_RbPwm);
	srSlid = to_string(0);
	SetEvent(hE_Sli);
	Sleep(100);
	InputCtrl(false);
	SetEvent(hE_I2cTest);
	iCountTestI2c++;
}

LRESULT CTabFour::OnEdThr4M(WPARAM wParam, LPARAM lParam)
{
	wsrMtrThr4 += (const wchar_t*)wParam + (wstring)L"\r\n";
	jedThr4M.SetWindowTextW(wsrMtrThr4.c_str());
	return NO_ERROR;
}

LRESULT CTabFour::OnEdThr4V(WPARAM wParam, LPARAM lParam)
{
	wstring wsrMix((const wchar_t*)wParam), wsrName(L"");
	if (wsrMix.find(wsrName) != string::npos)
	{
		wsrMix = wsrMix.substr(wsrName.length(), wsrMix.length() - wsrName.length());
		jedThr4V.SetWindowTextW(wsrMix.c_str());
	}
	return NO_ERROR;
}

void  CTabFour::InputCtrl(bool bEnable)
{
	GetDlgItem(IDC_RB_THR4LASTADC)->EnableWindow(bEnable);
	GetDlgItem(IDC_RB_THR4AVEADC)->EnableWindow(bEnable);
	GetDlgItem(IDC_RB_THR4PWMC)->EnableWindow(bEnable);
	GetDlgItem(IDC_RB_THR4PWMF)->EnableWindow(bEnable);
	jslThr4.EnableWindow(bEnable);
	if (iCountTestI2c == SOCKET_I2C_AUTOMATIC)//???
		jbnTestI2c.EnableWindow(0);
	else
		jbnTestI2c.EnableWindow(bEnable);
	if (bEnable == true)
	{
		SendDlgItemMessage(IDC_RB_THR4LASTADC, BM_CLICK);
		SendDlgItemMessage(IDC_RB_THR4PWMC, BM_CLICK);
		SendMessageW(RG_WM_ED_THR4V, (WPARAM)to_wstring(0).c_str());
	}
}