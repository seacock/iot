#pragma once

#include "AsiDlg.h"
#include "DlgExBase.h"
#include "TabOne.h"
#include "TabTwo.h"
#include "TabThree.h"
#include "TabFour.h"
#include "TabFive.h"

#define ERROR_COMM 5
#define ERROR_CLIENT_SIDE 4
#define NUM_WEB_THREADS 50
#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))
#define BUFLEN 512  //+++ Max length of buffer.
#define NUM_TEC 3
#define SERVER_SIDE 1000//???A
#define CLIENT_SIDE 2000//???A

//+++ It's elements are needed throughout application.
struct Hook
{
	CAsiDlg *pAsiDlg;	//+++ Pointer to parent dialog.

	//+++ Pointers to tabbed dialog pages.
	CTabOne *pTabOne;
	CTabTwo *pTabTwo;
	CTabThree *pTabThree;
	CTabFour *pTabFour;
	CTabFive *pTabFive;
	
	//+++ One structure for each socket. One socket for each remote thread. Each thread needs its own set of variables to communicate. Local copies or references expire when thread exits and Postmessage delays. Global strings, if any, need CRITICAL_SECTION.
	struct Channel
	{
		Hook *pHook;
		SOCKET AcceptSocket;	//+++ Socket of RaspberryPi2 client.
		wstring wsrRemoteThread, wsrMonitor;	//+++ Remote thread name; total/partial string received from RaspberryPi2 client.
		CDialogEx *pTabbDlg;
		UINT uiWmEdMonitor, uiWmEdValue, uiWmProgress;	//+++ WMsg for: Edit ctrl monitor; Edit ctrl value; Progress ctrl.
	} astChann[NUM_SOCKETS];	//+++ Array of structures for remote threads.	
	
	HANDLE ahReceiveTp[NUM_SOCKETS];	//+++ Array of handles to ReceiveTp.
	HANDLE hBroadTp;	//+++ Handle to BroadTp.
	HANDLE hConnectTp;	//+++ Handle to ConnectTp.
	HANDLE hCloseConnectTp;	//+++ Handle to CloseConnectTp.	
	HANDLE hI2cMaTxTp;	//+++ Handle to I2cMaTxTp.	
	HANDLE hI2cMaRxTp;	//+++ Handle to I2cMaRxTp.
	HANDLE hI2cAuTxTp;	//+++ Handle to I2cAuTxTp.
	HANDLE hI2cAuRxTp;	//+++ Handle to I2cAuRxTp.

	//+++ Argument for ThreadExCoTp.
	struct ThreadExCo
	{
		CAsiDlg *pAsiDlg;	//+++ Pointer to parent dialog.
		HANDLE hThreadExCo;	//+++ Handle to thread whose exit code needs to be examined.
	} astThreadExCo[NUM_TEC];	//+++ For threads: ConnectTp, I2cMaRxTp, I2cAuRxTp.

	struct ServerI2C
	{
		char acIP[BUFLEN];
		char acPort[BUFLEN];
		char acWebPortR3[BUFLEN];
		char acWebPortNi[BUFLEN];
	} stServerI2c;
	SOCKET SockManual, SockAutom;
};

wstring StToWsUtf8(const string &str);
string WsToStUtf8(const wstring &wstr);