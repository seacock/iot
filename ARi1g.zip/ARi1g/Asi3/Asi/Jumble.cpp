#include "stdafx.h"
#include "ShaWa.h"

int SocketAddr(HWND hWnd, wstring wsrClassName, char *pcHostName, char *pcPortNumber, sockaddr_in **sockaddr_ipv4);
int MsgWsa(HWND hWnd, wstring wsrWhich, wstring wsrMsg, bool bCleanup);

template <typename T>
string NumberToStringHex(T Number);	//+++ Transform a decimal number to a string of hex.

wstring ThrAffinity(HANDLE hWkrThread, DWORD_PTR dwThreadAffinityMask)
{
	wstring wsrOut;
	wchar_t wchBuf[BUFLEN];
	DWORD_PTR dwOldThreadAffinityMask = SetThreadAffinityMask(hWkrThread, dwThreadAffinityMask);
	_itow_s(dwOldThreadAffinityMask, wchBuf, sizeof(wchBuf) / sizeof(wchar_t), 10);
	wsrOut = L"OldThreadAffinityMask " + (wstring)wchBuf + L"\r\n";
	_itow_s(dwThreadAffinityMask, wchBuf, sizeof(wchBuf) / sizeof(wchar_t), 10);
	wsrOut += L"ThreadAffinityMask " + (wstring)wchBuf + L"\r\n";

	return wsrOut;
}

SOCKET ConnectToServer(Hook *pstHook)
{
	CTabOne *pTabOne = (CTabOne*)pstHook->pTabOne;

	WSADATA wsaData;
	SOCKET ConnectSocket = INVALID_SOCKET;
	addrinfo *result = NULL, *ptr = NULL, hints;
	int iResult;

	iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);	//+++ Initialize Winsock.
	if (iResult != 0)
		return MsgWsaCMA(L"WSAStartup() failed with error: " + to_wstring(iResult) + L"\r\n", pTabOne, false);

	ZeroMemory(&hints, sizeof(hints));
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_protocol = IPPROTO_TCP;

	//+++ Resolve the server address and port.
	iResult = getaddrinfo(pstHook->stServerI2c.acIP, pstHook->stServerI2c.acPort, &hints, &result);
	if (iResult != 0)
		return MsgWsaCMA(L"getaddrinfo() failed with error: " + to_wstring(WSAGetLastError()) + L"\r\n", pTabOne, true);

	//+++ Attempt to connect to an address until one succeeds.
	for (ptr = result; ptr != NULL; ptr = ptr->ai_next)
	{
		ConnectSocket = socket(ptr->ai_family, ptr->ai_socktype, ptr->ai_protocol);	//+++ Create a SOCKET for connecting to server.		
		if (ConnectSocket == INVALID_SOCKET)
			return MsgWsaCMA(L"socket() failed with error: " + to_wstring(WSAGetLastError()) + L"\r\n", pTabOne, true);

		iResult = connect(ConnectSocket, ptr->ai_addr, (int)ptr->ai_addrlen);	//+++ Connect to server.
		if (iResult == SOCKET_ERROR)
		{
			MsgWsaCMA(L"connect() failed with error: " + to_wstring(WSAGetLastError()) + L"\r\n", pTabOne, false, ConnectSocket);
			ConnectSocket = INVALID_SOCKET;
			continue;
		}
		break;
	}

	freeaddrinfo(result);

	if (ConnectSocket == INVALID_SOCKET)
		return MsgWsaCMA(L"Unable to connect to server!\r\n", pTabOne, true);

	WSACleanup();

	return ConnectSocket;
}

int MsgWsaCMA(wstring wsrMsg, CTabOne *pTabOne, bool bCleanup, SOCKET Socket)
{
	pTabOne->SendMessageW(RG_WM_ED_SOC_T, (WPARAM)wsrMsg.c_str());
	if (Socket != INVALID_SOCKET)
		closesocket(Socket);

	if (bCleanup == true)
		WSACleanup();

	return ERROR_COMM;
}

void CloseHandleNull(HANDLE hHan)
{
	if (hHan)
	{
		CloseHandle(hHan);
		hHan = NULL;
	}
}

int SocketAddr(HWND hWnd, wstring wsrClassName, char *pcHostName, char *pcPortNumber, sockaddr_in **sockaddr_ipv4)
{
	int iCount = 1;
	addrinfo *result = NULL, *ptr = NULL, hints;
	wstring wsrMonSoc;

	//+++ Initialize Winsock.
	WSADATA wsaData;
	if (WSAStartup(MAKEWORD(2, 2), &wsaData) != NO_ERROR)
		return MsgWsa(hWnd, wsrClassName, L" WSAStartup() failed with error: " + to_wstring(WSAGetLastError()) + L"\r\n", false);

	//+++ Setup the hints address info structure which is passed to the getaddrinfo() function.
	ZeroMemory(&hints, sizeof(hints));
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_protocol = IPPROTO_TCP;

	//+++ If the call succeeds, the result variable will hold a linked list of addrinfo structures containing response information.
	if (getaddrinfo(pcHostName, pcPortNumber, &hints, &result) != 0)
		return MsgWsa(hWnd, wsrClassName, L" getaddrinfo() failed with error: " + to_wstring(WSAGetLastError()) + L"\r\n", true);

	wsrMonSoc += L"getaddrinfo() returned success\n";

	//+++ Retrieve each address and print out the hex bytes.
	for (ptr = result; ptr != NULL; ptr = ptr->ai_next)
	{
		wsrMonSoc += L"getaddrinfo response " + to_wstring(iCount++) + L"\r\n" + L"\tFlags: " + StToWsUtf8(NumberToStringHex(ptr->ai_flags)) + L"\tFamily: ";
		switch (ptr->ai_family)
		{
		case AF_UNSPEC: case AF_INET6: case AF_NETBIOS: default:
			wsrMonSoc += L"This app considers only IPv4 address and not this family: " + to_wstring(ptr->ai_family) + L"\r\n";
			break;
		case AF_INET:
			*sockaddr_ipv4 = (sockaddr_in*)ptr->ai_addr;
			wchar_t awchStringBuf[BUFLEN];
			wsrMonSoc += L"\tAF_INET (IPv4) address " + (wstring)InetNtop(AF_INET, &(*sockaddr_ipv4)->sin_addr, awchStringBuf, ARRAY_SIZE(awchStringBuf));
			break;
		}

		wsrMonSoc += L"\tSocket type: ";
		switch (ptr->ai_socktype)
		{
		case 0:
			wsrMonSoc += L"Unspecified\r\n";
			break;
		case SOCK_STREAM:
			wsrMonSoc += L"\tSOCK_STREAM (stream)\r\n";
			break;
		case SOCK_DGRAM: case SOCK_RAW: case SOCK_RDM: case SOCK_SEQPACKET: default:
			wsrMonSoc += L"This app considers only SOCK_STREAM and not this type: " + to_wstring(ptr->ai_socktype) + L"\r\n";
			break;
		}

		wsrMonSoc += L"\tProtocol: ";
		switch (ptr->ai_protocol)
		{
		case 0:
			wsrMonSoc += L"Unspecified\r\n";
			break;
		case IPPROTO_TCP:
			wsrMonSoc += L"IPPROTO_TCP (TCP)  " + to_wstring(ptr->ai_protocol) + L"\r\n";
			break;
		case IPPROTO_UDP: default:
			wsrMonSoc += L"This app considers only IPPROTO_TCP and not this protocol: " + to_wstring(ptr->ai_protocol) + L"\r\n";
			break;
		}
	}

	freeaddrinfo(result);
	WSACleanup();

	SendMessageW(hWnd, RG_WM_ED_SOC_T, (WPARAM)wsrMonSoc.c_str(), NULL);

	if (*sockaddr_ipv4 == NULL)
		return ERROR_COMM;

	return NO_ERROR;
}

int MsgWsa(HWND hWnd, wstring wsrWhich, wstring wsrMsg, bool bCleanup)
{
	wstring wsrWhichMsg = wsrWhich + wsrMsg;
	SendMessageW(hWnd, RG_WM_ED_SOC_T, (WPARAM)wsrWhichMsg.c_str(), NULL);

	if (bCleanup == true)
		WSACleanup();

	return ERROR_COMM;
}

template <typename T>
string NumberToStringHex(T Number)
{
	ostringstream ss;
	ss << hex << Number;
	return ss.str();
}