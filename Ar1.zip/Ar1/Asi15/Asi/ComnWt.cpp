#include "stdafx.h"
#include "Asi.h"

#define SELECT_TIMEOUT 30 * 1000 * 1000	//+++ x sec.
#define SELECT_TIME_LIMIT_ERROR 0
#define RECEIVED_STRING_LENGTH 10000
#define WAIT_TIMEOUT_B 25000
#define TEC_CONNECT 0
#define TEC_I2CMARX 1
#define TEC_I2CAURX 2
#define TEMPORARY_STRINGS 5

DWORD WINAPI T_Receive(LPVOID lpParam);	//+++ Worker thread: receives from RaspberryPi2 through 4 sockets, (5th temporary).
DWORD WINAPI T_I2cMaTx(LPVOID lpParam);	//+++ Worker thread: transmits to RaspberryPi2 through 5th socket acquired by T_Receive.
DWORD WINAPI T_I2cMaRx(LPVOID lpParam);
DWORD WINAPI T_I2cAuTx(LPVOID lpParam);	//+++ Worker thread: tests RaspberryPi2's I2C through 5th socket acquired by T_Receive.
DWORD WINAPI T_I2cAuRx(LPVOID lpParam);
DWORD WINAPI T_ThreadExCo(LPVOID lpParam);

DWORD WINAPI T_Connect(LPVOID lpParam)
{
	Hook *pstHook = (Hook*)lpParam;
	pstHook->astThreadExCo[TEC_CONNECT].hThreadExCo = pstHook->hT_Connect;
	pstHook->astThreadExCo[TEC_CONNECT].pAsiDlg = pstHook->pAsiDlg;
	CreateThread(NULL, 0, T_ThreadExCo, &pstHook->astThreadExCo[TEC_CONNECT], 0, NULL);
	CTabOne *pTabOne = pstHook->pTabOne;
	wstring wsrMonSoc = L"T_Connect\r\n";
	wsrMonSoc += theApp.ThrAffinity(6);
	pTabOne->SendMessageW(RG_WM_ED_SOC_T, (WPARAM)wsrMonSoc.c_str());

	wsrMonSoc = L"Waiting for handshake from T_Broad...\n";
	pTabOne->SendMessageW(RG_WM_ED_SOC_T, (WPARAM)wsrMonSoc.c_str());

	DWORD dwExitCodeThread;
	DWORD dwWaitResult = WaitForSingleObject(pstHook->hT_Broad, WAIT_TIMEOUT_B);
	switch (dwWaitResult)
	{
	case WAIT_OBJECT_0:
		GetExitCodeThread(pstHook->hT_Broad, &dwExitCodeThread);
		CloseHandle(pstHook->hT_Broad);
		if (dwExitCodeThread == ERROR_COMM)
		{
			pstHook->pAsiDlg->SendMessageW(RG_WM_PIC_LIGHT, RED_LIGHT);
			return theApp.ErrWsaSock(L"T_Connect() waited: T_Broad failure." + (wstring)L"\r\n", false);
		}
		break;
	case WAIT_TIMEOUT:
		CloseHandle(pstHook->hT_Broad);
		pstHook->pAsiDlg->SendMessageW(RG_WM_PIC_LIGHT, RED_LIGHT);
		return theApp.ErrWsaSock(L"T_Connect() waited too long for T_Broad." + (wstring)L"\r\n", false);
		break;	//+++ Redundant.
	}

	//+++ Initialize Winsock.
	WSADATA wsaData;
	int iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
	if (iResult != NO_ERROR)
		return theApp.ErrWsaSock(L"WSAStartup() failed with error: " + to_wstring(iResult) + L"\r\n", false);

	//+++ Create a SOCKET for listening for incoming connection requests.
	SOCKET ListenSocket = pTabOne->TieSockAddr((char*)pTabOne->srHostName.c_str(), (char*)pTabOne->srPortNumber.c_str(), SERVER_SIDE);

	//+++ Create a SOCKET for accepting incoming requests.
	wsrMonSoc = L"Waiting for client to connect...\n";
	pTabOne->SendMessageW(RG_WM_ED_SOC_T, (WPARAM)wsrMonSoc.c_str());

	timeval stTimeout;	//+++ Timeout for select.
	stTimeout.tv_sec = 2;//???
	stTimeout.tv_usec = SELECT_TIMEOUT;
	fd_set stRead;	//+++ Read set.
	FD_ZERO(&stRead);
	FD_SET(ListenSocket, &stRead);	//+++ Associate socket to read set.

	for (int iCount = 0; iCount < NUM_SOCKETS; iCount++)	//+++ Accept the connection.
	{
		//+++ Check if the socket is ready within timeout.
		int iSel = select(0, &stRead, NULL, NULL, &stTimeout);
		if (iSel == SELECT_TIME_LIMIT_ERROR || iSel == SOCKET_ERROR)
		{
			for (int iSock = 0; iSock < NUM_SOCKETS; iSock++)
				pTabOne->ShutCloseSocket(pstHook->astChann[iSock].AcceptSocket);

			return theApp.ErrWsaSock(L"select() waited more than SELECT_TIMEOUT or SOCKET_ERROR: " + to_wstring(SELECT_TIMEOUT / (1000 * 1000)) + L" sec\n", true);
		}

		//+++ Blocking socket. From here to the recv function in T_Receive, operations must be as fast as possible or this server can miss data sent by client.
		pstHook->astChann[iCount].AcceptSocket = accept(ListenSocket, NULL, NULL);
		if (pstHook->astChann[iCount].AcceptSocket == INVALID_SOCKET)
		{
			for (int iSock = 0; iSock < NUM_SOCKETS; iSock++)
				pTabOne->ShutCloseSocket(pstHook->astChann[iSock].AcceptSocket);

			return theApp.ErrWsaSock(L"accept() failed with error: " + to_wstring(WSAGetLastError()) + L"\r\n", true);
		}
		else
		{
			sockaddr stSockAddr;
			int iLen = sizeof(sockaddr);
			getpeername(pstHook->astChann[iCount].AcceptSocket, &stSockAddr, &iLen);
			USHORT usPort = ((sockaddr_in*)&stSockAddr)->sin_port;
			wsrMonSoc = L"Client connected at ephemeral port = " + to_wstring(usPort) + L"\r\n";
			pTabOne->SendMessageW(RG_WM_ED_SOC_T, (WPARAM)wsrMonSoc.c_str());

			pstHook->astChann[iCount].pHook = pstHook;
			pstHook->ahT_Receive[iCount] = CreateThread(NULL, 0, T_Receive, &pstHook->astChann[iCount], 0, NULL);	//+++ Default security; default stack; thr func name; argument to thr func; default flags; no thr identifier.
		}
	}

	shutdown(ListenSocket, SD_RECEIVE);
	closesocket(ListenSocket);	//+++ No longer need server socket.	

	//+++ All client's threads have connected through their sockets, so show that changing window's colors.
	pTabOne->jedCuSocTh.bChangeBkgnd = true;
	pTabOne->jedCuSocTh.RedrawWindow();

	//+++ Wait till all T_Receive instances exit.
	dwWaitResult = WaitForMultipleObjects(ARRAY_SIZE(pstHook->ahT_Receive), pstHook->ahT_Receive, TRUE, INFINITE);
	switch (dwWaitResult)
	{
	case WAIT_OBJECT_0:
		for (int iCount = 0; iCount < ARRAY_SIZE(pstHook->ahT_Receive); iCount++)	//+++ Close thread procedure handles.			
		{
			pstHook->pTabOne->ShutCloseSocket(pstHook->astChann[iCount].AcceptSocket);
			GetExitCodeThread(pstHook->ahT_Receive[iCount], &dwExitCodeThread);
			CloseHandle(pstHook->ahT_Receive[iCount]);
			if (dwExitCodeThread == ERROR_COMM)
				theApp.ErrWsaSock(L"T_Connect() waited: ahT_Receive failure." + (wstring)L"\r\n", false);
			if (dwExitCodeThread == ERROR_CLIENT_SIDE)
				theApp.ErrWsaSock(L"T_Connect() waited: ahT_Receive disconnection from client side." + (wstring)L"\r\n", false);
		}
		break;
	}

	WSACleanup();

	return NO_ERROR;
}

DWORD WINAPI T_Receive(LPVOID lpParam)
{
	Hook::Channel *pstChannel = (Hook::Channel*)lpParam;
	Hook *pstHook = (Hook*)pstChannel->pHook;
	int iResult, iBytesReceived = 0, iTimes = 0;	//+++ Result of recv; total bytes received from remote thread; number of strings received from RaspberryPi2 client.
	char acReceived[BUFLEN];	//+++ Present char array received from RaspberryPi2 client.
	bool bStart = true, bEnd = false;	//+++ Only first time each remote thread sends its name.
	
	//+++ Receive until the peer closes the connection.
	do
	{
		iResult = recv(pstChannel->AcceptSocket, acReceived, BUFLEN, 0);	//+++ Never use string.c_str() : tricky sometimes works other times don't.

		if (iResult > 0)
		{
			iTimes++;
			iBytesReceived += iResult;
			string srReceived = acReceived;	//+++ Present string received from RaspberryPi2 client.
			wstring wsrReceived = StToWsUtf8(srReceived.c_str());	//+++ String received from RaspberryPi2 client.
			
			if (bStart == true)
			{
				bStart = false;
				wstring wsrAffinity;
				pstChannel->wsrRemoteThread = wsrReceived;

				basic_string <char>::size_type indexCh;
				indexCh = srReceived.find("TEMPORARY", 0);
				if (indexCh != string::npos)
					pstChannel->wsrRemoteThread = L"TEMPORARY";

				if (pstChannel->wsrRemoteThread == L"ONE")
				{
					wsrAffinity = theApp.ThrAffinity(6);
					pstChannel->uiWmEdValue = RG_WM_ED_THR1V;
					pstChannel->uiWmProgress = RG_WM_PGS_THR1;
					pstHook->pTabTwo->jedThr1M.EnableWindow();
					pstHook->pTabTwo->jedThr1V.EnableWindow();
					pstHook->pTabTwo->jpgsThr1.EnableWindow();
					pstHook->pTabTwo->jpgsThr1.SetPos(0);
					pstChannel->uiWmEdMonitor = RG_WM_ED_THR1M;
					pstChannel->pTabbDlg = pstHook->pTabTwo;
				}
				else if (pstChannel->wsrRemoteThread == L"TWO")
				{
					wsrAffinity = theApp.ThrAffinity(6);
					pstChannel->uiWmEdValue = RG_WM_ED_THR2V;
					pstChannel->uiWmProgress = RG_WM_PGS_THR2;
					pstHook->pTabThree->jedThr2M.EnableWindow();
					pstHook->pTabThree->jedThr2V.EnableWindow();
					pstHook->pTabThree->jpgsThr2.EnableWindow();
					pstChannel->uiWmEdMonitor = RG_WM_ED_THR2M;
					pstChannel->pTabbDlg = pstHook->pTabThree;
				}
				else if (pstChannel->wsrRemoteThread == L"THREE")
				{
					wsrAffinity = theApp.ThrAffinity(6);
					pstChannel->uiWmEdValue = RG_WM_ED_THR3V;
					pstChannel->uiWmProgress = RG_WM_PGS_THR3;
					pstHook->pTabThree->jedThr3M.EnableWindow();
					pstHook->pTabThree->jedThr3V.EnableWindow();
					pstHook->pTabThree->jpgsThr3.EnableWindow();
					pstChannel->uiWmEdMonitor = RG_WM_ED_THR3M;
					pstChannel->pTabbDlg = pstHook->pTabThree;
				}
				else if (pstChannel->wsrRemoteThread == L"TEMPORARY")
				{
					wsrAffinity = theApp.ThrAffinity(6);
					pstChannel->uiWmEdValue = RG_WM_ED_THR4V;
					pstChannel->uiWmEdMonitor = RG_WM_ED_THR4M;
					pstChannel->pTabbDlg = pstHook->pTabFour;

					basic_string <char>::size_type delim1Start, delim1End, delim2Start = 0;
					string srSub = "-_-_", asrTempor[TEMPORARY_STRINGS];
					for (int iCount = 0; iCount < TEMPORARY_STRINGS; iCount++)
					{
						delim1Start = srReceived.find(srSub, delim2Start);
						if (delim1Start != string::npos)
						{
							delim1End = delim1Start + srSub.length();
							delim2Start = srReceived.find(srSub, delim1End);
							if (delim2Start != string::npos)
								asrTempor[iCount] = srReceived.substr(delim1End, delim2Start - delim1End);
						}
					}

					int iCheck;
					for (int iCount = 0; iCount < TEMPORARY_STRINGS; iCount++)
					{
						switch (iCount)
						{
						case 0:
							iCheck = stoi(asrTempor[iCount]);
							if (iCheck == ADC_LASTVAL)
								pstHook->pTabFour->OnBnClickedRbThr4LastAdc();
							else if (iCheck == ADC_AVERAGE)
								pstHook->pTabFour->OnBnClickedRbThr4AveAdc();
							break;							
						case 1:
							iCheck = stoi(asrTempor[iCount]);
							if (iCheck == PWM_CONTINUOUS)
								pstHook->pTabFour->OnBnClickedRbThr4PwmC();
							else if (iCheck == PWM_FUNCTION)
								pstHook->pTabFour->OnBnClickedRbThr4PwmF();
							break;
						case 2:
							strcpy_s(pstHook->stServerI2c.acPort, sizeof(pstHook->stServerI2c.acPort), asrTempor[iCount].c_str());
							break;
						case 3:
							strcpy_s(pstHook->stServerI2c.acWebPortR3, sizeof(pstHook->stServerI2c.acWebPortR3), asrTempor[iCount].c_str());
							break;
						case 4:
							strcpy_s(pstHook->stServerI2c.acWebPortNi, sizeof(pstHook->stServerI2c.acWebPortNi), asrTempor[iCount].c_str());
							pstHook->hT_I2cMaTx = CreateThread(NULL, 0, T_I2cMaTx, pstHook, 0, NULL);
							pstHook->pTabFive->SendMessageW(RG_WM_INPUT_WEB);
							bEnd = true;	//+++ This thread stops here and is replaced by T_I2cMaTx.
							break;
						}
					}

					pstHook->pTabFour->SendMessageW(WM_SHOWWINDOW);
					pstHook->pTabFour->bRaspberryInit = false;
				}

				pstChannel->pTabbDlg->SendMessageW(pstChannel->uiWmEdMonitor, (WPARAM)wsrAffinity.c_str());
				wstring wsrFirstB = L"First bytes received: " + to_wstring(iResult) + L"\r\n";
				pstChannel->pTabbDlg->SendMessageW(pstChannel->uiWmEdMonitor, (WPARAM)wsrFirstB.c_str());
				pstChannel->pTabbDlg->SendMessageW(pstChannel->uiWmEdMonitor, (WPARAM)wsrReceived.c_str());
			}

			if (pstChannel->wsrMonitor.length() > RECEIVED_STRING_LENGTH)
				pstChannel->wsrMonitor.clear();

			pstChannel->wsrMonitor += wsrReceived + L"\r\n";

			if (pstChannel->wsrRemoteThread != L"TEMPORARY")
			{
				pstChannel->pTabbDlg->SendMessageW(pstChannel->uiWmEdValue, (WPARAM)wsrReceived.c_str());
				pstChannel->pTabbDlg->SendMessageW(pstChannel->uiWmProgress, (WPARAM)wsrReceived.c_str());
			}			
		}
		else
		{
			//+++ No messages sent to possible dismissed dialogs. They can't be delivered: exception or block of app. 
			pstChannel->wsrMonitor += L"Total bytes received: " + to_wstring(iBytesReceived) + L"\r\n";
			pstChannel->wsrMonitor += L"Total strings received: " + to_wstring(iTimes) + L"  Only last are shown.\r\n";
			pstChannel->wsrMonitor += L"Connection closed.\n";
			if (pstChannel->wsrRemoteThread != L"TEMPORARY")
			{			//???
				if (iResult == 0)
				{
					pstChannel->wsrMonitor += L"Connection closed by client: " + pstChannel->wsrRemoteThread + L"\r\n";
					pstHook->pAsiDlg->SendMessageW(RG_WM_PIC_LIGHT, INDIGO_LIGHT);
					return ERROR_CLIENT_SIDE;
				}//???

				if (iResult < 0)
				{
					pstChannel->wsrMonitor += L"Something wrong: " + pstChannel->wsrRemoteThread + L"\r\n";
					pstHook->pAsiDlg->SendMessageW(RG_WM_PIC_LIGHT, RED_LIGHT);
					return ERROR_COMM;
				}
			}
		}
	} while (iResult > 0 && bEnd == false);

	return NO_ERROR;
}

DWORD WINAPI T_I2cMaTx(LPVOID lpParam)
{
	theApp.ThrAffinity(12);
	Hook *pstHook = (Hook*)lpParam;
	CAsiDlg *pAsiDlg = pstHook->pAsiDlg;
	CTabFour *pTabFour = pstHook->pTabFour;
	CTabOne *pTabOne = pstHook->pTabOne;

	pstHook->SockManual = pTabOne->TieSockAddr(pstHook->stServerI2c.acIP, pstHook->stServerI2c.acPort, CLIENT_SIDE);

	pstHook->hT_I2cMaRx = CreateThread(NULL, 0, T_I2cMaRx, pstHook, 0, NULL);

	string srBnShut;
	pstHook->pTabOne->jbnShut.EnableWindow();	

	//+++ Default event attributes; manual-reset event; initial state nonsignaled; no name.	
	pTabFour->hE_RbAdc = CreateEvent(NULL, TRUE, FALSE, NULL);
	pTabFour->hE_RbPwm = CreateEvent(NULL, TRUE, FALSE, NULL);
	pTabFour->hE_Sli = CreateEvent(NULL, TRUE, FALSE, NULL);
	pTabFour->hE_I2cTest = CreateEvent(NULL, TRUE, FALSE, NULL);

	bool bCycle = true;	//+++ Keep WaitForMultipleObjects cycling till pAsiDlg->hE_...I2cMaTx is signalled.
	pTabFour->InputCtrl(true);
	HANDLE ahKernelObj[7] = { pTabFour->hE_RbAdc, pTabFour->hE_RbPwm, pTabFour->hE_Sli, pTabFour->hE_I2cTest, pAsiDlg->hE_RyExitI2cMaTx, pAsiDlg->hE_RyShutCommI2cMaTx, pAsiDlg->hE_LaptopDismissI2cMaTx };
	while (bCycle == true)
	{
		DWORD dwWaitResults = WaitForMultipleObjects(ARRAY_SIZE(ahKernelObj), ahKernelObj, FALSE, INFINITE);
		switch (dwWaitResults)
		{
		case WAIT_OBJECT_0 + 0:	//+++ Radiobuttons of TabFour for ADC.
			send(pstHook->SockManual, pTabFour->srRbAdc.c_str(), (int)pTabFour->srRbAdc.size(), 0);
			ResetEvent(pTabFour->hE_RbAdc);
			break;
		case WAIT_OBJECT_0 + 1:	//+++ Radiobuttons of TabFour for PWM.
			send(pstHook->SockManual, pTabFour->srRbPwm.c_str(), (int)pTabFour->srRbPwm.size(), 0);
			ResetEvent(pTabFour->hE_RbPwm);
			break;
		case WAIT_OBJECT_0 + 2:	//+++ Slider of TabFour for PWM.
			send(pstHook->SockManual, pTabFour->srSlid.c_str(), (int)pTabFour->srSlid.size(), 0);
			ResetEvent(pTabFour->hE_Sli);
			break;
		case WAIT_OBJECT_0 + 3:	//+++ Test I2C.	
			pstHook->hT_I2cAuTx = CreateThread(NULL, 0, T_I2cAuTx, pstHook, 0, NULL);
			ResetEvent(pTabFour->hE_I2cTest);
			break;
		case WAIT_OBJECT_0 + 4:	//+++ RyS's communication threads stop communication and RyS exits.
			srBnShut = to_string(I2C_RY_EXIT);
			send(pstHook->SockManual, srBnShut.c_str(), (int)srBnShut.size(), 0);
			ResetEvent(pAsiDlg->hE_RyExitI2cMaTx);
			bCycle = false;	//+++ Exit this thread.
			break;
		case WAIT_OBJECT_0 + 5:	//+++ RyS's communication threads stop communication, but RyS continues working.
			srBnShut = to_string(I2C_RY_SHUT_COMM);
			send(pstHook->SockManual, srBnShut.c_str(), (int)srBnShut.size(), 0);
			ResetEvent(pAsiDlg->hE_RyShutCommI2cMaTx);
			bCycle = false;	//+++ Exit this thread.
			break;
		case WAIT_OBJECT_0 + 6:	//+++ Laptop is dismissed, but RyS continues working.
			srBnShut = to_string(I2C_LAPTOP_DISMISS);
			send(pstHook->SockManual, srBnShut.c_str(), (int)srBnShut.size(), 0);
			ResetEvent(pAsiDlg->hE_LaptopDismissI2cMaTx);
			bCycle = false;	//+++ Exit this thread.
			break;
		}
	}

	shutdown(pstHook->SockManual, SD_SEND);	//+++ Cleanup. When Raspberry receives this, it will close the socket and T_I2cMaRx will receive 0 bytes, breaking off recv loop.

	return NO_ERROR;
}

DWORD WINAPI T_I2cMaRx(LPVOID lpParam)
{
	theApp.ThrAffinity(12);
	Hook *pstHook = (Hook*)lpParam;
	pstHook->astThreadExCo[TEC_I2CMARX].hThreadExCo = pstHook->hT_I2cMaRx;
	pstHook->astThreadExCo[TEC_I2CMARX].pAsiDlg = pstHook->pAsiDlg;
	CreateThread(NULL, 0, T_ThreadExCo, &pstHook->astThreadExCo[TEC_I2CMARX], 0, NULL);

	CTabFour *pTabFour = pstHook->pTabFour;
	CTabOne *pTabOne = pstHook->pTabOne;
	int iResult;
	string srReceived;
	char acReceived[BUFLEN] = "";

	do
	{
		iResult = recv(pstHook->SockManual, acReceived, BUFLEN, 0);	//+++ Never use string.c_str() : tricky sometimes works other times don't.
		if (iResult > 0)
		{
			srReceived = acReceived;
			int iReceived = atoi(srReceived.c_str());
			if (iReceived >= 0 && iReceived <= I2C_RY_MAX_PROGRESS)
				pTabFour->jpgsThr4.SetPos(iReceived);//???
		}
		else if (iResult == 0)
			pTabOne->SendMessageW(RG_WM_ED_SOC_T, (WPARAM)L"T_I2cMaRx connection closed\r\n");
		else
			return theApp.ErrWsaSock(L"recv() failed with error: " + to_wstring(WSAGetLastError()) + L"\r\n", false, pstHook->SockManual);
	} while (iResult > 0);
	
	closesocket(pstHook->SockManual);	//+++ Cleanup.

	return NO_ERROR;
}

DWORD WINAPI T_I2cAuTx(LPVOID lpParam)
{
	theApp.ThrAffinity(12);
	Hook *pstHook = (Hook*)lpParam;
	CAsiDlg *pAsiDlg = pstHook->pAsiDlg;
	CTabFour *pTabFour = pstHook->pTabFour;

	CTabOne *pTabOne = pstHook->pTabOne;
	pstHook->SockAutom = pTabOne->TieSockAddr(pstHook->stServerI2c.acIP, pstHook->stServerI2c.acPort, CLIENT_SIDE);
	pstHook->hT_I2cAuRx = CreateThread(NULL, 0, T_I2cAuRx, pstHook, 0, NULL);

	int iCount = 0;
	string srTestI2c;	//+++ Tests I2C, with feed back.
	bool bCycle = true;	//+++ Keep WaitForMultipleObjects cycling till pAsiDlg->hE_ShutI2cAuTx is signalled.
	LARGE_INTEGER liDueTime;
	liDueTime.QuadPart = -10 * 1000 * 100;

	HANDLE hPeriodicTmr = CreateWaitableTimer(NULL, FALSE, NULL);	//+++ Create an unnamed synchronization waitable timer.
	SetWaitableTimer(hPeriodicTmr, &liDueTime, 100, NULL, NULL, 0);	//+++ Timer is periodic.

	HANDLE ahKernelObj[2] = { hPeriodicTmr, pAsiDlg->hE_ShutI2cAuTx };
	while (bCycle == true)
	{
		DWORD dwWaitResults = WaitForMultipleObjects(ARRAY_SIZE(ahKernelObj), ahKernelObj, FALSE, INFINITE);
		switch (dwWaitResults)
		{
		case WAIT_OBJECT_0 + 0:	//+++ I2C test.
			srTestI2c = to_string(iCount);
			send(pstHook->SockAutom, srTestI2c.c_str(), (int)srTestI2c.size(), 0);
			iCount++;
			if (iCount == I2C_RY_MAX_PROGRESS + 1)
			{
				srTestI2c = to_string(iCount - 1);
				send(pstHook->SockAutom, srTestI2c.c_str(), (int)srTestI2c.size(), 0);
				bCycle = false;
			}
			break;
		case WAIT_OBJECT_0 + 1:	//+++ Shutting communication: exit from thread.			
			ResetEvent(pAsiDlg->hE_ShutI2cAuTx);
			bCycle = false;	//+++ Exit this thread.
			break;
		}
	}

	//+++ Cleanup.
	CloseHandle(hPeriodicTmr);
	shutdown(pstHook->SockAutom, SD_SEND);	//+++ When Raspberry receives this, it will close the socket and T_I2cAuRx will receive 0 bytes, breaking off recv loop.
	pTabFour->InputCtrl(true);

	return NO_ERROR;
}

DWORD WINAPI T_I2cAuRx(LPVOID lpParam)
{
	theApp.ThrAffinity(12);
	Hook *pstHook = (Hook*)lpParam;
	pstHook->astThreadExCo[TEC_I2CAURX].hThreadExCo = pstHook->hT_I2cAuRx;
	pstHook->astThreadExCo[TEC_I2CAURX].pAsiDlg = pstHook->pAsiDlg;
	CreateThread(NULL, 0, T_ThreadExCo, &pstHook->astThreadExCo[TEC_I2CAURX], 0, NULL);

	CTabFour *pTabFour = pstHook->pTabFour;
	CTabOne *pTabOne = pstHook->pTabOne;
	int iResult;
	string srReceived;
	char acReceived[BUFLEN] = "";

	do
	{
		iResult = recv(pstHook->SockAutom, acReceived, BUFLEN, 0);	//+++ Never use string.c_str() : tricky sometimes works other times don't.
		if (iResult > 0)
		{
			srReceived = acReceived;
			int iReceived = atoi(srReceived.c_str());
			if (iReceived >= 0 && iReceived <= I2C_RY_MAX_PROGRESS)
				pTabFour->jpgsThr4.SetPos(iReceived);
		}
		else if (iResult == 0)
			pTabOne->SendMessageW(RG_WM_ED_SOC_T, (WPARAM)L"T_I2cAuRx connection closed\r\n");
		else
			return theApp.ErrWsaSock(L"recv() failed with error: " + to_wstring(WSAGetLastError()) + L"\r\n", false, pstHook->SockAutom);
	} while (iResult > 0);

	//+++ Cleanup.
	closesocket(pstHook->SockAutom);
	pTabFour->jpgsThr4.SetPos(0);
	pTabFour->OnBnClickedRbThr4PwmF();//???

	return NO_ERROR;
}