/*
 * adc.h
 *
 *  Created on: 21 ott 2018
 *      Author: andre
 */

#ifndef ADC_H_
#define ADC_H_

#include <xdc/runtime/Types.h>
#include <ti/drivers/ADC.h>

#define Board_ADC3  CC1310_LAUNCHXL_ADC3    //+++  CC1310_LAUNCHXL_DIO26_ANALOG order of CC1310_LAUNCHXL_ADCName within adcCC26xxHWAttrs
#define Board_ADC4  CC1310_LAUNCHXL_ADC4    //+++  CC1310_LAUNCHXL_DIO27_ANALOG order of CC1310_LAUNCHXL_ADCName within adcCC26xxHWAttrs

#pragma DATA_ALIGN(aucADCTaskStack, 8)  /* Make sure we have nice 8-byte alignment on the stack to avoid wasting memory */
#define STACKSIZE 1024
static uint8_t aucADCTaskStack[STACKSIZE];

Void AdcTf(UArg arg0, UArg arg1);
void StartAdcTf(void);

#endif /* ADC_H_ */
