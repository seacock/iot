/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;

class Talker extends Thread {
    Socket conn = null;
    StringBuilder strBuild;
    
    public Talker(Socket conn, StringBuilder strBuild) {
        this.conn = conn;
        this.strBuild = strBuild;
    }

    @Override
    public void run() {
        OutputStream outToServer = null;
        try {
            outToServer = conn.getOutputStream();
        } catch (IOException ex) {
            Logger.getLogger(Talker.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        DataOutputStream out = new DataOutputStream(outToServer);
        try {
            out.writeUTF("Hello from " + conn.getLocalSocketAddress() + 
                    "\nThis is the talker thread of Java client connecting to GNU C++ ServerMix, hosted by Raspberry.\n" + 
                    "Another listener thread is waiting message from ServerMix. The socket gives timeout for 5 ms, so its timeout has been set to 80 ms.\n" +
                    "This WebApp is hosted by Raspberry and managed by its Tomcat9.\n" +  
                    "Range value: " + strBuild + "\nA preceding formatting of String to send with writeUTF\n" + 
                    "is necessary: str.substring .???Red!!!!!!!!!123???Orange!!!!!!456???Yellow!!!!!!789???Green!!!!!!!000Ciao\n");
        } catch (IOException ex) {
            Logger.getLogger(Talker.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

class Listener extends Thread {
    Socket conn = null;
    boolean listening = true;
    StringBuilder strBuild;

    public Listener(Socket conn, StringBuilder strBuild) {
        this.conn = conn;
        this.strBuild = strBuild;
    }

    @Override
    public void run() {
        BufferedReader reader;
        try {
            reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String srLine = "";//??????
            while (listening) {
                srLine = reader.readLine();
                if (srLine == null)///??????
                    return;// Connection lost
                
                System.out.println(srLine + "\n\n");
                strBuild.append(srLine);
                if (srLine.indexOf("EndOfTransmission", 0) != -1)
                    break;                
            }              
        } catch (SocketTimeoutException ex) {
            strBuild.append("TIMEOUT socket   ");
            strBuild.append(ex);
        } catch (IOException ex) {
            Logger.getLogger(Listener.class.getName()).log(Level.SEVERE, null, ex);
        }        
    }
}

/**
 *
 * @author Administrator
 */
public class Client_J {
    StringBuilder strBuild;
    
    public Client_J(StringBuilder strBuild) {
        this.strBuild = strBuild;
    }
    
    void Communicate()
    {
        String serverName = "sporadic.hopto.org";
        int port = 7000;
        try {
            System.out.println("Connecting to " + serverName + " on port " + port);
            try (Socket client = new Socket(serverName, port)) {     //??????          
                System.out.println("Just connected to " + client.getRemoteSocketAddress());
                client.setSoTimeout(/*80*/0);//???
                
                Thread talkThread = new Thread(new Talker(client, strBuild), "JavaClientSocketTalker");
                talkThread.start();
                try {
                    talkThread.join();
                } catch (InterruptedException ex) {
                    Logger.getLogger(Client_J.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                Thread listenThread = new Thread(new Listener(client, strBuild), "JavaClientSocketListener");
                listenThread.start();
                try {
                    listenThread.join();
                } catch (InterruptedException ex) {
                    Logger.getLogger(Client_J.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}